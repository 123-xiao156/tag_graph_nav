robot_msg

用于通用底盘的信息交互,定义了交互格式topic类型\service类型

20230227 姜翠环 第一版
20231008 窦强 添加FileTransfer.srv
20240219 陈涛 添加Relocalization.msg
20250628 fangyao 添加Database_one.srv
20251013 liuzhiwen 添加Detection.msg Detections.msg
20251211 liuzhiwen 添加UseSensors.srv
20251224 yuhaonan 添加PolygonWithHoles.msg PolygonWithHolesStamped.msg AssistanceMode.srv Marker.msgs中string task字段
20251224 yuhaonan 暂时去掉Marker.msgs中string task字段
20260107 liuzhiwen 修复误删除的UseSensors.srv
20250112 pangfenglin 修改CoverageArea.srv服务类型 版本0.0.11
20250112 pangfenglin 修改task.action，添加充电逻辑 版本0.0.12
20260224 pangfenglin 添加EdgeCleanPlanService.srv服务 版本0.0.13
20260312 pangfenglin Task.action中添加feedback漏扫字段 版本0.0.14
20260508 yuhaonan 添加Marker.msgs中string task字段 版本0.0.15
20260602 pangfenglin 修改CoverageArea服务，添加贴边路径生成 版本0.0.16
20260606 yuhaonan 增加数据库新调用格式，版本0.0.17
20260623 yuhaonan 修改新数据库接口，版本0.0.18
20260708 pangfenglin 修改CoverageArea服务，添加错误码，版本0.0.19