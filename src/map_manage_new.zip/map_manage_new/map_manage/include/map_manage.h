/*
'''
@Time    : 2023/04/18  11:45
@Author  : ZHANG KAI KAI
@Contact : 1936230913@qq.com
@Version : 0.3
@Language: c++
@Desc    : 地图管理模块
  */
#ifndef MAP_MANAGE_REFACTORED_H
#define MAP_MANAGE_REFACTORED_H

#include <ros/ros.h>
#include <ros/package.h>
#include <vector>
#include <set>
#include <chrono>
#include <fstream>
#include <time.h>
#include <dirent.h>
#include <exception>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <cv_bridge/cv_bridge.h>
#include <tf/transform_listener.h>
#include <tf/transform_datatypes.h>
#include <jsoncpp/json/json.h>
#include <glog/logging.h>
#include <cmath>
#include <atomic>
#include <Eigen/Core>
#include <std_msgs/Bool.h>

#include "robot_msgs/MapManage.h"
#include "robot_msgs/System.h"
#include "robot_msgs/Switch.h"
#include "robot_msgs/Database_data.h"
#include "map_service.h"
#include "slam_state_machine_msgs/MissionManagerActionAction.h"
#include <actionlib/client/simple_action_client.h>
#include <boost/thread/mutex.hpp>
#include <thread>
#include <mutex>
#include <yaml-cpp/yaml.h>
#include <unistd.h>
#include <sys/stat.h>
#include <ctime>

#define SUCCESS "success"
#define LOC_FILE_PATH "/home/iimt/.cfg/mapping/state_machine_localization/install_isolated/share/cartographer/launch"
#define LOC_FILE "lifelong.lua"

class MapManage
{
    struct MapData
    {
        std::string origin_point_x;
        std::string origin_point_y;
        std::string origin_point_yaw;
        std::string map_resolution;
    };

    enum ActionIndex
    {
        WAIT = 0,
        CHANGEMAP, // 切图
        BUILDMAP,  // 建图
        STOPMAP,   // 停止地图
        SAVEMAP,   // 保存地图
        INITPOSE   // 重定位
    };

public:
    explicit MapManage(ros::NodeHandle n);
    ~MapManage();
    void MainLoopOnce();

private:
    void thread_RequestAtion();
    void PublishMapStatus();
    void StartLocazation();
    void SendGoal(std::string cmd);

    void CanSaveMapCallback(const std_msgs::BoolConstPtr &msg);
    void InitialposeCallback(const geometry_msgs::PoseWithCovarianceStamped &msg);
    void ElevatorStatusCallback(const std_msgs::String::ConstPtr &msg);
    bool ServiceMapHander(robot_msgs::MapManage::Request &request, robot_msgs::MapManage::Response &response);
    bool ChangeMapServiceHandler(robot_msgs::Switch::Request &request, robot_msgs::Switch::Response &response);

    void doneCallback(const actionlib::SimpleClientGoalState &state,
                      const slam_state_machine_msgs::MissionManagerActionResultConstPtr &result);
    void activeCallback();
    void feedbackCallback(const slam_state_machine_msgs::MissionManagerActionFeedbackConstPtr &feedback);

    bool IsActionSuccess() const;
    bool ParseInitPoseRequest(const std::string &request_data, Eigen::Vector3f &pose);
    bool ParseChangeMapRequest(const std::string &request_data, std::string &map_name, Eigen::Vector3f &pose);
    bool StopLocalizationIfNeeded(const std::string &fail_code,
                                  const std::string &stop_success_log,
                                  const std::string &stop_fail_log);
    bool StartLocalizationAction(const std::string &map_name,
                                 const Eigen::Vector3f &pose,
                                 const std::string &fail_code,
                                 const std::string &success_log,
                                 const std::string &fail_log);
    bool ChangeMapViaMapServer(const std::string &map_name,
                            const Eigen::Vector3f &pose,
                            const std::string &fail_code,
                            const std::string &success_log,
                            const std::string &fail_log);
    bool ChangeToDefaultMapIfNeeded(const std::string &fail_code);

    void ReadYamlForMapName();
    bool ReadYamlMap(std::string map_name, MapData &res_mapdata);
    bool DeleteTableByMap(std::string map_name);
    bool CheckIfAnyMapExists();
    void GetFileNames(std::string path, std::vector<std::string> &filenames);
    void GetOnlyFileName(std::vector<std::string> &file_name, std::set<std::string> &file_name_OnlyS);
    std::string ImageToBase64(const std::string &image_path);
    bool Base64ToImage(const std::string &base64_str, const std::string &map_path);
    cv::Mat RotaMap(cv::Mat const &map);
    std::string GenerateMapInfo(nav_msgs::OccupancyGrid &map);
    void StrSplit(std::string str, const char split, std::vector<std::string> &rst);

    void SaveBothLocationMaps(const std::string &map_before, const std::string &map_after);
    void SaveLocationMap(const std::string &map_name, const std::string &save_dir, const std::string &suffix);
    void SaveMetadata(const std::string &save_dir,
                      const std::string &map_before,
                      const std::string &map_after,
                      bool before_ok,
                      bool after_ok);
    std::string GetCurrentTimestamp();
    void CreateDirectoryIfNotExists(const std::string &path);
    void CleanExpiredMaps(int days_to_keep = 15);

    geometry_msgs::PoseWithCovarianceStamped BuildInitialPoseFromSwitchRequest(const robot_msgs::Switch::Request &request) const;

private:
    ros::NodeHandle nh_;
    MapServer map_service_;
    actionlib::SimpleActionClient<slam_state_machine_msgs::MissionManagerActionAction> ac_client_;

    ros::Subscriber can_save_pbstream_subscriber_;
    ros::Subscriber initial_pose_sub_;
    ros::Subscriber elevator_status_sub_;

    ros::Publisher pub_fault_;
    ros::Publisher map_state_pub_;
    ros::Publisher curr_map_pub_;

    ros::ServiceServer map_manage_service_;
    ros::ServiceServer change_map_service_;
    ros::ServiceClient database_client_;

    std::string map_status_;  // 实时的状态
    std::string map_path_; // 存储地图数据的路径，死的
    std::string algorithm_;
    std::string yamlpath_;

    std::string curr_map_name_;
    std::string default_map_name_;
    std::string last_map_name_before_lift_;
    std::string request_data_;

    std::mutex mutex_action_;

    std::atomic<int> action_result_{-1};
    std::atomic<int> action_index_{ActionIndex::WAIT};
    std::atomic<bool> can_save_pbstream_{false};

    bool is_save_lift_map_{false};
};

#endif
