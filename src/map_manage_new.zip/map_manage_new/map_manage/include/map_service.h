/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME:   map_service.h
 * * @description: 地图服务头文件
 * **********************************************************************/
#ifndef MAP_SERVICE_H
#define MAP_SERVICE_H

#include <fstream>
#include <string>

#include <boost/filesystem.hpp>
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <nav_msgs/GetMap.h>
#include <nav_msgs/SetMap.h>
#include <robot_msgs/ElevatorPoint.h>
#include <robot_msgs/Switch.h>
#include <ros/ros.h>
#include <ros/timer.h>
#include <std_msgs/String.h>
#include <std_srvs/Empty.h>
#include <tf2/LinearMath/Quaternion.h>
#include <yaml-cpp/yaml.h>

#ifdef HAVE_YAMLCPP_GT_0_5_0
template <typename T>
void operator>>(const YAML::Node &node, T &i)
{
    i = node.as<T>();
}
#endif

enum MapMode
{
    TRINARY,
    SCALE,
    RAW
};

enum class MapUpdateTarget
{
    NavigationOnly,
    LocalizationOnly,
    Both
};

enum class MapDataType
{
    Navigation,
    Localization
};

namespace map_service_internal
{
    /**********************************************************************
     * * @brief:       从图片文件加载地图数据到 ROS 地图响应结构
     * * @input:       resp: 地图响应对象，输出地图数据
     * *               fname: 地图图片文件路径
     * *               res: 地图分辨率（米/像素）
     * *               negate: 是否反转黑白占用语义
     * *               occ_th: 占用阈值
     * *               free_th: 空闲阈值
     * *               origin: 地图原点 [x, y, yaw]
     * *               mode: 地图加载模式
     * * @output:      resp: 填充后的地图消息
     * * @return:      void
     * **********************************************************************/
    void LoadMapFromFile(nav_msgs::GetMap::Response *resp,
                         const char *fname,
                         double res,
                         bool negate,
                         double occ_th,
                         double free_th,
                         double *origin,
                         MapMode mode = TRINARY);
}

class MapServer
{
public:
    explicit MapServer(ros::NodeHandle n);
    ~MapServer();

    bool IsInitialized() const;
    void RefreshDefaultMapName();
    std::string GetDefaultMapName() const;

    bool GetCurrentMap(nav_msgs::OccupancyGrid &map, MapDataType type) const;

    bool ChangeMap(const std::string &map_name,
                   const geometry_msgs::PoseWithCovarianceStamped &initial_pose,
                   const std::string &context);
    bool SetInitialPoseOnly(const geometry_msgs::PoseWithCovarianceStamped &initial_pose,
                            const std::string &context);
    bool ReloadNavigationMapOnly(const std::string &map_name,
                                 bool clear_costmaps,
                                 const std::string &context);
    bool UpdateMapsByTarget(const std::string &map_name,
                            MapUpdateTarget target,
                            const std::string &context,
                            robot_msgs::Switch::Response *response = nullptr);

private:
    /**********************************************************************
     * * @brief:       定时初始化默认地图、禁行区与初始位姿
     * * @input:       定时器事件参数
     * * @output:
     * * @return:      void
     * **********************************************************************/
    void CallBackOnceClearMap(const ros::TimerEvent &);
    void PublishMapServiceFault(const std::string &fault_code);


    /**********************************************************************
     * * @brief:       读取默认地图配置
     * **********************************************************************/
    void ReadYaml();

    /**********************************************************************
     * * @brief:       处理禁行区更新请求
     * **********************************************************************/
    void ProhibitionCB(const std_msgs::String::ConstPtr &msg);

    /**********************************************************************
     * * @brief:       复制禁行区配置文件到统一目标路径
     * **********************************************************************/
    bool CopyFileData2File(const std::string &file_name);

    /**********************************************************************
     * * @brief:       根据解析后的参数值加载地图
     * **********************************************************************/
    bool loadMapFromValues(const std::string &map_file_name,
                           double resolution,
                           int negate,
                           double occ_th,
                           double free_th,
                           double origin[3],
                           MapMode mode,
                           nav_msgs::GetMap::Response &target_resp);
    bool loadMapFromYaml(const std::string &path_to_yaml, nav_msgs::GetMap::Response &target_resp);
    /**********************************************************************
     * * @brief: 刷新默认地图对应的禁行区参数并清空代价地图，成功返回true
     * **********************************************************************/
    bool ReloadProhibitionAreasAndClearCostmaps(const std::string &map_name, const std::string &context);
    bool ClearCostmaps(const std::string &context);
    /**********************************************************************
     * * @brief: 调用服务切换地图（with_map控制是否切换）并设置AMCL初始位姿，成功返回true
     * **********************************************************************/
    bool ApplyAmclSetMap(const geometry_msgs::PoseWithCovarianceStamped &initial_pose,
                         bool with_map,
                         const std::string &context);
    /**********************************************************************
     * * @brief: 调用服务得到返航点，成功返回true
     * **********************************************************************/
    bool QueryBackPoint(robot_msgs::ElevatorPoint &srv, const std::string &context);

private:
    ros::NodeHandle nh_;
    ros::NodeHandle private_nh_;

    ros::Publisher map_pub_;
    ros::Publisher metadata_pub_;
    ros::Publisher map_amcl_pub_;
    ros::Publisher metadata_amcl_pub_;
    ros::Publisher pub_mapservice_failed_;

    ros::Subscriber sub_save_prohibition_;

    ros::ServiceClient client_originpoint_;

    ros::ServiceClient client_set_map_;
    ros::ServiceClient clear_costmap_client_;

    ros::Timer timer_;



    std::string default_map_;
    std::string map_path_;              // 地图文件夹路径：这个是存放不同地图的文件夹路径
    std::string prohibition_file_path_; // 禁行区文件夹路径：这个是最终被复制到导航系统使用的禁行区配置文件路径
    std::string prohibition_path_;      // 禁行区文件夹路径：这个是存放不同地图对应的禁行区配置文件的文件夹路径
    std::string nav_yaml_path_;         // 主要用来更新default_map_
    std::string algorithm_loc_;
    std::string nav_node_ = "";

    bool initialization_complete_{false};

    nav_msgs::GetMap::Response navigation_map_resp_;
    nav_msgs::GetMap::Response localization_map_resp_;
};

#endif
