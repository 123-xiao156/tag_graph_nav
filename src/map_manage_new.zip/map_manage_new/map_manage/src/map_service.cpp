/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME:   map_service.cpp
 * * @description: 地图服务实现
 * **********************************************************************/

#include "map_service.h"

#include <SDL/SDL_image.h>
#include <glog/logging.h>

#include <cmath>
#include <cstring>
#include <stdexcept>

namespace map_service_internal
{
    constexpr int MapIdx(int sx, int i, int j)
    {
        return sx * j + i;
    }
    // 从图片文件加载地图数据到 ROS 地图响应结构 PNG/JPG->ROS标准类型
    void LoadMapFromFile(nav_msgs::GetMap::Response *resp,
                         const char *fname,
                         double res,
                         bool negate,
                         double occ_th,
                         double free_th,
                         double *origin,
                         MapMode mode)
    {
        if (fname == nullptr || resp == nullptr || origin == nullptr)
        {
            throw std::runtime_error("Failed to load fname,or resp is nullptr or origin is nullptr");
        }

        SDL_Surface *img = IMG_Load(fname);
        if (img == nullptr)
        {
            std::string errmsg = std::string("failed to open image file \"") +
                                 std::string(fname) + std::string("\": ") + IMG_GetError();
            throw std::runtime_error(errmsg);
        }

        resp->map.info.width = img->w;
        resp->map.info.height = img->h;
        resp->map.info.resolution = res;
        resp->map.info.origin.position.x = origin[0];
        resp->map.info.origin.position.y = origin[1];
        resp->map.info.origin.position.z = 0.0;

        tf2::Quaternion q;
        q.setRPY(0, 0, origin[2]);
        q.normalize();
        resp->map.info.origin.orientation.x = q.x();
        resp->map.info.origin.orientation.y = q.y();
        resp->map.info.origin.orientation.z = q.z();
        resp->map.info.origin.orientation.w = q.w();

        resp->map.data.resize(resp->map.info.width * resp->map.info.height);

        const int rowstride = img->pitch; // 每行的字节数
        const int n_channels = img->format->BytesPerPixel; // 通道数
        const int avg_channels = (mode == TRINARY || !img->format->Amask) ? n_channels : (n_channels - 1);

        unsigned char *pixels = static_cast<unsigned char *>(img->pixels);
        for (unsigned int j = 0; j < resp->map.info.height; ++j)
        {
            for (unsigned int i = 0; i < resp->map.info.width; ++i)
            {
                unsigned char *p = pixels + j * rowstride + i * n_channels;
                int color_sum = 0;
                for (int k = 0; k < avg_channels; ++k)
                {
                    color_sum += *(p + k);
                }
                double color_avg = color_sum / static_cast<double>(avg_channels);
                int alpha = (n_channels == 1) ? 1 : *(p + n_channels - 1);

                if (negate)
                {
                    color_avg = 255 - color_avg;
                }

                if (mode == RAW)
                {
                    unsigned char value = static_cast<unsigned char>(color_avg);
                    resp->map.data[MapIdx(resp->map.info.width, i, resp->map.info.height - j - 1)] = value;
                    continue;
                }

                double occ = (255 - color_avg) / 255.0;
                int8_t value = 0;
                if (occ > occ_th)
                {
                    value = 100;
                }
                else if (occ < free_th)
                {
                    value = 0;
                }
                else if (mode == TRINARY || alpha < 1.0)
                {
                    value = -1;
                }
                else
                {
                    double ratio = (occ - free_th) / (occ_th - free_th);
                    value = static_cast<int8_t>(1 + 98 * ratio);
                }
                resp->map.data[MapIdx(resp->map.info.width, i, resp->map.info.height - j - 1)] = value;
            }
        }

        SDL_FreeSurface(img);
    }
} // namespace map_service_internal

MapServer::MapServer(ros::NodeHandle n) : private_nh_(n)
{
    private_nh_.param("map_file_path", map_path_, std::string("/home/iimt/.cfg/controlmaster/controlmaster/map/"));
    private_nh_.param("prohibition_path", prohibition_path_, std::string("/home/iimt/.cfg/controlmaster/controlmaster/map/prohibition_areas/"));
    private_nh_.param("prohibition_file_path", prohibition_file_path_, std::string("/home/iimt/.cfg/controlmaster/controlmaster/param/yaml/new_nav/general_chassis/prohibition_areas.yaml"));
    private_nh_.param("default_map", default_map_, std::string("cc_1D_1F_carea"));
    private_nh_.param("yamlpath", nav_yaml_path_, std::string("/home/iimt/.cfg/controlmaster/controlmaster/param/yaml/"));
    private_nh_.param("algorithm_loc", algorithm_loc_, std::string("amcl"));
    int nav_version = 1;
    private_nh_.param("nav_version", nav_version, 1);
    nav_node_ = (nav_version == 2) ? "/task_base" : "/move_base";

    client_set_map_ = nh_.serviceClient<nav_msgs::SetMap>("/set_map");
    client_originpoint_ = nh_.serviceClient<robot_msgs::ElevatorPoint>("/map_point");

    metadata_pub_ = nh_.advertise<nav_msgs::MapMetaData>("map_metadata", 1, true);
    map_pub_ = nh_.advertise<nav_msgs::OccupancyGrid>("map", 1, true);
    metadata_amcl_pub_ = nh_.advertise<nav_msgs::MapMetaData>("amcl_map_metadata", 1, true);
    map_amcl_pub_ = nh_.advertise<nav_msgs::OccupancyGrid>("amcl_map", 1, true);
    pub_mapservice_failed_ = nh_.advertise<std_msgs::String>("/ugv_fault", 5);

    sub_save_prohibition_ = nh_.subscribe("/save_prohibition_topic", 1, &MapServer::ProhibitionCB, this);

    UpdateMapsByTarget(default_map_, MapUpdateTarget::Both, "constructor", nullptr);
    timer_ = nh_.createTimer(ros::Duration(1.0), &MapServer::CallBackOnceClearMap, this);
    LOG(ERROR) << "是否初始化完成：" << initialization_complete_;
}

MapServer::~MapServer() = default;

// 开机只执行一次，发布默认地图、禁行区和初始位姿，确保导航系统正常启动
void MapServer::CallBackOnceClearMap(const ros::TimerEvent &) // 这几步的顺序没有要求吗 ？？？
{
    static bool clear_flg = false;
    static int clear_cnt = 0;
    if (clear_flg)
    {
        return;
    }

    ++clear_cnt;
    if (clear_cnt < 20)
    {
        return;
    }

    ReadYaml();
    if (!UpdateMapsByTarget(default_map_, MapUpdateTarget::Both, "startup", nullptr))
    {
        LOG(ERROR) << "发布导航和定位地图话题失败";
        return;
    }

    robot_msgs::ElevatorPoint get_back;
    get_back.request.request_mapname = default_map_;
    get_back.request.point_type = "back";

    geometry_msgs::PoseWithCovarianceStamped msg_poseinit;
    msg_poseinit.header.frame_id = "map";
    msg_poseinit.header.stamp = ros::Time::now();
    msg_poseinit.pose.pose.position.z = 0.0;

    if (QueryBackPoint(get_back, "startup"))
    {
        LOG(INFO) << "开机时订阅到back点";
        msg_poseinit.pose.pose.position.x = std::stod(get_back.response.orign_point.X);
        msg_poseinit.pose.pose.position.y = std::stod(get_back.response.orign_point.Y);
        double yaw = std::stod(get_back.response.orign_point.YAW);
        if (yaw > M_PI)
        {
            yaw -= M_PI * 2.0;
        }
        else if (yaw < -M_PI)
        {
            yaw += M_PI * 2.0;
        }
        tf2::Quaternion q;
        q.setRPY(0, 0, yaw);
        q.normalize();
        msg_poseinit.pose.pose.orientation.x = q.x();
        msg_poseinit.pose.pose.orientation.y = q.y();
        msg_poseinit.pose.pose.orientation.z = q.z();
        msg_poseinit.pose.pose.orientation.w = q.w();
    }
    else
    {
        LOG(INFO) << "开机时未订阅到back点";
        msg_poseinit.pose.pose.position.x = 0.0;
        msg_poseinit.pose.pose.position.y = 0.0;
        msg_poseinit.pose.pose.orientation.x = 0.0;
        msg_poseinit.pose.pose.orientation.y = 0.0;
        msg_poseinit.pose.pose.orientation.z = 0.0;
        msg_poseinit.pose.pose.orientation.w = 1.0;
    }

    if (!ApplyAmclSetMap(msg_poseinit, true, "startup"))
    {
        LOG(ERROR) << "amcl地图赋值失败";
        return;
    }
    if (!ReloadProhibitionAreasAndClearCostmaps(default_map_, "startup")){
      LOG(ERROR) << "禁止层或者clearcostmap失败";
      return;
    }
    clear_flg = true;
    initialization_complete_ = true;
    timer_.stop();
}

void MapServer::PublishMapServiceFault(const std::string &fault_code)
{
    std_msgs::String msg;
    msg.data = fault_code.empty() ? "" : ("mapservice_failed:" + fault_code);
    pub_mapservice_failed_.publish(msg);
}

bool MapServer::IsInitialized() const
{
    return initialization_complete_;
}

void MapServer::RefreshDefaultMapName()
{
    ReadYaml();
}

std::string MapServer::GetDefaultMapName() const
{
    return default_map_;
}

bool MapServer::GetCurrentMap(nav_msgs::OccupancyGrid &map, MapDataType type) const
{
    const nav_msgs::GetMap::Response &resp = (type == MapDataType::Navigation) ? navigation_map_resp_ : localization_map_resp_;
    if (resp.map.info.width == 0 || resp.map.info.height == 0)
    {
        return false;
    }
    map = resp.map;
    return true;
}

bool MapServer::ChangeMap(const std::string &map_name,
                          const geometry_msgs::PoseWithCovarianceStamped &initial_pose,
                          const std::string &context)
{
    if (!initialization_complete_)
    {
        LOG(ERROR) << context << " map service not initialized";
        return false;
    }
    if (map_name.empty())
    {
        return SetInitialPoseOnly(initial_pose, context + "_pose_only");
    }
    if (!UpdateMapsByTarget(map_name, MapUpdateTarget::Both, context, nullptr))
    {
        return false;
    }
    LOG(INFO) << "两张地图话题发布成功";
    if (!ReloadProhibitionAreasAndClearCostmaps(map_name, context))
    {
        return false;
    }
    LOG(INFO) << "禁止层发布成功";
    if (!ApplyAmclSetMap(initial_pose, true, context))
    {
        return false;
    }
    LOG(INFO) << "定位重置成功";
    return true;
}

bool MapServer::SetInitialPoseOnly(const geometry_msgs::PoseWithCovarianceStamped &initial_pose, const std::string &context)
{
    if (!initialization_complete_) 
    {
        LOG(ERROR) << context << " map service not initialized";
        return false;
    }
    return ApplyAmclSetMap(initial_pose, false, context);
}
// 只更新导航地图，适用于保存完编辑地图后刷新导航地图的场景，成功返回true
bool MapServer::ReloadNavigationMapOnly(const std::string &map_name, bool clear_costmaps, const std::string &context)
{
    if (!initialization_complete_)
    {
        LOG(ERROR) << context << " map service not initialized";
        return false;
    }
    if (clear_costmaps)
    {
        return ClearCostmaps(context) && UpdateMapsByTarget(map_name, MapUpdateTarget::NavigationOnly, context, nullptr);
    }
    return UpdateMapsByTarget(map_name, MapUpdateTarget::NavigationOnly, context, nullptr);
}

void MapServer::ReadYaml()
{
    try
    {
        YAML::Node config = YAML::LoadFile(nav_yaml_path_);
        if (config["default_map"])
        {
            default_map_ = config["default_map"].as<std::string>();
        }
    }
    catch (const YAML::Exception &e)
    {
        LOG(ERROR) << "YAML Error: " << e.what();
    }
}

// 禁行区刷新回调，更新默认地图对应的禁行区参数
void MapServer::ProhibitionCB(const std_msgs::String::ConstPtr &msg)
{
    ReadYaml();
    if (default_map_ == msg->data)
    {
        ReloadProhibitionAreasAndClearCostmaps(msg->data, "prohibition_update");
        if (navigation_map_resp_.map.info.width > 0 && navigation_map_resp_.map.info.height > 0)
        {
            map_pub_.publish(navigation_map_resp_.map);
            metadata_pub_.publish(navigation_map_resp_.map.info);
        }
    }
    else
    {
        LOG(INFO) << "更新了禁止层,但不是默认地图";
    }
}
// 将指定禁行区文件复制到统一配置文件位置
bool MapServer::CopyFileData2File(const std::string &file_name)
{
    std::ifstream sourceFile(file_name);
    std::ofstream destinationFile(prohibition_file_path_);
    if (sourceFile && destinationFile)
    {
        destinationFile << sourceFile.rdbuf();
        return true;
    }
    else
    {
        LOG(ERROR) << "copy prohibition file failed: " << file_name << " -> " << prohibition_file_path_;
    }
    sourceFile.close();
    destinationFile.close();
    return false;
}

// 根据解析后的地图参数加载地图并刷新缓存消息
bool MapServer::loadMapFromValues(const std::string &map_file_name,
                                  double resolution,
                                  int negate,
                                  double occ_th,
                                  double free_th,
                                  double origin[3],
                                  MapMode mode,
                                  nav_msgs::GetMap::Response &target_resp)
{
    try
    {
        map_service_internal::LoadMapFromFile(&target_resp,
                                              map_file_name.c_str(),
                                              resolution,
                                              negate,
                                              occ_th,
                                              free_th,
                                              origin,
                                              mode);
    }
    catch (std::runtime_error &e)
    {
        LOG(ERROR) << "load map from values failed: " << e.what();
        return false;
    }

    ros::Time::waitForValid();
    target_resp.map.info.map_load_time = ros::Time::now();
    target_resp.map.header.frame_id = "map";
    target_resp.map.header.stamp = ros::Time::now();
    return true;
}

bool MapServer::loadMapFromYaml(const std::string &path_to_yaml, nav_msgs::GetMap::Response &target_resp)
{
    std::string mapfname;
    MapMode mode;
    double res;
    int negate;
    double occ_th;
    double free_th;
    double origin[3];
    std::ifstream fin(path_to_yaml.c_str());
    if (fin.fail())
    {
        LOG(ERROR) << "open yaml failed: " << path_to_yaml;
        return false;
    }
#ifdef HAVE_YAMLCPP_GT_0_5_0
    YAML::Node doc = YAML::Load(fin);
#else
    YAML::Parser parser(fin);
    YAML::Node doc;
    parser.GetNextDocument(doc);
#endif
    try
    {
        doc["resolution"] >> res;
        doc["negate"] >> negate;
        doc["occupied_thresh"] >> occ_th;
        doc["free_thresh"] >> free_th;
    }
    catch (YAML::InvalidScalar &)
    {
        LOG(ERROR) << "yaml scalar invalid: " << path_to_yaml;
        return false;
    }
    try
    {
        std::string modeS;
        doc["mode"] >> modeS;
        if (modeS == "trinary")
            mode = TRINARY;
        else if (modeS == "scale")
            mode = SCALE;
        else if (modeS == "raw")
            mode = RAW;
        else
        {
            LOG(ERROR) << "yaml mode invalid: " << path_to_yaml;
            return false;
        }
    }
    catch (YAML::Exception &)
    {
        mode = TRINARY;
    }
    try
    {
        doc["origin"][0] >> origin[0];
        doc["origin"][1] >> origin[1];
        doc["origin"][2] >> origin[2];
    }
    catch (YAML::InvalidScalar &)
    {
        LOG(ERROR) << "yaml origin invalid: " << path_to_yaml;
        return false;
    }
    try
    {
        doc["image"] >> mapfname;
        if (mapfname.empty())
        {
            LOG(ERROR) << "yaml image empty: " << path_to_yaml;
            return false;
        }
        boost::filesystem::path mapfpath(mapfname);
        if (!mapfpath.is_absolute())
        {
            boost::filesystem::path dir(path_to_yaml);
            dir = dir.parent_path();
            mapfpath = dir / mapfpath;
            mapfname = mapfpath.string();
        }
    }
    catch (YAML::InvalidScalar &)
    {
        LOG(ERROR) << "yaml image invalid: " << path_to_yaml;
        return false;
    }
    return loadMapFromValues(mapfname, res, negate, occ_th, free_th, origin, mode, target_resp);
}

bool MapServer::ReloadProhibitionAreasAndClearCostmaps(const std::string &map_name, const std::string &context)
{
    nh_.setParam(nav_node_ + "/global_costmap/static_layer/prohibition_areas", "");
    nh_.setParam(nav_node_ + "/local_costmap/static_layer/prohibition_areas", "");
    nh_.setParam(nav_node_ + "/only_static_costmap/static_layer/prohibition_areas", "");

    const std::string prohibition_from_path = prohibition_path_ + map_name + ".yaml";
    if (!CopyFileData2File(prohibition_from_path))
    {
        LOG(ERROR) << context << " copy prohibition file failed: " << prohibition_from_path;
    }

    const std::string global_ns = nav_node_ + "/global_costmap/static_layer/prohibition_areas";
    const std::string local_ns = nav_node_ + "/local_costmap/static_layer/prohibition_areas";
    const std::string only_static_ns = nav_node_ + "/only_static_costmap/static_layer/prohibition_areas";

    const int result1 = system(("rosparam load " + prohibition_file_path_ + " " + global_ns).c_str());
    const int result2 = system(("rosparam load " + prohibition_file_path_ + " " + local_ns).c_str());
    const int result3 = system(("rosparam load " + prohibition_file_path_ + " " + only_static_ns).c_str());

    if (result1 == 0 && result2 == 0 && result3 == 0)
    {
        LOG(INFO) << context << " reload prohibition areas success";
    }
    else
    {
        LOG(ERROR) << context << " reload prohibition areas failed";
    }

    return ClearCostmaps(context);
}

bool MapServer::ClearCostmaps(const std::string &context)
{
    clear_costmap_client_ = nh_.serviceClient<std_srvs::Empty>(nav_node_ + "/clear_costmaps");
    if (!clear_costmap_client_.waitForExistence(ros::Duration(10)))
    {
        LOG(ERROR) << context << " clear_costmaps service not available";
        return false;
    }

    std_srvs::Empty srv;
    if (!clear_costmap_client_.call(srv))
    {
        LOG(ERROR) << context << " clear_costmaps call failed";
        return false;
    }

    LOG(INFO) << context << " clear_costmaps success";
    return true;
}

bool MapServer::ApplyAmclSetMap(const geometry_msgs::PoseWithCovarianceStamped &initial_pose,
                                bool with_map,
                                const std::string &context)
{
    if (algorithm_loc_ != "amcl")
    {
        return true;
    }

    nav_msgs::SetMap srv_set_map;
    if (with_map)
    {
        if (localization_map_resp_.map.info.width == 0 || localization_map_resp_.map.info.height == 0)
        {
            LOG(ERROR) << context << " localization map cache is empty";
            return false;
        }
        srv_set_map.request.map = localization_map_resp_.map;
    }
    srv_set_map.request.initial_pose = initial_pose;

    if (!client_set_map_.waitForExistence(ros::Duration(10)))
    {
        LOG(ERROR) << context << " set_map service not available";
        return false;
    }
    if (!client_set_map_.call(srv_set_map))
    {
        LOG(ERROR) << context << " set_map call failed";
        return false;
    }
    if (!srv_set_map.response.success)
    {
        LOG(ERROR) << context << " set_map response failed";
        return false;
    }

    LOG(INFO) << context << " set_map success";
    return true;
}
// 调用服务得到返航点，成功返回true
bool MapServer::QueryBackPoint(robot_msgs::ElevatorPoint &srv, const std::string &context)
{
    if (!client_originpoint_.waitForExistence(ros::Duration(10)))
    {
        LOG(ERROR) << context << " map_point service not available";
        return false;
    }
    if (!client_originpoint_.call(srv))
    {
        LOG(ERROR) << context << " map_point call failed";
        return false;
    }
    if (srv.response.response_state != "ok")
    {
        LOG(ERROR) << context << " map_point response_state=" << srv.response.response_state;
        return false;
    }
    return true;
}

bool MapServer::UpdateMapsByTarget(const std::string &map_name,
                                   MapUpdateTarget target,
                                   const std::string &context,
                                   robot_msgs::Switch::Response *response)
{
    bool ok = true;
    const std::string path = map_path_ + map_name + "_";

    auto publish_navigation = [&]() -> bool
    {
        nav_msgs::GetMap::Response loaded_resp;
        const std::string nav_yaml = path + "nav.yaml";
        if (!loadMapFromYaml(nav_yaml, loaded_resp))
        {
            LOG(ERROR) << context << " load navigation map failed: " << nav_yaml;
            PublishMapServiceFault("B0484");
            if (response != nullptr)
            {
                response->result = response->RESULT_UNDEFINED_FAILURE;
            }
            return false;
        }

        navigation_map_resp_ = loaded_resp;
        metadata_pub_.publish(navigation_map_resp_.map.info);
        map_pub_.publish(navigation_map_resp_.map);
        if (response != nullptr)
        {
            response->map = navigation_map_resp_.map;
            response->result = response->RESULT_SUCCESS;
        }
        PublishMapServiceFault("");
        return true;
    };

    auto publish_localization = [&]() -> bool
    {
        nav_msgs::GetMap::Response loaded_resp;
        const std::string loc_yaml = path + "loc.yaml";
        if (!loadMapFromYaml(loc_yaml, loaded_resp))
        {
            LOG(ERROR) << context << " load localization map failed: " << loc_yaml;
            PublishMapServiceFault("B0484");
            if (response != nullptr && target == MapUpdateTarget::LocalizationOnly)
            {
                response->result = response->RESULT_UNDEFINED_FAILURE;
            }
            return false;
        }

        localization_map_resp_ = loaded_resp;
        metadata_amcl_pub_.publish(localization_map_resp_.map.info);
        map_amcl_pub_.publish(localization_map_resp_.map);
        if (response != nullptr && target == MapUpdateTarget::LocalizationOnly)
        {
            response->map = localization_map_resp_.map;
            response->result = response->RESULT_SUCCESS;
        }
        PublishMapServiceFault("");
        return true;
    };

    switch (target)
    {
    case MapUpdateTarget::NavigationOnly:
        ok = publish_navigation();
        break;
    case MapUpdateTarget::LocalizationOnly:
        ok = publish_localization();
        break;
    case MapUpdateTarget::Both:
        ok = publish_navigation();
        ok = publish_localization() && ok;
        break;
    default:
        ok = false;
        LOG(ERROR) << context << " update target invalid";
        break;
    }

    return ok;
}