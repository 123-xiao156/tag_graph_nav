﻿/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	map_manage.cpp
 * * @description:  地图管理节点
 * * @version:  	0.0.14
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司 ZHANG KAI KAI 1936230913@qq.com
 * * @date:  	    2025-11-05
 * **********************************************************************/

#include "map_manage.h"
#include <glog/logging.h>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <sys/stat.h>
#include <unistd.h>
#include <tf/transform_datatypes.h>

#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <array>
#include <cerrno>
#include <cstring>
#include <sstream>

namespace
{
    constexpr std::array<const char, 64> kBase64Chars = {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f',
        'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
        'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'};

    std::string Base64Encode(const std::vector<unsigned char> &input)
    {
        std::string output;
        output.reserve(((input.size() + 2) / 3) * 4);

        int val = 0;
        int valb = -6;
        for (unsigned char c : input)
        {
            val = (val << 8) + c;
            valb += 8;
            while (valb >= 0)
            {
                output.push_back(kBase64Chars[(val >> valb) & 0x3F]);
                valb -= 6;
            }
        }
        if (valb > -6)
        {
            output.push_back(kBase64Chars[((val << 8) >> (valb + 8)) & 0x3F]);
        }
        while (output.size() % 4 != 0)
        {
            output.push_back('=');
        }
        return output;
    }

    std::vector<unsigned char> Base64Decode(const std::string &input)
    {
        std::vector<int> table(256, -1);
        for (int i = 0; i < 64; ++i)
        {
            table[static_cast<unsigned char>(kBase64Chars[i])] = i;
        }

        std::vector<unsigned char> output;
        int val = 0;
        int valb = -8;
        for (unsigned char c : input)
        {
            if (table[c] == -1)
            {
                if (c == '=')
                {
                    break;
                }
                continue;
            }
            val = (val << 6) + table[c];
            valb += 6;
            if (valb >= 0)
            {
                output.push_back(static_cast<unsigned char>((val >> valb) & 0xFF));
                valb -= 8;
            }
        }
        return output;
    }

    bool RemoveFileIfExists(const std::string &path)
    {
        if (::unlink(path.c_str()) == 0)
        {
            return true;
        }
        return errno == ENOENT;
    }
} // namespace

MapManage::MapManage(ros::NodeHandle n) : nh_(n), map_service_(n), ac_client_("slam_mission_manager_action", true)
{
    std::string curr_map;
    nh_.param("map_path", map_path_, std::string("/home/iimt/.cfg/controlmaster/controlmaster/map/"));
    nh_.param("algorithm_loc", algorithm_, std::string("amcl"));
    nh_.param("yamlpath", yamlpath_, std::string("/home/iimt/.cfg/controlmaster/controlmaster/param/yaml/"));
    nh_.param("default_map", curr_map, std::string("cc_1D_1F_carea"));
    nh_.param("is_save_lift_map", is_save_lift_map_, false);
    default_map_name_ = curr_map;
    curr_map_name_ = curr_map;
    last_map_name_before_lift_.clear();

    map_state_pub_ = nh_.advertise<std_msgs::String>("/map_status", 1, true);
    curr_map_pub_ = nh_.advertise<std_msgs::String>("/current_map", 1, true);
    pub_fault_ = nh_.advertise<std_msgs::String>("ugv_fault", 10);
    map_manage_service_ = nh_.advertiseService("/srv_map", &MapManage::ServiceMapHander, this);
    change_map_service_ = nh_.advertiseService("/change_map", &MapManage::ChangeMapServiceHandler, this); 
    
    // 订阅电梯状态
    elevator_status_sub_ = nh_.subscribe<std_msgs::String>("/elevator_status", 10, &MapManage::ElevatorStatusCallback, this); 
    can_save_pbstream_subscriber_ = nh_.subscribe<std_msgs::Bool>("/can_save_pbstream", 1, &MapManage::CanSaveMapCallback, this); // 谁发 ？？？
    initial_pose_sub_ = nh_.subscribe("/initialpose", 10, &MapManage::InitialposeCallback, this);

    database_client_ = nh_.serviceClient<robot_msgs::Database_data>("/database_operate"); // 创建一个客户端，连接名为/database_operate
    LOG(INFO) << " 等待slam_mission_manager_action  action server 启动...,配置文件的算法是：" + algorithm_;
    if (algorithm_ == "carto")
    {
        ac_client_.waitForServer();
        StartLocazation();
    }
    LOG(INFO) << "等待slam_mission_manager_action  action server 启动成功";
}
MapManage::~MapManage()
{
}
/**********************************************************************
 * * @brief:  是否可以保存地图
 * * @input:
 * * @output:
 * * @return:  void：无返回值。
 * **********************************************************************/
void MapManage::CanSaveMapCallback(const std_msgs::BoolConstPtr &msg) 
{
    can_save_pbstream_ = msg->data; 
}
/**********************************************************************
 * * @brief:  获取carto算法条件下rviz中点击2D pose estimate发出来的位置信息
 * * @input:  msg: 包含初始位姿和协方差信息的ROS消息
 * * @output:
 * * @return:  void：无返回值。
 * **********************************************************************/
void MapManage::InitialposeCallback(const geometry_msgs::PoseWithCovarianceStamped &msg)
{
    if (algorithm_ == "carto")
    {
        const double yaw = tf::getYaw(msg.pose.pose.orientation);
        // 如果当前正在定位，先停止定位，再返回true；如果当前没有在定位，直接返回true；如果停止定位失败，返回false
        if (!StopLocalizationIfNeeded("failed[B0432]", "停止定位成功：", "停止定位失败："))
        {
            return;
        }
        // 开始定位
        const Eigen::Vector3f pose(
            static_cast<float>(msg.pose.pose.position.x),
            static_cast<float>(msg.pose.pose.position.y),
            static_cast<float>(yaw));
        StartLocalizationAction(
            curr_map_name_,
            pose,
            "failed[B0439]",
            "initalpose localization success：",
            "initalpose localization failed：");
    }
}
/**********************************************************************
 * * @brief:  电梯状态回调，检测LIFT状态时保存地图
 * * @input:  msg: 电梯状态消息
 * * @output:
 * * @return:  void
 * **********************************************************************/
void MapManage::ElevatorStatusCallback(const std_msgs::String::ConstPtr &msg)
{
    if (is_save_lift_map_)
    {
        const std::string status = msg->data;
        if (status == "ENTER_ELEVATOR")
        {
            LOG(INFO) << " 检测到电梯乘梯状态，准备保存定位地图快照";
            const std::string current_map = curr_map_name_;
            if (current_map.empty())
            {
                LOG(WARNING) << " curr_map_name_为空，跳过记录电梯前地图";
                return;
            }
            last_map_name_before_lift_ = current_map;
            LOG(INFO) << " 记录电梯前地图: " + current_map;
        }
        else if (status == "OUT_ELEVATOR")
        {
            if (last_map_name_before_lift_.empty())
            {
                LOG(WARNING) << " 收到OUT_ELEVATOR但没有记录到乘梯前地图，跳过保存";
                return;
            }
            const std::string current_map = curr_map_name_;
            if (current_map.empty())
            {
                LOG(WARNING) << " OUT_ELEVATOR时curr_map_name_为空，跳过保存";
                return;
            }
            LOG(INFO) << " 电梯过程完成，开始保存切换后定位地图";
            SaveBothLocationMaps(last_map_name_before_lift_, current_map);
            last_map_name_before_lift_.clear();
        }
    }
}
// ==================== Action 回调 ====================
void MapManage::doneCallback(
    const actionlib::SimpleClientGoalState &state,
    const slam_state_machine_msgs::MissionManagerActionResultConstPtr &result)
{
    int code = -1;
    try
    {
        code = std::stoi(result->ack_data);
    }
    catch (const std::exception &)
    {
        code = -1;
    }
    action_result_ = code;
    LOG(INFO) << "Result: " << result->ack_data;
}

void MapManage::activeCallback()
{
    LOG(INFO) << "Goal just went active";
}

void MapManage::feedbackCallback(const slam_state_machine_msgs::MissionManagerActionFeedbackConstPtr &feedback)
{
    LOG(INFO) << "Feedback: " << feedback->count;
}

/**********************************************************************
 * @brief:  定位请求处理线程，负责执行地图切换和定位操作
 * @input:
 * @output:
 * @return:  void：无返回值。
 * **********************************************************************/
void MapManage::PublishMapStatus()
{
    std_msgs::String fault_msg;
    if (map_status_ != "running" && map_status_ != "success")
    {
        fault_msg.data = map_status_;
    }
    else
    {
        fault_msg.data.clear();
    }
    pub_fault_.publish(fault_msg);

    std_msgs::String pub_map_status_msg;
    pub_map_status_msg.data = map_status_;
    map_state_pub_.publish(pub_map_status_msg);

    // 发布当前地图名称
    std_msgs::String map_name_msg;
    if (!map_service_.IsInitialized())
    {
        map_name_msg.data = default_map_name_;
    }
    // 查看地图文件夹中是否存在地图
    if (!CheckIfAnyMapExists())
    {
        // 如果没有地图文件，显示default_map
        map_name_msg.data = "";
        curr_map_pub_.publish(map_name_msg);
        return;
    }
    // map_server就绪后的正常逻辑
    if (curr_map_name_.empty())
    {
        map_name_msg.data = default_map_name_;
        LOG(WARNING) << " 当前地图名为空，使用默认地图: " + default_map_name_;
    }
    else
    {
        map_name_msg.data = curr_map_name_;
    }
    curr_map_pub_.publish(map_name_msg);
}
/**********************************************************************
 * * @brief:  地图管理服务处理器
 * * @input:  request: 服务请求，包含操作类型和请求数据 response: 服务响应，返回操作状态和结果数据
 * * @output:  response: 填充响应状态和数据
 * * @return:  bool
 * **********************************************************************/
bool MapManage::ChangeMapServiceHandler(robot_msgs::Switch::Request &request, robot_msgs::Switch::Response &response) // 原map_server中的change_map服务端拆解成当前函数和map_serviec_.ChangMap()函数
{
    if (!map_service_.IsInitialized())
    {
        LOG(INFO) << "切换地图服务调用成功，但地图初始化未完成，请等待";
        response.result = response.RESULT_UNDEFINED_FAILURE;
        return true;
    }

    if (request.isChange)
    {
        if (!request.map_name.empty())
        {
            consmap_resp_t geometry_msgs::PoseWithCovarianceStamped initial_pose = BuildInitialPoseFromSwitchRequest(request);
            const bool ok = map_service_.ChangeMap(request.map_name, initial_pose, "change_map_service");
            if (ok)
            {
                map_service_.GetCurrentMap(response.map, MapDataType::Navigation); 
                response.result = response.RESULT_SUCCESS;
                curr_map_name_ = request.map_name;
            }
            else
            {
                response.result = response.RESULT_UNDEFINED_FAILURE;
            }
            return true;
        }

        const geometry_msgs::PoseWithCovarianceStamped initial_pose = BuildInitialPoseFromSwitchRequest(request); // 不应该是else吗 ？？？
        response.result = map_service_.SetInitialPoseOnly(initial_pose, "change_map_service_pose_only")
                              ? response.RESULT_SUCCESS
                              : response.RESULT_UNDEFINED_FAILURE;
        return true;
    }
    response.result = response.RESULT_UNDEFINED_FAILURE;
    return true;
}

bool MapManage::ServiceMapHander(robot_msgs::MapManage::Request &request, robot_msgs::MapManage::Response &response)
{
    std::lock_guard<std::mutex> lock(mutex_action_);
    action_result_ = -1;
    std::string srv_type = request.request_type;
    std::string srv_data = request.request_data;
    LOG(INFO) << " 收到了地图相关请求," + request.request_type + ":" + request.request_data;
    if (action_index_ != ActionIndex::WAIT) // 存图的时候也直接return ？？？
    {
        response.response_status = "failed[B0483]";
        response.response_data = "action_is_running";
        map_status_ = "failed[B0483]";
        LOG(INFO) << " action正在工作中，action_index_：" << action_index_ << "," << request.request_type << ":" << request.request_data;
        return true;
    }
    request_data_ = request.request_data;
    map_status_ = "running"; // 服务开启时，map_status为running

    if (srv_type == "changemap") // 切换地图
    {
        std::string target_map;
        Eigen::Vector3f pose = Eigen::Vector3f::Zero();
        if (!ParseChangeMapRequest(request.request_data, target_map, pose))
        {
            response.response_status = "failed[B0431]";
            response.response_data = "Invalid change map data.";
            map_status_ = "failed[B0431]";
            LOG(ERROR) << request.request_data << " is invalid data.";
            return true;
        }
        action_index_ = ActionIndex::CHANGEMAP;
        PublishMapStatus();
        thread_RequestAtion();
        PublishMapStatus();
        response.response_status = map_status_;
        response.response_data = request.request_data;
        return true;
    }
    else if (srv_type == "initpose")
    {
        Eigen::Vector3f pose = Eigen::Vector3f::Zero();
        if (!ParseInitPoseRequest(request.request_data, pose))
        {
            response.response_status = "failed[B0431]";
            response.response_data = "Invalid initial pose";
            map_status_ = "failed[B0431]";
            LOG(ERROR) << request.request_data << " is invalid data.";
            return true;
        }
        action_index_ = ActionIndex::INITPOSE;
        PublishMapStatus();
        thread_RequestAtion();
        PublishMapStatus();
        response.response_status = map_status_;
        response.response_data = request.request_data;
        return true;
    }
    else if ((srv_type == "buildmap"))
    {
        if (algorithm_ == "carto")
        {
            // 大小地图 大地图 选mapping_big_area.lua  小地图选 mapping_small_area.lua
            action_index_ = ActionIndex::BUILDMAP;
            PublishMapStatus();
            thread_RequestAtion();
            PublishMapStatus();
            response.response_status = map_status_;
            response.response_data = request.request_data;
        }
        else
        {
            LOG(INFO) << "amcl定位方式";
            response.response_status = "success";
            response.response_data = ""; // 返回保存路径
            map_status_ = "success";
        }
        return true;
    }
    else if ((srv_type == "savemap"))
    {
        if (algorithm_ == "carto")
        {
            if (!can_save_pbstream_)
            {
                LOG(INFO) << " 保存地图 ：can_save_pbstream_为false";
                // 发布地图状态
                map_status_ = "failed[B0481]";
                response.response_data = srv_data;
                response.response_status = "failed[B0481]";
            }
            else
            {
                action_index_ = ActionIndex::SAVEMAP;
                PublishMapStatus();
                thread_RequestAtion();
                PublishMapStatus();
                response.response_status = map_status_;
                response.response_data = request.request_data;
            }
        }
        else
        {
            LOG(INFO) << "amcl定位方式";
            response.response_status = "success";
            response.response_data = ""; // 返回保存路径
            map_status_ = "success";
        }
        return true;
    }
    else if ((srv_type == "stopmap"))
    {
        if (algorithm_ == "carto")
        {
            action_index_ = ActionIndex::STOPMAP;
            PublishMapStatus();
            thread_RequestAtion();
            PublishMapStatus();
            response.response_status = map_status_;
            response.response_data = request.request_data;
        }
        else
        {
            LOG(INFO) << "amcl定位方式";
            response.response_status = "success";
            response.response_data = ""; // 返回保存路径
            map_status_ = "success";
        }
        return true;
    }
    else if (srv_type == "deletemap")
    {
        // 删除数据库的指定表格
        bool delete_result = DeleteTableByMap(request.request_data);
        if (delete_result)
        {
            LOG(INFO) << "map : " + request.request_data + " database  was deleted";
        } // 删除失败，已经提示原因
        const std::string map_name = request.request_data;
        RemoveFileIfExists(map_path_ + map_name + "_nav.pgm");
        RemoveFileIfExists(map_path_ + map_name + "_loc.pgm");
        RemoveFileIfExists(map_path_ + map_name + "_loc.yaml");
        RemoveFileIfExists(map_path_ + map_name + "_nav.yaml");
        RemoveFileIfExists(map_path_ + map_name + ".pbstream");
        RemoveFileIfExists("/home/iimt/.cfg/controlmaster/controlmaster/map/prohibition_areas/" + map_name + ".yaml");
        response.response_status = "success";
        response.response_data = "Deleting map succeeded";
        map_status_ = "success";
    }
    else if (srv_type == "getmaplist")
    {
        // 想要得到目录的路径
        std::set<std::string> file_name_OnlyS;
        std::string file_path = map_path_;
        std::vector<std::string> files_names;
        std::vector<std::string> array;
        // 遍历文件
        GetFileNames(file_path, files_names);
        // 得到唯一的名字
        GetOnlyFileName(files_names, file_name_OnlyS);
        for (auto iter = file_name_OnlyS.cbegin(); iter != file_name_OnlyS.cend(); ++iter)
        {
            // 将得到的路径的字符串推到数组当中,按字母顺序排好序了
            array.push_back(*iter);
        }
        std::string res_str = "";
        // 循环上传文件中所有的文件
        for (int i = 0; i < array.size(); i++)
        {
            res_str += array[i];
            if (i < array.size() - 1)
                res_str += ",";
        }
        LOG(INFO) << " getmaplist res_str =：" + res_str;
        response.response_status = "success";
        response.response_data = res_str;
        map_status_ = "success";
    }
    else if (srv_type == "editmap")
    {
        srv_data = request.request_data;
        const std::string nav_map_path = map_path_ + srv_data + "_nav.pgm";
        const std::string map_str = ImageToBase64(nav_map_path);
        cv::Mat image = cv::imread(nav_map_path, cv::IMREAD_UNCHANGED);
        cv::Size size = image.size();
        MapData map_data;
        ReadYamlMap(srv_data, map_data);
        std::string data_uplaod =
            map_data.origin_point_x + ":" + map_data.origin_point_y + ":" + map_data.origin_point_yaw + ":" +
            map_data.map_resolution + ":" + map_str + ":" + std::to_string(size.width) + ":" + std::to_string(size.height);
        LOG(INFO) << " editmap data_uplaod ：" << std::string(map_data.origin_point_x + ":" + map_data.origin_point_y + ":" + map_data.origin_point_yaw + ":" + map_data.map_resolution);
        response.response_status = "success";
        response.response_data = data_uplaod;
        map_status_ = "success";
    }
    else if (srv_type == "saveeditmap")
    {
        std::vector<std::string> parts;
        StrSplit(request.request_data, ':', parts);
        if (parts.size() < 2)
        {
            response.response_status = "failed[B0431]";
            response.response_data = "Invalid saveeditmap data";
            map_status_ = "failed[B0431]";
            LOG(ERROR) << "saveeditmap data invalid: " << request.request_data;
            return true;
        }
        const std::string &map_name = parts[0];
        const std::string &map_base64 = parts[1];
        const std::string nav_map_path = map_path_ + map_name + "_nav.pgm";
        if (!Base64ToImage(map_base64, nav_map_path))
        {
            response.response_status = "failed[B0481]";
            response.response_data = "saveeditmap write failed";
            map_status_ = "failed[B0481]";
            LOG(ERROR) << "saveeditmap write failed: " << nav_map_path;
            return true;
        }
        LOG(INFO) << "saveeditmap save path: " << nav_map_path;
        response.response_status = "success";
        response.response_data = nav_map_path;
        map_status_ = "success";
        if (map_name == curr_map_name_)
        {
            // 只更新导航地图，适用于保存完编辑地图后刷新导航地图的场景，成功返回true
            const bool flag = map_service_.ReloadNavigationMapOnly(map_name, true, "saveeditmap_refresh_nav");
            if (flag)
            {
                LOG(INFO) << "change nav map success";
            }
            else
            {
                LOG(ERROR) << "change nav map failed";
            }
        }
    }
    else if (srv_type == "getmapdata")
    {
        nav_msgs::OccupancyGrid map;
        MapDataType map_type = MapDataType::Navigation;
        if (request.request_data == "loc" || request.request_data == "localization" || request.request_data == "amcl")
        {
            map_type = MapDataType::Localization;
        }
        if (!map_service_.GetCurrentMap(map, map_type))
        {
            response.response_status = "failed[B0484]";
            response.response_data = "current map is empty";
            map_status_ = "failed[B0484]";
            LOG(ERROR) << "get current map failed";
            return true;
        }
        std::string res_map = GenerateMapInfo(map);
        response.response_status = "success";
        response.response_data = res_map; // 返回保存路径
        map_status_ = "success";
    }
    else if (srv_type == "getdefaultmap")
    {
        ReadYamlForMapName();
        response.response_status = "success";
        response.response_data = default_map_name_; // 返回保存路径
    }
    else
    {
        LOG(ERROR) << "Invalid request type: " << srv_type << ", 强制为空";
        response.response_status = "success";
        response.response_data = ""; // 返回保存路径
        map_status_ = "success";
    }
    return true;
}
/**********************************************************************
 * * @brief:  定位请求处理线程，负责执行地图切换和定位操作
 * * @input:
 * * @output:
 * * @return:  void：无返回值。
 * **********************************************************************/
void MapManage::thread_RequestAtion()
{
    if (action_index_ != ActionIndex::WAIT)
    {
        LOG(INFO) << "action_index_: " << action_index_;
    }
    switch (action_index_)
    {
    case ActionIndex::WAIT:
    {
        break;
    }
    case ActionIndex::CHANGEMAP:
    {
        std::string target_map;
        Eigen::Vector3f pose = Eigen::Vector3f::Zero();
        if (!ParseChangeMapRequest(request_data_, target_map, pose))
        {
            map_status_ = "failed[B0431]";
            LOG(ERROR) << request_data_ << " is invalid data.";
            action_index_ = ActionIndex::WAIT;
            break;
        }

        if (!ChangeMapViaMapServer(
                target_map,
                pose,
                "failed[B0432]",
                "callchangemapsrv success, " + target_map,
                "changemap failed[B0432]"))
        {
            action_index_ = ActionIndex::WAIT;
            break;
        }

        if (algorithm_ == "amcl")
        {
            map_status_ = "success";
            action_index_ = ActionIndex::WAIT;
            break;
        }
        else
        {
            if (!StopLocalizationIfNeeded("failed[B0432]", "切图 停止定位成功：", "切图 停止定位失败："))
            {
                action_index_ = ActionIndex::WAIT;
                break;
            }
            StartLocalizationAction(
                curr_map_name_,
                pose,
                "failed[B0432]",
                "切图 重定位成功：",
                "切图 重定位失败：");
            action_index_ = ActionIndex::WAIT;
            break;
        }
    }
    case ActionIndex::INITPOSE:
    {
        Eigen::Vector3f pose = Eigen::Vector3f::Zero();
        if (!ParseInitPoseRequest(request_data_, pose))
        {
            map_status_ = "failed[B0431]";
            action_index_ = ActionIndex::WAIT;
            break;
        }

        if (algorithm_ == "amcl")
        {
            geometry_msgs::PoseWithCovarianceStamped pose_msg;
            pose_msg.header.stamp = ros::Time::now();
            pose_msg.header.frame_id = "map";
            pose_msg.pose.pose.position.x = pose.x();
            pose_msg.pose.pose.position.y = pose.y();
            pose_msg.pose.covariance[0] = 0.25; 
            pose_msg.pose.covariance[6 * 1 + 1] = 0.25;
            pose_msg.pose.covariance[6 * 5 + 5] = 0.06853891945200942;
            pose_msg.pose.pose.orientation.z = std::sin(static_cast<double>(pose.z()) / 2.0);
            pose_msg.pose.pose.orientation.w = std::cos(static_cast<double>(pose.z()) / 2.0);
            if (map_service_.SetInitialPoseOnly(pose_msg, "initpose"))
            {
                map_status_ = "success";
                LOG(INFO) << "amcl initpose success: x=" << pose.x() << ", y=" << pose.y() << ", yaw=" << pose.z();
            }
            else
            {
                map_status_ = "failed[B0439]";
                LOG(ERROR) << "amcl initpose failed";
            }
            action_index_ = ActionIndex::WAIT;
            break;
        }
        else
        {
            if (!StopLocalizationIfNeeded("failed[B0439]", "停止定位成功：", "initpose stop localization failed："))
            {
                action_index_ = ActionIndex::WAIT;
                break;
            }
            StartLocalizationAction(
                curr_map_name_,
                pose,
                "failed[B0439]",
                "initpose localization success：",
                "initpose localization failed：");
            action_index_ = ActionIndex::WAIT;
            break;
        }
    }
    case ActionIndex::BUILDMAP:
    {
        if (!StopLocalizationIfNeeded("failed[B0481]", "建图时停止定位成功：", "建图时停止定位失败："))
        {
            action_index_ = ActionIndex::WAIT;
            break;
        }

        slam_state_machine_msgs::MissionManagerActionGoal mapping_goal;
        mapping_goal.send_data = "start_mapping";
        mapping_goal.configuration_directory = LOC_FILE_PATH;
        if (request_data_ == "small_area")
        {
            mapping_goal.configuration_basename = "mapping_small_area.lua";
            LOG(INFO) << "buildmap 选的是小地图";
        }
        else
        {
            mapping_goal.configuration_basename = "mapping_big_area.lua";
            LOG(INFO) << "buildmap 选的是大地图";
        }
        ac_client_.sendGoal(mapping_goal,
                            boost::bind(&MapManage::doneCallback, this, _1, _2),
                            boost::bind(&MapManage::activeCallback, this),
                            boost::bind(&MapManage::feedbackCallback, this, _1));
        ac_client_.waitForResult();
        if (IsActionSuccess())
        {
            map_status_ = "success";
            LOG(INFO) << "建图成功：" << action_result_;
        }
        else
        {
            map_status_ = "failed[B0481]";
            LOG(ERROR) << "建图失败：" << action_result_;
        }
        action_index_ = ActionIndex::WAIT;
        break;
    }
    case ActionIndex::SAVEMAP:
    {
        if (!can_save_pbstream_)
        {
            map_status_ = "failed[B0481]";
            LOG(INFO) << "保存地图：can_save_pbstream_为false";
            action_index_ = ActionIndex::WAIT;
            break;
        }

        slam_state_machine_msgs::MissionManagerActionGoal save_goal;
        save_goal.send_data = "save_mapping";
        save_goal.filename = map_path_ + request_data_ + ".pbstream"; // pbstream的绝对路径
        ac_client_.sendGoal(save_goal,
                            boost::bind(&MapManage::doneCallback, this, _1, _2),
                            boost::bind(&MapManage::activeCallback, this),
                            boost::bind(&MapManage::feedbackCallback, this, _1));
        ac_client_.waitForResult();
        if (!IsActionSuccess())
        {
            map_status_ = "failed[B0481]";
            LOG(ERROR) << "保存地图失败：" << action_result_;
            action_index_ = ActionIndex::WAIT;
            break;
        }

        LOG(INFO) << "保存地图成功：" << action_result_;
        // 如果当前地图不是默认地图，切回默认地图，主要用于建图后切回默认地图继续定位
        if (!ChangeToDefaultMapIfNeeded("failed[B0481]"))
        {
            action_index_ = ActionIndex::WAIT;
            break;
        }

        StartLocalizationAction(
            default_map_name_,
            Eigen::Vector3f::Zero(),
            "failed[B0481]",
            "保存地图后开启定位成功：",
            "保存地图后开启定位失败：");
        action_index_ = ActionIndex::WAIT;
        break;
    }
    case ActionIndex::STOPMAP:
    {
        LOG(INFO) << "停止建图";
        if (!StopLocalizationIfNeeded("failed[B0482]", "停止定位成功：", "停止定位失败："))
        {
            action_index_ = ActionIndex::WAIT;
            break;
        }
        // 如果当前地图不是默认地图，切回默认地图，主要用于建图后切回默认地图继续定位
        if (!ChangeToDefaultMapIfNeeded("failed[B0482]"))
        {
            action_index_ = ActionIndex::WAIT;
            break;
        }

        StartLocalizationAction(
            default_map_name_,
            Eigen::Vector3f::Zero(),
            "failed[B0482]",
            "停止定位后开启定位成功：",
            "停止定位后开启定位失败：");
        action_index_ = ActionIndex::WAIT;
        break;
    }
    default:
    {
        break;
    }
    }
}

/**********************************************************************
 * * @brief:  新算法定位请求处理函数，负责执行定位操作
 * * @input:
 * * @output:
 * * @return:  void：无返回值。
 * **********************************************************************/
void MapManage::StartLocazation()
{
    StartLocalizationAction(
        curr_map_name_,
        Eigen::Vector3f::Zero(),
        "failed[B0480]",
        "开机定位成功：",
        "开机定位失败：");
}
// 发送定位/建图命令
void MapManage::SendGoal(std::string cmd)
{
    slam_state_machine_msgs::MissionManagerActionGoal goal;
    goal.send_data = cmd;
    ac_client_.sendGoal(goal,
                        boost::bind(&MapManage::doneCallback, this, _1, _2),
                        boost::bind(&MapManage::activeCallback, this),
                        boost::bind(&MapManage::feedbackCallback, this, _1));
    ac_client_.waitForResult();
}

bool MapManage::IsActionSuccess() const
{
    const int code = action_result_;
    return code == 0 || code == 6 || code == 10 || code == 16;
}

bool MapManage::ParseInitPoseRequest(const std::string &request_data, Eigen::Vector3f &pose)
{
    std::vector<std::string> list;
    StrSplit(request_data, ',', list);
    if (list.size() < 3)
    {
        return false;
    }
    try
    {
        pose.x() = static_cast<float>(std::stof(list[0]));
        pose.y() = static_cast<float>(std::stof(list[1]));
        pose.z() = static_cast<float>(std::stof(list[2]));
    }
    catch (const std::exception &)
    {
        return false;
    }
    return true;
}

bool MapManage::ParseChangeMapRequest(const std::string &request_data, std::string &map_name, Eigen::Vector3f &pose)
{
    std::vector<std::string> list;
    StrSplit(request_data, ',', list);
    if (list.size() < 4)
    {
        return false;
    }
    try
    {
        map_name = list[0];
        pose.x() = static_cast<float>(std::stof(list[1]));
        pose.y() = static_cast<float>(std::stof(list[2]));
        pose.z() = static_cast<float>(std::stof(list[3]));
    }
    catch (const std::exception &)
    {
        return false;
    }
    return true;
}
// 如果当前正在定位，先停止定位，再返回true；如果当前没有在定位，直接返回true；如果停止定位失败，返回false
bool MapManage::StopLocalizationIfNeeded(const std::string &fail_code,
                                         const std::string &stop_success_log,
                                         const std::string &stop_fail_log)
{
    SendGoal("get_state");
    if (action_result_ == 100)
    {
        return true;
    }

    SendGoal("stop");
    if (IsActionSuccess())
    {
        LOG(INFO) << stop_success_log << action_result_;
        return true;
    }

    map_status_ = fail_code;
    LOG(ERROR) << stop_fail_log << action_result_;
    return false;
}
// 开始定位
bool MapManage::StartLocalizationAction(const std::string &map_name,
                                        const Eigen::Vector3f &pose,
                                        const std::string &fail_code,
                                        const std::string &success_log,
                                        const std::string &fail_log)
{
    slam_state_machine_msgs::MissionManagerActionGoal goal;
    goal.send_data = "start_localization";
    goal.configuration_directory = LOC_FILE_PATH;
    goal.configuration_basename = LOC_FILE;
    goal.load_state_filename = map_path_ + map_name + ".pbstream";
    goal.use_initial_pose = true;

    geometry_msgs::Quaternion geo_q = tf::createQuaternionMsgFromYaw(static_cast<double>(pose.z()));
    goal.initial_pose.orientation.w = geo_q.w;
    goal.initial_pose.orientation.x = 0.0;
    goal.initial_pose.orientation.y = 0.0;
    goal.initial_pose.orientation.z = geo_q.z;
    goal.initial_pose.position.x = static_cast<double>(pose.x());
    goal.initial_pose.position.y = static_cast<double>(pose.y());

    ac_client_.sendGoal(goal,
                        boost::bind(&MapManage::doneCallback, this, _1, _2),
                        boost::bind(&MapManage::activeCallback, this),
                        boost::bind(&MapManage::feedbackCallback, this, _1));
    ac_client_.waitForResult();

    if (IsActionSuccess())
    {
        map_status_ = "success";
        LOG(INFO) << success_log << action_result_;
        return true;
    }

    map_status_ = fail_code;
    LOG(ERROR) << fail_log << action_result_;
    return false;
}

bool MapManage::ChangeMapViaMapServer(const std::string &map_name,
                                      const Eigen::Vector3f &pose,
                                      const std::string &fail_code,
                                      const std::string &success_log,
                                      const std::string &fail_log)
{  
    geometry_msgs::PoseWithCovarianceStamped pose_msg;
    pose_msg.header.frame_id = "map";
    pose_msg.header.stamp = ros::Time::now();
    pose_msg.pose.pose.position.x = static_cast<double>(pose.x());
    pose_msg.pose.pose.position.y = static_cast<double>(pose.y());
    pose_msg.pose.pose.position.z = 0.0;
    geometry_msgs::Quaternion geo_q = tf::createQuaternionMsgFromYaw(static_cast<double>(pose.z()));
    pose_msg.pose.pose.orientation = geo_q;

    if (!map_service_.ChangeMap(map_name, pose_msg, "map_manage_change_map"))
    {
        map_status_ = fail_code;
        LOG(ERROR) << fail_log;
        return false;
    }

    curr_map_name_ = map_name;
    LOG(INFO) << success_log;
    return true;
}
// 如果当前地图不是默认地图，切回默认地图，主要用于建图后切回默认地图继续定位
bool MapManage::ChangeToDefaultMapIfNeeded(const std::string &fail_code)
{
    ReadYamlForMapName();
    if (default_map_name_.empty())
    {
        map_status_ = fail_code;
        LOG(ERROR) << "默认地图为空，无法切回默认地图";
        return false;
    }

    if (curr_map_name_ == default_map_name_)
    {
        LOG(INFO) << "当前地图与默认地图一致，不需要切图";
        return true;
    }

    return ChangeMapViaMapServer(
        default_map_name_,
        Eigen::Vector3f::Zero(),
        fail_code,
        "当前地图与默认地图不一致，切图成功",
        "当前地图与默认地图不一致，切图失败");
}

// ==================== 内部工具函数 ====================
/**********************************************************************
 * * @brief:  读取yaml文件中的默认地图
 * * @input:
 * * @output:
 * * @return:  void：无返回值
 * **********************************************************************/
void MapManage::ReadYamlForMapName()
{
    map_service_.RefreshDefaultMapName();
    default_map_name_ = map_service_.GetDefaultMapName();
    LOG(INFO) << " 读到了默认地图," + default_map_name_;
}

/**********************************************************************
 * * @brief:  从yaml文件中，读取地图信息
 * * @input:  map_name:地图名称 res_mapdata：地图数据
 * * @output:
 * * @return:  bool：成功返回true，失败返回false。
 * **********************************************************************/
bool MapManage::ReadYamlMap(std::string map_name, MapData &res_mapdata)
{
    try
    {
        const YAML::Node config = YAML::LoadFile(map_path_ + map_name + "_loc.yaml");
        if (config["origin"] && config["origin"].IsSequence() && config["origin"].size() >= 3)
        {
            res_mapdata.origin_point_x = std::to_string(config["origin"][0].as<double>());
            res_mapdata.origin_point_y = std::to_string(config["origin"][1].as<double>());
            res_mapdata.origin_point_yaw = std::to_string(config["origin"][2].as<double>());
        }
        if (config["resolution"])
        {
            res_mapdata.map_resolution = std::to_string(config["resolution"].as<double>());
        }
    }
    catch (const std::exception &e)
    {
        LOG(ERROR) << "read yaml failed: " << e.what();
        return false;
    }
    return true;
}
/**********************************************************************
 * * @brief:  通过地图名字删除数据库中的数据表
 * * @input:  request_map_name: 地图名称
 * * @output:
 * * @return:  bool
 * **********************************************************************/
bool MapManage::DeleteTableByMap(std::string request_map_name)
{
    std::string table_name = "";
    robot_msgs::Database_data srv;
    srv.request.request_type = 0;
    srv.request.request_data = "";
    if (!database_client_.waitForExistence(ros::Duration(10)))
    {
        LOG(ERROR) << "database_operate died";
    }
    if (database_client_.call(srv))
    {
        std::string json_table_list = srv.response.response_data;
        Json::Value root;
        JSONCPP_STRING err;
        Json::CharReaderBuilder builder;
        const auto rawJsonLength = static_cast<int>(json_table_list.length());
        const std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
        LOG(INFO) << "table list :" + json_table_list;
        if (!reader->parse(json_table_list.c_str(), json_table_list.c_str() + rawJsonLength, &root, &err))
        {
            LOG(ERROR) << "table list parsing error.";
            return false;
        }
        Json::Value::Members jm = root.getMemberNames(); // 获取表名
        int len = jm.size();
        // if (len < 1 || (len >= 1 && jm[0] != "tableList")) {
        if (len < 1 || jm[0] != "tableList")
        {
            // ROS_ERROR("The table list content is not in the correct formatr.");
            LOG(ERROR) << "The table list content is not in the correct formatr.";
            return false;
        }
        if (root["tableList"].isArray())
        {
            int size_t = root["tableList"].size();
            std::string map_name;
            std::string t_name;
            for (int i = 0; i < size_t; i++)
            {
                map_name = root["tableList"][i]["linkmap"].asString();
                t_name = root["tableList"][i]["pointlistname"].asString();
                if (map_name == request_map_name)
                {
                    table_name = t_name;
                    break;
                }
            }
        }
        if (table_name == "") // request_map_name对应的表格不存在
        {
            LOG(ERROR) << "The table corresponding to " + request_map_name + " does not exist";
            return false;
        }
    }
    else
    {
        LOG(ERROR) << "Failed to obtain all waypoint tables";
        return false;
    }

    srv.request.request_type = 2;
    srv.request.request_data = table_name;
    if (!database_client_.waitForExistence(ros::Duration(10)))
    {
        LOG(ERROR) << "database_operate died";
    }
    if (database_client_.call(srv))
    {
        LOG(INFO) << " Table deleted successfully";
    }
    else
    {
        LOG(INFO) << " Failed to delete table";
        return false;
    }

    return true;
}
/**********************************************************************
 * * @brief:  检查map_path目录下是否存在任何地图文件
 * * @input:
 * * @output:
 * * @return:  bool: 存在地图文件返回true，否则返回false
 * **********************************************************************/
bool MapManage::CheckIfAnyMapExists()
{
    try
    {
        DIR *pDir;
        struct dirent *ptr;
        if (!(pDir = opendir(map_path_.c_str())))
        {
            LOG(ERROR) << " 无法打开地图目录: " + map_path_;
            return false;
        }

        std::set<std::string> unique_map_names;

        while ((ptr = readdir(pDir)) != 0)
        {
            if (strcmp(ptr->d_name, ".") != 0 && strcmp(ptr->d_name, "..") != 0)
            {
                std::string filename = ptr->d_name;
                // 检查是否为地图文件（_loc.yaml 或 _nav.yaml 或 .pbstream）
                if (filename.find("_loc.yaml") != std::string::npos ||
                    filename.find("_nav.yaml") != std::string::npos ||
                    filename.find(".pbstream") != std::string::npos)
                {
                    // 提取地图名称（去掉后缀）
                    std::string map_name;
                    size_t pos = filename.find("_loc.yaml");
                    if (pos != std::string::npos)
                    {
                        map_name = filename.substr(0, pos);
                    }
                    else
                    {
                        pos = filename.find("_nav.yaml");
                        if (pos != std::string::npos)
                        {
                            map_name = filename.substr(0, pos);
                        }
                        else
                        {
                            pos = filename.find(".pbstream");
                            if (pos != std::string::npos)
                            {
                                map_name = filename.substr(0, pos);
                            }
                        }
                    }

                    if (!map_name.empty())
                    {
                        unique_map_names.insert(map_name);
                    }
                }
            }
        }
        closedir(pDir);

        bool has_maps = !unique_map_names.empty();
        if (has_maps)
        {
            LOG_EVERY_N(INFO, 300) << "检测到地图文件，地图数量: " + std::to_string(unique_map_names.size());
        }
        else
        {
            LOG(INFO) << "地图目录中没有检测到任何地图文件";
        }

        return has_maps;
    }
    catch (const std::exception &e)
    {
        LOG(ERROR) << " CheckIfAnyMapExists异常: " + std::string(e.what());
        return false;
    }
}
/**
 * @header GetFileNames
 * @brief 获取path下文件名
 */
void MapManage::GetFileNames(std::string path, std::vector<std::string> &filenames)
{
    try
    {
        DIR *pDir;
        struct dirent *ptr;
        if (!(pDir = opendir(path.c_str())))
        {
            return;
        }
        std::string mapName = "";
        while ((ptr = readdir(pDir)) != 0)
        {
            if (strcmp(ptr->d_name, ".") != 0 && strcmp(ptr->d_name, "..") != 0)
                filenames.push_back(ptr->d_name); //(path + "/" + ptr->d_name)
        }
        closedir(pDir);
    }
    catch (const std::exception e)
    {
        LOG(ERROR) << "GetFileNames Query file name exception.";
    }
}
/**********************************************************************
 * * @brief:  得到指定后缀的文件名，并去重
 * * @input:
 * * @output:
 * * @return:  void：无返回值。
 * **********************************************************************/
void MapManage::GetOnlyFileName(std::vector<std::string> &file_name, std::set<std::string> &file_name_OnlyS)
{
    try
    {
        for (const auto &name : file_name)
        {
            const std::size_t pos = name.find("_loc");
            if (pos != std::string::npos)
            {
                file_name_OnlyS.insert(name.substr(0, pos)); 
            }
            else
            {
                LOG(ERROR) << name << " is not a valid file.";
            }
        }
    }
    catch (const std::exception &)
    {
        LOG(ERROR) << "GetOnlyFileName query file name exception.";
    }
}
/**********************************************************************
 * * @brief:  定位请求处理线程，负责执行地图切换和定位操作
 * * @input:
 * * @output:
 * * @return:  void：无返回值。
 * **********************************************************************/
std::string MapManage::ImageToBase64(const std::string &image_path)
{
    std::ifstream file(image_path, std::ios::binary);
    if (!file)
    {
        LOG(ERROR) << "open image failed: " << image_path;
        return "";
    }
    std::vector<unsigned char> data((std::istreambuf_iterator<char>(file)), std::istreambuf_iterator<char>());
    return Base64Encode(data);
}

/**********************************************************************
 * * @brief:  将Base64编码的字符串转换为图片并保存到指定路径
 * * @input:  base64Str: Base64编码的图片数据字符串 map_path: 图片保存的目标路径
 * * @output:
 * * @return:  void：无返回值。
 * **********************************************************************/
bool MapManage::Base64ToImage(const std::string &base64_str, const std::string &map_path)
{
    const std::vector<unsigned char> decoded = Base64Decode(base64_str);
    std::ofstream output(map_path, std::ios::binary);
    if (!output)
    {
        LOG(ERROR) << "open output image failed: " << map_path;
        return false;
    }
    output.write(reinterpret_cast<const char *>(decoded.data()), static_cast<std::streamsize>(decoded.size()));
    return output.good();
}
/**********************************************************************
 * * @brief:  沿x轴翻转地图
 * * @input:  map: 图片保存的目标路径
 * * @output:
 * * @return:  返回翻转结果
 * **********************************************************************/
cv::Mat MapManage::RotaMap(cv::Mat const &map)
{
    cv::Mat result;
    result.create(map.size(), map.type());
    int height = map.rows;
    int width = map.cols;
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            result.at<uchar>(height - i - 1, j) = map.at<uchar>(i, j);
        }
    }
    return result;
}
/**********************************************************************
 * * @brief:  生成json数据封装
 * * @input:  map: 地图数据
 * * @output:
 * * @return:  返回翻转结果
 * **********************************************************************/
std::string MapManage::GenerateMapInfo(nav_msgs::OccupancyGrid &map)
{
    const int map_width = static_cast<int>(map.info.width);
    const int map_height = static_cast<int>(map.info.height);
    const double map_origin_x = map.info.origin.position.x;
    const double map_origin_y = map.info.origin.position.y;
    const double map_resolution = map.info.resolution;

    cv::Mat image(map.info.height, map.info.width, CV_8UC1);
    for (int array_index = 0; array_index < static_cast<int>(map.data.size()); ++array_index)
    {
        const int row = array_index / image.cols;
        const int col = array_index % image.cols;
        const int curr_data = map.data[array_index];

        int value = 125;
        if (curr_data == 100)
        {
            value = 0; // black
        }
        else if (curr_data == 0)
        {
            value = 255; // white
        }
        image.at<uchar>(row, col) = static_cast<uchar>(value);
    }

    const cv::Mat rotated_map = RotaMap(image);
    std::vector<unsigned char> png_bytes;
    if (!cv::imencode(".png", rotated_map, png_bytes))
    {
        LOG(ERROR) << "encode map image failed";
        return "";
    }

    std::ostringstream oss;
    oss << "mapWidth:" << map_width
        << "_mapHeight:" << map_height
        << "_Resolution:" << map_resolution
        << "_mapOriginX:" << map_origin_x
        << "_mapOriginY:" << map_origin_y
        << "_mapImg:" << Base64Encode(png_bytes);
    return oss.str();
}

/**********************************************************************
 * * @brief:  使用指定字符分割字符串，并将结果存储到向量中
 * * @input:  str: 待分割的原始字符串 split: 用作分隔符的字符
 * * @output:  rst: 存储分割结果的字符串向量
 * * @return:  void：无返回值
 * **********************************************************************/
void MapManage::StrSplit(std::string str, const char split, std::vector<std::string> &rst)
{
    if (str == "")
        return;
    // 在字符串末尾也加入分隔符，方便截取最后一段
    std::string strs = str + split;
    size_t pos = strs.find(split);
    // 若找不到内容则字符串搜索函数返回 npos
    while (pos != strs.npos)
    {
        std::string temp = strs.substr(0, pos);
        rst.push_back(temp);
        // 去掉已分割的字符串,在剩下的字符串中进行分割
        strs = strs.substr(pos + 1, strs.size());
        pos = strs.find(split);
    }
}
/**********************************************************************
 * * @brief:  保存切换前后的两张定位地图
 * * @input:  map_before: 切换前地图名, map_after: 切换后地图名
 * * @output:
 * * @return:  void
 * **********************************************************************/
void MapManage::SaveBothLocationMaps(const std::string &map_before, const std::string &map_after)
{
    // 创建保存目录
    std::string base_path = "/home/iimt/.cfg/controlmaster/controlmaster/changemap/";
    std::string timestamp = GetCurrentTimestamp();
    std::string save_dir = base_path + timestamp + "/";
    CreateDirectoryIfNotExists(save_dir);
    LOG(INFO) << " 开始保存定位地图快照到: " + save_dir << " 切换前地图: " + map_before + ", 切换后地图: " + map_after;
    // 保存切换前定位地图
    bool save_before_ok = false;
    if (!map_before.empty())
    {
        SaveLocationMap(map_before, save_dir, "before_lift");
        save_before_ok = true;
        LOG(INFO) << " 保存切换前定位地图: " + map_before;
    }
    else
    {
        LOG(WARNING) << " 切换前地图名为空，跳过保存";
    }
    // 保存切换后定位地图
    bool save_after_ok = false;
    if (!map_after.empty())
    {
        SaveLocationMap(map_after, save_dir, "after_lift");
        save_after_ok = true;
        LOG(INFO) << " 保存切换后定位地图: " + map_after;
    }
    else
    {
        LOG(WARNING) << " 切换后地图名为空，跳过保存";
    }

    // 保存元数据文件，记录切换信息
    SaveMetadata(save_dir, map_before, map_after, save_before_ok, save_after_ok);
    if (save_before_ok && save_after_ok)
    {
        LOG(INFO) << " 定位地图快照保存成功";
    }
    else
    {
        LOG(ERROR) << " 定位地图快照保存部分失败";
    }
    // 15天后清除
    CleanExpiredMaps(15);
}

/**********************************************************************
 * * @brief:  保存单个定位地图的快照（只保存 _loc.pgm 和 _loc.yaml）
 * * @input:  map_name: 地图名, save_dir: 保存目录, suffix: 文件名后缀
 * * @output:
 * * @return:  void
 * **********************************************************************/
void MapManage::SaveLocationMap(const std::string &map_name, const std::string &save_dir, const std::string &suffix)
{
    std::string source_base = map_path_ + map_name;
    std::string dest_base = save_dir + map_name + "_" + suffix;

    // 只保存定位地图相关的文件
    std::vector<std::pair<std::string, std::string>> files_to_copy = {
        {source_base + "_loc.pgm", dest_base + "_loc.pgm"},
        {source_base + "_loc.yaml", dest_base + "_loc.yaml"}};

    for (const auto &file_pair : files_to_copy)
    {
        const std::string &src = file_pair.first;
        const std::string &dst = file_pair.second;
        // 检查源文件是否存在
        std::ifstream src_file(src, std::ios::binary);
        if (!src_file.good())
        {
            LOG(WARNING) << " 定位地图文件不存在: " + src;
            continue;
        }
        src_file.close();
        // 复制文件
        std::ifstream src_stream(src, std::ios::binary);
        std::ofstream dst_stream(dst, std::ios::binary);
        if (src_stream && dst_stream)
        {
            dst_stream << src_stream.rdbuf();
            LOG(INFO) << " 复制定位地图文件成功: " + src + " -> " + dst;
        }
        else
        {
            LOG(ERROR) << " 复制定位地图文件失败: " + src;
        }
        src_stream.close();
        dst_stream.close();
    }
}

/**********************************************************************
 * * @brief:  保存切换元数据信息
 * * @input:  save_dir: 保存目录, map_before: 切换前地图, map_after: 切换后地图
 * * @output:
 * * @return:  void
 * **********************************************************************/
void MapManage::SaveMetadata(const std::string &save_dir,
                             const std::string &map_before,
                             const std::string &map_after,
                             bool before_ok,
                             bool after_ok)
{
    std::string metadata_file = save_dir + "metadata.txt";
    std::ofstream meta(metadata_file);

    if (meta.is_open())
    {
        // 获取当前时间
        time_t now = time(nullptr);
        struct tm *t = localtime(&now);
        char time_str[64];
        strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", t);

        meta << "=== Map Change Record (Location Map Only) ===" << std::endl;
        meta << "Timestamp: " << time_str << std::endl;
        meta << "Trigger: GOTO_LIFT_" << std::endl;
        meta << "============================================" << std::endl;
        meta << "Map before lift: " << map_before << std::endl;
        meta << "  - Location map: " << (before_ok ? "Saved ✓" : "Failed ✗") << std::endl;
        meta << std::endl;
        meta << "Map after lift: " << map_after << std::endl;
        meta << "  - Location map: " << (after_ok ? "Saved ✓" : "Failed ✗") << std::endl;
        meta << "============================================" << std::endl;

        meta.close();
        LOG(INFO) << " 保存元数据文件: " + metadata_file;
    }
    else
    {
        LOG(ERROR) << " 无法创建元数据文件: " + metadata_file;
    }
}

/**********************************************************************
 * * @brief:  获取当前时间戳字符串
 * * @input:
 * * @output:
 * * @return:  std::string: 格式为 YYYYMMDD_HHMMSS 的时间戳
 * **********************************************************************/
std::string MapManage::GetCurrentTimestamp()
{
    time_t now = time(nullptr);
    struct tm *t = localtime(&now);
    char timestamp[32];
    strftime(timestamp, sizeof(timestamp), "%Y%m%d_%H%M%S", t);
    return std::string(timestamp);
}

/**********************************************************************
 * * @brief:  创建目录（如果不存在）
 * * @input:  path: 目录路径
 * * @output:
 * * @return:  void
 * **********************************************************************/
void MapManage::CreateDirectoryIfNotExists(const std::string &path)
{
    // 使用 access 检查目录是否存在
    if (access(path.c_str(), F_OK) != 0)
    {
        // 目录不存在，创建
        std::string cmd = "mkdir -p " + path;
        int ret = system(cmd.c_str());
        if (ret == 0)
        {
            LOG(INFO) << " 创建目录成功: " + path;
        }
        else
        {
            LOG(ERROR) << " 创建目录失败: " + path;
        }
    }
    else
    {
        LOG(INFO) << " 目录已存在: " + path;
    }
}
/**********************************************************************
 * * @brief:  清理超过指定天数的旧地图快照（在保存新地图时调用）
 * * @input:  days_to_keep: 保留天数，默认15天
 * * @output:
 * * @return:  void
 * **********************************************************************/
void MapManage::CleanExpiredMaps(int days_to_keep)
{
    std::string base_path = "/home/iimt/.cfg/controlmaster/controlmaster/changemap/";
    // 检查目录是否存在
    if (access(base_path.c_str(), F_OK) != 0)
    {
        return; // 目录不存在，无需清理
    }
    // 获取当前时间
    time_t now = time(nullptr);
    time_t cutoff_time = now - (days_to_keep * 24 * 3600);
    // 遍历目录
    DIR *dir = opendir(base_path.c_str());
    if (!dir)
    {
        LOG(ERROR) << " 无法打开电梯地图目录进行清理";
        return;
    }
    struct dirent *entry;
    int deleted_count = 0;
    while ((entry = readdir(dir)) != nullptr)
    {
        // 跳过 . 和 ..
        if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
        {
            continue;
        }
        std::string dir_name = entry->d_name;
        std::string full_path = base_path + dir_name;
        // 检查是否为目录（时间戳格式 YYYYMMDD_HHMMSS）
        struct stat stat_buf;
        if (stat(full_path.c_str(), &stat_buf) == 0 && S_ISDIR(stat_buf.st_mode))
        {
            // 从目录名解析时间戳（格式：20260403_143022）
            if (dir_name.length() == 15 && dir_name[8] == '_')
            {
                struct tm tm_struct = {0};
                tm_struct.tm_year = std::stoi(dir_name.substr(0, 4)) - 1900;
                tm_struct.tm_mon = std::stoi(dir_name.substr(4, 2)) - 1;
                tm_struct.tm_mday = std::stoi(dir_name.substr(6, 2));
                tm_struct.tm_hour = std::stoi(dir_name.substr(9, 2));
                tm_struct.tm_min = std::stoi(dir_name.substr(11, 2));
                tm_struct.tm_sec = std::stoi(dir_name.substr(13, 2));
                time_t dir_time = mktime(&tm_struct);
                if (dir_time != -1 && dir_time < cutoff_time)
                {
                    // 删除过期目录
                    std::string cmd = "rm -rf " + full_path;
                    if (system(cmd.c_str()) == 0)
                    {
                        deleted_count++;
                        LOG(INFO) << " 删除过期地图快照: " + dir_name;
                    }
                    else
                    {
                        LOG(ERROR) << " 删除失败: " + full_path;
                    }
                }
            }
        }
    }
    closedir(dir);
    if (deleted_count > 0)
    {
        LOG(INFO) << " 清理完成，删除了 " + std::to_string(deleted_count) + " 个过期目录";
    }
}

geometry_msgs::PoseWithCovarianceStamped MapManage::BuildInitialPoseFromSwitchRequest(const robot_msgs::Switch::Request &request) const
{
    geometry_msgs::PoseWithCovarianceStamped pose_msg;
    pose_msg.header.frame_id = "map";
    pose_msg.header.stamp = ros::Time::now();
    pose_msg.pose.pose.position.x = request.x;
    pose_msg.pose.pose.position.y = request.y;
    pose_msg.pose.pose.position.z = request.z;
    pose_msg.pose.pose.orientation.x = request.ox;
    pose_msg.pose.pose.orientation.y = request.oy;
    pose_msg.pose.pose.orientation.z = request.oz;
    pose_msg.pose.pose.orientation.w = request.ow;
    return pose_msg;
}
void MapManage::MainLoopOnce()
{
    std::lock_guard<std::mutex> lock(mutex_action_); // 使用互斥锁保护接下来的操作，以避免并发访问导致的问题。
    thread_RequestAtion();
    PublishMapStatus();
}
/*****************************************主程序相关******************************************************/

const static std::string IIMT_LOG_PATH = "/home/iimt/.logs/";
std::string ToStringYearMonthDay()
{
    // 获取当前时间
    auto now = std::chrono::system_clock::now();

    // 将时间转换为时间点类型
    auto now_time_t = std::chrono::system_clock::to_time_t(now);
    auto now_tm = std::localtime(&now_time_t);
    auto now_time_point = std::chrono::system_clock::from_time_t(now_time_t);

    // 输出年月日
    int year = now_tm->tm_year + 1900;
    int month = now_tm->tm_mon + 1;
    int day = now_tm->tm_mday;
    // int date = year * 10000 + month * 100 + day;

    return std::to_string(year) + "-" + ((month < 10 ? "0" : "") + std::to_string(month)) + "-" + ((day < 10 ? "0" : "") + std::to_string(day));
}
// 将信息输出到单独的文件和 LOG(ERROR)
void SignalHandle(const char *data, int size)
{
    ros::shutdown();
    std::string all_path = IIMT_LOG_PATH + ToStringYearMonthDay() + "/map_manage/fatal.log";
    std::ofstream fs(all_path, std::ios::app | std::ios::out);
    std::string str = std::string(data, size);
    LOG(ERROR) << str;
    fs << str;
    fs.close();
    // google::ShutdownGoogleLogging();
}
int main(int argc, char *argv[])
{
    std::string all_path = IIMT_LOG_PATH + ToStringYearMonthDay() + "/map_manage/";
    if (access(all_path.c_str(), F_OK) == -1)
    {
        std::string fullPath;
        fullPath = all_path;
        if (fullPath[fullPath.size() - 1] != '/')
        {
            fullPath += "/";
        }
        // create dirs;
        for (uint32_t i = 1; i < fullPath.size(); i++)
        {
            if ('/' == fullPath[i])
            {
                std::string curPath = fullPath.substr(0, i);
                if (access(curPath.c_str(), F_OK) != 0)
                {
                    if (mkdir(curPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) == -1)
                    {
                        LOG(ERROR) << "mkdir:" << curPath << ", failed " << strerror(errno);
                        return 0;
                    }
                }
            }
        }
    }
    google::InitGoogleLogging(argv[0]);
    google::InstallFailureSignalHandler();
    google::InstallFailureWriter(&SignalHandle);
    FLAGS_logbufsecs = 0;                   // 日志实时输出
    FLAGS_max_log_size = 10;                // 最大日志文件大小 10M
    FLAGS_logtostderr = false;              // 设置日志消息是否转到标准输出而不是日志文件
    FLAGS_stop_logging_if_full_disk = true; // 设置是否在磁盘已满时避免日志记录到磁盘
    FLAGS_colorlogtostderr = true;          // 设置记录到标准输出的颜色消息（如果终端支持）
    FLAGS_alsologtostderr = true;           // 设置日志消息除了日志文件之外是否去标准输出
    google::SetLogDestination(google::INFO, all_path.data());
    LOG(INFO) << "Glog ON, path is " << all_path;

    ros::init(argc, argv, "map_manage_node");
    ros::NodeHandle nh("~");
    MapManage map_manage(nh);
    ros::Rate loop_rate(10);
    while (nh.ok())
    {
        map_manage.MainLoopOnce();
        ros::spinOnce();
        loop_rate.sleep();
    }
    return 0;
}
