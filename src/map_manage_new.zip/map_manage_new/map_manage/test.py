#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import math
import argparse

import rospy
from tf.transformations import quaternion_from_euler

from robot_msgs.srv import Switch, SwitchRequest
from robot_msgs.srv import MapManage, MapManageRequest


def wait_service(name: str, timeout: float = 10.0) -> bool:
    try:
        rospy.wait_for_service(name, timeout=timeout)
        return True
    except rospy.ROSException:
        rospy.logerr("service not available: %s", name)
        return False


def call_change_map_full(
    map_name: str,
    x: float,
    y: float,
    yaw: float,
    service_name: str = "/change_map",
):
    """
    切图并设置初始位姿
    等价于：
        isChange = True
        map_name 非空
    """
    if not wait_service(service_name):
        return False

    try:
        proxy = rospy.ServiceProxy(service_name, Switch)
        req = SwitchRequest()
        req.map_name = map_name
        req.x = x
        req.y = y
        req.z = 0.0

        qx, qy, qz, qw = quaternion_from_euler(0.0, 0.0, yaw)
        req.ox = qx
        req.oy = qy
        req.oz = qz
        req.ow = qw
        req.isChange = True

        resp = proxy(req)
        rospy.loginfo("change_map(full) response.result = %s", str(resp.result))
        return True
    except rospy.ServiceException as e:
        rospy.logerr("change_map(full) call failed: %s", str(e))
        return False


def call_change_map_pose_only(
    x: float,
    y: float,
    yaw: float,
    service_name: str = "/change_map",
):
    """
    只设置初始位姿
    等价于：
        isChange = True
        map_name 为空
    """
    if not wait_service(service_name):
        return False

    try:
        proxy = rospy.ServiceProxy(service_name, Switch)
        req = SwitchRequest()
        req.map_name = ""
        req.x = x
        req.y = y
        req.z = 0.0

        qx, qy, qz, qw = quaternion_from_euler(0.0, 0.0, yaw)
        req.ox = qx
        req.oy = qy
        req.oz = qz
        req.ow = qw
        req.isChange = True

        resp = proxy(req)
        rospy.loginfo("change_map(pose_only) response.result = %s", str(resp.result))
        return True
    except rospy.ServiceException as e:
        rospy.logerr("change_map(pose_only) call failed: %s", str(e))
        return False


def call_change_map_nav_only(
    map_name: str,
    service_name: str = "/change_map",
):
    """
    只刷新导航图
    等价于：
        isChange = False
        ow = -10000.0
    """
    if not wait_service(service_name):
        return False

    try:
        proxy = rospy.ServiceProxy(service_name, Switch)
        req = SwitchRequest()
        req.map_name = map_name
        req.x = 0.0
        req.y = 0.0
        req.z = 0.0
        req.ox = 0.0
        req.oy = 0.0
        req.oz = 0.0
        req.ow = -10000.0
        req.isChange = False

        resp = proxy(req)
        rospy.loginfo("change_map(nav_only) response.result = %s", str(resp.result))
        return True
    except rospy.ServiceException as e:
        rospy.logerr("change_map(nav_only) call failed: %s", str(e))
        return False


def call_srv_move(
    service_name: str = "/srv_move",
):
    """
    调用 /srv_move
    常见 type 例如：
        continue / cancel / end / estop / back / marker / location / cover
    """
    if not wait_service(service_name):
        return False

    try:
        proxy = rospy.ServiceProxy(service_name, MapManage)
        req = MapManageRequest()
        req.request_type = "changemap"
        req.request_data = "cc_1D_1F_carea,0.0,0.0,0.0"

        # req.request_type = "initpose"
        # req.request_data = "10.0,10.0,10.0"

        # req.request_type = "getmaplist"

        # req.request_type = "editmap"
        # req.request_data = "cc_1D_1F_carea"

        # req.request_type = "getmapdata"
        # req.request_type = "getdefaultmap"
        # marker / location 如果你后面要补参数，
        # 可以在这里继续填 req.marker / req.location
        resp = proxy(req)
        rospy.loginfo("srv_move response.data = %s", str(resp.response_data))
        return True
    except rospy.ServiceException as e:
        rospy.logerr("srv_move call failed: %s", str(e))
        return False


def build_parser():
    parser = argparse.ArgumentParser(
        description="Call /change_map and /srv_move in ROS1"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_change = subparsers.add_parser("change_map", help="call /change_map")
    p_change.add_argument(
        "--mode",
        choices=["full", "pose_only", "nav_only"],
        default="full",
        help="full=切图并设置位姿, pose_only=只设位姿, nav_only=只刷新导航图",
    )
    p_change.add_argument("--map", default="", help="地图名")
    p_change.add_argument("--x", type=float, default=0.0, help="x")
    p_change.add_argument("--y", type=float, default=0.0, help="y")
    p_change.add_argument("--yaw", type=float, default=0.0, help="yaw(rad)")
    p_change.add_argument(
        "--service",
        default="/change_map",
        help="change_map service name",
    )

    p_move = subparsers.add_parser("move", help="call /srv_move")
    p_move.add_argument(
        "--service",
        default="/srv_map",
        help="srv_move service name",
    )

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    rospy.init_node("call_change_map_and_move_client", anonymous=True)

    ok = False

    if args.command == "change_map":
        if args.mode == "full":
            if not args.map:
                rospy.logerr("--mode full requires --map")
                sys.exit(1)
            ok = call_change_map_full(
                map_name=args.map,
                x=args.x,
                y=args.y,
                yaw=args.yaw,
                service_name=args.service,
            )
        elif args.mode == "pose_only":
            ok = call_change_map_pose_only(
                x=args.x,
                y=args.y,
                yaw=args.yaw,
                service_name=args.service,
            )
        elif args.mode == "nav_only":
            if not args.map:
                rospy.logerr("--mode nav_only requires --map")
                sys.exit(1)
            ok = call_change_map_nav_only(
                map_name=args.map,
                service_name=args.service,
            )

    elif args.command == "move":
        ok = call_srv_move(
            service_name=args.service,
        )

    sys.exit(0 if ok else 2)


if __name__ == "__main__":
    main()
