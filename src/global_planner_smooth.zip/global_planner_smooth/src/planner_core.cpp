/*********************************************************************
 *
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2008, 2013, Willow Garage, Inc.
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of Willow Garage, Inc. nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *
 * Author: Eitan Marder-Eppstein
 *         David V. Lu!!
 * sukai 注释 2022-03-26
 *********************************************************************/
#include <global_planner/planner_core.h>
#include <pluginlib/class_list_macros.h>
#include <costmap_2d/cost_values.h>
#include <costmap_2d/costmap_2d.h>

#include <global_planner/dijkstra.h>
#include <global_planner/astar.h>
#include <global_planner/grid_path.h>
#include <global_planner/gradient_path.h>
#include <global_planner/quadratic_calculator.h>

// register this planner as a BaseGlobalPlanner plugin
PLUGINLIB_EXPORT_CLASS(global_planner::GlobalPlanner, nav_core::BaseGlobalPlanner)

namespace global_planner
{

    void GlobalPlanner::outlineMap(unsigned char *costarr, int nx, int ny, unsigned char value)
    {
        unsigned char *pc = costarr;
        for (int i = 0; i < nx; i++)
            *pc++ = value;
        pc = costarr + (ny - 1) * nx;
        for (int i = 0; i < nx; i++)
            *pc++ = value;
        pc = costarr;
        for (int i = 0; i < ny; i++, pc += nx)
            *pc = value;
        pc = costarr + nx - 1;
        for (int i = 0; i < ny; i++, pc += nx)
            *pc = value;
    }

    GlobalPlanner::GlobalPlanner() : costmap_(NULL), initialized_(false), allow_unknown_(true),
                                     p_calc_(NULL), planner_(NULL), path_maker_(NULL), orientation_filter_(NULL),
                                     potential_array_(NULL)
    {
    }

    GlobalPlanner::GlobalPlanner(std::string name, costmap_2d::Costmap2D *costmap, std::string frame_id) : GlobalPlanner()
    {
        // initialize the planner
        initialize(name, costmap, frame_id);
    }

    GlobalPlanner::~GlobalPlanner()
    {
        if (p_calc_)
            delete p_calc_;
        if (planner_)
            delete planner_;
        if (path_maker_)
            delete path_maker_;
        if (dsrv_)
            delete dsrv_;
    }

    void GlobalPlanner::initialize(std::string name, costmap_2d::Costmap2DROS *costmap_ros)
    {
        initialize(name, costmap_ros->getCostmap(), costmap_ros->getGlobalFrameID());
        footprint_ = costmap_ros->getRobotFootprint();// 20260709
        costmap_2d::calculateMinAndMaxDistances(footprint_, inscribed_radius_, circumscribed_radius_);
    }

    void GlobalPlanner::initialize(std::string name, costmap_2d::Costmap2D *costmap, std::string frame_id)
    {
        if (!initialized_)
        {
            ros::NodeHandle private_nh("~/" + name);
            costmap_ = costmap;
            frame_id_ = frame_id;
            unsigned int cx = costmap->getSizeInCellsX(), cy = costmap->getSizeInCellsY();

            private_nh.param("old_navfn_behavior", old_navfn_behavior_, false);
            if (!old_navfn_behavior_)
                convert_offset_ = 0.5;
            else
                convert_offset_ = 0.0;

            bool use_quadratic;
            private_nh.param("use_quadratic", use_quadratic, true);
            private_nh.param("cost_step", cost_step_, 50);
            // 根据选择new出对应的p_calc_实例. 计算“一个点”的可行性
            if (use_quadratic)
                p_calc_ = new QuadraticCalculator(cx, cy); // 使用二次差值近似的potential
            else
                p_calc_ = new PotentialCalculator(cx, cy); //

            bool use_dijkstra;
            private_nh.param("use_dijkstra", use_dijkstra, true);
            // 根据选择new出对应的planner实例. 计算“所有”的可行点
            if (use_dijkstra)
            {
                // dijkstra算法
                DijkstraExpansion *de = new DijkstraExpansion(p_calc_, cx, cy);
                if (!old_navfn_behavior_)
                    de->setPreciseStart(true);
                planner_ = de;
            }
            else
                planner_ = new AStarExpansion(p_calc_, cx, cy); // A*算法

            bool use_grid_path;
            private_nh.param("use_grid_path", use_grid_path, false);
            // 路径方法，new出path_maker_实例。从可行点中提取路径
            if (use_grid_path)
                // 栅格路径，从终点开始找上下或左右4个中最小的栅格直到起点
                path_maker_ = new GridPath(p_calc_);
            else
                // 梯度路径，从周围八个栅格中找到下降梯度最大的点
                path_maker_ = new GradientPath(p_calc_);

            orientation_filter_ = new OrientationFilter();

            plan_pub_ = private_nh.advertise<nav_msgs::Path>("raw_plan", 1);
            smooth_plan_pub_ = private_nh.advertise<nav_msgs::Path>("plan", 1);
            potential_pub_ = private_nh.advertise<nav_msgs::OccupancyGrid>("potential", 1);

            private_nh.param("allow_unknown", allow_unknown_, true);
            planner_->setHasUnknown(allow_unknown_);
            private_nh.param("planner_window_x", planner_window_x_, 0.0);
            private_nh.param("planner_window_y", planner_window_y_, 0.0);
            private_nh.param("default_tolerance", default_tolerance_, 0.0);
            private_nh.param("publish_scale", publish_scale_, 100);
            private_nh.param("outline_map", outline_map_, true);

            // make_plan_srv_ = private_nh.advertiseService("make_plan", &GlobalPlanner::makePlanService, this);// 20231113 庞风麟 取消服务

            dsrv_ = new dynamic_reconfigure::Server<global_planner::GlobalPlannerConfig>(ros::NodeHandle("~/" + name));
            dynamic_reconfigure::Server<global_planner::GlobalPlannerConfig>::CallbackType cb = boost::bind(
                &GlobalPlanner::reconfigureCB, this, _1, _2);
            dsrv_->setCallback(cb);

            initialized_ = true;
        }
        else
            ROS_WARN("This planner has already been initialized, you can't call it twice, doing nothing");
    }

    void GlobalPlanner::reconfigureCB(global_planner::GlobalPlannerConfig &config, uint32_t level)
    {
        planner_->setLethalCost(config.lethal_cost);
        path_maker_->setLethalCost(config.lethal_cost);
        planner_->setNeutralCost(config.neutral_cost);
        planner_->setFactor(config.cost_factor);
        publish_potential_ = config.publish_potential;
        orientation_filter_->setMode(config.orientation_mode);
        orientation_filter_->setWindowSize(config.orientation_window_size);
    }

    void GlobalPlanner::clearRobotCell(const geometry_msgs::PoseStamped &global_pose, unsigned int mx, unsigned int my)
    {
        if (!initialized_)
        {
            ROS_ERROR(
                "This planner has not been initialized yet, but it is being used, please call initialize() before use");
            return;
        }

        // set the associated costs in the cost map to be free
        costmap_->setCost(mx, my, costmap_2d::FREE_SPACE);
    }

    bool GlobalPlanner::makePlanService(nav_msgs::GetPlan::Request &req, nav_msgs::GetPlan::Response &resp)
    {
        makePlan(req.start, req.goal, resp.plan.poses);

        resp.plan.header.stamp = ros::Time::now();
        resp.plan.header.frame_id = frame_id_;

        return true;
    }

    void GlobalPlanner::mapToWorld(double mx, double my, double &wx, double &wy)
    {
        wx = costmap_->getOriginX() + (mx + convert_offset_) * costmap_->getResolution();
        wy = costmap_->getOriginY() + (my + convert_offset_) * costmap_->getResolution();
    }

    bool GlobalPlanner::worldToMap(double wx, double wy, double &mx, double &my)
    {
        double origin_x = costmap_->getOriginX(), origin_y = costmap_->getOriginY();
        double resolution = costmap_->getResolution();

        if (wx < origin_x || wy < origin_y)
            return false;

        mx = (wx - origin_x) / resolution - convert_offset_;
        my = (wy - origin_y) / resolution - convert_offset_;

        if (mx < costmap_->getSizeInCellsX() && my < costmap_->getSizeInCellsY())
            return true;

        return false;
    }

    bool GlobalPlanner::makePlan(const geometry_msgs::PoseStamped &start, const geometry_msgs::PoseStamped &goal,
                                 std::vector<geometry_msgs::PoseStamped> &plan)
    {
        return makePlan(start, goal, default_tolerance_, plan);
    }

    // 两个步骤完成路径的生成：
    //  1. 计算可行点矩阵potential_array (planner_->calculatePotentials)
    //  2. 从可行点矩阵中提取路径plan (path_maker_->getPath)）
    bool GlobalPlanner::makePlan(const geometry_msgs::PoseStamped &start, const geometry_msgs::PoseStamped &goal,
                                 double tolerance, std::vector<geometry_msgs::PoseStamped> &plan)
    {
        boost::mutex::scoped_lock lock(mutex_);
        // step 1: 是否已经初始化
        if (!initialized_)
        {
            ROS_ERROR(
                "This planner has not been initialized yet, but it is being used, please call initialize() before use");
            return false;
        }

        // 清空路径
        plan.clear();

        ros::NodeHandle n;
        std::string global_frame = frame_id_;

        // step 2.1 目标点的坐标系应该和全局坐标系一致
        if (goal.header.frame_id != global_frame)
        {
            ROS_ERROR(
                "The goal pose passed to this planner must be in the %s frame.  It is instead in the %s frame.", global_frame.c_str(), goal.header.frame_id.c_str());
            return false;
        }
        // step 2.2 起始点的坐标系应该和全局坐标系一致
        if (start.header.frame_id != global_frame)
        {
            ROS_ERROR(
                "The start pose passed to this planner must be in the %s frame.  It is instead in the %s frame.", global_frame.c_str(), start.header.frame_id.c_str());
            return false;
        }

        double wx = start.pose.position.x;
        double wy = start.pose.position.y;

        unsigned int start_x_i, start_y_i, goal_x_i, goal_y_i;
        double start_x, start_y, goal_x, goal_y;
        // step 3 判断起始点和目标点是否超出了全局代价地图的范围
        if (!costmap_->worldToMap(wx, wy, start_x_i, start_y_i))
        {
            ROS_WARN(
                "The robot's start position is off the global costmap. Planning will always fail, are you sure the robot has been properly localized?");
            return false;
        }
        if (old_navfn_behavior_)
        {
            start_x = start_x_i;
            start_y = start_y_i;
        }
        else
        {
            worldToMap(wx, wy, start_x, start_y);
        }

        wx = goal.pose.position.x;
        wy = goal.pose.position.y;

        if (!costmap_->worldToMap(wx, wy, goal_x_i, goal_y_i))
        {
            ROS_WARN_THROTTLE(1.0,
                              "The goal sent to the global planner is off the global costmap. Planning will always fail to this goal.");
            return false;
        }
        if (old_navfn_behavior_)
        {
            goal_x = goal_x_i;
            goal_y = goal_y_i;
        }
        else
        {
            worldToMap(wx, wy, goal_x, goal_y);
        }
        // step 4 清除起始单元格，它不可能是障碍物
        clearRobotCell(start, start_x_i, start_y_i);

        int nx = costmap_->getSizeInCellsX(), ny = costmap_->getSizeInCellsY();

        // step 5 确保global_planner用的数组大小和地图一致
        p_calc_->setSize(nx, ny);
        planner_->setSize(nx, ny);
        path_maker_->setSize(nx, ny);
        potential_array_ = new float[nx * ny];

        if (outline_map_)
            outlineMap(costmap_->getCharMap(), nx, ny, costmap_2d::LETHAL_OBSTACLE);
        // step 6 核心步骤， 计算出potential_array_
        // 20260403 start
        for (int cost_threshold = 0; cost_threshold < 253; cost_threshold += cost_step_)
        {
            planner_->setCostThreshold(cost_threshold);
            bool found_legal = planner_->calculatePotentials(costmap_->getCharMap(), start_x, start_y, goal_x, goal_y,
                                                             nx * ny * 2, potential_array_);
            if (!old_navfn_behavior_)
                planner_->clearEndpoint(costmap_->getCharMap(), potential_array_, goal_x_i, goal_y_i, 2);
            if (publish_potential_)
                publishPotential(potential_array_);
            if (found_legal)
            {
                // step 7 提取全局路径，用path_maker_->getPath得到路径
                if (getPlanFromPotential(start_x, start_y, goal_x, goal_y, goal, plan))
                {
                    // 更新目标点的时间戳，和路径的其他点时间戳一致
                    geometry_msgs::PoseStamped goal_copy = goal;
                    goal_copy.header.stamp = ros::Time::now();
                    plan.push_back(goal_copy);
                    ROS_INFO("Success to get a plan in the cost_threshold: %d ", cost_threshold);
                    break;
                }
                else
                {
                    ROS_ERROR("current cost_threshold is: %d ,Failed to get a plan from potential when a legal potential was found. This shouldn't happen.", cost_threshold);
                    continue;
                }
            }
            else
            {
                ROS_ERROR("current cost_threshold is: %d, Failed to get a plan.", cost_threshold);
                continue;
            }
        }
        // 20260403 end

        //  step 8 给路径添加方向
        orientation_filter_->processPath(start, plan);

        std::vector<geometry_msgs::PoseStamped> smooth_path = BsplineSmooth(plan, 0.05);
        // orientation_filter_->processPath(start, smooth_path);

        // 发布路径和可视化
        publishPlan(plan, plan_pub_);
        publishPlan(smooth_path, smooth_plan_pub_);
        plan = smooth_path;

        // 1. 可配置参数
        double angle_threshold = 0.785;               // 航向差阈值(rad≈90°)，小于该值边走边对齐，不做原地旋转校验
        double sample_step = 0.03;                                  // 旋转采样步长(rad≈1.7°)，步长越小精度越高
        unsigned char cost_threshold = costmap_2d::LETHAL_OBSTACLE; // 碰撞阈值
        double safety_margin = 0.23;                                // 角点安全裕度(m)，向外扩2cm避免擦碰

        // 2. 前置校验：路径点不足或航向差太小，直接跳过
        if (plan.size() >= 2)
        {
            double current_theta = tf::getYaw(start.pose.orientation);
            // 拟合路径起始段的期望朝向（前2点计算，可改为多点拟合提升平滑度）
            double dx = plan[1].pose.position.x - plan[0].pose.position.x;
            double dy = plan[1].pose.position.y - plan[0].pose.position.y;
            double target_theta = atan2(dy, dx);

            // 航向差小于阈值，无需原地旋转，直接跳过
            double angle_diff = fabs(angles::shortest_angular_distance(current_theta, target_theta));
            if (angle_diff > angle_threshold)
            {
                // 3. 获取全局代价地图与机器人轮廓
                double robot_x = start.pose.position.x;
                double robot_y = start.pose.position.y;

                // 4. 计算两个方向的绝对转角
                double delta_ccw = angles::normalize_angle_positive(target_theta - current_theta); // 逆时针转角 0~2π
                double delta_cw = 2 * M_PI - delta_ccw;                                            // 顺时针转角 0~2π
                std::cout << "delta_ccw: " << delta_ccw << ", delta_cw: " << delta_cw << std::endl;
                // 5. 辅助校验函数：原地旋转全程是否安全
                auto check_rotation_safe = [&](const bool is_ccw) -> bool
                {
                    double total_angle = is_ccw ? delta_ccw : delta_cw;
                    double step_dir = is_ccw ? sample_step : -sample_step;
                    int sample_num = static_cast<int>(ceil(fabs(total_angle) / fabs(step_dir)));

                    // 预计算车体四个角的径向扩展（加安全裕度）
                    std::vector<geometry_msgs::Point> corner_points = footprint_;
                    if (safety_margin > 1e-6)
                    {
                        for (auto &pt : corner_points)
                        {
                            double r = hypot(pt.x, pt.y);
                            if (r > 1e-6)
                            {
                                double scale = (r + safety_margin) / r;
                                pt.x *= scale;
                                pt.y *= scale;
                            }
                        }
                    }
                    std::cout << "校验方向: " << (is_ccw ? "逆时针(左)" : "顺时针(右)") << " 总转角: " << total_angle * 180 / M_PI << "度, 采样点数: " << sample_num << " 个" << std::endl;
                    // 逐角度采样校验
                    for (int i = 1; i <= sample_num; ++i)
                    {
                        double theta = current_theta + i * step_dir;
                        double cos_t = cos(theta);
                        double sin_t = sin(theta);

                        // 遍历四个角点，逐一校验碰撞
                        for (const auto &corner : corner_points)
                        {
                            double wx = robot_x + corner.x * cos_t - corner.y * sin_t;
                            double wy = robot_y + corner.x * sin_t + corner.y * cos_t;
                            unsigned int mx, my;
                            if (!costmap_->worldToMap(wx, wy, mx, my))
                                return false;
                            unsigned char cell_cost = costmap_->getCost(mx, my);
                            if (cell_cost >= cost_threshold)
                                return false;
                        }
                    }
                    return true;
                };

                // 6. 双方向安全校验
                bool ccw_safe = check_rotation_safe(true); // 逆时针（左转）是否安全
                bool cw_safe = check_rotation_safe(false); // 顺时针（右转）是否安全

                // 7. 方向决策
                bool default_prefer_ccw = (delta_ccw < delta_cw); // 默认逻辑：优先最小转角
                bool final_rotate_ccw = default_prefer_ccw;

                if (ccw_safe && !cw_safe)
                {
                    final_rotate_ccw = true;
                    std::cout << "GlobalPlanner: 顺时针旋转有障碍，强制逆时针对齐";
                }
                else if (!ccw_safe && cw_safe)
                {
                    final_rotate_ccw = false;
                    std::cout << "GlobalPlanner: 逆时针旋转有障碍，强制顺时针对齐";
                }
                else
                {
                    std::cout << "GlobalPlanner: 保持默认逻辑";
                }
                // 原理：微调路径前几段朝向，让"最小转角方向"恰好等于安全方向，下游自动按此旋转
                if (final_rotate_ccw != default_prefer_ccw)
                {
                    const int adjust_num = std::min(5, (int)plan.size());
                    // 计算安全方向的总转角（不是最短角，是完整旋转角度）
                    double total_angle = final_rotate_ccw ? delta_ccw : -delta_cw;
                    double step_angle = total_angle / adjust_num;

                    // 从当前朝向出发，沿安全方向逐点步进
                    for (int i = 0; i < adjust_num; ++i)
                    {
                        double theta_i = current_theta + step_angle * (i + 1);
                        // 这里即使theta_i超出±π也没关系，逐步进的差值方向始终正确
                        plan[i].pose.orientation = tf::createQuaternionMsgFromYaw(theta_i);
                    }
                }
            }
        }
        delete[] potential_array_;
        return !plan.empty();
    }

    void GlobalPlanner::publishPlan(const std::vector<geometry_msgs::PoseStamped> &path, ros::Publisher &pub)
    {
        if (!initialized_)
        {
            ROS_ERROR(
                "This planner has not been initialized yet, but it is being used, please call initialize() before use");
            return;
        }

        // create a message for the plan
        nav_msgs::Path gui_path;
        gui_path.poses.resize(path.size());

        gui_path.header.frame_id = frame_id_;
        gui_path.header.stamp = ros::Time::now();

        // Extract the plan in world co-ordinates, we assume the path is all in the same frame
        for (unsigned int i = 0; i < path.size(); i++)
        {
            gui_path.poses[i] = path[i];
        }

        pub.publish(gui_path);
    }

    // 获取路径(此时路径暂无朝向)
    bool GlobalPlanner::getPlanFromPotential(double start_x, double start_y, double goal_x, double goal_y,
                                             const geometry_msgs::PoseStamped &goal,
                                             std::vector<geometry_msgs::PoseStamped> &plan)
    {
        if (!initialized_)
        {
            ROS_ERROR(
                "This planner has not been initialized yet, but it is being used, please call initialize() before use");
            return false;
        }

        std::string global_frame = frame_id_;

        // 清空路径
        plan.clear();

        std::vector<std::pair<float, float>> path;
        // 这个path的点只有在map中的位置信息(x,y)
        if (!path_maker_->getPath(potential_array_, start_x, start_y, goal_x, goal_y, path))
        {
            ROS_ERROR("NO PATH!");
            return false;
        }

        ros::Time plan_time = ros::Time::now();
        // 将path中每个点转换到world下，方向信息还没加入，这里统一设为零，然后依次存储到plan中
        for (int i = path.size() - 1; i >= 0; i--)
        {
            std::pair<float, float> point = path[i];
            // 把map的全局路径转换到world下
            double world_x, world_y;
            mapToWorld(point.first, point.second, world_x, world_y);

            geometry_msgs::PoseStamped pose;
            pose.header.stamp = plan_time;
            pose.header.frame_id = global_frame;
            pose.pose.position.x = world_x;
            pose.pose.position.y = world_y;
            pose.pose.position.z = 0.0;
            pose.pose.orientation.x = 0.0;
            pose.pose.orientation.y = 0.0;
            pose.pose.orientation.z = 0.0;
            pose.pose.orientation.w = 1.0;
            plan.push_back(pose);
        }
        if (old_navfn_behavior_)
        {
            plan.push_back(goal);
        }
        return !plan.empty();
    }

    void GlobalPlanner::publishPotential(float *potential)
    {
        int nx = costmap_->getSizeInCellsX(), ny = costmap_->getSizeInCellsY();
        double resolution = costmap_->getResolution();
        nav_msgs::OccupancyGrid grid;
        // Publish Whole Grid
        grid.header.frame_id = frame_id_;
        grid.header.stamp = ros::Time::now();
        grid.info.resolution = resolution;

        grid.info.width = nx;
        grid.info.height = ny;

        double wx, wy;
        costmap_->mapToWorld(0, 0, wx, wy);
        grid.info.origin.position.x = wx - resolution / 2;
        grid.info.origin.position.y = wy - resolution / 2;
        grid.info.origin.position.z = 0.0;
        grid.info.origin.orientation.w = 1.0;

        grid.data.resize(nx * ny);

        float max = 0.0;
        for (unsigned int i = 0; i < grid.data.size(); i++)
        {
            float potential = potential_array_[i];
            if (potential < POT_HIGH)
            {
                if (potential > max)
                {
                    max = potential;
                }
            }
        }

        for (unsigned int i = 0; i < grid.data.size(); i++)
        {
            if (potential_array_[i] >= POT_HIGH)
            {
                grid.data[i] = -1;
            }
            else
            {
                if (fabs(max) < DBL_EPSILON)
                {
                    grid.data[i] = -1;
                }
                else
                {
                    grid.data[i] = potential_array_[i] * publish_scale_ / max;
                }
            }
        }
        potential_pub_.publish(grid);
    }
 
      // add new start
    double GlobalPlanner::CalculatePathLength(const std::vector<geometry_msgs::PoseStamped> &path)
    {
        double length = 0.0;
        for (size_t i = 1; i < path.size(); i++)
        {
            double dx = path[i].pose.position.x - path[i - 1].pose.position.x;
            double dy = path[i].pose.position.y - path[i - 1].pose.position.y;
            length += hypot(dx, dy);
        }
        return length;
    }

    // ========== 工具函数：路径去重，移除过近的冗余点 ==========
    std::vector<geometry_msgs::PoseStamped> GlobalPlanner::RemoveDuplicatePoints(const std::vector<geometry_msgs::PoseStamped> &path, double min_dist)
    {
        std::vector<geometry_msgs::PoseStamped> res;
        if (path.empty())
            return res;

        res.push_back(path.front());
        for (size_t i = 1; i < path.size(); ++i)
        {
            double dx = path[i].pose.position.x - res.back().pose.position.x;
            double dy = path[i].pose.position.y - res.back().pose.position.y;
            if (hypot(dx, dy) > min_dist)
            {
                res.push_back(path[i]);
            }
        }
        // 强制保留终点
        if (res.back().pose.position.x != path.back().pose.position.x ||
            res.back().pose.position.y != path.back().pose.position.y)
        {
            res.push_back(path.back());
        }
        return res;
    }

    // ========== 工具函数：按弧长等间距提取控制点 ==========
    std::vector<geometry_msgs::PoseStamped> GlobalPlanner::ExtractControlPoints(const std::vector<geometry_msgs::PoseStamped> &path, double spacing)
    {
        std::vector<geometry_msgs::PoseStamped> cps;
        if (path.size() < 2)
            return path;

        cps.push_back(path.front());
        double total_len = CalculatePathLength(path);
        double acc_len = 0.0;
        double target_len = spacing;

        for (size_t i = 1; i < path.size(); ++i)
        {
            double dx = path[i].pose.position.x - path[i - 1].pose.position.x;
            double dy = path[i].pose.position.y - path[i - 1].pose.position.y;
            double seg_len = hypot(dx, dy);
            if (seg_len < 1e-6)
                continue;

            // 按弧长插值生成均匀控制点
            while (acc_len + seg_len >= target_len && target_len < total_len - 1e-6)
            {
                double ratio = (target_len - acc_len) / seg_len;
                geometry_msgs::PoseStamped p;
                p.header = path.front().header;
                p.pose.position.x = path[i - 1].pose.position.x + ratio * dx;
                p.pose.position.y = path[i - 1].pose.position.y + ratio * dy;
                cps.push_back(p);
                target_len += spacing;
            }
            acc_len += seg_len;
        }
        cps.push_back(path.back());

        // 三次B样条至少需要4个控制点，不足则自动补点
        while (cps.size() < 4)
        {
            cps.insert(cps.begin() + cps.size() / 2, path[path.size() / 2]);
        }
        return cps;
    }

    // ========== B样条核心：查找参数t所在的节点区间 ==========
    int GlobalPlanner::FindKnotSpan(int degree, const std::vector<double> &knot, double t)
    {
        int n = knot.size() - degree - 2;
        // 边界特殊处理
        if (t >= knot.back() - 1e-6)
            return n;
        if (t <= knot.front() + 1e-6)
            return degree;

        // 二分查找加速
        int low = degree, high = n + 1;
        int mid = (low + high) / 2;
        while (t < knot[mid] || t >= knot[mid + 1])
        {
            if (t < knot[mid])
                high = mid;
            else
                low = mid;
            mid = (low + high) / 2;
        }
        return mid;
    }

    // ========== B样条核心：德布尔非递归算法计算曲线上点 ==========
    void GlobalPlanner::DeBoor(int degree, const std::vector<double> &knot,const std::vector<geometry_msgs::PoseStamped> &cps, double t, double &out_x, double &out_y)
    {
        int span = FindKnotSpan(degree, knot, t);
        std::vector<double> bx(degree + 1), by(degree + 1);

        // 初始化参与计算的控制点
        for (int j = 0; j <= degree; ++j)
        {
            bx[j] = cps[span - degree + j].pose.position.x;
            by[j] = cps[span - degree + j].pose.position.y;
        }

        // 德布尔递推公式
        for (int r = 1; r <= degree; ++r)
        {
            for (int j = degree; j >= r; --j)
            {
                double denom = knot[span + j + 1 - r] - knot[span + j - degree];
                if (fabs(denom) < 1e-6)
                    continue;
                double alpha = (t - knot[span + j - degree]) / denom;
                bx[j] = (1 - alpha) * bx[j - 1] + alpha * bx[j];
                by[j] = (1 - alpha) * by[j - 1] + alpha * by[j];
            }
        }
        out_x = bx[degree];
        out_y = by[degree];
    }
    
    bool GlobalPlanner::CheckCollision(const geometry_msgs::PoseStamped &pose)
    {
        double x = pose.pose.position.x;
        double y = pose.pose.position.y;
        double radius = circumscribed_radius_;

        unsigned int mx_min, mx_max, my_min, my_max;
        if (!costmap_->worldToMap(x - radius, y - radius, mx_min, my_min))
            return true;
        if (!costmap_->worldToMap(x + radius, y + radius, mx_max, my_max))
            return true;

        for (unsigned int mx = mx_min; mx <= mx_max; ++mx)
        {
            for (unsigned int my = my_min; my <= my_max; ++my)
            {
                double wx, wy;
                costmap_->mapToWorld(mx, my, wx, wy);
                double dx = wx - x;
                double dy = wy - y;
                if (dx * dx + dy * dy <= radius * radius)
                {
                    unsigned char cost = costmap_->getCost(mx, my);
                    if (cost == costmap_2d::LETHAL_OBSTACLE)
                        return true;
                }
            }
        }
        return false;
    }
    // std::vector<geometry_msgs::PoseStamped> GlobalPlanner::BsplineSmooth(const std::vector<geometry_msgs::PoseStamped> &global_path, double point_distance)
    // {
    //     // 路径过短直接返回
    //     if (global_path.size() < 4)
    //         return global_path;

    //     /***************
    //      * 1. 路径预处理：去重
    //      ***************/
    //     std::vector<geometry_msgs::PoseStamped> filtered_path = RemoveDuplicatePoints(global_path, 0.05);
    //     if (filtered_path.size() < 4)
    //         return global_path;

    //     /***************
    //      * 2. 多级平滑降级配置（从强到弱，单位：米）
    //      *    控制点间距越大，平滑越强，越容易偏离原路径
    //      ***************/
    //     const std::vector<double> smooth_levels = {0.7, 0.5, 0.35, 0.2};
    //     const int degree = 3;
    //     double total_length = CalculatePathLength(filtered_path);

    //     // 计算采样点数
    //     int sample_num = static_cast<int>(total_length / point_distance) + 1;
    //     sample_num = std::min(std::max(sample_num, 50), 1000);

    //     std::vector<geometry_msgs::PoseStamped> final_path;
    //     bool find_valid = false;

    //     /***************
    //      * 3. 逐级尝试平滑，找到第一个无碰撞的结果
    //      ***************/
    //     for (double spacing : smooth_levels)
    //     {
    //         // 3.1 提取当前等级的控制点
    //         std::vector<geometry_msgs::PoseStamped> control_points = ExtractControlPoints(filtered_path, spacing);
    //         int n = control_points.size() - 1;

    //         // 3.2 构造钳位节点向量（Clamped Knot Vector）
    //         std::vector<double> knot;
    //         // 前 degree+1 个节点为 0
    //         for (int i = 0; i <= degree; ++i)
    //             knot.push_back(0.0);
    //         // 中间节点均匀分布
    //         int inner_knot_num = n - degree;
    //         for (int i = 1; i <= inner_knot_num; ++i)
    //             knot.push_back(static_cast<double>(i) / (inner_knot_num + 1));
    //         // 后 degree+1 个节点为 1
    //         for (int i = 0; i <= degree; ++i)
    //             knot.push_back(1.0);

    //         // 3.3 德布尔算法采样生成平滑路径
    //         std::vector<geometry_msgs::PoseStamped> smooth_path;
    //         smooth_path.reserve(sample_num);
    //         for (int s = 0; s < sample_num; s++)
    //         {
    //             double t = static_cast<double>(s) / (sample_num - 1);
    //             geometry_msgs::PoseStamped pose;
    //             pose.header = global_path.front().header;

    //             double x, y;
    //             DeBoor(degree, knot, control_points, t, x, y);
    //             pose.pose.position.x = x;
    //             pose.pose.position.y = y;
    //             smooth_path.push_back(pose);
    //         }

    //         // 3.4 整体碰撞检测
    //         bool has_collision = false;
    //         for (const auto &pose : smooth_path)
    //         {
    //             if (CheckCollision(pose))
    //             {
    //                 has_collision = true;
    //                 break;
    //             }
    //         }

    //         if (!has_collision)
    //         {
    //             final_path = smooth_path;
    //             find_valid = true;
    //             break;
    //         }
    //     }

    //     // 所有等级都碰撞，退回原始路径
    //     if (!find_valid)
    //     {
    //         final_path = global_path;
    //     }

    //     /***************
    //      * 4. 重新计算航向角yaw
    //      ***************/
    //     for (size_t i = 0; i < final_path.size() - 1; i++)
    //     {
    //         double dx = final_path[i + 1].pose.position.x - final_path[i].pose.position.x;
    //         double dy = final_path[i + 1].pose.position.y - final_path[i].pose.position.y;
    //         double yaw = atan2(dy, dx);
    //         tf2::Quaternion q;
    //         q.setRPY(0, 0, yaw);
    //         final_path[i].pose.orientation = tf2::toMsg(q);
    //     }
    //     if (final_path.size() > 1)
    //     {
    //         final_path.back().pose.orientation = final_path[final_path.size() - 2].pose.orientation;
    //     }

    //     return final_path;
    // }
    std::vector<geometry_msgs::PoseStamped> GlobalPlanner::BsplineSmooth(const std::vector<geometry_msgs::PoseStamped> &global_path, double point_distance)
    {
        if (global_path.size() < 4)
            return global_path;

        /***************
         * 可调参数配置
         ***************/
        //const double smooth_margin = 0.2;                                     // 预筛选安全余量，设为0则不提前预判
        const std::vector<double> smooth_levels = {0.6, 0.4, 0.25, 0.1}; // 平滑等级：控制点间距，从强到弱
        const int degree = 3;
        //const double expand_radius = circumscribed_radius_ + smooth_margin;

        /***************
         * 1. 路径预处理：去重
         ***************/
        std::vector<geometry_msgs::PoseStamped> filtered_path = RemoveDuplicatePoints(global_path, 0.05);
        if (filtered_path.size() < 4)
            return global_path;

        /***************
         * 2. 预筛选：标记每个点是否属于可平滑的安全区域
         ***************/
        std::vector<bool> is_safe(filtered_path.size(), false);
        for (size_t i = 0; i < filtered_path.size(); ++i)
        {
            is_safe[i] = !CheckCollision(filtered_path[i]);
        }

        /***************
         * 3. 划分连续段（安全段/危险段）
         ***************/
        struct PathSegment
        {
            int start_idx;
            int end_idx;
            bool is_safe;
        };
        std::vector<PathSegment> segments;
        int seg_start = 0;
        bool current_safe = is_safe[0];

        for (size_t i = 1; i < filtered_path.size(); ++i)
        {
            if (is_safe[i] != current_safe)
            {
                segments.push_back({seg_start, (int)i - 1, current_safe});
                seg_start = i;
                current_safe = is_safe[i];
            }
        }
        segments.push_back({seg_start, (int)filtered_path.size() - 1, current_safe});

        /***************
         * 4. 逐段处理：安全段多级平滑降级，危险段保留原始路径
         ***************/
        std::vector<geometry_msgs::PoseStamped> final_path;

        for (size_t s = 0; s < segments.size(); ++s)
        {
            const auto &seg = segments[s];
            std::vector<geometry_msgs::PoseStamped> sub_path(
                filtered_path.begin() + seg.start_idx,
                filtered_path.begin() + seg.end_idx + 1);

            std::vector<geometry_msgs::PoseStamped> processed_seg;
            bool found_valid = false;

            if (seg.is_safe && sub_path.size() >= 4)
            {
                // 安全段：从强到弱依次尝试平滑等级
                for (double ctrl_spacing : smooth_levels)
                {
                    std::vector<geometry_msgs::PoseStamped> control_points = ExtractControlPoints(sub_path, ctrl_spacing);
                    int n = control_points.size() - 1;
                    if (n < degree)
                        continue; // 控制点不足，跳过该等级

                    // 构造钳位节点向量
                    std::vector<double> knot;
                    for (int i = 0; i <= degree; ++i)
                        knot.push_back(0.0);
                    int inner_knot_num = n - degree;
                    for (int i = 1; i <= inner_knot_num; ++i)
                        knot.push_back(static_cast<double>(i) / (inner_knot_num + 1));
                    for (int i = 0; i <= degree; ++i)
                        knot.push_back(1.0);

                    // 采样生成平滑路径
                    double seg_len = CalculatePathLength(sub_path);
                    int sample_num = static_cast<int>(seg_len / point_distance) + 1;
                    sample_num = std::min(std::max(sample_num, 20), 500);

                    std::vector<geometry_msgs::PoseStamped> smooth_seg;
                    for (int i = 0; i < sample_num; ++i)
                    {
                        double t = static_cast<double>(i) / (sample_num - 1);
                        geometry_msgs::PoseStamped pose;
                        pose.header = global_path.front().header;
                        double x, y;
                        DeBoor(degree, knot, control_points, t, x, y);
                        pose.pose.position.x = x;
                        pose.pose.position.y = y;
                        smooth_seg.push_back(pose);
                    }

                    // 碰撞检测：该等级平滑后无碰撞则采用
                    bool has_collision = false;
                    for (const auto &pose : smooth_seg)
                    {
                        if (CheckCollision(pose))
                        {
                            has_collision = true;
                            break;
                        }
                    }

                    if (!has_collision)
                    {
                        processed_seg = smooth_seg;
                        found_valid = true;
                        break;
                    }
                }
            }

            // 所有平滑等级都失败，或本身是危险段/过短段：重采样保留原始路径
            if (!found_valid)
            {
                processed_seg = ResamplePath(sub_path, point_distance);
            }

            // 拼接到最终结果（跳过重复首点）
            if (s == 0)
            {
                final_path.insert(final_path.end(), processed_seg.begin(), processed_seg.end());
            }
            else
            {
                final_path.insert(final_path.end(), processed_seg.begin() + 1, processed_seg.end());
            }
        }

        /***************
         * 5. 统一计算航向角yaw
         ***************/
        for (size_t i = 0; i < final_path.size() - 1; i++)
        {
            double dx = final_path[i + 1].pose.position.x - final_path[i].pose.position.x;
            double dy = final_path[i + 1].pose.position.y - final_path[i].pose.position.y;
            double yaw = atan2(dy, dx);
            tf2::Quaternion q;
            q.setRPY(0, 0, yaw);
            final_path[i].pose.orientation = tf2::toMsg(q);
        }
        if (final_path.size() > 1)
        {
            final_path.back().pose.orientation = final_path[final_path.size() - 2].pose.orientation;
        }

        return final_path;
    }
    std::vector<geometry_msgs::PoseStamped> GlobalPlanner::ResamplePath(
        const std::vector<geometry_msgs::PoseStamped> &path, double point_spacing)
    {
        std::vector<geometry_msgs::PoseStamped> res;
        if (path.size() < 2)
            return path;

        res.push_back(path.front());
        double total_len = CalculatePathLength(path);
        double acc_len = 0.0;
        double target_len = point_spacing;

        for (size_t i = 1; i < path.size(); ++i)
        {
            double dx = path[i].pose.position.x - path[i - 1].pose.position.x;
            double dy = path[i].pose.position.y - path[i - 1].pose.position.y;
            double seg_len = hypot(dx, dy);
            if (seg_len < 1e-6)
                continue;

            while (acc_len + seg_len >= target_len && target_len < total_len - 1e-6)
            {
                double ratio = (target_len - acc_len) / seg_len;
                geometry_msgs::PoseStamped p;
                p.header = path.front().header;
                p.pose.position.x = path[i - 1].pose.position.x + ratio * dx;
                p.pose.position.y = path[i - 1].pose.position.y + ratio * dy;
                res.push_back(p);
                target_len += point_spacing;
            }
            acc_len += seg_len;
        }
        res.push_back(path.back());
        return res;
    }

} // end namespace global_planner
