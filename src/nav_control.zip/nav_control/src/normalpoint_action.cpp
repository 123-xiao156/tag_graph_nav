/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	move_action.cpp
 * * @description:  门禁、乘梯、覆盖，乘梯动作
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "normalpoint_action.h"

std::string getVoiceNameByPointName(std::string pointName);

NormalpointAction::NormalpointAction(ros::NodeHandle nh) : nh_(nh)
{
    nh_.param<int>("nav_version", nav_, 1); //#1move_base导航，2nav_base导航
	string nav_node="";
    if(nav_==1)
    {
        nav_node="/move_base";
    }
    if(nav_==2)
    {
        nav_node="/task_base";
    }
    clear_costmap_client_ = nh_.serviceClient<std_srvs::Empty>(nav_node+"/clear_costmaps");
    pub_voice_ = nh_.advertise<robot_msgs::Voice>("/voiceplay", 10);
    nh_.param("car_type", car_type_, std::string("UC"));
}

// 初始化，创建线程
void NormalpointAction::Init()
{
    interval_ms_ = 100;
    std::thread t(&NormalpointAction::TimerThread, this, interval_ms_);
    t.detach();
}

// 线程开始
void NormalpointAction::TimerThread(int16_t interval_ms)
{
    while (ros::ok())
    {
        if (!thread_pause_flag_)
        {
            MainLoop();
        }
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
/**********************************************************************
 * @function    PublishVoice
 * @brief       发布音频信息到ROS话题
 * @input       data: 日志内容字符串
 * @output      无
 * @return      无
 * @author      jiangcuihuan
 * @date        202310
 **********************************************************************/
void NormalpointAction::PublishVoice(std::string name)
{
    robot_msgs::Voice msg;
    msg.info_volume = 70;    // 音量70%
    msg.info_type = "voice"; // 播放语音
    msg.info_data = name;    // 语音名称，见语音列表
    pub_voice_.publish(msg);
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       接收interface_action发送的指令的槽函数
 * * @input:       movecmd: 包含移动命令数据的QVariant对象
 * * @output:      更新数据库，处理各种导航命令
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NormalpointAction::slot_NewCmd(QVariant movecmd)
{
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();
    if (mdc.taskcmd_type == TaskStatus::T_ESTOP)
    {
        thread_pause_flag_ = true;
        process_index_ = ProcessIndex::STEP0;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP)
    {
        thread_pause_flag_ = true;
        process_index_ = ProcessIndex::STEP0;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_CANCEL)
    {
        if (!p_shard_data_->current_lift_state_)
        {
            thread_pause_flag_ = true;
            process_index_ = ProcessIndex::STEP0;
        }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_GOON)
    {
        thread_pause_flag_ = false;
        process_index_ = ProcessIndex::STEP0;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_END)
    {
        thread_pause_flag_ = true;
        process_index_ = ProcessIndex::STEP0;
    }
    LOG(INFO) << "slot_NewCmd接收到interface_action的新指令:" << mdc.taskcmd_type;
}
/**********************************************************************
 * * @function:    SetCmd 
 * * @brief:       从navcontrol的TASK_HANDOUT调用此命令
 * * @input:       cmd_type  pdata
 * * @output:      更新数据库，处理各种导航命令
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
// 
void NormalpointAction::SetCmd(std::string cmd_type, PoseData pdata)
{
    LOG(INFO) << "SetCmd normalpoint 被调用，current_lift_state_=" << p_shard_data_->current_lift_state_;
    if (p_shard_data_->current_lift_state_)
    {
        LOG(INFO) << "在乘梯状态不再立即执行指令，等待乘梯状态结束继续执行最后一次发的指令";
        p_shard_data_->continue_state_ = true;
        p_shard_data_->storage_cmd_type = cmd_type;
        p_shard_data_->storage_pdata = pdata;
        thread_pause_flag_ = false;
        process_index_ = ProcessIndex::STEP0;
    }
    else
    {
        LOG(INFO) << "navcontrol调用normalpoint_action的SetCmd发送指令进行导航";
        mtx_.lock();
        goal_point_.point_name = pdata.point_name;
        goal_point_.map = pdata.map;
        goal_point_.type = pdata.type;
        goal_point_.x = pdata.x;
        goal_point_.y = pdata.y;
        goal_point_.yaw = pdata.yaw;
        thread_pause_flag_ = false;
        process_index_ = ProcessIndex::STEP1;
        mtx_.unlock();
    }
}

// 定时器线程执行任务
void NormalpointAction::MainLoop()
{
    static int s_aborate_cnt = 0;
    static int s_time_cnt = 0;
    static int s_num = 0;
    if (s_aborate_cnt > 60000)
    {
        s_aborate_cnt = 0;
    }
    if (s_time_cnt > 60000)
    {
        s_time_cnt = 0;
    }
    if (s_num >= 60000)
    {
        s_num = 0;
    }

    switch (process_index_)
    {
    case ProcessIndex::STEP0:
    {
        if (p_shard_data_->continue_state_)
        {
            if (p_shard_data_->access_lift_shared_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
            {
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;
                LOG(INFO) << "STEP0:等待乘梯完成，完成了开始继续最新的任务";
                p_shard_data_->current_lift_state_ = false;
                p_shard_data_->continue_state_ = false;
                SetCmd(p_shard_data_->storage_cmd_type, p_shard_data_->storage_pdata);
                break;
            }
        }
    }
    break;
    // 请求门禁闸机和乘梯
    case ProcessIndex::STEP1:
    {
        s_aborate_cnt = 0;
        s_time_cnt = 0;
        s_num = 0;
        p_shard_data_->current_lift_state_flag_ = true;
        // 请求门禁闸机和乘梯命令
        MoveDataCmd mdc;
        mdc.taskcmd_type = TaskStatus::T_LOCALE;
        PoseData pose;
        pose.x = goal_point_.x;
        pose.y = goal_point_.y;
        pose.yaw = goal_point_.yaw;
        pose.type = goal_point_.type;
        pose.map = goal_point_.map;
        mdc.goal.push_back(pose);
        QVariant qvr;
        qvr.setValue(mdc);
        // 信号槽，请求门禁闸机和乘梯
        emit signal_AccessLiftCmd(qvr);
        process_index_ = ProcessIndex::STEP2;
        LOG(INFO) << "STEP1:请求门禁闸机和乘梯，目标地图名称为: " << goal_point_.map;
    }
    break;
    // 等待门禁闸机和乘梯的结果
    case ProcessIndex::STEP2:
    {
        if (s_num % 50 == 0)
        {
            LOG(INFO) << "STEP2:正在等待门禁闸机和乘梯的结果";
        }
        s_num++;
        // 门禁闸机和乘梯的结果
        if (p_shard_data_->access_lift_shared_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        {
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;
            
            
            p_shard_data_->current_lift_state_ = false;
            p_shard_data_->current_lift_state_flag_ = false;
            
            
            process_index_ = ProcessIndex::STEP9;
            LOG(INFO) << "STEP2:门禁闸机和乘梯通过";
            if (p_shard_data_->continue_state_)
            {
                p_shard_data_->current_lift_state_ = false;
                p_shard_data_->continue_state_ = false;
                thread_pause_flag_ = true;
                LOG(INFO) << "STEP2:门禁闸机和乘梯通过，但是在乘梯时最新发送的指令是返航，开始进行返航任务";
            }
        }
        else if (p_shard_data_->access_lift_shared_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        {
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_ABORTED;
            process_index_ = ProcessIndex::STEP0;
            p_shard_data_->current_lift_state_ = false;
            p_shard_data_->current_lift_state_flag_ = false;
            thread_pause_flag_ = true;
            LOG(INFO) << "STEP2:门禁闸机和乘梯中止";
        }
        else if (p_shard_data_->access_lift_shared_nav_status_.goal_status == NavStatus::NAV_FAILED)
        {
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_FAILED;
            process_index_ = ProcessIndex::STEP0;
            p_shard_data_->current_lift_state_ = false;
            p_shard_data_->current_lift_state_flag_ = false;
            thread_pause_flag_ = true;
            LOG(INFO) << "STEP2:门禁闸机和乘梯失败";
        }
    }
    break;
    // 门禁闸机和乘梯完成，开始发送目标点
    case ProcessIndex::STEP9:
    {
        p_shard_data_->current_lift_state_ = false;
        p_shard_data_->current_lift_state_flag_ = false;

        // 目标点
        MoveDataCmd mdc;
        mdc.taskcmd_type = TaskStatus::T_LOCALE;
        PoseData pose;
        pose.x = goal_point_.x;
        pose.y = goal_point_.y;
        pose.yaw = goal_point_.yaw;
        pose.type = goal_point_.type;
        pose.map = goal_point_.map;
        mdc.goal.push_back(pose);
        QVariant qvr;
        qvr.setValue(mdc);
        // 信号槽，请求move_action，进行路径规划
        emit signal_MoveCmd(qvr);
        process_index_ = ProcessIndex::STEP10;
        LOG(INFO) << "STEP9:门禁闸机和乘梯完成，开始发送目标点";
    }
    break;
    // 等待移动到目标点的结果
    case ProcessIndex::STEP10:
    {
        if (p_shard_data_->move_status_ == MoveStatus::ARRIVE)
        {
            if (car_type_ == "DR-01")
            {
                std::string pointName = goal_point_.point_name;

                // 先把点的名称转成小写
                std::transform(pointName.begin(), pointName.end(), pointName.begin(),
                               [](unsigned char c)
                               { return std::tolower(c); });

                if (pointName == "kitchen")
                {
                    PublishVoice("Kitchen1");
                }
                else
                {
                    std::string voiceName = getVoiceNameByPointName(pointName);
                    if (voiceName != "")
                    {
                        PublishVoice(voiceName);
                    }
                    else
                    {
                        PublishVoice("AtTheTabe1");
                    }
                    usleep(150000); // 150ms
                    PublishVoice("Finish");
                }
            }
            
            // 目标点成功到达
            s_aborate_cnt = 0;
            s_time_cnt = 0;
            s_num = 0;
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            process_index_ = ProcessIndex::STEP0;
            p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_SUCCESS; 
            LOG(INFO) << "STEP10:门禁闸机和乘梯完成后，目标点到达";

            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->move_status_ == MoveStatus::ABORTED)
        {
            // 重置move_action导航状态
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            if (s_aborate_cnt >= p_shard_data_->nav_resend_time_)
            {
                s_time_cnt = 0;
                s_aborate_cnt = 0;
                s_num = 0;
                p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_ABORTED;

                LOG(ERROR) << "STEP10:门禁闸机和乘梯完成后，导航失败第 " + std::to_string(s_aborate_cnt) + "次，无法导航成功，中止导航";
                process_index_ = ProcessIndex::STEP0;
                thread_pause_flag_ = true;
            }
            else
            {
                // 重新发送目标点进行导航
                s_aborate_cnt++;
                process_index_ = ProcessIndex::STEP11;
                // 20250728 c_add 处理导航失败的策略，先清空障碍层，延时重新发点
                std_srvs::Empty srv;
                LOG(INFO) << "STEP10:move_action导航到目标点导航失败第 " << s_aborate_cnt << " 次，重新发送目标点";
                if(!clear_costmap_client_.waitForExistence(ros::Duration(10)))
                {
                    LOG(ERROR) << "clear_costmap_ died";
                }        
                clear_costmap_client_.call(srv);
                s_time_cnt = 0;
            }
        }
    }
    break;
    case ProcessIndex::STEP11:
    {
        s_time_cnt++;
        // 等待50*100ms=5s重新规划一次
        if (s_time_cnt % 50 == 0)
        {
            if (car_type_ == "DR-01")
            {
                PublishVoice("EncounterPerdestrian");
            }
            else
            {
                // PublishVoice("NoPass");
            }
            // 重新发送目标点
            process_index_ = ProcessIndex::STEP9;
            LOG(INFO) << "STEP11:move_action导航到目标点导航失败，清空代价地图后，重新发送目标点";
        }
    }
    break;
    default:
        break;
    }
}
/**********************************************************************
 * @function    getVoiceNameByPointName
 * @brief       通过点使用对于音频名称
 * @input       pointName: 点名称，导航点，门禁点...
 * @output      无
 * @return      无
 * @author      jiangcuihuan
 * @date        202310
 **********************************************************************/
std::string getVoiceNameByPointName(std::string pointName)
{
    if (pointName.size() < 2)
    {
        return "";
    }else
    {
        std::string num = pointName.substr(1);
        return "ArriveTable" + num;
    }
}
