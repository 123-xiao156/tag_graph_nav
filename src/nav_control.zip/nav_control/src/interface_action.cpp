/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	interface_action.cpp
 * * @description:  门禁、乘梯、覆盖
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "interface_action.h"
#include <robot_msgs/Web.h>

InterfaceAction::InterfaceAction(ros::NodeHandle nh) : nh_(nh)
{
    // 定义移动命令服务接口
    api_service_ = nh_.advertiseService("/srv_move", &InterfaceAction::callback_ApiService, this);
    pub_voice_ = nh_.advertise<robot_msgs::Voice>("/voiceplay", 10);
    path_query_client = nh_.serviceClient<robot_msgs::Web>("/srv_teach_path");
    // 20250902 c_add 添加乘梯功能关闭时检查当前地图与指令地图是否匹配
    nh_.param<bool>("lift", autolift_, false);
}

// 初始化，创建线程
void InterfaceAction::Init()
{
    interval_ms_ = 100;
    std::thread t(&InterfaceAction::TimerThread, this, interval_ms_);
    t.detach();
}

// 线程开始
void InterfaceAction::TimerThread(int16_t interval_ms)
{
    while (ros::ok())
    {
        // TODO
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
/**********************************************************************
 * * @function:    PublishVoice 
 * * @brief:       发布语音
 * * @input:       data: 语音名称
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void InterfaceAction::slot_PubVoice(std::string name)
{
    PublishVoice(name);
}
/**********************************************************************
 * * @function:    PublishVoice 
 * * @brief:       发布语音
 * * @input:       data: 语音名称
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void InterfaceAction::PublishVoice(std::string name)
{
    robot_msgs::Voice msg;
    msg.info_volume = 70;    // 音量70%
    msg.info_type = "voice"; // 播放语音
    msg.info_data = name;    // 语音名称，见语音列表
    pub_voice_.publish(msg);
}
/**********************************************************************
 * * @function:    callback_ApiService 
 * * @brief:       解析控制中心发送的导航命令，处理路标点和路点数据
 * * @input:       request: 服务请求，包含命令类型、路标点和路点数组
 * * @input:       response: 服务响应，返回执行状态
 * * @output:      response: 填充响应数据，发送命令到导航控制模块
 * * @return:      bool: 总是返回true，表示服务调用成功
 * * @note:        支持的命令类型：cancel、end、estop、continue、back、marker、location、estop_task、continue_task
 * *               响应状态格式："running[mapname,x,y,yaw]/success/failed[错误码]"
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
bool InterfaceAction::callback_ApiService(robot_msgs::Move::Request &request, robot_msgs::Move::Response &response)
{
    // 命令类型cancel、end、estop、continue、back、marker、location、estop_task、continue_task
    string cmd_word = request.type;
    // 输出marker点和location点到日志中
    std::string marker;
    std::string location;
    for (int i = 0; i < request.marker.size(); i++)
    {
        marker += request.marker[i].mapname + ":" + request.marker[i].markername + ",";
    }
    for (int i = 0; i < request.location.size(); i++)
    {
        location += request.location[i].mapname + ":" + std::to_string(request.location[i].x) + "_" + std::to_string(request.location[i].y) + "_" + std::to_string(request.location[i].yaw) + ",";
    }
    LOG(INFO) << "收到了srv_move命令: 命令类型为: " << cmd_word << " ,路点marker为: " << marker << " ,路点location为: " << location;

    // 导航发送新任务时复位乘梯状态
    p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;

    // 解析命令，发送给navcontrol
    if (cmd_word == "cancel")
    {
        // 复位乘梯中收到导航取消命令
        p_shard_data_->lift_cancel_ = false;
        SendCmd(TaskStatus::T_CANCEL);
        response.data = "success";
    }
    else if (cmd_word == "end")
    {
        // 复位乘梯中收到导航取消命令
        p_shard_data_->lift_cancel_ = false;
        SendCmd(TaskStatus::T_END);
        // 复位乘梯时发送新命令的一些标志位
        p_shard_data_->current_lift_state_ = false;
        p_shard_data_->continue_state_ = false;
        p_shard_data_->current_lift_state_flag_ = false;
        response.data = "success";
    }
    else if (cmd_word == "estop")
    {
        SendCmd(TaskStatus::T_ESTOP);
        response.data = "success";
    }
    else if (cmd_word == "continue")
    {
        SendCmd(TaskStatus::T_GOON);
        response.data = "success";
    }
    else if (cmd_word == "back")
    {
        emit signal_PubStatus("running");
        SendCmd(TaskStatus::T_BACK);
        response.data = "running";
    }
    else if (cmd_word == "marker")
    {
        if (request.marker.size() <= 0)
        {
            emit signal_PubStatus("MARKER_POINT_NULL");
            p_shard_data_->fault_code_.B0410 = true;
            LOG(ERROR) << "收到的marker点为空";
            response.data = "running";
            return true;
        }
        else
        {
            p_shard_data_->fault_code_.B0410 = false;
        }
        emit signal_PubStatus("running");

        // 清空所有任务队列
        std::vector<ApiPointInfo> empty;
        std::swap(empty, p_shard_data_->api_recved_target_vector_);
        std::vector<std::string> empty_path;
        std::swap(empty_path, p_shard_data_->api_recved_path_vector_);
        std::vector<std::string> empty_cpath;
        std::swap(empty_cpath, p_shard_data_->api_recved_cpath_vector_); // 清空覆盖路径队列

        int size_l = request.marker.size();
        p_shard_data_->fault_code_.B0498 = false;
        
        // 步骤1：同时查询数据库获取所有示教路径和覆盖路径
        std::vector<std::pair<std::string, std::string>> all_teach_paths; // 存储<map_name, path_name>
        std::vector<std::pair<std::string, std::string>> all_cover_paths; // 存储<map_name, cpath_name>
        bool teach_db_query_success = false;
        bool cover_db_query_success = false;
        //小区域清扫特有路径名称
        std::vector<std::string> area_clean_names = {"area_clean_1", "area_clean_2", "area_clean_3"};
        
        // 查询示教路径（Tquery）
        if (path_query_client.waitForExistence(ros::Duration(2.0))) {
            robot_msgs::Web srv;
            srv.request.request_type = "Tquery";
            srv.request.request_data = "";
            
            if (path_query_client.call(srv) && srv.response.response_type == "success") {
                std::string result = srv.response.response_data;
                QByteArray json_data = result.c_str();
                QJsonDocument doc = QJsonDocument::fromJson(json_data);
                
                if (!doc.isNull() && doc.isObject()) {
                    QJsonObject root = doc.object();
                    if (root.contains("paths") && root["paths"].isArray()) {
                        QJsonArray paths_array = root["paths"].toArray();
                        
                        for (const QJsonValue& path_value : paths_array) {
                            if (path_value.isObject()) {
                                QJsonObject path_obj = path_value.toObject();
                                if (path_obj.contains("map") && path_obj.contains("name")) {
                                    string map_name = path_obj["map"].toString().toStdString();
                                    string path_name = path_obj["name"].toString().toStdString();
                                    all_teach_paths.push_back(std::make_pair(map_name, path_name));
                                }
                            }
                        }
                        teach_db_query_success = true;
                        LOG(INFO) << "查询到 " << all_teach_paths.size() << " 条示教路径";
                    }
                }
            }
        }
        
        // 查询覆盖路径（Cquery） - 使用相同的服务客户端
        if (path_query_client.waitForExistence(ros::Duration(2.0))) {
            robot_msgs::Web srv;
            srv.request.request_type = "Cquery";  // 使用Cquery查询覆盖路径
            srv.request.request_data = "";
            
            if (path_query_client.call(srv) && srv.response.response_type == "success") {
                std::string result = srv.response.response_data;
                QByteArray json_data = result.c_str();
                QJsonDocument doc = QJsonDocument::fromJson(json_data);
                
                if (!doc.isNull() && doc.isObject()) {
                    QJsonObject root = doc.object();
                    if (root.contains("paths") && root["paths"].isArray()) {
                        QJsonArray cpaths_array = root["paths"].toArray();
                        
                        for (const QJsonValue& cpath_value : cpaths_array) {
                            if (cpath_value.isObject()) {
                                QJsonObject cpath_obj = cpath_value.toObject();
                                if (cpath_obj.contains("map") && cpath_obj.contains("name")) {
                                    string map_name = cpath_obj["map"].toString().toStdString();
                                    string cpath_name = cpath_obj["name"].toString().toStdString();
                                    all_cover_paths.push_back(std::make_pair(map_name, cpath_name));
                                }
                            }
                        }
                        cover_db_query_success = true;
                        LOG(INFO) << "查询到 " << all_cover_paths.size() << " 条覆盖路径";
                    }
                }
            }
        }
        
        if (!teach_db_query_success && !cover_db_query_success) {
            LOG(WARNING) << "路径查询失败，所有点按普通点处理";
        }
        
        // 步骤2：检查每个点的类型（普通点、示教路径、覆盖路径、小区域清扫）
        bool has_teach_paths = false;
        bool has_cover_paths = false;
        bool has_normal_points = false;
        bool has_area_clean_points = false;
        
        // 为每个点标记类型
        std::vector<int> point_types(size_l, 0); // 0=未知, 1=普通点, 2=示教路径, 3=覆盖路径, 4=小区域清扫
        
        for (int i = 0; i < size_l; i++)
        {
            string map_name = request.marker[i].mapname;
            string point_name = request.marker[i].markername;
            
            bool is_teach_path = false;
            bool is_cover_path = false;
            bool is_area_clean = false;

            //检查是否是小区域清扫路径
            for (const auto& area_name : area_clean_names) {
                if (point_name == area_name) {
                    is_area_clean = true;
                    break;
                }
            }
            
            // 检查是否是示教路径
            if (teach_db_query_success) {
                for (const auto& path : all_teach_paths) {
                    if (path.first == map_name && path.second == point_name) {
                        is_teach_path = true;
                        break;
                    }
                }
            }
            
            // 检查是否是覆盖路径
            if (cover_db_query_success) {
                for (const auto& cpath : all_cover_paths) {
                    if (cpath.first == map_name && cpath.second == point_name) {
                        is_cover_path = true;
                        break;
                    }
                }
            }
            
            if (is_teach_path) {
                point_types[i] = 2; // 示教路径
                has_teach_paths = true;
                LOG(INFO) << "点 " << map_name << "/" << point_name << " 是示教路径";
            } 
            else if (is_cover_path) {
                point_types[i] = 3; // 覆盖路径
                has_cover_paths = true;
                LOG(INFO) << "点 " << map_name << "/" << point_name << " 是覆盖路径";
            } 
            else if (is_area_clean) {
                point_types[i] = 4; // 小区域清扫
                has_area_clean_points = true;
                LOG(INFO) << "点 " << map_name << "/" << point_name << " 是小区域清扫点";
            }
            else {
                point_types[i] = 1; // 普通点
                has_normal_points = true;
                LOG(INFO) << "点 " << map_name << "/" << point_name << " 是普通点";
            }
        }
        // 步骤4：不再按类型分开处理，而是全部放入统一队列

        for (int i = 0; i < size_l; i++)
        {
            string map_name = request.marker[i].mapname;
            string point_name = request.marker[i].markername;
            //string point_task = request.marker[i].task;
            
            if (!autolift_ && map_name != p_shard_data_->current_map_)
            {
                p_shard_data_->fault_code_.B0498 = true;
                LOG(ERROR) << "不乘梯时收到的点为其他楼层的点";
                return false;
            }
            
            // 根据类型创建不同的 point_type
            string point_type;
            if (point_types[i] == 2) {
                point_type = "teach_path";
            } else if (point_types[i] == 3) {
                point_type = "cover_path";
            }else if (point_types[i] == 4) {
                point_type = "cover";
            }
            else {
                point_type = "market";
            }
            //if(point_types[i] == 2||point_types[i] == 3){
            //    point_task=point_task;
            //}else {
            //    point_task="none";
            //}
            //ApiPointInfo point_info(point_name, map_name, point_type,point_task, 0, 0, 0);
            ApiPointInfo point_info(point_name, map_name, point_type , 0, 0, 0);
            p_shard_data_->api_recved_target_vector_.push_back(point_info);
            
            LOG(INFO) << "添加点到统一队列: 名称=" << point_name << ", 地图=" << map_name << ", 类型=" << point_type;
        }

        // 发送统一的命令
        if (!p_shard_data_->api_recved_target_vector_.empty()) {
            LOG(INFO) << "添加了 " << p_shard_data_->api_recved_target_vector_.size() << " 个点到统一队列";
            SendCmd(TaskStatus::T_MARKET);
            response.data = "running";
        } else {
            response.data = "failed";
        }
    }
    else if (cmd_word == "location")
    {
        if (request.location.size() <= 0)
        {
            emit signal_PubStatus("LOCATION_POINT_NULL");
            p_shard_data_->fault_code_.B0410 = true;
            LOG(ERROR) << "收到的location点为空";
            response.data = "running";
            return true;
        }
        else
        {
            p_shard_data_->fault_code_.B0410 = false;
        }
        emit signal_PubStatus("running");

        // 将location点的位置信息传入到共享数据中
        p_shard_data_->location_point_.x = request.location[0].x;
        p_shard_data_->location_point_.y = request.location[0].y;
        p_shard_data_->location_point_.yaw = request.location[0].yaw;

        SendCmd(TaskStatus::T_LOCALE);
        response.data = "running";
    }
    else if (cmd_word == "estop_task")
    {
        SendCmd(TaskStatus::T_TASK_ESTOP);
        response.data = "success";
    }
    else if (cmd_word == "continue_task")
    {
        SendCmd(TaskStatus::T_TASK_GOON);
        response.data = "success";
    }
    return true;
}
/**********************************************************************
 * * @function:    SendCmd 
 * * @brief:       发送运动控制指令给导航控制模块(navcontrol)
 * * @input:       ts_type: 任务状态枚举值
 * * @output:      通过信号发送运动命令数据
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void InterfaceAction::SendCmd(TaskStatus ts_type)
{
    LOG(INFO) << "SendCmd TaskStatus is: " << ts_type;
    MoveDataCmd mdc;
    mdc.taskcmd_type = ts_type;
    QVariant qvr;
    qvr.setValue(mdc);
    emit signal_MoveCmd(qvr);
}