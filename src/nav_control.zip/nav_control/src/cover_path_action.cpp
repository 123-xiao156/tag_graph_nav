#include "cover_path_action.h"
#include <robot_msgs/Web.h>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QByteArray>

CoverPathAction::CoverPathAction(ros::NodeHandle nh): nh_(nh)
{
    pub_voice_ = nh_.advertise<robot_msgs::Voice>("/voiceplay", 10);
    srv_draw_cpath_ = nh_.serviceClient<robot_msgs::Web>("/srv_teach_path");  // 覆盖路径服务
    io_data_all_pub_ = nh_.advertise<std_msgs::String>("/io_serial_all", 10, true);
}

void CoverPathAction::Init()
{
    interval_ms_ = 100;
    std::thread t(&CoverPathAction::TimerThread, this, interval_ms_);
    t.detach();
}

void CoverPathAction::TimerThread(int16_t interval_ms)
{
    while (ros::ok())
    {
        if (!thread_pause_flag_)
        {
            MainLoop();
        }
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}

void CoverPathAction::PublishVoice(const std::string &name)
{
    robot_msgs::Voice msg;
    msg.info_volume = 70;
    msg.info_type = "voice";
    msg.info_data = name;
    pub_voice_.publish(msg);
}

void CoverPathAction::slot_NewCmd(QVariant movecmd)
{
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();
    LOG(INFO) << "slot_NewCmd收到指令类型: " << mdc.taskcmd_type;
    
    bool is_cover_relevant_cmd = 
        (mdc.taskcmd_type == TaskStatus::T_ESTOP ||
         mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP ||
         mdc.taskcmd_type == TaskStatus::T_CANCEL ||
         mdc.taskcmd_type == TaskStatus::T_END ||
         mdc.taskcmd_type == TaskStatus::T_GOON||
         mdc.taskcmd_type == TaskStatus::T_MARKET);
    
    if (!is_cover_relevant_cmd) {
        LOG(INFO) << "忽略非相关命令: " << mdc.taskcmd_type;
        return;
    }
    
    // 重置恢复标志
    if (mdc.taskcmd_type != TaskStatus::T_GOON) {
        is_recovering_ = false;
    }
    
    if (mdc.taskcmd_type == TaskStatus::T_CANCEL ||
        mdc.taskcmd_type == TaskStatus::T_END)
    {
        mtx_.lock();
        thread_pause_flag_ = true;
        first_flag_ = false;
        process_index_ = ProcessIndex::STEP0;
        
        // 清空路径队列
        cpath_queue_.clear();
        mtx_.unlock();
        
        is_executing_cover_ = false;  // 标记为未执行覆盖路径
        LOG(INFO) << "收到停止指令，清空覆盖路径队列";
        is_recovering_ = false;
    }    
    else if (mdc.taskcmd_type == TaskStatus::T_ESTOP ||
        mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP)
    {
        mtx_.lock();
        thread_pause_flag_ = true;
        first_flag_ = false;
        process_index_ = ProcessIndex::STEP0;
        
        // 清空路径队列
        cpath_queue_.clear();
        mtx_.unlock();
        
        LOG(INFO) << "收到暂停指令，清空覆盖路径队列";
        is_recovering_ = false;
    }
    else if(mdc.taskcmd_type == TaskStatus::T_GOON||
            mdc.taskcmd_type == TaskStatus::T_TASK_GOON)
    {
        // 如果已经在恢复中，忽略重复命令
        if (is_recovering_) {
            LOG(INFO) << "已经在恢复过程中，忽略重复的恢复命令";
            return;
        }
        
        is_recovering_ = true;
        LOG(INFO) << "收到继续命令，恢复执行";
        
        // 检查当前是否是被暂停状态
        if (p_shard_data_->coverpath_nav_status_.goal_status == NavStatus::NAV_STOP ||
            p_shard_data_->coverpath_nav_status_.goal_status == NavStatus::NAV_RUN)
        {
            LOG(INFO) << "恢复被暂停的覆盖路径: " << send_cpath_name_;
            
            // 恢复路径状态
            p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_RUN;
            p_shard_data_->move_status_ = MoveStatus::RUNNING;
            
            // 重置暂停标志
            thread_pause_flag_ = false;
            first_flag_ = false;
            need_resend_path_ = false;
            
            // 重新发送剩余路径给 move_action - 使用保存的精确恢复点！！！
            if (p_shard_data_->has_paused_path_ && 
                p_shard_data_->paused_path_info_.point_info.point_name == cpath_only_name_)
            {
                // 检查是否有保存的剩余点
                if (!p_shard_data_->paused_path_info_.remaining_points.empty())
                {
                    LOG(INFO) << "使用共享数据中保存的剩余点进行恢复，共 " << p_shard_data_->paused_path_info_.remaining_points.size() << " 个点";
                    
                    // 直接使用保存的剩余点构建命令
                    MoveDataCmd path_cmd;
                    path_cmd.taskcmd_type = TaskStatus::T_LOCALE;
                    path_cmd.goal.clear();
                    
                    for (const auto& point : p_shard_data_->paused_path_info_.remaining_points)
                    {
                        PoseData pose;
                        pose.type = GlobalPlannerType::COVER_PATH;
                        pose.x = point.x;
                        pose.y = point.y;
                        pose.yaw = point.yaw;
                        path_cmd.goal.push_back(pose);
                    }
                    
                    if (!path_cmd.goal.empty())
                    {
                        QVariant qvr;
                        qvr.setValue(path_cmd);
                        emit signal_MoveCmd(qvr);
                        
                        // 更新 send_path_ 为剩余点
                        send_path_.poses.clear();
                        for (const auto& point : p_shard_data_->paused_path_info_.remaining_points)
                        {
                            geometry_msgs::PoseStamped pose_stamped;
                            pose_stamped.header.frame_id = "map";
                            pose_stamped.header.stamp = ros::Time::now();
                            pose_stamped.pose.position.x = point.x;
                            pose_stamped.pose.position.y = point.y;
                            pose_stamped.pose.position.z = 0.0;
                            
                            tf2::Quaternion q;
                            q.setRPY(0, 0, point.yaw);
                            pose_stamped.pose.orientation.x = q.x();
                            pose_stamped.pose.orientation.y = q.y();
                            pose_stamped.pose.orientation.z = q.z();
                            pose_stamped.pose.orientation.w = q.w();
                            send_path_.poses.push_back(pose_stamped);
                        }
                        
                        process_index_ = ProcessIndex::RUN;
                        
                        LOG(INFO) << "成功使用保存的剩余点恢复，发送 " << path_cmd.goal.size() << " 个点";
                    }
                    else
                    {
                        LOG(WARNING) << "保存的剩余点为空，无法恢复";
                        process_index_ = ProcessIndex::STEP1;
                    }
                }
                else
                {
                    LOG(WARNING) << "没有保存的剩余点，重新请求路径";
                    process_index_ = ProcessIndex::STEP1;
                }
            }
            else 
            {
                LOG(WARNING) << "没有暂停信息或路径不匹配，无法恢复路径执行";
                process_index_ = ProcessIndex::STEP1;
            }
        }
        
        // 3秒后自动重置恢复标志
        std::thread([this]() {
            std::this_thread::sleep_for(std::chrono::seconds(3));
            this->is_recovering_ = false;
        }).detach();
    }
    else
    {
        thread_pause_flag_ = false;
        first_flag_ = false;
        process_index_ = ProcessIndex::RUN;
        LOG(INFO) << "正常继续执行";
        is_recovering_ = false;
    }
    
    CmdVelStr cmd_vel;
    cmd_vel.linear = 0.0;
    cmd_vel.angular = 0.0;
    emit signal_CmdVel(cmd_vel);
}
void CoverPathAction::SendRemainingPath()
{
    if (send_path_.poses.empty()) {
        LOG(INFO) << "没有剩余路径可发送";
        return;
    }
    
    LOG(INFO) << "重新发送剩余" << send_path_.poses.size() << "个路径点";
    
    MoveDataCmd mdc;
    mdc.taskcmd_type = TaskStatus::T_LOCALE;
    mdc.goal.clear();
    
    for(auto& point : send_path_.poses) {
        PoseData pose;
        pose.type = GlobalPlannerType::COVER_PATH;
        pose.x = point.pose.position.x;
        pose.y = point.pose.position.y;
        
        tf::Quaternion q(
            point.pose.orientation.x,
            point.pose.orientation.y, 
            point.pose.orientation.z,
            point.pose.orientation.w);
        tf::Matrix3x3 m(q);
        double roll, pitch, yaw;
        m.getRPY(roll, pitch, yaw);
        pose.yaw = yaw;
        
        mdc.goal.push_back(pose);
    }
    
    QVariant qvr;
    qvr.setValue(mdc);
    emit signal_MoveCmd(qvr);
    
    p_shard_data_->move_status_ = MoveStatus::IDLE;
}
bool CoverPathAction::ListenTF(std::string target, std::string source, geometry_msgs::Pose2D &pose)
{
    try
    {
        tf_listener_.waitForTransform(target, source, ros::Time(0), ros::Duration(1.0));
        tf_listener_.lookupTransform(target, source, ros::Time(0), transform_base_link_to_odom_);
    }
    catch (tf::TransformException &ex)
    {
        LOG(ERROR) << "无法获取变换: " << ex.what();
        return false;
    }

    pose.x = transform_base_link_to_odom_.getOrigin().x();
    pose.y = transform_base_link_to_odom_.getOrigin().y();
    pose.theta = tf::getYaw(transform_base_link_to_odom_.getRotation());
    return true;
}

void CoverPathAction::SetCmd(std::string cmd_type, PoseData pdata)
{
    LOG(INFO) << "SetCmd被调用，路径类型: " << cmd_type;
    if (cmd_type == "cover_path") {
    
        // 检查路径信息是否完整
        if (pdata.path_map.empty() || pdata.path_name.empty()) {
            LOG(WARNING) << "路径信息不完整: 地图名=" << pdata.path_map << ", 路径名=" << pdata.path_name;
            return;
        }
        
        // 检查是否是补扫任务（路径名包含 "_rescan"）
        bool is_rescan = (pdata.path_name.find("_rescan") != std::string::npos);
        
        mtx_.lock();
        p_shard_data_->nav_progress_.dis_to_end = -1;
        cmd_type_ = cmd_type;
        cpath_map_name_ = pdata.path_map;
        cpath_only_name_ = pdata.path_name;
        send_cpath_name_ = "/" + pdata.path_map + "/" + pdata.path_name;
        
        // 清空之前的路径数据
        send_path_.poses.clear();
        cpath_queue_.clear();
        current_cpath_index_ = 0;
        multi_cpath_mode_ = false;
        
        if (is_rescan) {
            // 补扫任务：直接使用共享数据中已经准备好的路径点
            LOG(INFO) << "检测到补扫任务 " << pdata.path_name << "，直接使用已有路径点";
            
            // 从共享数据的补扫信息中获取路径点
            std::string original_name = pdata.path_name.substr(0, pdata.path_name.find("_rescan"));
            
            std::lock_guard<std::mutex> rescan_lock(p_shard_data_->rescan_mutex_);
            auto it = p_shard_data_->cover_path_rescan_map_.find(original_name);
            
            if (it != p_shard_data_->cover_path_rescan_map_.end() && 
                !it->second.all_rescan_points.empty()) {
                
                // 使用已经准备好的补扫点
                for (const auto& point : it->second.all_rescan_points) {
                    geometry_msgs::PoseStamped pose_stamped;
                    pose_stamped.header.frame_id = "map";
                    pose_stamped.header.stamp = ros::Time::now();
                    pose_stamped.pose.position.x = point.x;
                    pose_stamped.pose.position.y = point.y;
                    pose_stamped.pose.position.z = 0.0;
                    
                    tf2::Quaternion q;
                    q.setRPY(0, 0, point.yaw);
                    pose_stamped.pose.orientation.x = q.x();
                    pose_stamped.pose.orientation.y = q.y();
                    pose_stamped.pose.orientation.z = q.z();
                    pose_stamped.pose.orientation.w = q.w();
                    send_path_.poses.push_back(pose_stamped);
                }
                
                LOG(INFO) << "补扫任务加载了 " << send_path_.poses.size() << " 个路径点";
                
                // 直接进入发送路径状态，跳过数据库请求
                p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_RUN;
                thread_pause_flag_ = false;
                process_index_ = ProcessIndex::SEND_PATH;
                first_flag_ = false;
                is_resume_mode_ = false;
            } else {
                LOG(ERROR) << "补扫任务找不到路径点数据: " << original_name;
                process_index_ = ProcessIndex::STEP0;
                thread_pause_flag_ = true;
            }
        } else {
            // 普通覆盖路径：需要从数据库请求
            LOG(INFO) << "设置当前路径: " << send_cpath_name_;
            thread_pause_flag_ = false;
            process_index_ = ProcessIndex::STEP1;
            first_flag_ = false;
        }
        
        mtx_.unlock();
        
        LOG(INFO) << "SetCmd完成，开始执行" << (is_rescan ? "补扫路径" : "单一路径");
    }
    else if (cmd_type == "resume_path") {
        // 恢复暂停的路径
        LOG(INFO) << "恢复暂停的路径: " << pdata.path_map << "/" << pdata.path_name;
        
        mtx_.lock();
        
        // 设置路径信息
        cpath_map_name_ = pdata.path_map;
        cpath_only_name_ = pdata.path_name;
        send_cpath_name_ = "/" + pdata.path_map + "/" + pdata.path_name;
        if (p_shard_data_->has_paused_path_ && 
            p_shard_data_->paused_path_info_.point_info.point_name == cpath_only_name_ &&
            !p_shard_data_->paused_path_info_.remaining_points.empty())
        {
            LOG(INFO) << "SetCmd中发现共享数据中有剩余点，直接使用剩余点恢复";
            
            // 直接使用剩余点构建路径
            send_path_.poses.clear();
            for (const auto& point : p_shard_data_->paused_path_info_.remaining_points)
            {
                geometry_msgs::PoseStamped pose_stamped;
                pose_stamped.header.frame_id = "map";
                pose_stamped.header.stamp = ros::Time::now();
                pose_stamped.pose.position.x = point.x;
                pose_stamped.pose.position.y = point.y;
                pose_stamped.pose.position.z = 0.0;
                
                tf2::Quaternion q;
                q.setRPY(0, 0, point.yaw);
                pose_stamped.pose.orientation.x = q.x();
                pose_stamped.pose.orientation.y = q.y();
                pose_stamped.pose.orientation.z = q.z();
                pose_stamped.pose.orientation.w = q.w();
                send_path_.poses.push_back(pose_stamped);
            }
            
            // 标记为恢复模式
            is_resume_mode_ = true;
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            thread_pause_flag_ = false;
            process_index_ = ProcessIndex::SEND_PATH;  // 直接发送路径
            first_flag_ = false;
        }
        else
        {
            // 标记为恢复模式，需要重新请求路径
            is_resume_mode_ = true;
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            thread_pause_flag_ = false;
            process_index_ = ProcessIndex::RESUME_PATH;
            first_flag_ = false;
        }
        
        mtx_.unlock();
        LOG(INFO) << "SetCmd完成，开始恢复路径";
    }
}
void CoverPathAction::MainLoop()
{
    switch (process_index_)
    {
        case ProcessIndex::STEP0:
        {
            if (!first_flag_)
            {
                first_flag_ = true;
                CmdVelStr cmd_vel;
                cmd_vel.linear = 0.0;
                cmd_vel.angular = 0.0;
                emit signal_CmdVel(cmd_vel);
            }
        }
        break;
        
        case ProcessIndex::STEP1:
        {
            // start_reached_ = false;
            // end_reached_ = false;
            if (cpath_map_name_.empty() || cpath_only_name_.empty()) {
                LOG(WARNING) << "路径名为空，跳过STEP1";
                process_index_ = ProcessIndex::STEP0;
                thread_pause_flag_ = true;
                break;
            }
            LOG(INFO) << "进入STEP1，请求覆盖路径: " << cpath_only_name_ << ", 地图: " << cpath_map_name_;
            send_path_.poses.clear();
            
            robot_msgs::Web srv;
            srv.request.request_type = "Cselect";  // 使用Cselect选择覆盖路径
            
            // 构造JSON格式的请求数据
            QJsonObject request_obj;
            request_obj["map"] = QString::fromStdString(cpath_map_name_);
            request_obj["path"] = QString::fromStdString(cpath_only_name_);
            QJsonDocument request_doc(request_obj);
            srv.request.request_data = request_doc.toJson().toStdString();
            
            LOG(INFO) << "请求覆盖路径服务，请求数据: " << srv.request.request_data;
            
            if (!srv_draw_cpath_.waitForExistence(ros::Duration(3.0))) {
                LOG(ERROR) << "覆盖路径服务不存在或未启动";
                process_index_ = ProcessIndex::STEP0;
                break;
            }
            
            if (srv_draw_cpath_.call(srv))
            {
                LOG(INFO) << "覆盖路径服务调用成功";
                
                if (srv.response.response_type == "success")
                {
                    LOG(INFO) << "cover_path_action 覆盖路径服务响应成功";
                    
                    std::string result = srv.response.response_data;
                    
                    // 解析JSON格式的覆盖路径数据
                    send_path_.header.frame_id = "map";
                    send_path_.header.stamp = ros::Time::now();
                    
                    QByteArray json_data = QByteArray::fromStdString(result);
                    QJsonDocument doc = QJsonDocument::fromJson(json_data);
                    
                    if (!doc.isNull() && doc.isObject())
                    {
                        QJsonObject root = doc.object();
                        
                        if (root.contains("points") && root["points"].isArray())
                        {
                            QJsonArray points_array = root["points"].toArray();
                            LOG(INFO) << "解析到 " << points_array.size() << " 个覆盖路径点";
                            
                            for (const QJsonValue& point_value : points_array)
                            {
                                if (point_value.isObject())
                                {
                                    QJsonObject point_obj = point_value.toObject();
                                    geometry_msgs::PoseStamped pose_stamped;
                                    pose_stamped.header.frame_id = "map";
                                    pose_stamped.header.stamp = ros::Time::now();
                                    
                                    if (point_obj.contains("x") && point_obj.contains("y"))
                                    {
                                        pose_stamped.pose.position.x = point_obj["x"].toString().toDouble();
                                        pose_stamped.pose.position.y = point_obj["y"].toString().toDouble();
                                        pose_stamped.pose.position.z = 0.0;
                                        
                                        double yaw = 0.0;
                                        if (point_obj.contains("yaw")) {
                                            yaw = point_obj["yaw"].toString().toDouble();
                                        }
                                        
                                        tf2::Quaternion q;
                                        q.setRPY(0, 0, yaw);
                                        pose_stamped.pose.orientation.x = q.x();
                                        pose_stamped.pose.orientation.y = q.y();
                                        pose_stamped.pose.orientation.z = q.z();
                                        pose_stamped.pose.orientation.w = q.w();
                                        
                                        send_path_.poses.push_back(pose_stamped);
                                    }
                                }
                            }
                            
                            LOG(INFO) << "成功解析 " << send_path_.poses.size() << " 个覆盖路径点";
                            
                            if (!send_path_.poses.empty())
                            {
                                p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_RUN;
                                process_index_ = ProcessIndex::SEND_PATH;
                                
                                //std::string state = "GOTO_" + send_cpath_name_ + "_success";
                                //emit signal_PubStatus("success");
                                LOG(INFO) << "step1 覆盖路径数据不为空并发送路径: " << send_cpath_name_;
                            }
                            else
                            {
                                LOG(ERROR) << "覆盖路径数据为空";
                                process_index_ = ProcessIndex::STEP0;
                            }
                        }
                    }
                }
            }
        }
        break;
        
        case ProcessIndex::SEND_PATH:
        {
            if (send_path_.poses.empty()) {
                LOG(ERROR) << "send_path_为空，无法发送覆盖路径";
                process_index_ = ProcessIndex::STEP0;
                break;
            }
            p_shard_data_->at_start_ = false;
            p_shard_data_->at_end_ = false;
            // // 提取起始点
            // {
            //     start_pose_.x = send_path_.poses.front().pose.position.x;
            //     start_pose_.y = send_path_.poses.front().pose.position.y;
            // }
            // // 提取终点
            // {            
            //     end_pose_.x = send_path_.poses.back().pose.position.x;
            //     end_pose_.y = send_path_.poses.back().pose.position.y;
            // }
            MoveDataCmd mdc;
            mdc.taskcmd_type = TaskStatus::T_LOCALE;
            mdc.goal.clear();
            
            for(auto& point : send_path_.poses) {
                PoseData pose;
                pose.type = GlobalPlannerType::COVER_PATH;
                pose.x = point.pose.position.x;
                pose.y = point.pose.position.y;
                
                tf::Quaternion q(
                    point.pose.orientation.x,
                    point.pose.orientation.y, 
                    point.pose.orientation.z,
                    point.pose.orientation.w);
                tf::Matrix3x3 m(q);
                double roll, pitch, yaw;
                m.getRPY(roll, pitch, yaw);
                pose.yaw = yaw;
                
                mdc.goal.push_back(pose);
            }
            
            QVariant qvr;
            qvr.setValue(mdc);
            emit signal_MoveCmd(qvr);
            
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            process_index_ = ProcessIndex::RUN;
        }
        break;
        case ProcessIndex::RESUME_PATH:
        {
            LOG(INFO) << "进入RESUME_PATH状态，恢复暂停的路径";
            
            // 这里需要从NavControl获取剩余的路径点
            // 假设通过共享数据传递
            if (is_resume_mode_) {
                // 设置路径状态为运行
                p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_RUN;
                
                // 直接发送剩余的路径点给move_action 
                
                process_index_ = ProcessIndex::RUN;
                is_resume_mode_=false;
                LOG(INFO) << "恢复路径执行: " << send_cpath_name_;
            } else {
                LOG(ERROR) << "恢复模式标志未设置，返回STEP0";
                process_index_ = ProcessIndex::STEP0;
            }
        }
        break;
        case ProcessIndex::RUN:
        {
            if (cmd_type_ != "cover_path") {
                // 如果不是覆盖路径，不应该停留在 RUN 状态
                if (process_index_ == ProcessIndex::RUN) {
                    LOG(INFO) << "cmd_type_不是cover_path，退出RUN状态";
                    process_index_ = ProcessIndex::STEP0;
                    thread_pause_flag_ = true;
                }
                break;
            }
            
            // 检查路径名称是否有效
            if (cpath_only_name_.empty()) {
                LOG(INFO) << "路径名称为空，退出RUN状态";
                process_index_ = ProcessIndex::STEP0;
                thread_pause_flag_ = true;
                is_executing_cover_ = false;
                break;
            }
            /*if (p_shard_data_->move_status_ == MoveStatus::ARRIVE && !is_executing_cover_) {
                LOG(WARNING) << "检测到残留的ARRIVE状态且未在执行，主动重置move_status_";
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                break;  // 跳出，等待下次循环
            }*/
            std_msgs::String cmdctrl;
            // 首先检查是否处于暂停状态
            if (p_shard_data_->coverpath_nav_status_.goal_status == NavStatus::NAV_STOP) 
            {
                // 处于暂停状态，等待恢复
                LOG(INFO) << "覆盖路径处于暂停状态，等待恢复命令... 下发0速";

                CmdVelStr cmd_vel;
                cmd_vel.linear = 0.0;
                cmd_vel.angular = 0.0;
                emit signal_CmdVel(cmd_vel);
                /*if (cpath_task_ == "wash") {
                    cmdctrl.data = "washClose";
                    io_data_all_pub_.publish(cmdctrl);
                } else if (cpath_task_ == "brush") {
                    cmdctrl.data = "brushClose";
                    io_data_all_pub_.publish(cmdctrl);
                } else if (cpath_task_ == "mop") {
                    cmdctrl.data = "mopClose";
                    io_data_all_pub_.publish(cmdctrl);
                } else if (cpath_task_ == "saction") {
                    cmdctrl.data = "sactionClose";
                    io_data_all_pub_.publish(cmdctrl);
                }*/
                break;
                // 检查是否收到恢复命令
                if (p_shard_data_->coverpath_nav_status_.goal_status == NavStatus::NAV_RUN) 
                {
                    LOG(INFO) << "收到恢复命令，继续执行覆盖路径";
                    /*if (cpath_task_ == "wash") {
                        cmdctrl.data = "washOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "brush") {
                        cmdctrl.data = "brushOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "mop") {
                        cmdctrl.data = "mopOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "saction") {
                        cmdctrl.data = "sactionOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    }*/
                    // 发送继续命令给 move_action
                    MoveDataCmd goon_cmd;
                    goon_cmd.taskcmd_type = TaskStatus::T_GOON;
                    QVariant qvr_goon;
                    qvr_goon.setValue(goon_cmd);
                    emit signal_MoveCmd(qvr_goon);
                    
                    // 设置移动状态为运行
                    p_shard_data_->move_status_ = MoveStatus::RUNNING;
                    
                    LOG(INFO) << "已发送继续命令，恢复路径执行";
                }
                else
                {
                    // 保持暂停状态，不发速度命令
                    CmdVelStr cmd_vel;
                    cmd_vel.linear = 0.0;
                    cmd_vel.angular = 0.0;
                    emit signal_CmdVel(cmd_vel);
                    
                    break;  // 跳出，等待恢复
                }
                if (need_resend_path_) 
                {
                    // 重新发送剩余的路径点
                    LOG(INFO) << "重新发送剩余路径点";
                    SendRemainingPath();
                    need_resend_path_ = false;
                }
            }
            //ROS_INFO("DEBUG;RUN状态，检查路径导航进度，move_status_: %d", p_shard_data_->move_status_);
            else if(p_shard_data_->move_status_ == MoveStatus::RUNNING && cmd_type_== "cover_path")
            {
                /*if(p_shard_data_->at_start_){
                    if (cpath_task_ == "wash") {
                        cmdctrl.data = "washOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "brush") {
                        cmdctrl.data = "brushOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "mop") {
                        cmdctrl.data = "mopOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "saction") {
                        cmdctrl.data = "sactionOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    }
                }
                else if(p_shard_data_->at_end_){
                    if (cpath_task_ == "wash") {
                        cmdctrl.data = "washClose";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "brush") {
                        cmdctrl.data = "brushClose";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "mop") {
                        cmdctrl.data = "mopClose";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (cpath_task_ == "saction") {
                        cmdctrl.data = "sactionClose";
                        io_data_all_pub_.publish(cmdctrl);
                    }
                }*/
            }
            else if (p_shard_data_->move_status_ == MoveStatus::ARRIVE && cmd_type_== "cover_path") 
            {
                LOG(INFO) << "捕获到ARRIVE状态，检查路径信息: " << cpath_only_name_;
                
                // 增加一个标志，确保只有真正在执行时才处理
                static bool is_executing = false;
                is_executing_cover_ = false;
                
                // 检查是否真的在执行覆盖路径（通过一个成员变量）
                /*if (!is_executing_cover_) {  // 建议添加成员变量
                    LOG(WARNING) << "收到ARRIVE但未开始执行覆盖路径，忽略";
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    break;
                }*/
                
                // 确认当前确实在执行覆盖路径
                if (cpath_only_name_.empty() || send_cpath_name_.empty()) {
                    LOG(WARNING) << "收到ARRIVE但路径信息无效，忽略";
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    // 重置执行标志
                    is_executing_cover_ = false;
                    break;
                }
                
                // 验证是否真的在导航状态
                if (p_shard_data_->coverpath_nav_status_.goal_status != NavStatus::NAV_RUN) {
                    LOG(WARNING) << "收到ARRIVE但导航状态不是RUN，当前状态: " << p_shard_data_->coverpath_nav_status_.goal_status;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    // 重置执行标志
                    is_executing_cover_ = false;
                    process_index_ = ProcessIndex::STEP0;
                    p_shard_data_->cover_success_=true;
                    thread_pause_flag_ = true;
                    break;
                }

                // 检查当前处理的是否真的是覆盖路径
                if (!cpath_only_name_.empty() && cpath_only_name_ != "") 
                {
                    LOG(INFO) << "确认当前处理的是覆盖路径: " << send_cpath_name_ << "，设置coverpath_nav_status_=NAV_SUCCESS";
                    mtx_.lock();
                    p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
                    p_shard_data_->move_status_ = MoveStatus::IDLE; 
                    p_shard_data_->now_nav_status_="success";

                    //std::string success_status = "GOTO_" + send_cpath_name_ + "_success";
                    /*if (p_shard_data_->is_path_over_){
                        emit signal_PubStatus("success");
                        p_shard_data_->is_path_over_=false;
                    }*/
                    //emit signal_PubStatus("success");
                    //ROS_INFO("DEBUG;CoverPathAction发出信号: %s", success_status.c_str()); 
                    std::string state = "GOTO_" + send_cpath_name_ + "_success";
                    emit signal_PubStatus(state);
                    
                    /*if(p_shard_data_->at_end_){
                        if (cpath_task_ == "wash") {
                            cmdctrl.data = "washClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (cpath_task_ == "brush") {
                            cmdctrl.data = "brushClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (cpath_task_ == "mop") {
                            cmdctrl.data = "mopClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (cpath_task_ == "saction") {
                            cmdctrl.data = "sactionClose";
                            io_data_all_pub_.publish(cmdctrl);
                        }
                    }*/
                    LOG(INFO) << "覆盖路径执行成功: " << send_cpath_name_;
                    LOG(INFO) << "清除路径类型，路径名称以及清空完整路径名 ";
                    // 立即清除状态，防止其他Action误用
                    cmd_type_ = "";           // 清空类型，防止影响下一条路径
                    cpath_only_name_ = "";     // 清空路径名
                    send_cpath_name_ = "";     // 清空完整路径名
                    LOG(INFO) << "设置导航状态：" << p_shard_data_->coverpath_nav_status_.goal_status;
                    p_shard_data_->cover_success_=true;
                    mtx_.unlock();
                    process_index_ = ProcessIndex::STEP0;
                    thread_pause_flag_ = true;
                }
                else 
                {
                    LOG(WARNING) << "收到ARRIVE但路径信息无效: " << cpath_only_name_ << "，忽略该状态";
                }
            }
            else if (p_shard_data_->move_status_ == MoveStatus::ABORTED && cmd_type_== "cover_path") {
                if (!cpath_only_name_.empty() && cpath_only_name_ != "")
                {
                    p_shard_data_->is_cover_path_start_ = false;  
                    p_shard_data_->is_cover_path_end_ = false;  

                    //std::string failed_status = "GOTO_" + send_cpath_name_ + "_failed";
                    //emit signal_PubStatus(failed_status);  
                    if(p_shard_data_->at_end_){
                        /*if (cpath_task_ == "wash") {
                            cmdctrl.data = "washClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (cpath_task_ == "brush") {
                            cmdctrl.data = "brushClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (cpath_task_ == "mop") {
                            cmdctrl.data = "mopClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (cpath_task_ == "saction") {
                            cmdctrl.data = "sactionClose";
                            io_data_all_pub_.publish(cmdctrl);
                        }*/
                    }
                    /*if (multi_cpath_mode_) {
                        // 继续下一条覆盖路径
                        current_cpath_index_++;
                        if (current_cpath_index_ < cpath_queue_.size()) {
                            process_index_ = ProcessIndex::STEP1;
                        } else {
                            process_index_ = ProcessIndex::STEP0;
                            thread_pause_flag_ = true;
                        }
                    }*/ 
                    //else {
                    LOG(INFO) << "stepRUN 覆盖路径执行成功: " << send_cpath_name_;
                    mtx_.lock();
                    p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_FAILED;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    p_shard_data_->now_nav_status_="failed";
                    process_index_ = ProcessIndex::STEP0;
                    thread_pause_flag_ = true;
                    std::string state = "GOTO_" + send_cpath_name_ + "_failed";
                    emit signal_PubStatus(state);
                    LOG(ERROR) << "覆盖路径执行失败: " << send_cpath_name_;
                    LOG(INFO) << "清除路径类型，路径名称以及清空完整路径名 ";
                    // 立即清除状态，防止其他Action误用
                    cmd_type_ = "";           // 清空类型，防止影响下一条路径
                    cpath_only_name_ = "";     // 清空路径名
                    send_cpath_name_ = "";     // 清空完整路径名
                    LOG(INFO) << "设置导航状态：" << p_shard_data_->coverpath_nav_status_.goal_status;
                    //p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    p_shard_data_->cover_fault_=true;
                    mtx_.unlock();
                    process_index_ = ProcessIndex::STEP0;
                    thread_pause_flag_ = true;
                }
            }
        }
        break;
        
        default:
            process_index_ = ProcessIndex::STEP0;
        break;
    }
}






