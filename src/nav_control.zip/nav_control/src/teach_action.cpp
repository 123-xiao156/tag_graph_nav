#include "teach_action.h"
#include <robot_msgs/Web.h>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>
#include <QByteArray>

TeachAction::TeachAction(ros::NodeHandle nh):nh_(nh)
{
    clear_costmap_client_ = nh_.serviceClient<std_srvs::Empty>("/move_base/clear_costmaps");
    pub_voice_ = nh_.advertise<robot_msgs::Voice>("/voiceplay", 10);
    srv_draw_path_ = nh_.serviceClient<robot_msgs::Web>("/srv_teach_path");
    io_data_all_pub_ = nh_.advertise<std_msgs::String>("/io_serial_all", 10, true);
}

void TeachAction::Init()
{
    interval_ms_ = 100;
    std::thread t(&TeachAction::TimerThread,this,interval_ms_);
    t.detach();
}

void TeachAction::TimerThread(int16_t interval_ms)
{
    while (ros::ok())
    {
        if (!thread_pause_flag_)
        {
            MainLoop();
        }
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}

// 发布语音
void TeachAction::PublishVoice(const std::string &name)
{
    robot_msgs::Voice msg;
    msg.info_volume = 70;    // 音量70%
    msg.info_type = "voice"; // 播放语音
    msg.info_data = name;    // 语音名称，见语音列表
    pub_voice_.publish(msg);
}

// 接收interface_action发送的指令
void TeachAction::slot_NewCmd(QVariant movecmd)
{
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();
    bool is_teach_relevant_cmd = 
        (mdc.taskcmd_type == TaskStatus::T_ESTOP ||
         mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP ||
         mdc.taskcmd_type == TaskStatus::T_CANCEL ||
         mdc.taskcmd_type == TaskStatus::T_END ||
         mdc.taskcmd_type == TaskStatus::T_GOON||
         mdc.taskcmd_type == TaskStatus::T_MARKET);
    
    if (!is_teach_relevant_cmd) {
        LOG(INFO) << "teachPathAction忽略非相关命令: " << mdc.taskcmd_type;
        return;
    }
    LOG(INFO) << "teach_action slot_NewCmd收到指令类型: " << mdc.taskcmd_type;
    if (mdc.taskcmd_type != TaskStatus::T_GOON) {
        is_recovering_ = false;
    }
    if (mdc.taskcmd_type == TaskStatus::T_CANCEL ||
        mdc.taskcmd_type == TaskStatus::T_END)
    {
        mtx_.lock();
        thread_pause_flag_ = true;
        first_flag_ = false;
        process_index_ = ProcessIndex::STEP0;
        
        // 清空路径队列
        path_queue_.clear();
        current_path_index_ = 0;
        multi_path_mode_ = false;
        mtx_.unlock();
        
        is_executing_teach_ = false;  // 标记为未执行示教路径
        LOG(INFO) << "收到停止指令，清空示教路径队列";
        is_recovering_ = false;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_ESTOP ||
        mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP)
    {
        mtx_.lock();
        thread_pause_flag_ = true;
        first_flag_ = false;
        process_index_ = ProcessIndex::STEP0;
        
        // 清空路径队列
        path_queue_.clear();
        current_path_index_ = 0;
        multi_path_mode_ = false;
        mtx_.unlock();
        
        LOG(INFO) << "收到停止指令，清空示教路径队列";
        is_recovering_ = false;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_GOON||
            mdc.taskcmd_type == TaskStatus::T_TASK_GOON )
    {
        if (is_recovering_) {
            LOG(INFO) << "已经在恢复过程中，忽略重复的恢复命令";
            return;
        }
        
        is_recovering_ = true;
        LOG(INFO)<< "收到继续命令，恢复执行";
        
        // 检查当前是否是被暂停状态
        if (p_shard_data_->teachingpath_nav_status_.goal_status == NavStatus::NAV_STOP ||
            p_shard_data_->teachingpath_nav_status_.goal_status == NavStatus::NAV_RUN)
        {
            LOG(INFO) << "恢复被暂停的示教路径: " << send_path_name_;
            
            // 恢复路径状态
            p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_RUN;
            p_shard_data_->move_status_ = MoveStatus::RUNNING;
            
            // 重置暂停标志
            thread_pause_flag_ = false;
            first_flag_ = false;
            need_resend_path_ = false; 
            // 使用共享数据中保存的剩余点进行恢复
            if (p_shard_data_->has_paused_path_ && 
                p_shard_data_->paused_path_info_.point_info.point_name == path_only_name_)
            {
                // 检查是否有保存的剩余点
                if (!p_shard_data_->paused_path_info_.remaining_points.empty())
                {
                    // 查询路径子类型        
                    robot_msgs::Web query_srv;
                    query_srv.request.request_type = "Tquery";
                    
                    QJsonObject query_obj;
                    query_obj["map"] = QString::fromStdString(path_map_name_);
                    QJsonDocument query_doc(query_obj);
                    query_srv.request.request_data = query_doc.toJson().toStdString();
                    
                    current_path_sub_type_ = "normal";  // 默认值
                    
                    if (srv_draw_path_.waitForExistence(ros::Duration(3.0)) && srv_draw_path_.call(query_srv)) {
                        if (query_srv.response.response_type == "success") {
                            std::string result = query_srv.response.response_data;
                            QByteArray json_data = QByteArray::fromStdString(result);
                            QJsonDocument doc = QJsonDocument::fromJson(json_data);
                            
                            if (!doc.isNull() && doc.isObject()) {
                                QJsonObject root = doc.object();
                                if (root.contains("paths") && root["paths"].isArray()) {
                                    QJsonArray paths_array = root["paths"].toArray();
                                    for (const QJsonValue& path_value : paths_array) {
                                        if (path_value.isObject()) {
                                            QJsonObject path_obj = path_value.toObject();
                                            if (path_obj.contains("name") && path_obj["name"].toString().toStdString() == path_only_name_) {
                                                if (path_obj.contains("sub_type")) {
                                                    current_path_sub_type_ = path_obj["sub_type"].toString().toStdString();
                                                    LOG(INFO) << "T_GOON查询到子类型: " << current_path_sub_type_;
                                                }
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    GlobalPlannerType goon_path_type;
                    if (current_path_sub_type_ == "edge") {
                        goon_path_type = GlobalPlannerType::FIX_PATH;
                        LOG(INFO) << "T_GOON使用 FIX_PATH 模式 (edge类型)"; 
                    } else {
                        goon_path_type = GlobalPlannerType::COVER_PATH;
                        LOG(INFO) << "T_GOON使用 COVER_PATH 模式 (normal类型)"; 
                    }
                    
                    LOG(INFO) << "使用共享数据中保存的剩余点进行恢复，共" << p_shard_data_->paused_path_info_.remaining_points.size() << " 个点";
                    
                    // 直接使用保存的剩余点构建命令
                    MoveDataCmd path_cmd;
                    path_cmd.taskcmd_type = TaskStatus::T_LOCALE;
                    path_cmd.goal.clear();

                    for (const auto& point : p_shard_data_->paused_path_info_.remaining_points)
                    {
                        PoseData pose;
                        pose.type = goon_path_type;
                        pose.x = point.x;
                        pose.y = point.y;
                        pose.yaw = point.yaw;
                        path_cmd.goal.push_back(pose);
                    }
                    
                    if (!path_cmd.goal.empty())
                    {
                        QVariant qvr;
                        qvr.setValue(path_cmd);
                        emit signal_MoveCmd(qvr);
                        
                        // 更新 send_path_ 为剩余点
                        send_path_.poses.clear();
                        for (const auto& point : p_shard_data_->paused_path_info_.remaining_points)
                        {
                            geometry_msgs::PoseStamped pose_stamped;
                            pose_stamped.header.frame_id = "map";
                            pose_stamped.header.stamp = ros::Time::now();
                            pose_stamped.pose.position.x = point.x;
                            pose_stamped.pose.position.y = point.y;
                            pose_stamped.pose.position.z = 0.0;
                            
                            tf2::Quaternion q;
                            q.setRPY(0, 0, point.yaw);
                            pose_stamped.pose.orientation.x = q.x();
                            pose_stamped.pose.orientation.y = q.y();
                            pose_stamped.pose.orientation.z = q.z();
                            pose_stamped.pose.orientation.w = q.w();
                            send_path_.poses.push_back(pose_stamped);
                        }
                        
                        process_index_ = ProcessIndex::RUN;
                        
                        LOG(INFO) << "成功使用保存的剩余点恢复，发送" << path_cmd.goal.size() << "个点";
                    }
                    else
                    {
                        LOG(WARNING) << "保存的剩余点为空，无法恢复";
                        process_index_ = ProcessIndex::STEP1;
                    }
                }
                else
                {
                    LOG(WARNING) << "没有保存的剩余点，重新请求路径";
                    process_index_ = ProcessIndex::STEP1;
                }
            }
            else
            {
                LOG(INFO) << "没有暂停信息或路径不匹配，无法恢复路径执行";
                process_index_ = ProcessIndex::STEP1;
            } 
        }
        
        // 3秒后自动重置恢复标志
        std::thread([this]() {
            std::this_thread::sleep_for(std::chrono::seconds(3));
            this->is_recovering_ = false;
        }).detach();
    }
    else
    {
        // 如果不是暂停状态，正常继续
        thread_pause_flag_ = false;
        first_flag_ = false;
        process_index_ = ProcessIndex::RUN;
        LOG(INFO) << "正常继续执行";
        is_recovering_ = false;
    }
    
    LOG(INFO) << "slot_NewCmd接收到interface_action的新指令" << mdc.taskcmd_type;
    CmdVelStr cmd_vel;
    cmd_vel.linear = 0.0;
    cmd_vel.angular = 0.0;
    emit signal_CmdVel(cmd_vel);
}
void TeachAction::SendRemainingPath()
{
    if (send_path_.poses.empty()) {
        LOG(INFO) << "没有剩余路径可发送";
        return;
    }
    
    LOG(INFO) << "重新发送剩余" << send_path_.poses.size() << "个路径点";
    
    MoveDataCmd mdc;
    mdc.taskcmd_type = TaskStatus::T_LOCALE;
    mdc.goal.clear();
        
    GlobalPlannerType path_type;
    if (current_path_sub_type_ == "edge") {
        path_type = GlobalPlannerType::FIX_PATH;
        LOG(INFO) << "SendRemainingPath:路径子类型为 edge，使用 FIX_PATH 模式";
    } else {
        path_type = GlobalPlannerType::COVER_PATH;
        LOG(INFO) << "SendRemainingPath:路径子类型为 normal，使用 COVER_PATH 模式";
    }

    for(auto& point : send_path_.poses) {
        PoseData pose;
        pose.type = path_type;
        pose.x = point.pose.position.x;
        pose.y = point.pose.position.y;
        
        tf::Quaternion q(
            point.pose.orientation.x,
            point.pose.orientation.y, 
            point.pose.orientation.z,
            point.pose.orientation.w);
        tf::Matrix3x3 m(q);
        double roll, pitch, yaw;
        m.getRPY(roll, pitch, yaw);
        pose.yaw = yaw;
        
        mdc.goal.push_back(pose);
    }
    
    QVariant qvr;
    qvr.setValue(mdc);
    emit signal_MoveCmd(qvr);
    
    p_shard_data_->move_status_ = MoveStatus::IDLE;
}
// 设置下一条路径
bool TeachAction::SetNextPath()
{
    if (current_path_index_ >= path_queue_.size()) {
        LOG(INFO) << "所有路径执行完成";
        return false;
    }
    
    std::string next_path = path_queue_[current_path_index_];
    LOG(INFO) << "设置第" << current_path_index_ + 1 << "/" << path_queue_.size() << "条路径: " << next_path;
    
    // 解析路径格式
    size_t first_slash = next_path.find('/');
    size_t second_slash = next_path.find('/', first_slash + 1);
    
    if (first_slash == std::string::npos || second_slash == std::string::npos) {
        LOG(ERROR) << "路径名称格式错误: " << next_path;
        return false;
    }
    
    // 提取地图名
    std::string map_name = next_path.substr(first_slash + 1, second_slash - first_slash - 1);
    std::string remaining = next_path.substr(second_slash + 1);
    
    // 检查是否有任务名
    size_t third_slash = remaining.find('/');
    std::string path_name, task_name;
    
    if (third_slash == std::string::npos) {
        // 格式：/地图名/路径名
        path_name = remaining;
        task_name = "";
    } else {
        // 格式：/地图名/路径名/任务名
        path_name = remaining.substr(0, third_slash);
        task_name = remaining.substr(third_slash + 1);
    }
    
    path_map_name_ = map_name;
    path_only_name_ = path_name;
    //tpath_task_ = task_name;
    send_path_name_ = next_path;
    
    std::string log_msg = "INFO;navtask_node;teach_action 开始执行第 " + 
                          std::to_string(current_path_index_ + 1) + "/" + 
                          std::to_string(path_queue_.size()) + " 条路径: " + next_path;
    if (!task_name.empty()) {
        log_msg += " 任务：" + task_name;
    }
    LOG(INFO) << log_msg;

    return true;
}

// 处理多路径错误
void TeachAction::HandleMultiPathError(const std::string& error_msg)
{
    LOG(ERROR) << "多路径执行错误: " << error_msg;
    p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_FAILED;
    first_flag_ = false;
    process_index_ = ProcessIndex::STEP0;
    thread_pause_flag_ = true;
    path_queue_.clear();
    multi_path_mode_ = false;
    
    //std::string state = "MULTI_PATH_FAILED";
    //emit signal_PubStatus(state);
    
    CmdVelStr cmd_vel;
    cmd_vel.linear = 0.0;
    cmd_vel.angular = 0.0;
    emit signal_CmdVel(cmd_vel);
}

// 完成当前路径，准备下一条
void TeachAction::CompleteCurrentPath(bool success)
{
    std::string current_path = send_path_name_;
    //std::string state = "GOTO_" + current_path + (success ? "_success" : "_failed");
    //emit signal_PubStatus(state);
    
    if (success) {
        LOG(INFO) << "路径执行成功: " << current_path;
    } else {
        LOG(ERROR) << "路径执行失败: " << current_path;
    }
    
    // 移动到下一条路径
    current_path_index_++;
    
    if (current_path_index_ < path_queue_.size()) {
        // 还有更多路径要执行
        if (SetNextPath()) {
            process_index_ = ProcessIndex::STEP1;  // 重新开始请求下一条路径
            LOG(INFO) << "准备执行下一条路径";
        } else {
            HandleMultiPathError("设置下一条路径失败");
        }
    } else {
        // 所有路径执行完成
        LOG(INFO) << "所有路径执行完成";
        p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
        process_index_ = ProcessIndex::STEP0;
        thread_pause_flag_ = true;
        path_queue_.clear();
        multi_path_mode_ = false;
        
        //emit signal_PubStatus("MULTI_PATH_COMPLETE");
    }
}
bool TeachAction::ListenTF(std::string target, std::string source, geometry_msgs::Pose2D &pose)
{
    try
    {
        tf_listener_.waitForTransform(target, source, ros::Time(0), ros::Duration(1.0));
        tf_listener_.lookupTransform(target, source, ros::Time(0), transform_base_link_to_odom_);
    }
    catch (tf::TransformException &ex)
    {
        LOG(ERROR) << "无法查找变换: " << ex.what();
        return false;
    }

    pose.x = transform_base_link_to_odom_.getOrigin().x();
    pose.y = transform_base_link_to_odom_.getOrigin().y();
    pose.theta = tf::getYaw(transform_base_link_to_odom_.getRotation());
    return true;
}

// 从navcontrol的TASK_HANDOUT调用此命令
void TeachAction::SetCmd(std::string cmd_type, PoseData pdata)
{
    LOG(INFO) << "SetCmd被调用，路径类型: " << cmd_type;
    if (cmd_type == "teach_path") {
        // 检查路径信息是否完整
        if (pdata.path_map.empty() || pdata.path_name.empty()) {
            LOG(ERROR) << "路径信息不完整: 地图名=" << pdata.path_map << ", 路径名=" << pdata.path_name;
            return;
        }
        
        mtx_.lock();
        p_shard_data_->nav_progress_.dis_to_end = -1;
        cmd_type_ = cmd_type;
        path_map_name_ = pdata.path_map;
        path_only_name_ = pdata.path_name;
        send_path_name_ = "/" + pdata.path_map + "/" + pdata.path_name;
        is_executing_teach_ = true;
        
        // 清空之前的路径数据
        send_path_.poses.clear();
        path_queue_.clear();
        current_path_index_ = 0;
        multi_path_mode_ = false;
        
        LOG(INFO) << "设置当前路径: " << send_path_name_;
        
        // 启动执行
        thread_pause_flag_ = false;
        process_index_ = ProcessIndex::STEP1;
        first_flag_ = false;
        
        mtx_.unlock();
        
        LOG(INFO) << "SetCmd完成，开始执行单一路径";
    }
    else if (cmd_type == "resume_path") {
        // 恢复暂停的路径
        LOG(INFO) << "恢复暂停的路径: " << pdata.path_map << "/" << pdata.path_name;
        
        mtx_.lock();
        
        // 设置路径信息
        path_map_name_ = pdata.path_map;
        path_only_name_ = pdata.path_name;
        send_path_name_ = "/" + pdata.path_map + "/" + pdata.path_name;

        // 查询路径子类型
        robot_msgs::Web query_srv;
        query_srv.request.request_type = "Tquery";
        
        QJsonObject query_obj;
        query_obj["map"] = QString::fromStdString(path_map_name_);
        QJsonDocument query_doc(query_obj);
        query_srv.request.request_data = query_doc.toJson().toStdString();
        
        current_path_sub_type_ = "normal";  // 默认值
        
        if (srv_draw_path_.waitForExistence(ros::Duration(3.0)) && srv_draw_path_.call(query_srv)) {
            if (query_srv.response.response_type == "success") {
                std::string result = query_srv.response.response_data;
                QByteArray json_data = QByteArray::fromStdString(result);
                QJsonDocument doc = QJsonDocument::fromJson(json_data);
                
                if (!doc.isNull() && doc.isObject()) {
                    QJsonObject root = doc.object();
                    if (root.contains("paths") && root["paths"].isArray()) {
                        QJsonArray paths_array = root["paths"].toArray();
                        for (const QJsonValue& path_value : paths_array) {
                            if (path_value.isObject()) {
                                QJsonObject path_obj = path_value.toObject();
                                if (path_obj.contains("name") && path_obj["name"].toString().toStdString() == path_only_name_) {
                                    if (path_obj.contains("sub_type")) {
                                        current_path_sub_type_ = path_obj["sub_type"].toString().toStdString();
                                        LOG(INFO) << "恢复路径查询子类型: " << current_path_sub_type_;
                                    }
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
        if (p_shard_data_->has_paused_path_ && 
            p_shard_data_->paused_path_info_.point_info.point_name == path_only_name_ &&
            !p_shard_data_->paused_path_info_.remaining_points.empty())
        {
            LOG(INFO) << "SetCmd中发现共享数据中有剩余点，直接使用剩余点恢复";
            
            // 直接使用剩余点构建路径
            send_path_.poses.clear();
            for (const auto& point : p_shard_data_->paused_path_info_.remaining_points)
            {
                geometry_msgs::PoseStamped pose_stamped;
                pose_stamped.header.frame_id = "map";
                pose_stamped.header.stamp = ros::Time::now();
                pose_stamped.pose.position.x = point.x;
                pose_stamped.pose.position.y = point.y;
                pose_stamped.pose.position.z = 0.0;
                
                tf2::Quaternion q;
                q.setRPY(0, 0, point.yaw);
                pose_stamped.pose.orientation.x = q.x();
                pose_stamped.pose.orientation.y = q.y();
                pose_stamped.pose.orientation.z = q.z();
                pose_stamped.pose.orientation.w = q.w();
                send_path_.poses.push_back(pose_stamped);
            }
            
            // 标记为恢复模式
            is_resume_mode_ = true;
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            thread_pause_flag_ = false;
            process_index_ = ProcessIndex::SEND_PATH;  // 直接发送路径
            first_flag_ = false;
        }
        else
        {
            // 标记为恢复模式，需要重新请求路径
            is_resume_mode_ = true;
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            thread_pause_flag_ = false;
            process_index_ = ProcessIndex::RESUME_PATH;
            first_flag_ = false;
        }
        
        mtx_.unlock();
        
        LOG(INFO) << "SetCmd完成，开始恢复路径";
    }
}
void TeachAction::HandlePathError(const std::string& error_msg)
{
    LOG(ERROR) << "路径错误: " << error_msg;
    
    p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_FAILED;
    LOG(ERROR) << "路径错误，设置teachingpath_nav_status_为NAV_FAILED";

    first_flag_ = false;
    process_index_ = ProcessIndex::STEP0;
    thread_pause_flag_ = true;
    
    //std::string state = "GOTO_" + send_path_name_ + "_failed";
    //emit signal_PubStatus(state);
    
    CmdVelStr cmd_vel;
    cmd_vel.linear = 0.0;
    cmd_vel.angular = 0.0;
    emit signal_CmdVel(cmd_vel);
}

void TeachAction::MainLoop()
{
    switch (process_index_)
    {

        case ProcessIndex::STEP0:
        {
            if (!first_flag_)
            {
                first_flag_ = true;
                CmdVelStr cmd_vel;
                cmd_vel.linear = 0.0;
                cmd_vel.angular = 0.0;
                emit signal_CmdVel(cmd_vel);
            }
        }
        break;
        
        // 请求示教路径
        // 在 TeachAction::MainLoop() 的 STEP1 case 中修改
        case ProcessIndex::STEP1:
        {
            // start_reached_ = false;
            // end_reached_ = false;
            LOG(INFO) << "进入STEP1，请求路径: " << path_only_name_ << ", 地图: " << path_map_name_;
            if (path_map_name_.empty() || path_only_name_.empty()) {
            LOG(WARNING) << "路径名为空，跳过STEP1";
            process_index_ = ProcessIndex::STEP0;
            thread_pause_flag_ = true;
            break;
            }

            send_path_.poses.clear();
            robot_msgs::Web srv;
            srv.request.request_type = "Tquery";
            
            QJsonObject query_obj;
            query_obj["map"] = QString::fromStdString(path_map_name_);
            QJsonDocument query_doc(query_obj);
            srv.request.request_data = query_doc.toJson().toStdString();
            
            LOG(INFO) << "查询路径子类型，请求数据: " << srv.request.request_data;
            
            // 默认设置为 normal
            current_path_sub_type_ = "normal";
            
            if (srv_draw_path_.waitForExistence(ros::Duration(3.0)) && srv_draw_path_.call(srv)) {
                if (srv.response.response_type == "success") {
                    // 解析返回的路径列表，找到匹配的路径
                    std::string result = srv.response.response_data;
                    QByteArray json_data = QByteArray::fromStdString(result);
                    QJsonDocument doc = QJsonDocument::fromJson(json_data);
                    
                    if (!doc.isNull() && doc.isObject()) {
                        QJsonObject root = doc.object();
                        if (root.contains("paths") && root["paths"].isArray()) {
                            QJsonArray paths_array = root["paths"].toArray();
                            for (const QJsonValue& path_value : paths_array) {
                                if (path_value.isObject()) {
                                    QJsonObject path_obj = path_value.toObject();
                                    if (path_obj.contains("name") && path_obj["name"].toString().toStdString() == path_only_name_) {
                                        if (path_obj.contains("sub_type")) {
                                            current_path_sub_type_ = path_obj["sub_type"].toString().toStdString();
                                            LOG(INFO) << "找到路径 " << path_only_name_ << "，子类型: " << current_path_sub_type_;
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                LOG(WARNING) << "查询路径子类型服务调用失败，使用默认值 normal";
            }

            srv.request.request_type = "Tselect";
            
            // 构造JSON格式的请求数据
            QJsonObject request_obj;
            request_obj["map"] = QString::fromStdString(path_map_name_);
            request_obj["path"] = QString::fromStdString(path_only_name_);
            QJsonDocument request_doc(request_obj);
            srv.request.request_data = request_doc.toJson().toStdString();
            
            LOG(INFO) << "请求路径服务，请求数据: " << srv.request.request_data;
            
            // 添加服务存在性检查
            if (!srv_draw_path_.waitForExistence(ros::Duration(3.0))) {
                LOG(ERROR) << "路径服务不存在或未启动";
                break;
            }
            
            if (srv_draw_path_.call(srv))
            {
                LOG(INFO) << "路径服务调用成功，响应类型: " << srv.response.response_type;
                if (srv.response.response_type == "success")
                {
                    LOG(INFO) << "request draw path service response success";
                    
                    // 解析返回的路径数据
                    std::string result = srv.response.response_data;
                    LOG(INFO) << "收到路径数据，长度: " << result.length();
                    
                    // 打印前200个字符用于调试
                    if (result.length() > 0) {
                        std::string preview = result.substr(0, std::min((size_t)200, result.length()));
                        LOG(INFO) << "响应数据预览: " << preview;
                    }
                    
                    // 解析JSON格式的路径数据
                    send_path_.header.frame_id = "map";
                    send_path_.header.stamp = ros::Time::now();
                    
                    QByteArray json_data = QByteArray::fromStdString(result);
                    QJsonDocument doc = QJsonDocument::fromJson(json_data);
                    
                    if (!doc.isNull() && doc.isObject())
                    {
                        QJsonObject root = doc.object();
                        
                        // 检查是否有points数组
                        if (root.contains("points") && root["points"].isArray())
                        {
                            QJsonArray points_array = root["points"].toArray();
                            LOG(INFO) << "解析到 " << points_array.size() << " 个路径点";
                            
                            for (const QJsonValue& point_value : points_array)
                            {
                                if (point_value.isObject())
                                {
                                    QJsonObject point_obj = point_value.toObject();
                                    geometry_msgs::PoseStamped pose_stamped;
                                    pose_stamped.header.frame_id = "map";
                                    pose_stamped.header.stamp = ros::Time::now();
                                    
                                    // 解析坐标
                                    if (point_obj.contains("x") && point_obj.contains("y"))
                                    {
                                        pose_stamped.pose.position.x = point_obj["x"].toString().toDouble();
                                        pose_stamped.pose.position.y = point_obj["y"].toString().toDouble();
                                        pose_stamped.pose.position.z = 0.0;
                                        
                                        // 解析朝向
                                        double yaw = 0.0;
                                        if (point_obj.contains("yaw")) {
                                            yaw = point_obj["yaw"].toString().toDouble();
                                        }
                                        
                                        // 将yaw转换为四元数
                                        tf2::Quaternion q;
                                        q.setRPY(0, 0, yaw);
                                        pose_stamped.pose.orientation.x = q.x();
                                        pose_stamped.pose.orientation.y = q.y();
                                        pose_stamped.pose.orientation.z = q.z();
                                        pose_stamped.pose.orientation.w = q.w();
                                        
                                        send_path_.poses.push_back(pose_stamped);
                                    }
                                    else
                                    {
                                        LOG(WARNING) << "路径点缺少x或y字段";
                                    }
                                }
                            }
                            
                            LOG(INFO) << "成功解析 " << send_path_.poses.size() << " 个路径点";
                            
                            if (!send_path_.poses.empty())
                            {
                                p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_RUN;
                                if (need_resume_after_request_) {
                                    LOG(INFO) << "路径数据已重新获取，准备恢复执行";
                                    need_resume_after_request_ = false;
                                    
                                    if (p_shard_data_->has_paused_path_ && 
                                        p_shard_data_->paused_path_info_.point_info.point_name == path_only_name_)
                                    {
                                        size_t start_idx = p_shard_data_->paused_path_info_.paused_point_id;
                                        if (start_idx < send_path_.poses.size()) {
                                            std::vector<geometry_msgs::PoseStamped> remaining_poses;
                                            for (size_t i = start_idx; i < send_path_.poses.size(); i++) {
                                                remaining_poses.push_back(send_path_.poses[i]);
                                            }
                                            send_path_.poses = remaining_poses;
                                            LOG(INFO) << "重新请求后截取剩余路径，从索引 " << start_idx << " 开始，剩余 " << send_path_.poses.size() << " 个点";
                                        }
                                    }
                                }
                                LOG(INFO) << "设置teachingpath_nav_status_为NAV_RUN";
                                
                                // 直接进入发送路径状态
                                process_index_ = ProcessIndex::SEND_PATH;
                                LOG(INFO) << "STEP1:发送路径";

                                
                                
                                // 发布状态
                                //std::string state = "GOTO_" + send_path_name_;
                                //emit signal_PubStatus(state);
                            }
                            else
                            {
                                LOG(ERROR) << "解析后send_path_为空";
                            }
                        }
                        else
                        {
                            LOG(ERROR) << "JSON中未找到points数组";
                            // 尝试打印JSON结构
                            QString json_str = doc.toJson(QJsonDocument::Indented);
                            LOG(INFO) << "完整的JSON结构:" << json_str.toStdString(); 
                        }
                    }
                    else
                    {
                        LOG(ERROR) << "Failed to parse response data as JSON";
                    }
                }
                else
                {
                    LOG(ERROR) << "服务响应失败: " << srv.response.response_type;
                }
            }
            else
            {
                LOG(ERROR) << "路径服务调用失败";
            }
        }
        break;
        
        case ProcessIndex::SEND_PATH:
        {
            // 确保send_path_有数据
            if (send_path_.poses.empty()) {
                LOG(ERROR) << "send_path_为空，无法发送路径";
                break;
            }
            int point_count = 0;
            MoveDataCmd mdc;
            mdc.taskcmd_type = TaskStatus::T_LOCALE;
            mdc.goal.clear();
            
            GlobalPlannerType path_type;
            if (current_path_sub_type_ == "edge") {
                path_type = GlobalPlannerType::FIX_PATH;  // edge类型使用固定路径
                LOG(INFO) << "路径子类型为 edge，使用 FIX_PATH 模式";
            } else {
                path_type = GlobalPlannerType::COVER_PATH;  // normal类型使用覆盖路径
                LOG(INFO) << "路径子类型为 normal，使用 COVER_PATH 模式";
            }
            // 将路径所有点添加到目标中
            for(auto& point : send_path_.poses) 
            {
                PoseData pose;
                pose.type = path_type;  // 使用当前路径模式
                pose.x = point.pose.position.x;
                pose.y = point.pose.position.y;
                
                // 计算yaw
                tf::Quaternion q(
                    point.pose.orientation.x,
                    point.pose.orientation.y, 
                    point.pose.orientation.z,
                    point.pose.orientation.w);
                tf::Matrix3x3 m(q);
                double roll, pitch, yaw;
                m.getRPY(roll, pitch, yaw);
                pose.yaw = yaw;
                
                mdc.goal.push_back(pose);
                point_count++;
            }
            LOG(INFO) << "实际添加了 " << point_count << " 个目标点，路径类型: " << (path_type == GlobalPlannerType::FIX_PATH ? "FIX_PATH" : "COVER_PATH");
  
            QVariant qvr;
            qvr.setValue(mdc);
            emit signal_MoveCmd(qvr);
            
            // 重置move状态
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            
            // 进入运行状态
            process_index_ = ProcessIndex::RUN;
        }
        break;
        case ProcessIndex::RESUME_PATH:
        {
            LOG(INFO) << "进入RESUME_PATH状态，恢复暂停的路径";
            if (is_resume_mode_) {
                    
                robot_msgs::Web query_srv;
                query_srv.request.request_type = "Tquery";
                
                QJsonObject query_obj;
                query_obj["map"] = QString::fromStdString(path_map_name_);
                QJsonDocument query_doc(query_obj);
                query_srv.request.request_data = query_doc.toJson().toStdString();
                
                current_path_sub_type_ = "normal";  // 默认值
                
                if (srv_draw_path_.waitForExistence(ros::Duration(3.0)) && srv_draw_path_.call(query_srv)) {
                    if (query_srv.response.response_type == "success") {
                        std::string result = query_srv.response.response_data;
                        QByteArray json_data = QByteArray::fromStdString(result);
                        QJsonDocument doc = QJsonDocument::fromJson(json_data);
                        
                        if (!doc.isNull() && doc.isObject()) {
                            QJsonObject root = doc.object();
                            if (root.contains("paths") && root["paths"].isArray()) {
                                QJsonArray paths_array = root["paths"].toArray();
                                for (const QJsonValue& path_value : paths_array) {
                                    if (path_value.isObject()) {
                                        QJsonObject path_obj = path_value.toObject();
                                        if (path_obj.contains("name") && path_obj["name"].toString().toStdString() == path_only_name_) {
                                            if (path_obj.contains("sub_type")) {
                                                current_path_sub_type_ = path_obj["sub_type"].toString().toStdString();
                                                LOG(INFO) << "RESUME_PATH查询到子类型: " << current_path_sub_type_;
                                            }
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                
                // 根据子类型选择路径类型
                GlobalPlannerType resume_path_type;
                if (current_path_sub_type_ == "edge") {
                    resume_path_type = GlobalPlannerType::FIX_PATH;
                    LOG(INFO) << "RESUME_PATH使用 FIX_PATH 模式 (edge类型)"; 
                } else {
                    resume_path_type = GlobalPlannerType::COVER_PATH;
                    LOG(INFO) << "RESUME_PATH使用 COVER_PATH 模式 (normal类型)"; 
                }
                
                // 从共享数据获取剩余路径信息
                if (p_shard_data_->has_paused_path_ && 
                    p_shard_data_->paused_path_info_.point_info.point_name == path_only_name_)
                {
                    LOG(INFO) << "找到暂停信息，开始恢复路径执行";
                    // 设置路径状态为运行
                    p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_RUN;
                    
                    // 构造剩余的路径点
                    MoveDataCmd path_cmd;
                    path_cmd.taskcmd_type = TaskStatus::T_LOCALE;
                    path_cmd.goal.clear();
                    
                    // 从保存的剩余点构建路径
                    size_t remaining_count = 0;
                    for (const auto& point : p_shard_data_->paused_path_info_.remaining_points) {
                        PoseData pose;
                        pose.type = resume_path_type;
                        pose.x = point.x;
                        pose.y = point.y;
                        pose.yaw = point.yaw;
                        path_cmd.goal.push_back(pose);
                        remaining_count++;
                    }
                    
                    if (path_cmd.goal.empty()) {
                        LOG(WARNING) << "没有剩余路径点可恢复";
                        process_index_ = ProcessIndex::STEP0;
                        is_resume_mode_ = false;
                        break;
                    }
                    
                    // 发送剩余路径
                    QVariant qvr;
                    qvr.setValue(path_cmd);
                    emit signal_MoveCmd(qvr);
                    
                    LOG(INFO) << "发送 " << path_cmd.goal.size() << " 个剩余路径点进行恢复";
                    
                    // 更新 send_path_ 为剩余路径
                    if (p_shard_data_->paused_path_info_.remaining_points.size() > 0) {
                        send_path_.poses.clear();
                        for (const auto& point : p_shard_data_->paused_path_info_.remaining_points) {
                            geometry_msgs::PoseStamped pose_stamped;
                            pose_stamped.header.frame_id = "map";
                            pose_stamped.header.stamp = ros::Time::now();
                            pose_stamped.pose.position.x = point.x;
                            pose_stamped.pose.position.y = point.y;
                            pose_stamped.pose.position.z = 0.0;
                            
                            tf2::Quaternion q;
                            q.setRPY(0, 0, point.yaw);
                            pose_stamped.pose.orientation.x = q.x();
                            pose_stamped.pose.orientation.y = q.y();
                            pose_stamped.pose.orientation.z = q.z();
                            pose_stamped.pose.orientation.w = q.w();
                            send_path_.poses.push_back(pose_stamped);
                        }
                    }
                    
                    // 重置移动状态
                    p_shard_data_->move_status_ = MoveStatus::RUNNING;
                    
                    // 进入运行状态
                    process_index_ = ProcessIndex::RUN;
                    is_resume_mode_ = false;
                    
                    LOG(INFO) << "路径恢复成功，继续执行: " << send_path_name_;
                } 
                else 
                {
                    LOG(ERROR) << "恢复模式标志已设置但无暂停信息，返回STEP0";
                    process_index_ = ProcessIndex::STEP0;
                    is_resume_mode_ = false;
                }
            } 
            else 
            {
                LOG(ERROR) << "恢复模式标志未设置，返回STEP0";
                process_index_ = ProcessIndex::STEP0;
            }
        }
        break;
        case ProcessIndex::RUN:
        {
            if (cmd_type_ != "teach_path") {
                // 如果不是示教路径，不应该停留在 RUN 状态
                if (process_index_ == ProcessIndex::RUN) {
                    LOG(INFO) << "cmd_type_不是teach_path，退出RUN状态";
                    process_index_ = ProcessIndex::STEP0;
                    thread_pause_flag_ = true;
                }
                break;
            }
            
            // 检查路径名称是否有效
            if (path_only_name_.empty()) {
                LOG(WARNING) << "路径名称为空，退出RUN状态";
                process_index_ = ProcessIndex::STEP0;
                thread_pause_flag_ = true;
                break;
            }

            std_msgs::String cmdctrl;
            // 首先检查是否处于暂停状态
            if (p_shard_data_->teachingpath_nav_status_.goal_status == NavStatus::NAV_STOP) 
            {
                // 处于暂停状态，等待恢复
                LOG(INFO) << "路径处于暂停状态，等待恢复命令...";

                /*if (path_task_ == "wash") {
                    cmdctrl.data = "washClose";
                    io_data_all_pub_.publish(cmdctrl);
                } else if (path_task_ == "brush") {
                    cmdctrl.data = "brushClose";
                    io_data_all_pub_.publish(cmdctrl);
                } else if (path_task_ == "mop") {
                    cmdctrl.data = "mopClose";
                    io_data_all_pub_.publish(cmdctrl);
                } else if (path_task_ == "saction") {
                    cmdctrl.data = "sactionClose";
                    io_data_all_pub_.publish(cmdctrl);
                }*/
                // 检查是否收到恢复命令
                if (p_shard_data_->teachingpath_nav_status_.goal_status == NavStatus::NAV_RUN) 
                {
                    LOG(INFO) << "收到恢复命令，继续执行示教路径";
                    /*if (path_task_ == "wash") {
                        cmdctrl.data = "washOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "brush") {
                        cmdctrl.data = "brushOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "mop") {
                        cmdctrl.data = "mopOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "saction") {
                        cmdctrl.data = "sactionOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    }*/
                    // 发送继续命令给 move_action
                    MoveDataCmd goon_cmd;
                    goon_cmd.taskcmd_type = TaskStatus::T_GOON;
                    QVariant qvr_goon;
                    qvr_goon.setValue(goon_cmd);
                    emit signal_MoveCmd(qvr_goon);
                    
                    // 设置移动状态为运行
                    p_shard_data_->move_status_ = MoveStatus::RUNNING;
                    LOG(INFO) << "已发送继续命令，恢复路径执行";
                }
                else
                {
                    // 保持暂停状态，不发速度命令
                    CmdVelStr cmd_vel;
                    cmd_vel.linear = 0.0;
                    cmd_vel.angular = 0.0;
                    emit signal_CmdVel(cmd_vel);
                    break;  // 跳出，等待恢复
                }
                if (need_resend_path_) 
                {
                    // 重新发送剩余的路径点
                    LOG(INFO) << "重新发送剩余路径点";
                    SendRemainingPath();
                    need_resend_path_ = false;
                }
            }
            
            else if(p_shard_data_->move_status_ == MoveStatus::RUNNING && cmd_type_== "teach_path")
            {
                /*if(p_shard_data_->at_start_){
                    if (path_task_ == "wash") {
                        cmdctrl.data = "washOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "brush") {
                        cmdctrl.data = "brushOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "mop") {
                        cmdctrl.data = "mopOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "saction") {
                        cmdctrl.data = "sactionOpen";
                        io_data_all_pub_.publish(cmdctrl);
                    }
                }
                else if(p_shard_data_->at_end_){
                    if (path_task_ == "wash") {
                        cmdctrl.data = "washClose";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "brush") {
                        cmdctrl.data = "brushClose";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "mop") {
                        cmdctrl.data = "mopClose";
                        io_data_all_pub_.publish(cmdctrl);
                    } else if (path_task_ == "saction") {
                        cmdctrl.data = "sactionClose";
                        io_data_all_pub_.publish(cmdctrl);
                    }
                }*/
            }
            
            else if (p_shard_data_->move_status_ == MoveStatus::ARRIVE && cmd_type_== "teach_path") {
                LOG(INFO) << "捕获到ARRIVE状态，检查路径信息: path_only_name_='" << path_only_name_ << "'";

                //LOG(INFO) << "TeachAction捕获到ARRIVE状态，检查路径信息: path_only_name_='" << path_only_name_ << "'";
                
                // 增加一个标志，确保只有真正在执行时才处理
                static bool is_executing = false;
                
                // 检查是否真的在执行示教路径（通过一个成员变量）
                /*if (!is_executing_teach_) {  // 建议添加成员变量
                    LOG(WARNING) << "TeachAction收到ARRIVE但未开始执行示教路径，忽略";
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    break;
                }*/
                
                // 确认当前确实在执行示教路径
                if (path_only_name_.empty() || send_path_name_.empty()) {
                    LOG(INFO) << "收到ARRIVE但路径信息无效，忽略";
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    // 重置执行标志
                    is_executing_teach_ = false;
                    break;
                }
                
                // 验证是否真的在导航状态
                if (p_shard_data_->teachingpath_nav_status_.goal_status != NavStatus::NAV_RUN) {
                    LOG(INFO) << "收到ARRIVE但导航状态不是RUN，当前状态: " << p_shard_data_->teachingpath_nav_status_.goal_status;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    // 重置执行标志
                    is_executing_teach_ = false;
                    process_index_ = ProcessIndex::STEP0;
                    p_shard_data_->teach_success_=true;
                    thread_pause_flag_ = true;
                    break;
                }
                // 路径导航成功
                if (!path_only_name_.empty()&& path_only_name_ != "") 
                {
                    mtx_.lock();
                    LOG(INFO) << "确认当前处理的是示教路径: " << send_path_name_ << "，设置teachingpath_nav_status_=NAV_SUCCESS";

                    p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    p_shard_data_->now_nav_status_="success";
                    std::string state = "GOTO_" + send_path_name_ + "_success";
                    emit signal_PubStatus(state);
                    //std::string success_status = "GOTO_" + send_path_name_ + "_success";
                    /*if (p_shard_data_->is_path_over_){
                        emit signal_PubStatus("success");
                        p_shard_data_->is_path_over_=false;
                    }*/
                    //emit signal_PubStatus("success");

                    /*if(p_shard_data_->at_end_){
                        if (path_task_ == "wash") {
                            cmdctrl.data = "washClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (path_task_ == "brush") {
                            cmdctrl.data = "brushClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (path_task_ == "mop") {
                            cmdctrl.data = "mopClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (path_task_ == "saction") {
                            cmdctrl.data = "sactionClose";
                            io_data_all_pub_.publish(cmdctrl);
                        }
                    }*/
                    LOG(INFO) << "示教路径执行成功: " << send_path_name_ << ",清除路径类型，路径名称以及清空完整路径名 ";
                    // 立即清除状态，防止其他Action误用
                    cmd_type_ = "";           // 清空类型，防止影响下一条路径
                    path_only_name_ = "";     // 清空路径名
                    send_path_name_ = "";     // 清空完整路径名
                    LOG(INFO) << "设置导航状态：" << p_shard_data_->teachingpath_nav_status_.goal_status;
                    p_shard_data_->teach_success_=true;
                    mtx_.unlock();
                    process_index_ = ProcessIndex::STEP0;
                    thread_pause_flag_ = true;
                }
                else 
                {
                    LOG(INFO) << "收到ARRIVE但路径信息无效: path_only_name_='" << path_only_name_ << "'，忽略该状态";
                }
            }
            else if (p_shard_data_->move_status_ == MoveStatus::ABORTED && cmd_type_== "teach_path") {
                if (!path_only_name_.empty()&& path_only_name_ != "") 
                {
                    // 路径导航失败
                    //p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_FAILED;
                    LOG(INFO) << "路径导航失败";
                    p_shard_data_->is_teach_path_start_ = false;
                    p_shard_data_->is_teach_path_end_ = false;
                    
                    //std::string failed_status = "GOTO_" + send_path_name_ + "_failed";
                    //emit signal_PubStatus(failed_status);
                    /*if(p_shard_data_->at_end_){
                        if (path_task_ == "wash") {
                            cmdctrl.data = "washClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (path_task_ == "brush") {
                            cmdctrl.data = "brushClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (path_task_ == "mop") {
                            cmdctrl.data = "mopClose";
                            io_data_all_pub_.publish(cmdctrl);
                        } else if (path_task_ == "saction") {
                            cmdctrl.data = "sactionClose";
                            io_data_all_pub_.publish(cmdctrl);
                        }
                    }*/
                    /*if (multi_path_mode_) {
                        current_path_index_++;
                        if (current_path_index_ < path_queue_.size()) {
                            process_index_ = ProcessIndex::STEP1;
                        } else {
                            process_index_ = ProcessIndex::STEP0;
                            thread_pause_flag_ = true;
                        }
                    } else {*/
                        //立即清除状态，防止其他Action误用
                        // 直接结束
                    mtx_.lock();
                    p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_FAILED;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    process_index_ = ProcessIndex::STEP0;
                    thread_pause_flag_ = true;
                    p_shard_data_->now_nav_status_="failed";
                    
                    std::string state = "GOTO_" + path_only_name_ + "_failed";
                    emit signal_PubStatus(state);
                    LOG(INFO) << "示教路径执行失败: " << send_path_name_ << ",清除路径类型，路径名称以及清空完整路径名 ";
                    cmd_type_ = "";           // 清空类型，防止影响下一条路径
                    path_only_name_ = "";     // 清空路径名
                    send_path_name_ = "";     // 清空完整路径名
                    LOG(INFO) << "设置导航状态：" << p_shard_data_->teachingpath_nav_status_.goal_status;
                    p_shard_data_->teach_fault_=true;
                    //p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    mtx_.unlock();
                    process_index_ = ProcessIndex::STEP0;
                    thread_pause_flag_ = true;
                }
            }
        }
        break;
        
        default:
            process_index_ = ProcessIndex::STEP0;
        break;
    }
}






