#include "coverage_planner.h"
//https://doc.cgal.org/Manual/3.2/doc_html/cgal_manual/
void CoveragePlanner::plan(cv::Mat &img,int &raduis)//区域的边界，像素值,cv::Point &st
    {
    raduis_=raduis;
    //从起点向图片空白区域
    //Point_2 start=Point_2(img.rows/2,img.cols/2);
    cv::Mat gray;
    cv::cvtColor(img, gray, cv::COLOR_BGR2GRAY);

    cv::Mat img_ = gray.clone();

    cv::threshold(img_, img_, 250, 255, 0);//二值化
    //定义一个椭圆形的腐蚀核（kernel），并对图像进行腐蚀操作，用于去除图像中的噪点或细小区域。
    cv::Mat erode_kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(raduis_,raduis_), cv::Point(-1,-1)); // size: robot radius
    cv::morphologyEx(img_, img_, cv::MORPH_ERODE, erode_kernel);
     //定义一个椭圆形的开运算核，再对图像进行开运算操作，可以进一步平滑图像并消除一些小的对象。
    //cv::Mat open_kernel = cv::getStructuringElement(cv::MORPH_ELLIPSE, cv::Size(5,5), cv::Point(-1,-1));
    cv::morphologyEx(img_, img_, cv::MORPH_OPEN, erode_kernel);

//    cv::imshow("preprocess", img_);
    //通过findContours函数找到图像中的轮廓，存储在cnts中，并且给出了轮廓的层级关系，存储在hierarchy中。
    std::vector<std::vector<cv::Point>> cnts;
    std::vector<cv::Vec4i> hierarchy; // index: next, prev, first_child, parent
    cv::findContours(img_, cnts, hierarchy, cv::RETR_TREE, cv::CHAIN_APPROX_SIMPLE);

    std::vector<int> cnt_indices(cnts.size());
    std::iota(cnt_indices.begin(), cnt_indices.end(), 0);
    std::sort(cnt_indices.begin(), cnt_indices.end(), [&cnts](int lhs, int rhs){return cv::contourArea(cnts[lhs]) > cv::contourArea(cnts[rhs]);});
    int ext_cnt_idx = cnt_indices.front();

    cv::Mat cnt_canvas = img.clone();
    cv::drawContours(cnt_canvas, cnts, ext_cnt_idx, cv::Scalar(0,0,255));
    std::vector<std::vector<cv::Point>> contours;
    contours.emplace_back(cnts[ext_cnt_idx]);
    //std::cout<<"cnts: "<<cnts[ext_cnt_idx][0]<<std::endl;
    // find all the contours of obstacle
    for(size_t i = 0; i < hierarchy.size(); i++){
        if(hierarchy[i][3]==ext_cnt_idx){ // parent contour's index equals to external contour's index
            contours.emplace_back(cnts[i]);
            cv::drawContours(cnt_canvas, cnts, i, cv::Scalar(255,0,0));
        }
    }
    //cv::imwrite("contours", cnt_canvas);

    cv::Mat cnt_img = cv::Mat(img.rows, img.cols, CV_8UC3);
    cnt_img.setTo(255);
    for(size_t i = 0; i < contours.size(); i++){
        cv::drawContours(cnt_img, contours, i, cv::Scalar(0,0,0));
    }
    //cv::imwrite("only contours", cnt_img);
//把一个连续光滑曲线折线化，对图像轮廓点进行多边形拟合。
    cv::Mat poly_canvas = img.clone();
    std::vector<cv::Point> poly;
    std::vector<std::vector<cv::Point>> polys;
    for(auto& contour : contours){
        cv::approxPolyDP(contour, poly, 3, true);
        polys.emplace_back(poly);
        poly.clear();
    }
    for(size_t i = 0; i < polys.size(); i++){
        cv::drawContours(poly_canvas, polys, i, cv::Scalar(255,0,255));
    }
    //cv::imwrite("polygons", poly_canvas);

    cv::Mat poly_img = cv::Mat(img.rows, img.cols, CV_8UC3);
    poly_img.setTo(255);
    for(size_t i = 0; i < polys.size(); i++){
        cv::drawContours(poly_img, polys, i, cv::Scalar(0,0,0));
    }
	//cv::imwrite("only polygons", poly_img);

    // compute main direction边缘线段中出现频率最高的角度。

    // [0,180)
    std::vector<int> line_deg_histogram(180);
    double line_len; // weight
    double line_deg;
    int line_deg_idx;

    cv::Mat line_canvas = img.clone();
    auto ext_poly = polys.front();
    ext_poly.emplace_back(ext_poly.front());//将多边形的第一个顶点添加到末尾，以闭合多边形。
    for(size_t i = 1; i < ext_poly.size(); i++){
        line_len = std::sqrt(std::pow((ext_poly[i].x-ext_poly[i-1].x),2)+std::pow((ext_poly[i].y-ext_poly[i-1].y),2));//计算当前线段的长度。
        // y-axis towards up, x-axis towards right, theta is from x-axis to y-axis
        line_deg = std::round(atan2(-(ext_poly[i].y-ext_poly[i-1].y),(ext_poly[i].x)-ext_poly[i-1].x)/M_PI*180.0); // atan2: (-180, 180]计算当前线段的角度，使用反正切函数atan2，并将弧度转换为角度。
        line_deg_idx = (int(line_deg) + 180) % 180; // [0, 180)将角度映射到0到179范围内，以便更新角度直方图。
        line_deg_histogram[line_deg_idx] += int(line_len);//将当前线段长度加到对应角度的直方图中。

//        //std::cout<<"deg: "<<line_deg_idx<<std::endl;
//        cv::line(line_canvas, ext_poly[i], ext_poly[i-1], cv::Scalar(255,255,0));
//        cv::imshow("lines",line_canvas);
//        cv::waitKey();
    }

//    cv::waitKey();

    auto it = std::max_element(line_deg_histogram.begin(), line_deg_histogram.end());
    int main_deg = (it-line_deg_histogram.begin());//计算直方图中值最大的元素的索引，即主要角度。
    //std::cout<<"main deg: "<<main_deg<<std::endl;


    // construct polygon with holes

    std::vector<cv::Point> outer_poly = polys.front();
    polys.erase(polys.begin());
    std::vector<std::vector<cv::Point>> inner_polys = polys;

    //从目标区域多边形中提取第一个点（图片中心），作为覆盖路经的起点(转成像素点)
    //从outer_polygon中取离起离图片中心最近的点作为起点
    Polygon_2 outer_polygon;
    Point_2 start;
    double dist=sqrt(pow(img.rows/2, 2) + pow(img.cols/2, 2));//初始化为最大值
    for(const auto& point : outer_poly){
        outer_polygon.push_back(Point_2(point.x, point.y));
        //std::cout<<"outer_poly "<<point.x<<" "<<point.y<<std::endl;
        double  tmp_dis=sqrt(pow(point.x - img.rows/2, 2) + pow(point.y - img.cols/2, 2));//与图片中心（区域起点）的距离
        if(tmp_dis<dist)
        {
            dist=tmp_dis;//dist = std::min(tmp_dis,dist);
            start=Point_2(point.x, point.y);
            ////std::cout<<"start "<<point.x<<" "<<point.y<<std::endl;
        }
    }

    int num_holes = inner_polys.size();
    std::vector<Polygon_2> holes(num_holes);
    for(size_t i = 0; i < inner_polys.size(); i++){
        for(const auto& point : inner_polys[i]){
            holes[i].push_back(Point_2(point.x, point.y));
        }
    }
    PolygonWithHoles pwh(outer_polygon, holes.begin(), holes.end());

    // cell decomposition细胞分解
    std::vector<Polygon_2> bcd_cells;
//    polygon_coverage_planning::computeBestTCDFromPolygonWithHoles(pwh, &bcd_cells);
    polygon_coverage_planning::computeBestBCDFromPolygonWithHoles(pwh, &bcd_cells);
    totoal_areas_ = CGAL::to_double(polygon_coverage_planning::computeArea(pwh)) * 0.05 * 0.05;//这里算的是区域边界缩小后的面积（扣除孔洞），应该算原始区域的面积
    //std::cout << "clean area: " << totoal_areas_ << std::endl;
    auto cell_graph = calculateDecompositionAdjacency(bcd_cells);

    //=Point_2(offset_polygon[0]);//getStartingPoint(img);
    int starting_cell_idx = getCellIndexOfPoint(bcd_cells, start);
    //std::cout<<"starting_cell_idx:"<<starting_cell_idx;
    auto cell_idx_path = getTravellingPath(cell_graph, starting_cell_idx);
    //std::cout<<"path length: "<<cell_idx_path.size()<<std::endl;
    //std::cout<<"start";
    for(auto& cell_idx:cell_idx_path){
        //std::cout<<"->"<<cell_idx;
    }
    int sweep_step = raduis_;
    std::vector<std::vector<Point_2>> cells_sweeps;
    for (size_t i = 0; i < bcd_cells.size(); ++i) {
        // Compute all cluster sweeps.
        std::vector<Point_2> cell_sweep;
        Direction_2 best_dir;
        polygon_coverage_planning::findBestSweepDir(bcd_cells[i], &best_dir);
        polygon_coverage_planning::visibility_graph::VisibilityGraph vis_graph(bcd_cells[i]);

        bool counter_clockwise = true;
        polygon_coverage_planning::computeSweep(bcd_cells[i], vis_graph, sweep_step, best_dir, counter_clockwise, &cell_sweep);
        cells_sweeps.emplace_back(cell_sweep);
    }
    auto cell_intersections = calculateCellIntersections(bcd_cells, cell_graph);
    std::vector<Point_2> way_points;
//    Point_2 point = start;
//    std::list<Point_2> next_candidates;
//    Point_2 next_point;
//    std::vector<Point_2> shortest_path;
//
//    if(doReverseNextSweep(start, cells_sweeps[cell_idx_path.front()])){
//        shortest_path = getShortestPath(bcd_cells[cell_idx_path.front()], start, cells_sweeps[cell_idx_path.front()].back());
//        way_points.insert(way_points.end(), shortest_path.begin(), std::prev(shortest_path.end()));
//    } else{
//        shortest_path = getShortestPath(bcd_cells[cell_idx_path.front()], start, cells_sweeps[cell_idx_path.front()].front());
//        way_points.insert(way_points.end(), shortest_path.begin(), std::prev(shortest_path.end()));
//    }
//
//    point = way_points.back();
//
//    for(size_t i = 0; i < cell_idx_path.size(); ++i){
//        // has been cleaned?
//        if(!cell_graph[cell_idx_path[i]].isCleaned){
//            // need to reverse?
//            if(doReverseNextSweep(point, cells_sweeps[cell_idx_path[i]])){
//                way_points.insert(way_points.end(), cells_sweeps[cell_idx_path[i]].rbegin(), cells_sweeps[cell_idx_path[i]].rend());
//            }else{
//                way_points.insert(way_points.end(), cells_sweeps[cell_idx_path[i]].begin(), cells_sweeps[cell_idx_path[i]].end());
//            }
//            // now cleaned
//            cell_graph[cell_idx_path[i]].isCleaned = true;
//            // update current point
//            point = way_points.back();
//            // find shortest path to next cell
//            if((i+1)<cell_idx_path.size()){
//                next_candidates = cell_intersections[cell_idx_path[i]][cell_idx_path[i+1]];
//                if(doReverseNextSweep(point, cells_sweeps[cell_idx_path[i+1]])){
//                    next_point = findNextGoal(point, cells_sweeps[cell_idx_path[i+1]].back(), next_candidates);
//                    shortest_path = getShortestPath(bcd_cells[cell_idx_path[i]], point, next_point);
//                    way_points.insert(way_points.end(), std::next(shortest_path.begin()), std::prev(shortest_path.end()));
//                    shortest_path = getShortestPath(bcd_cells[cell_idx_path[i+1]], next_point, cells_sweeps[cell_idx_path[i+1]].back());
//                }else{
//                    next_point = findNextGoal(point, cells_sweeps[cell_idx_path[i+1]].front(), next_candidates);
//                    shortest_path = getShortestPath(bcd_cells[cell_idx_path[i]], point, next_point);
//                    way_points.insert(way_points.end(), std::next(shortest_path.begin()), std::prev(shortest_path.end()));
//                    shortest_path = getShortestPath(bcd_cells[cell_idx_path[i+1]], next_point, cells_sweeps[cell_idx_path[i+1]].front());
//                }
//                way_points.insert(way_points.end(), shortest_path.begin(), std::prev(shortest_path.end()));
//                point = way_points.back();
//            }
//        }else{
//            shortest_path = getShortestPath(bcd_cells[cell_idx_path[i]],
//                                            cells_sweeps[cell_idx_path[i]].front(),
//                                            cells_sweeps[cell_idx_path[i]].back());
//            if(doReverseNextSweep(point, cells_sweeps[cell_idx_path[i]])){
//                way_points.insert(way_points.end(), shortest_path.rbegin(), shortest_path.rend());
//            }else{
//                way_points.insert(way_points.end(), shortest_path.begin(), shortest_path.end());
//            }
//            point = way_points.back();
//
//            if((i+1)<cell_idx_path.size()){
//                next_candidates = cell_intersections[cell_idx_path[i]][cell_idx_path[i+1]];
//                if(doReverseNextSweep(point, cells_sweeps[cell_idx_path[i+1]])){
//                    next_point = findNextGoal(point, cells_sweeps[cell_idx_path[i+1]].back(), next_candidates);
//                    shortest_path = getShortestPath(bcd_cells[cell_idx_path[i]], point, next_point);
//                    way_points.insert(way_points.end(), std::next(shortest_path.begin()), std::prev(shortest_path.end()));
//                    shortest_path = getShortestPath(bcd_cells[cell_idx_path[i+1]], next_point, cells_sweeps[cell_idx_path[i+1]].back());
//                }else{
//                    next_point = findNextGoal(point, cells_sweeps[cell_idx_path[i+1]].front(), next_candidates);
//                    shortest_path = getShortestPath(bcd_cells[cell_idx_path[i]], point, next_point);
//                    way_points.insert(way_points.end(), std::next(shortest_path.begin()), std::prev(shortest_path.end()));
//                    shortest_path = getShortestPath(bcd_cells[cell_idx_path[i+1]], next_point, cells_sweeps[cell_idx_path[i+1]].front());
//                }
//                way_points.insert(way_points.end(), shortest_path.begin(), std::prev(shortest_path.end()));
//                point = way_points.back();
//            }
//        }
//    }

// 清空数据
    way_points.clear();
    vec_path_.clear();
    way_points.emplace_back(start);
    std::vector<bool> point_type;
    point_type.emplace_back(true);
    Point_2 point=start;

    for (auto &idx : cell_idx_path)
    {
        if (!cell_graph[idx].isCleaned)
        {
            // 把区域的第一个点的属性置为巡逻点
            if (doReverseNextSweep(point, cells_sweeps[idx]))
            {
                // way_points.insert(way_points.end(), cells_sweeps[idx].rbegin(), cells_sweeps[idx].rend());
                bool is_first_point = true;
                for (int i = (cells_sweeps[idx].size() - 1); i >= 0; --i) {
                    if (is_first_point){
                        is_first_point = false;
                        // 是巡逻点
                        way_points.emplace_back(cells_sweeps[idx].at(i));//0
                        point_type.emplace_back(true);
                    }else{
                        way_points.emplace_back(cells_sweeps[idx].at(i));//1
                        point_type.emplace_back(false);
                    }
                }
            }
            else
            {
                // way_points.insert(way_points.end(), cells_sweeps[idx].begin(), cells_sweeps[idx].end());
                bool is_first_point = true;
                for (size_t i = 0; i <= (cells_sweeps[idx].size() - 1); ++i) {
                    if (is_first_point){
                        is_first_point = false;
                        // 是巡逻点
                        way_points.emplace_back(cells_sweeps[idx].at(i));//0
                        point_type.emplace_back(true);
                    }else{
                        way_points.emplace_back(cells_sweeps[idx].at(i));//1
                        point_type.emplace_back(false);
                    }
                }
            }
            cell_graph[idx].isCleaned = true;
            point = way_points.back();//Point_2(way_points.back().x, way_points.back().y);
        }
    }

    cv::Point p1, p2;
//    cv::namedWindow("cover",cv::WINDOW_NORMAL);
//    cv::imshow("cover", img);
//    cv::waitKey();
    //把start画上
    cv::circle(img,cv::Point(CGAL::to_double(start.x()),CGAL::to_double(start.y())),2,cv::Scalar(0,255,255),-1);
    cv::putText(img, "0", cv::Point(CGAL::to_double(start.x()),CGAL::to_double(start.y())),cv::FONT_HERSHEY_COMPLEX, 0.2, cv::Scalar(0, 0, 255));
	int index=0;
    vec_path_.emplace_back(Vec2d(CGAL::to_double(start.x()),CGAL::to_double(start.y())));
    for(size_t i = 1; i < way_points.size(); ++i){

        p1 = cv::Point(CGAL::to_double(way_points[i-1].x()),CGAL::to_double(way_points[i-1].y()));
        p2 = cv::Point(CGAL::to_double(way_points[i].x()),CGAL::to_double(way_points[i].y()));
        vec_path_.emplace_back(Vec2d(p2.x,p2.y));
        if(point_type[i])
        {
        cv::circle(img,cv::Point(CGAL::to_double(way_points[i].x()),CGAL::to_double(way_points[i].y())),2,cv::Scalar(0,255,0),-1);
        cv::circle(img,cv::Point(CGAL::to_double(way_points[i-1].x()),CGAL::to_double(way_points[i-1].y())),2,cv::Scalar(0,255,0),-1);
        cv::line(img, p1, p2, cv::Scalar(0, 255, 0));//巡逻路经
        	index++;
            cv::putText(img, std::to_string(index), p2,cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(0, 0, 255));
            //cv::putText(img, std::to_string(i-1), p1,cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(0, 0, 255));
        }
        else
        {
           cv::line(img, p1, p2, cv::Scalar(0, 64, 100));
        }
//        cv::namedWindow("result_path",cv::WINDOW_NORMAL);
//        cv::imshow("result_path", img);
//        cv::waitKey(1);
        //cv::line(img, p1, p2, cv::Scalar(200, 200, 200));
    }

    cv::imwrite("result_path.png",img);
    //cv::waitKey();
}

void CoveragePlanner::onMouseHandle(int event, int x, int y, int flags, void* params)
{
    MouseParams* mp = (MouseParams*)params;
    switch (event)
    {
        case cv::EVENT_LBUTTONDOWN:
        {
            cv::circle(mp->img, cv::Point(x,y), 3, cv::Scalar(0, 64, 255), -1);
            cv::imshow("select start point", mp->img);
            //std::cout<<"<start point> x: "<<x<<", y: "<<y<<std::endl;
            mp->point = Point_2(x, y);
            break;
        }
        default:
        {
            break;
        }
    }
}
// // 计算两条直线的交点
// Point_2 CoveragePlanner::calculateIntersection(Point_2 p1, Point_2 p2, Point_2 p3, Point_2 p4) {
//     Point intersection;
    
//     // 计算交点坐标
//     double x1 = p1.x, y1 = p1.y;
//     double x2 = p2.x, y2 = p2.y;
//     double x3 = p3.x, y3 = p3.y;
//     double x4 = p4.x, y4 = p4.y;
    
//     double denom = (x1 - x2)*(y3 - y4) - (y1 - y2)*(x3 - x4);
//     if (denom == 0) {
//         // 平行线
//         intersection.x = -1;
//         intersection.y = -1;
//     } else {
//         intersection.x = ((x1*y2 - y1*x2)*(x3 - x4) - (x1 - x2)*(x3*y4 - y3*x4)) / denom;
//         intersection.y = ((x1*y2 - y1*x2)*(y3 - y4) - (y1 - y2)*(x3*y4 - y3*x4)) / denom;
//     }
    
//     return intersection;
// }

Point_2 CoveragePlanner::getStartingPoint(cv::Mat& img)
{
     MouseParams params(img);
     params.img = img.clone();

     cv::namedWindow("select start point", cv::WINDOW_AUTOSIZE);
     cv::imshow("select start point", params.img);
     cv::setMouseCallback("select start point", onMouseHandle, (void*)&(params));
     cv::waitKey();
     Point_2 point = params.point;

     img = params.img.clone();

     cv::destroyWindow("select start point");
    return point;
}
std::vector<CellNode> CoveragePlanner::calculateDecompositionAdjacency(const std::vector<Polygon_2>& decompositions) {

    std::vector<CellNode> polygon_adj_graph(decompositions.size());
    for (size_t i = 0; i < decompositions.size() - 1; ++i) {
        polygon_adj_graph[i].cellIndex = i;
        for (size_t j = i + 1; j < decompositions.size(); ++j) {
            PolygonWithHoles joined;
            if (CGAL::join(decompositions[i], decompositions[j], joined)) {
                polygon_adj_graph[i].neighbor_indices.emplace_back(j);
                polygon_adj_graph[j].neighbor_indices.emplace_back(i);
            }
        }
    }
    polygon_adj_graph.back().cellIndex = decompositions.size()-1;

    return polygon_adj_graph;
}

// DFS
void CoveragePlanner::walkThroughGraph(std::vector<CellNode>& cell_graph, int cell_index, int& unvisited_counter, std::deque<CellNode>& path)
{
    if(!cell_graph[cell_index].isVisited){
        cell_graph[cell_index].isVisited = true;
        unvisited_counter--;
    }
    path.emplace_front(cell_graph[cell_index]);

//    for debugging
//    //std::cout<< "cell: " <<cell_graph[cell_index].cellIndex<<std::endl;
//

    CellNode neighbor;
    int neighbor_idx = INT_MAX;

    for(size_t i = 0; i < cell_graph[cell_index].neighbor_indices.size(); i++){
        neighbor = cell_graph[cell_graph[cell_index].neighbor_indices[i]];
        neighbor_idx = cell_graph[cell_index].neighbor_indices[i];
        if(!neighbor.isVisited){
            break;
        }
    }

    // unvisited neighbor found
    if(!neighbor.isVisited){
        cell_graph[neighbor_idx].parentIndex = cell_graph[cell_index].cellIndex;
        walkThroughGraph(cell_graph, neighbor_idx, unvisited_counter, path);
    }
    // unvisited neighbor not found
    else{
        // cannot go on back-tracking
        if (cell_graph[cell_index].parentIndex == INT_MAX){
            return;
        }else if(unvisited_counter == 0){
            return;
        }else{
            walkThroughGraph(cell_graph, cell_graph[cell_index].parentIndex, unvisited_counter, path);
        }
    }
}

std::deque<int> CoveragePlanner::getTravellingPath(const std::vector<CellNode>& cell_graph, int first_cell_index)
{
    std::deque<int> travelling_path;

    std::deque<CellNode> _cell_path;
    std::vector<CellNode> _cell_graph = cell_graph;

    if(_cell_graph.size()==1){
        travelling_path.emplace_back(0);
    }else{
        int unvisited_counter = _cell_graph.size();
        walkThroughGraph(_cell_graph, first_cell_index, unvisited_counter, _cell_path);
        std::reverse(_cell_path.begin(), _cell_path.end());
    }

    for(auto& cell : _cell_path){
        travelling_path.emplace_back(cell.cellIndex);
    }

    return travelling_path;
}

std::vector<std::map<int, std::list<Point_2 >>> CoveragePlanner::calculateCellIntersections(std::vector<Polygon_2>& decompositions, std::vector<CellNode>& cell_graph){

    std::vector<std::map<int, std::list<Point_2 >>> cell_intersections(cell_graph.size());

    for(size_t i = 0; i < cell_graph.size(); ++i){
        for(size_t j = 0; j < cell_graph[i].neighbor_indices.size(); ++j){
            std::list<Point_2> pts;
            for(auto m = decompositions[i].edges_begin(); m != decompositions[i].edges_end(); ++m){
                for(auto n = decompositions[cell_graph[i].neighbor_indices[j]].edges_begin();
                    n != decompositions[cell_graph[i].neighbor_indices[j]].edges_end();
                    ++n){
                    Segment_2 segments[] = {*m, *n};
                    CGAL::compute_intersection_points(segments, segments+2, std::back_inserter(pts));
                }
            }

            for(auto p = decompositions[i].vertices_begin(); p != decompositions[i].vertices_end(); ++p){
                for(auto q = decompositions[cell_graph[i].neighbor_indices[j]].vertices_begin(); q != decompositions[cell_graph[i].neighbor_indices[j]].vertices_end(); ++q){
                    if(CGAL::to_double(p->x())==CGAL::to_double(q->x()) && CGAL::to_double(p->y())==CGAL::to_double(q->y())){
                        pts.insert(pts.end(), *p);
                    }
                }
            }

            auto verbose = std::unique(pts.begin(), pts.end());
            pts.erase(verbose, pts.end());
            cell_intersections[i].insert(std::make_pair(cell_graph[i].neighbor_indices[j], pts));
            cell_intersections[cell_graph[i].neighbor_indices[j]].insert(std::make_pair(i, pts));
        }
    }

    return cell_intersections;
}

Point_2 CoveragePlanner::findNextGoal(const Point_2& start, const Point_2& goal, const std::list<Point_2>& candidates){
    double min_cost = DBL_MAX;
    double cost;
    Point_2 next_point = start;
    Segment_2 seg_from_start, seg_to_goal;
    for(auto point = candidates.begin(); point != candidates.end(); ++point){
        seg_from_start = Segment_2(start, *point);
        seg_to_goal = Segment_2(*point, goal);
        cost = CGAL::to_double(seg_from_start.squared_length())+CGAL::to_double(seg_to_goal.squared_length());
        if(cost < min_cost){
            min_cost = cost;
            next_point = *point;
        }
    }
    return next_point;
}
