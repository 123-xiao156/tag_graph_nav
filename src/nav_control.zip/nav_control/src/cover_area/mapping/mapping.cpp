//
// Created by hela on 2024/01/23.
//
#include "mapping.h"
#include <glog/logging.h>
#include <execution>
#include <opencv2/opencv.hpp>

namespace mapping {

bool Mapping2D::Init(SE2& pose) {
    keyframe_id_ = 0;
    SetMappingParams(pose);
    first_scan_=true;
    return true;
}

void Mapping2D::SetMappingParams(SE2 pose)
{   //距原点的距离,,,根据矩形与原点的关系，生成图片，图片中心在矩形中心
    // mapping_params_.x_min=int(map_size_[0][0]*mapping_params_.resolution);
    // mapping_params_.y_min=int(map_size_[0][1]*mapping_params_.resolution);
    // mapping_params_.x_max=int(map_size_[1][0]*mapping_params_.resolution);
    // mapping_params_.y_max=int(map_size_[1][1]*mapping_params_.resolution);
    //mapping_params_.size_x = (mapping_params_.x_max-mapping_params_.x_min);//2.0 * std::max(fabs(mapping_params_.x_max),fabs(mapping_params_.x_min));
    //mapping_params_.size_y = (mapping_params_.y_max-mapping_params_.y_min);//2.0 * std::max(fabs(mapping_params_.y_max),fabs(mapping_params_.y_min));;
    //mapping_params_.center_image=Vec2d((mapping_params_.x_max-mapping_params_.x_min) / 2, (mapping_params_.y_max-mapping_params_.y_min) / 2);
    matrix_map_pose_<<1,0,
            0,-1;
    init_pose_=SE2::trans(vec_cover_[0]) * SE2::rot(0.0);
    //图片尺寸根据cover设置，最小1000，cover【0】在图片中心
    Vec2d cover_size=CalculateMapSize();
    mapping_params_.size[0] = cover_size[0]>1000.?cover_size[0]:1000.;
    mapping_params_.size[1] = cover_size[1]>1000.?cover_size[1]:1000.;
    mapping_params_.center_image=Vec2d((mapping_params_.size[0]) / 2, (mapping_params_.size[1]) / 2); 
    mapping_params_.x_min = 0;//+int(map_size_[0][0]*mapping_params_.resolution);
    mapping_params_.y_min = 0;//+int(map_size_[0][1]*mapping_params_.resolution);
    mapping_params_.x_max = mapping_params_.size[0];//+int(map_size_[1][0]*mapping_params_.resolution);
    mapping_params_.y_max = mapping_params_.size[1];//+int(map_size_[1][1]*mapping_params_.resolution);   
    current_frame_->pose_submap_ = init_pose_.inverse()*pose;//机器人在子图中的位置
    current_frame_->pose_=init_pose_;//全局map中的位置
    //std::cout<<"init pose_submap_: "<< current_frame_->pose_submap_.translation()<<" pose: "<<current_frame_->pose_.translation()<<std::endl;
    //std::cerr<<"param"<<mapping_params_.x_min<<" "<<mapping_params_.y_min
    //            <<" "<<mapping_params_.x_max<<" "<<mapping_params_.y_max<<std::endl;
    //occupancy_grid_ = cv::Mat(mapping_params_.size_x, mapping_params_.size_y, CV_8U, 127);
    //图片的上下左右边界为多边形的边界，
    // occupancy_grid_ = cv::Mat(2.0 * std::max(fabs(mapping_params_.x_max),fabs(mapping_params_.x_min)),
    //                             2.0 * std::max(fabs(mapping_params_.y_max),fabs(mapping_params_.y_min)),
    //                             CV_8U, 127);
    // occupancy_grid_ = cv::Mat(2.0 * mapping_params_.center_image[0],
    //                             2.0 * mapping_params_.center_image[1],
    //                             CV_8U, 127);
    occupancy_grid_ = cv::Mat(mapping_params_.size[0],
                                mapping_params_.size[1],
                                CV_8U, 127);
    //子图在图片的位置
   // SE2 submap_in_image=
    //SE2 se2 = SE2::trans( Eigen::Vector2d(laser_pose.pose.position.x, laser_pose.pose.position.y) ) * SE2::rot(yaw);
   }
    //计算地图的尺寸(以起点为原点)
Vec2d Mapping2D::CalculateMapSize()
{
    if(vec_cover_.empty())return Vec2d(0.,0.);
    double minX=0., maxX=0., minY=0., maxY=0.;
    for (const auto& point : vec_cover_) 
    {
        minX = std::min(minX, point[0]-vec_cover_[0][0]);
        maxX = std::max(maxX, point[0]-vec_cover_[0][0]);
        minY = std::min(minY, point[1]-vec_cover_[0][1]);
        maxY = std::max(maxY, point[1]-vec_cover_[0][1]);
        std::cerr<<"minX "<<minX<<" "<<point[0]-vec_cover_[0][0]<<std::endl;
        std::cerr<<"maxX "<<maxX<<" "<<point[0]-vec_cover_[0][0]<<std::endl;
        std::cerr<<"minY "<<minY<<" "<<point[1]-vec_cover_[0][1]<<std::endl;
        std::cerr<<"maxY "<<maxY<<" "<<point[1]-vec_cover_[0][1]<<std::endl;
    }
    Vec2d res=Vec2d(maxX-minX,maxY-minY);
    return res;
};
bool Mapping2D::ProcessScan(Scan* pscan) {

    current_frame_ = std::make_shared<Frame>(pscan);
    current_frame_->pose_submap_ = init_pose_.inverse()*pscan->pose;
    current_frame_->pose_=pscan->pose;
    //std::cout<<"pose_submap_: "<< current_frame_->pose_submap_.translation()<<" pose: "<<current_frame_->pose_.translation()<<std::endl;
    if (first_scan_) 
    {
        Init(pscan->pose);
    }
    first_scan_=false;
    //std::cerr<<" current_frame_->pose_"<<current_frame_->pose_.translation()<<std::endl;
    //以第一帧为原点，建立子图
    bool is_kf = IsKeyFrame();
    if (is_kf) {
        AddKeyFrame();//帧id+1
        AddLidarFrame(current_frame_);  // 更新栅格地图中的格子
    }
    /// 可视化输出
    occu_image_ = GetOccupancyGridBlackWhite();
    Visualize2DScan(current_frame_->scan_, current_frame_->pose_, occu_image_, Vec3b(0, 0, 255), 
                    mapping_params_.size, mapping_params_.resolution,
                   current_frame_->pose_submap_);
    //cv::imshow("occupancy map", occu_image_);
   // cv::waitKey(10);
    last_frame_ = current_frame_;
/**/
    return true;
}

bool Mapping2D::IsKeyFrame() {
    if (last_keyframe_ == nullptr) {//第一帧为关键帧
        return true;
    }
    SE2 delta_pose = last_keyframe_->pose_.inverse() * current_frame_->pose_;//当前帧的pose在上一帧中的坐标，即为delta
    //std::cout<<"current_frame_: "<< current_frame_->pose_.translation()<<
    //"last_keyframe_: "<<last_keyframe_->pose_.translation()<<std::endl;
    if (delta_pose.translation().norm() > keyframe_pos_th_ || fabs(delta_pose.so2().log()) > keyframe_ang_th_) {
        //std::cout<<"addkeyframe............."<<std::endl;
        return true;//norm是范数，求pose的平方根>0.3||角度>15°
    }

    return false;
}

void Mapping2D::AddKeyFrame() {
    LOG(INFO) << "add keyframe " << keyframe_id_;
    current_frame_->keyframe_id_ = keyframe_id_++;
    last_keyframe_ = current_frame_;
    keyframe_.push_back(current_frame_);
}
void Mapping2D::Visualize2DScan(Scan2d::ConstPtr scan, const SE2& pose, cv::Mat& image, const Vec3b& color, Vec2d& image_size,
                     float resolution, const SE2& pose_submap) {
    if (image.data == nullptr) {
        image = cv::Mat(image_size[0], image_size[1], CV_8UC3, cv::Vec3b(255, 255, 255));
    }
    for (size_t i = 0; i < scan->ranges.size(); ++i) {
        if (scan->ranges[i] < scan->range_min || scan->ranges[i] > scan->range_max) {
            continue;
        }

        double real_angle = scan->angle_min + i * scan->angle_increment;
        double x = scan->ranges[i] * std::cos(real_angle);
        double y = scan->ranges[i] * std::sin(real_angle);

        // if (real_angle < scan->angle_min + 30 * M_PI / 180.0 || real_angle > scan->angle_max - 30 * M_PI / 180.0) {
        //     continue;
        // }
        //jiang

        Vec2d psubmap = matrix_map_pose_*(pose_submap * Vec2d(x, y));//把点云转到submap坐标系下

        int image_x = int(psubmap[0] * resolution + image_size[0] / 2);
        int image_y = int(psubmap[1] * resolution + image_size[1] / 2);//机器人坐标：车头x朝右（与图片u重合），y朝上（与图片v相反）
        if (image_x >= 0 && image_x < image.cols && image_y >= 0 && image_y < image.rows) {
            image.at<cv::Vec3b>(image_y, image_x) = cv::Vec3b(color[0], color[1], color[2]);
        }
        
    }
    // // 同时画出pose自身所在位置
    // Vec2d pose_in_image =
    //     (matrix_map_pose_*pose_submap.translation()) * double(resolution) + mapping_params_.center_image;//Vec2d(image_size[0] / 2, image_size[1] / 2);
    // cv::circle(image, cv::Point2f(pose_in_image[0], pose_in_image[1]), 5, cv::Scalar(color[0], color[1], color[2]), 2);
    // //画出关键帧位置
    // for(auto key:keyframe_)
    // {
    //     pose_in_image =(matrix_map_pose_*key->pose_submap_.translation())* double(resolution) + mapping_params_.center_image;//Vec2d(image_size[0] / 2, image_size[1] / 2);
    //     cv::circle(image, cv::Point2f(pose_in_image[0], pose_in_image[1]), 3, cv::Scalar(255, 0, 0), 2);
    //     cv::putText(image, std::to_string(key->keyframe_id_), cv::Point2f(pose_in_image[0], pose_in_image[1]),
    //              cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(0, 0, 255));
    // }
    //画出cover区域
    Vec2d start,end;
    image_cover_.clear();//存储区域边界像素
    int si=vec_cover_.size();
    for(int i=0;i<si;i++)
    {
        if(i<si-1)
        {
            start =(matrix_map_pose_*(init_pose_.inverse()*vec_cover_[i]))* double(resolution) + mapping_params_.center_image;//Vec2d(image_size[0] / 2, image_size[1] / 2);
            end =(matrix_map_pose_*(init_pose_.inverse()*vec_cover_[i+1]))* double(resolution) + mapping_params_.center_image;//Vec2d(image_size[0] / 2, image_size[1] / 2);
        }
        else 
        {
            start =matrix_map_pose_*(init_pose_.inverse()*vec_cover_[i])* double(resolution) + mapping_params_.center_image;//Vec2d(image_size[0] / 2, image_size[1] / 2);
            end =matrix_map_pose_*(init_pose_.inverse()*vec_cover_[0])* double(resolution) + mapping_params_.center_image;//Vec2d(image_size[0] / 2, image_size[1] / 2);
        }
        image_cover_.push_back(cv::Point(static_cast<int>(start[0]), static_cast<int>(start[1])));
        //cv::line(image, startPoint, endPoint, color, thickness);
        cv::line(image, cv::Point2f(start[0], start[1]),  cv::Point2f(end[0], end[1]), cv::Scalar(255, 0, 0), 2);
        // cv::putText(image, std::to_string(i), cv::Point(start[0], start[1]),
        //         cv::FONT_HERSHEY_COMPLEX, 0.5, cv::Scalar(0, 0, 255));
    }
    //抠出目标区域
    std::vector<std::vector<cv::Point>> contours={image_cover_};
    cv::Mat mask = cv::Mat::zeros(image.size(), CV_8UC1);
    cv::fillPoly(mask, contours, cv::Scalar(255));
    cv::Mat result = image.clone();
    cv::bitwise_not(mask, mask);
    result.setTo(cv::Scalar(0), mask);
    image = result.clone();
}
cv::Mat Mapping2D::GetOccupancyGridBlackWhite() const {
    cv::Mat image(occupancy_grid_.rows,occupancy_grid_.cols, CV_8UC3);
    for (int y = 0; y < occupancy_grid_.rows; y++) {
        for (int x = 0; x < occupancy_grid_.cols; x++) {
            // 判断像素是否在边界内
            if (x >= mapping_params_.x_min && x <= mapping_params_.x_max && y >= mapping_params_.y_min && y <= mapping_params_.y_max) {
                if (occupancy_grid_.at<uchar>(y, x) == 127) {
                    image.at<cv::Vec3b>(y, x) = cv::Vec3b(127, 127, 127);//灰色
                } else if (occupancy_grid_.at<uchar>(y, x) < 127) {
                    image.at<cv::Vec3b>(y, x) = cv::Vec3b(0, 0, 0);//黑色
                } else if (occupancy_grid_.at<uchar>(y, x) > 127) {
                    image.at<cv::Vec3b>(y, x) = cv::Vec3b(255, 255, 255);//白色
                }
            } else {
                // 设置边界外的像素为黑色
                image.at<cv::Vec3b>(y, x) = cv::Vec3b(0, 0, 0);
            }
        }
    }
    return image;
}
// cv::Mat Mapping2D::GetOccupancyGridBlackWhite() const {
//     cv::Mat image(occupancy_grid_.rows,occupancy_grid_.cols, CV_8UC3);
//     //std::cerr<<"occupancy_grid_: "<<occupancy_grid_.cols<<"*"<<occupancy_grid_.rows<<std::endl;
//     for (int x = 0; x < occupancy_grid_.cols; ++x) {
//         for (int y = 0; y < occupancy_grid_.rows; ++y) {
//             if (occupancy_grid_.at<uchar>(y, x) == 127) {
//                 image.at<cv::Vec3b>(y, x) = cv::Vec3b(127, 127, 127);
//             } else if (occupancy_grid_.at<uchar>(y, x) < 127) {
//                 image.at<cv::Vec3b>(y, x) = cv::Vec3b(0, 0, 0);
//             } else if (occupancy_grid_.at<uchar>(y, x) > 127) {
//                 image.at<cv::Vec3b>(y, x) = cv::Vec3b(255, 255, 255);
//             }
//         }
//     }
//     return image;
// }

void Mapping2D::AddLidarFrame(std::shared_ptr<Frame> frame) {
    auto& scan = frame->scan_;
    // 此处不能直接使用frame->pose_submap_，因为frame可能来自上一个地图
    // 此时frame->pose_submap_还未更新，依旧是frame在上一个地图中的pose
    //SE2 pose_in_submap =frame->pose_submap_.inverse() * frame->pose_;//关键帧在子图中的位置
    SE2 pose_in_submap =frame->pose_submap_;//关键帧在子图中的位置
    //注意，这里的子图是以多边形的第一个点为起点的
    float theta = pose_in_submap.so2().log();
    //std::cerr<<"pose_in_submap "<< pose_in_submap.translation()[0] << " " << pose_in_submap.translation()[1] << " " << pose_in_submap.so2().log()<<std::endl;

    has_outside_pts_ = false;
    // 先计算点云末端点所在的网格
    std::set<Vec2i, less_vec<2>> endpoints;
    Vec2d pose_in_image;
    for (size_t i = 0; i < scan->ranges.size(); ++i) {
        double range=scan->ranges[i];
        if ((!std::isfinite(range) && range > 0) || (std::isnan(range)))continue;
        if (range < scan->range_min || range > scan->range_max) continue;
        double real_angle = scan->angle_min + i * scan->angle_increment;
        double x = range * std::cos(real_angle);
        double y = range * std::sin(real_angle);
        pose_in_image =(matrix_map_pose_*(pose_in_submap* Vec2d(x, y)))* double(mapping_params_.resolution) + mapping_params_.center_image;//Vec2d(1000. / 2, 1000. / 2);
        endpoints.emplace(Vec2i(pose_in_image[0],pose_in_image[1]));
    }
    //机器人位置
    pose_in_image =matrix_map_pose_*pose_in_submap.translation()* double(mapping_params_.resolution)+ mapping_params_.center_image; //Vec2d(1000./ 2, 1000. / 2);
    Vec2i start =Vec2i(pose_in_image[0],pose_in_image[1]);
     //pose_in_image =key->pose_submap_.inverse() * (key->pose_.translation())* double(resolution) + Vec2d(1000./ 2, 1000. / 2);
    std::for_each(std::execution::par_unseq, endpoints.begin(), endpoints.end(),
                      [this, &start](const auto& pt) { BresenhamFilling(start, pt); });
    /// 末端点涂黑
    std::for_each(endpoints.begin(), endpoints.end(), [this](const auto& pt) { SetPoint(pt, true); });
}

void Mapping2D::SetPoint(const Vec2i& pt, bool occupy) {
    int x = pt[0], y = pt[1];
    if (x < 0 || y < 0 || x >= occupancy_grid_.cols || y >= occupancy_grid_.rows) {
        if (occupy) {
            has_outside_pts_ = true;
        }
        return;
    }
    /// 这里设置了一个上下限
    uchar value = occupancy_grid_.at<uchar>(y, x);
    if (occupy) {
        if (value > 117) {
            occupancy_grid_.ptr<uchar>(y)[x] -= 1;
        }
    } else {
        if (value < 137) {
            occupancy_grid_.ptr<uchar>(y)[x] += 1;
        }
    }
}


void Mapping2D::BresenhamFilling(const Vec2i& p1, const Vec2i& p2) {
    int dx = p2.x() - p1.x();
    int dy = p2.y() - p1.y();
    int ux = dx > 0 ? 1 : -1;
    int uy = dy > 0 ? 1 : -1;

    dx = abs(dx);
    dy = abs(dy);
    int x = p1.x();
    int y = p1.y();

    if (dx > dy) {
        // 以x为增量
        int e = -dx;
        for (int i = 0; i < dx; ++i) {
            x += ux;
            e += 2 * dy;
            if (e >= 0) {
                y += uy;
                e -= 2 * dx;
            }

            if (Vec2i(x, y) != p2) {
                SetPoint(Vec2i(x, y), false);
            }
        }
    } else {
        int e = -dy;
        for (int i = 0; i < dy; ++i) {
            y += uy;
            e += 2 * dx;
            if (e >= 0) {
                x += ux;
                e -= 2 * dy;
            }
            if (Vec2i(x, y) != p2) {
                SetPoint(Vec2i(x, y), false);
            }
        }
    }
}
}  // namespace mapping
