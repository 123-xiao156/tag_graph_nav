/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	navcontrol.cpp
 * * @description:  门禁、乘梯、覆盖，乘梯动作
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fstream>
#include <QCoreApplication>
#include "navcontrol.h"

const static std::string IIMT_LOG_PATH = "/home/iimt/.logs/";
std::string ToStringYearMonthDay()
{
    // 获取当前时间
    auto now = std::chrono::system_clock::now();

    // 将时间转换为时间点类型
    auto now_time_t = std::chrono::system_clock::to_time_t(now);
    auto now_tm = std::localtime(&now_time_t);
    auto now_time_point = std::chrono::system_clock::from_time_t(now_time_t);

    // 输出年月日
    int year = now_tm->tm_year + 1900;
    int month = now_tm->tm_mon + 1;
    int day = now_tm->tm_mday;
    // int date = year * 10000 + month * 100 + day;

    return std::to_string(year) + "-" + ((month < 10 ? "0" : "") + std::to_string(month)) + "-" + ((day < 10 ? "0" : "") + std::to_string(day));
}
// 将信息输出到单独的文件和 LOG(ERROR)
void SignalHandle(const char *data, int size)
{
    ros::shutdown();
    std::string all_path = IIMT_LOG_PATH + ToStringYearMonthDay() + "/nav_control/";
    std::ofstream fs(all_path, std::ios::app | std::ios::out);
    std::string str = std::string(data, size);
    LOG(ERROR) << str;
    fs << str;
    fs.close();
    // google::ShutdownGoogleLogging();
}

int main(int argc, char *argv[])
{
    std::string all_path = IIMT_LOG_PATH + ToStringYearMonthDay() + "/nav_control/";
    if (access(all_path.c_str(), F_OK) == -1)
    {
        std::string fullPath = "";
        fullPath = all_path;
        if (fullPath[fullPath.size() - 1] != '/')
        {
            fullPath += "/";
        }
        // create dirs;
        for (uint32_t i = 1; i < fullPath.size(); i++)
        {
            if ('/' == fullPath[i])
            {
                std::string curPath = fullPath.substr(0, i);
                if (access(curPath.c_str(), F_OK) != 0)
                {
                    if (mkdir(curPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) == -1)
                    {
                        LOG(ERROR) << "mkdir:" << curPath << ", failed " << strerror(errno);
                        return 0;
                    }
                }
            }
        }
    }
    google::InitGoogleLogging(argv[0]);
    google::InstallFailureSignalHandler();
    google::InstallFailureWriter(&SignalHandle);
    FLAGS_logbufsecs = 0;                   // 日志实时输出
    FLAGS_max_log_size = 10;                // 最大日志文件大小 10M
    FLAGS_logtostderr = false;              // 设置日志消息是否转到标准输出而不是日志文件
    FLAGS_stop_logging_if_full_disk = true; // 设置是否在磁盘已满时避免日志记录到磁盘
    FLAGS_colorlogtostderr = true;          // 设置记录到标准输出的颜色消息（如果终端支持）
    FLAGS_alsologtostderr = true;           // 设置日志消息除了日志文件之外是否去标准输出
    google::SetLogDestination(google::INFO, all_path.data());
    LOG(INFO) << "Glog ON, path is " << all_path;

    QCoreApplication a(argc, argv);
    ros::init(argc, argv, "navcontrol_node");
    ros::NodeHandle nh("~");
    std::shared_ptr<ShardData> shard_data = std::make_unique<ShardData>();

    NavControl navc(nh);
    navc.SetShardData(shard_data);
    navc.Init();
    navc.start();
    return a.exec();
}
