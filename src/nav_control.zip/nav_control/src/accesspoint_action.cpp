/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	accesspoint_action.cpp
 * * @description:  门禁、乘梯
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "accesspoint_action.h"

AccesspointAction::AccesspointAction(ros::NodeHandle nh) : narrow_path::NarrowPath(nh), nh_(nh)
{
    nh_.param<float>("access_length", access_length_, 4.0);
    nh_.param<float>("access_width", access_width_, 3.0);
    //std::cout << "等待/move_base/make_plan服务 门禁或者闸机区域设置的最大长度和宽度分别为：" << access_length_ << " , " << access_width_ << std::endl;
    nh_.param("car_type", car_type_, std::string("UC"));
    // 20250409 c_add 添加门禁闸机开门等待时间参数
    nh_.param<float>("access_open_time", access_open_time_, 1.0);
    //遇到障碍物间隔20s后重新发长开门命令 y_add 20260409
    nh_.param<float>("access_open_time_interval", access_open_time_interval_, 20.0);
    //qDEBUG() << "read car_type_ is : " << QString::fromStdString(car_type_);
    int nav_version;
    nh_.param<int>("nav_version", nav_version, 1);  //#1move_base导航，2nav_base导航
    if(nav_version==1)
    {
        nav_node_="/move_base";
    }
    if(nav_version==2)
    {
        nav_node_="/task_base";
    }   
    // 请求门禁或者闸机
    client_access_ = nh_.serviceClient<robot_msgs::Elevator>("/srv_elevator");
    service_client_ = nav_node_=="/task_base" ?
                        nh_.serviceClient<robot_msgs::GetPlanService>(nav_node_+"/make_plan"):
                        nh_.serviceClient<nav_msgs::GetPlan>(nav_node_+"/make_plan");
    clear_costmap_client_ = nh_.serviceClient<std_srvs::Empty>(nav_node_+"/clear_costmaps");
    sub_running_result_ = nh_.subscribe<std_msgs::String>("/elevator_status", 10, &AccesspointAction::callback_ElevatorResult, this); // 订阅乘梯门禁话题
    pub_voice_ = nh_.advertise<robot_msgs::Voice>("/voiceplay", 10);
    // 20240918 c_add 过门禁启用超声波避停
    pub_ultrasonic_avoidance_ = nh_.advertise<std_msgs::String>("/start_ultra", 10);
    pub_access_gate_marker_ = nh_.advertise<visualization_msgs::Marker>("/access_gate_marker", 10, true);
    pub_cmd_sensor_= nh_.advertise<std_msgs::String>("/cmd_sensor", 10);
    SetVehicleStatus("over"); 
}

// 初始化，创建线程
void AccesspointAction::Init()
{
    interval_ms_ = 100;
    std::thread t(&AccesspointAction::TimerThread, this, interval_ms_);
    t.detach();
    keep_door_timer_ = nh_.createTimer(ros::Duration(access_open_time_interval_), &AccesspointAction::KeepDoorOpenCallback, this);
    keep_door_timer_.stop();
}

// 线程开始
void AccesspointAction::TimerThread(int16_t interval_ms)
{
    while (ros::ok())
    {
        if (!thread_pause_flag_)
        {
            MainLoop();
        }
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
/**********************************************************************
 * * @function:    PublishVoice 
 * * @brief:       发布语音
 * * @input:       data: 语音名称
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccesspointAction::PublishVoice(std::string name)
{
    robot_msgs::Voice msg;
    msg.info_volume = 70;    // 音量70%
    msg.info_type = "voice"; // 播放语音
    msg.info_data = name;    // 语音名称，见语音列表
    pub_voice_.publish(msg);
}
// 实现保持门禁开启的回调函数
void AccesspointAction::KeepDoorOpenCallback(const ros::TimerEvent&)
{
    // 只在通过门禁过程中且正在等待障碍物清除时发送开门命令
    if (access_index_ == AccessProcessIndex::STEP8 && this->IsWaitingObstacle())
    {
        std::string floor_no = GetFloorNo(p_shard_data_->current_map_);
        robot_msgs::Elevator srv;
        srv.request.type = "long_open_door";
        srv.request.aim_floor = std::atoi(floor_no.c_str());
        srv.request.pose.name = sort_access_points_[0].point_name;
        
        if(!client_access_.waitForExistence(ros::Duration(5)))
        {
            LOG(WARNING) << "门禁服务不可用，无法发送保持开门命令";
            return;
        }
        
        if (client_access_.call(srv))
        {
            LOG(INFO) << "障碍物等待中(已等待)，重新发送门禁常开命令";
        }
        else
        {
            LOG(WARNING) << "重新发送门禁常开命令失败";
        }
    }
}

// 添加启动/停止定时器的方法
void AccesspointAction::StartKeepDoorTimer()
{
    if (!keep_door_timer_.hasStarted())
    {
        keep_door_timer_.start();
        LOG(INFO) << "启动门禁保持定时器(20秒周期)";
    }
}

void AccesspointAction::StopKeepDoorTimer()
{
    if (keep_door_timer_.hasStarted())
    {
        keep_door_timer_.stop();
        LOG(INFO) << "停止门禁保持定时器";
    }
}
/**********************************************************************
 * * @function:    YawNormalize 
 * * @brief:       归一化角度到(−π,π]
 * * @input:       yaw: 角度
 * * @output:      
 * * @return:      double：返回归一化角度
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
double AccesspointAction::YawNormalize(double yaw)
{
    while (yaw > M_PI)
    {
        yaw -= 2 * M_PI;
    }
    while (yaw < -M_PI)
    {
        yaw += 2 * M_PI;
    }
    return yaw;
}
/**********************************************************************
 * * @function:    GetFloorNo 
 * * @brief:       分割map_name获取楼层号(guangdianyuan_B1_4F_area1)
 * * @input:       map_name: 地图名称
 * * @output:      
 * * @return:      std::string: 返回提取的楼层号，默认返回"0F"
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
std::string AccesspointAction::GetFloorNo(std::string map_name)
{
    std::string floor_no = "0F";
    char split_c = '_';
    std::vector<std::string> str_results;
    if (map_name == "")
    {
        LOG(ERROR) << "map_name is null.";
        return floor_no;
    }
    size_t pos = map_name.find(split_c);
    // 返回npos说明没有找到这个字符
    while (pos != map_name.npos)
    {
        std::string temp = map_name.substr(0, pos);
        str_results.push_back(temp);
        map_name = map_name.substr(pos + 1, map_name.size());
        pos = map_name.find(split_c);
    }
    if (str_results.size() > 2)
    {
        floor_no = str_results[2].substr(0, str_results[2].length() - 1);
        LOG(ERROR) << "floor no : " << floor_no;
        return floor_no;
    }
    else
    {
        LOG(WARNING) << "accesspoint_action" << map_name << "did not find the floor number";
        return floor_no;
    }
}
/**********************************************************************
 * * @function:    movePointAlongYaw 
 * * @brief:       根据已知点和线段长度计算新点坐标
 * * @input:       坐标：x
 * *               坐标：y
 * *               坐标：yaw
 * *               坐标：l长度
 * * @output:      
 * * @return:      std::string: 返回提取的楼层号，默认返回"0F"
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
AccesspointAction::PointStruct AccesspointAction::movePointAlongYaw(double x, double y, double yaw, double l)
{
    PointStruct p;
    p.x = x + l * cos(yaw);
    p.y = y + l * sin(yaw);
    return p;
}
/**********************************************************************
 * * @function:    AddPointToMarker 
 * * @brief:       将计算的点添加到marker中
 * * @input:       坐标：x
 * *               坐标：y
 * * @output:      
 * * @return:      return point;
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
// 将计算的点添加到marker中
geometry_msgs::Point AccesspointAction::AddPointToMarker(double x, double y)
{
    geometry_msgs::Point point;
    point.x = x;
    point.y = y;
    point.z = 0.0; // 点的高度
    return point;
}
/**********************************************************************
 * * @function:    GetAccessArea4Point 
 * * @brief:       计算矩形区域的4个角点坐标以及上下左右中心点坐标（从左上角开始逆时针旋转看，length代表左右，width代表上下）
 * * @input:       length：门禁长度 width：门禁宽度 p：门禁点
 * * @output:      
 * * @return:      return point;
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
// 左上、左、左下、下、右下、右、右上、上
// 右下、右、右上、上、左上、左、左下、下
std::vector<AccesspointAction::PointStruct> AccesspointAction::GetAccessArea4Point(const double length, const double width, const PointStruct p)
{
    std::vector<PointStruct> points;
    // 首先计算矩形区域中线与对角线之间的夹角
    double angle = acos(length / 2. / sqrt(pow(length / 2., 2) + pow(width / 2., 2)));

    PointStruct leftup = movePointAlongYaw(p.x, p.y, p.yaw - angle, sqrt(pow(length / 2., 2) + pow(width / 2., 2)));           // 左上
    PointStruct leftdown = movePointAlongYaw(p.x, p.y, p.yaw + angle, sqrt(pow(length / 2., 2) + pow(width / 2., 2)));         // 左下
    PointStruct rightdown = movePointAlongYaw(p.x, p.y, p.yaw + M_PI - angle, sqrt(pow(length / 2., 2) + pow(width / 2., 2))); // 右下
    PointStruct rightup = movePointAlongYaw(p.x, p.y, p.yaw + M_PI + angle, sqrt(pow(length / 2., 2) + pow(width / 2., 2)));   // 右上

    PointStruct down = movePointAlongYaw(p.x, p.y, p.yaw + M_PI / 2, width / 2.); // 门禁下
    PointStruct up = movePointAlongYaw(p.x, p.y, p.yaw - M_PI / 2, width / 2.);   // 门禁上
    PointStruct left = movePointAlongYaw(p.x, p.y, p.yaw, length / 2.);           // 门禁左
    PointStruct right = movePointAlongYaw(p.x, p.y, p.yaw + M_PI, length / 2.);   // 门禁右

    points.push_back(leftup);
    points.push_back(leftdown);
    points.push_back(rightdown);
    points.push_back(rightup);
    points.push_back(down);
    points.push_back(up);
    points.push_back(left);
    points.push_back(right);

    LOG(INFO) << "计算出来的门禁区域,门禁点x: " << p.x <<
               " ,门禁点y: " << p.y <<
               " ,门禁点yaw: " << p.yaw <<
               " ,左上角x: " << leftup.x <<
               " ,左上角y: " << leftup.y <<
               " ,右上角x: " << rightup.x <<
               " ,右上角y: " << rightup.y <<
               " ,左下角x: " << leftdown.x <<
               " ,左下角y: " << leftdown.y <<
               " ,右下角x: " << rightdown.x <<
               " ,右下角y: " << rightdown.y <<
               " ,上面的门禁点x: " << up.x <<
               " ,上面的门禁点y: " << up.y <<
               " ,下面的门禁点x: " + std::to_string(down.x) +
               " ,下面的门禁点y: " << down.y <<
               " ,左中x: " << left.x <<
               " ,左中y: " << left.y <<
               " ,右中x: " << right.x <<
               " ,右中y: " << right.y;

    return points;
}
/**********************************************************************
 * * @function:    IsPointInBottomMatrix 
 * * @brief:       判断路点是否进入矩形下半部分区域
 * * @input:       p：门禁点，points：当前点
 * * @output:      
 * * @return:      bool
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool AccesspointAction::IsPointInBottomMatrix(PointStruct &p, std::vector<PointStruct> &points)
{
    if (GetCross(points[6], points[1], p) > 0 &&
        GetCross(points[1], points[2], p) > 0 &&
        GetCross(points[2], points[7], p) > 0 &&
        GetCross(points[7], points[6], p) > 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
/**********************************************************************
 * * @function:    IsPointInTopMatrix 
 * * @brief:       判断路点是否进入矩形上半部分区域
 * * @input:       p：门禁点，points：当前点
 * * @output:      
 * * @return:      bool
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool AccesspointAction::IsPointInTopMatrix(PointStruct &p, std::vector<PointStruct> &points)
{
    if (GetCross(points[0], points[6], p) > 0 &&
        GetCross(points[6], points[7], p) > 0 &&
        GetCross(points[7], points[3], p) > 0 &&
        GetCross(points[3], points[0], p) > 0)
    {
        return true;
    }
    else
    {
        return false;
    }
}
/**********************************************************************
 * * @function:    CallPlanningService 
 * * @brief:       请求路径规划服务，并计算路径是否经过门禁或闸机区域
 * * @input:       service_client: ROS服务客户端引用 srv: 路径规划服务请求消息 all_area_points: 所有门禁/闸机区域点集     
 * * @output:      无
 * * @return:      int: 返回路径规划结果代码
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
int AccesspointAction::CallPlanningService(ros::ServiceClient &service_client, nav_msgs::GetPlan &srv, std::vector<std::vector<PointStruct>> &all_area_points)
{
    LOG(INFO) << "请求路径规划，并计算是否经过门禁闸机区域";
    // 20240701 c_add 保证可以call到此服务
    bool  res=false;
    if(nav_node_=="/task_base")
    {
        service_client_ =nh_.serviceClient<robot_msgs::GetPlanService>(nav_node_+"/make_plan");
        if(!service_client_.waitForExistence(ros::Duration(10)))
        {
            LOG(ERROR) << "make_plan died";
        } 
        robot_msgs::GetPlanService srv_task_base;
        srv_task_base.request.start=srv.request.start;
        srv_task_base.request.goal=srv.request.goal;
        srv_task_base.request.tolerance=srv.request.tolerance;
        res=service_client_.call(srv_task_base);
        if (res) {
            srv.response.plan = srv_task_base.response.plan;
            LOG(INFO) << "task_base 路径规划成功，路径点数量: " << srv.response.plan.poses.size();
        }
    }
    else 
    {
        service_client_ =nh_.serviceClient<nav_msgs::GetPlan>(nav_node_+"/make_plan");
        if(!service_client_.waitForExistence(ros::Duration(10)))
        {
            LOG(ERROR) << "make_plan died";
        } 
        res=service_client_.call(srv);
    }
    if (res)
    {
        if (srv.response.plan.poses.empty())
        {
            access_index_ = AccessProcessIndex::WAIT;
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
            LOG(ERROR) << "请求的路径规划为空";
            //ROS_WARN("accesspoint action get empty plan");
            thread_pause_flag_ = true;
            return -1;
        }
    }
    else
    {
        access_index_ = AccessProcessIndex::WAIT;
        p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
        LOG(ERROR) << "请求的路径规划没有反应";
        //ROS_ERROR("Failed to call service %s - is the robot moving", service_client.getService().c_str());
        thread_pause_flag_ = true;
        return -1;
    }

    std::vector<bool> in_access_area(all_area_points.size(), false);
    std::vector<int> in_access_area_index(all_area_points.size(), -1);
    // 记录门禁闸机区域的出入点，0：上5入下4出，1：下4入上5出
    std::vector<int> access_area_in_out_flag(all_area_points.size(), -1);
    for (size_t j = 0; j < all_area_points.size(); j++)
    {
        // 初始化状态
        in_bottom_area_ = false;
        in_top_area_ = false;

        // 遍历请求到的路径点，查看其是否经过门禁闸机区域
        for (int i = 0; i < srv.response.plan.poses.size(); i++)
        {
            p_in_first_.x = srv.response.plan.poses[i].pose.position.x;
            p_in_first_.y = srv.response.plan.poses[i].pose.position.y;
            // 先检查是否穿过了矩形下半部分区域
            if (!in_bottom_area_)
            {
                in_bottom_area_ = IsPointInBottomMatrix(p_in_first_, all_area_points[j]);
                if (in_bottom_area_ && !in_top_area_)
                { // 有点在矩形下半部分区域，并且没有点在矩形上半部分区域，则路径先穿过门禁下半区域
                    in_access_area_index[j] = i;
                    in_bottom_area_ = true;
                    LOG(INFO) << "路径现在穿过门禁下半区域，还没有穿过上半区域";
                }
                else if (in_bottom_area_ && in_top_area_)
                { // 有点在矩形下半部分区域，并且有点在矩形上半部分区域，且路径先穿过了矩形上半部分区域
                    LOG(INFO) << "路径先穿过门禁上半区域，现在穿过了下半区域";
                    // 请求的路径规划经过门禁或者闸机区域
                    in_access_area[j] = true;
                    access_area_in_out_flag[j] = 0;
                    break;
                }
            }

            // 后检查是否穿过了矩形上半部分区域
            if (!in_top_area_)
            {
                in_top_area_ = IsPointInTopMatrix(p_in_first_, all_area_points[j]);
                if (!in_bottom_area_ && in_top_area_)
                { // 有点在矩形上半部分区域，并且没有点在矩形下半部分区域，则路径先穿过门禁上半区域
                    in_access_area_index[j] = i;
                    in_top_area_ = true;
                    LOG(INFO) << "路径现在穿过门禁上半区域，还没有穿过下半区域";
                }
                else if (in_bottom_area_ && in_top_area_)
                { // 有点在矩形上半部分区域，并且有点在矩形下半部分区域，且路径先穿过了矩形下半部分区域
                    LOG(INFO) << "路径先穿过门禁下半区域，现在穿过了上半区域";
                    // 请求的路径规划经过门禁或者闸机区域
                    in_access_area[j] = true;
                    access_area_in_out_flag[j] = 1;
                    break;
                }
            }
        }
    }

    // 检查是否有路径穿过门禁区域
    bool hasTrue = std::any_of(in_access_area.begin(), in_access_area.end(), [](bool val) {
        return val;
    });
    if (hasTrue) {
        LOG(INFO) << "路径至少穿过一个门禁区域";
        // 开始排序门禁闸机点和区域
        // 找到 in_access_area 为 true 的索引
        std::vector<int> true_indices;
        for (size_t i = 0; i < in_access_area.size(); ++i) {
            if (in_access_area[i]) {
                true_indices.push_back(i);
            }
        }
        // 按照 in_access_area_index 对 true_indices 排序
        std::sort(true_indices.begin(), true_indices.end(),
                [&in_access_area_index](int a, int b) {
                    return in_access_area_index[a] < in_access_area_index[b];
                });
        // 按排序后的索引排序门禁闸机点和区域
        for (int idx : true_indices) {
            std::vector<PointStruct> in_or_out_points;
            // 门禁闸机区域的出入点，0：上5入下4出，1：下4入上5出
            if (access_area_in_out_flag[idx] == 0)
            {
                all_area_points[idx][5].yaw = YawNormalize(check_access_points_[idx].yaw+M_PI/2.);
                all_area_points[idx][4].yaw = YawNormalize(check_access_points_[idx].yaw+M_PI/2.);
                in_or_out_points.push_back(all_area_points[idx][5]);
                in_or_out_points.push_back(all_area_points[idx][4]);
            }else
            {
                all_area_points[idx][4].yaw = YawNormalize(check_access_points_[idx].yaw-M_PI/2.);
                all_area_points[idx][5].yaw = YawNormalize(check_access_points_[idx].yaw-M_PI/2.);
                in_or_out_points.push_back(all_area_points[idx][4]);
                in_or_out_points.push_back(all_area_points[idx][5]);
            }
            
            sort_area_points_.push_back(in_or_out_points);
            sort_access_points_.push_back(check_access_points_[idx]);
        }
        return 1;
    } else {
        LOG(INFO) << "路径没有穿过门禁闸机区域";
        return 0;
    }
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       接收api广播指令的槽函数
 * * @input:       movecmd:api广播指令
 * * @output:      无
 * * @return:      void：无返回
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccesspointAction::slot_NewCmd(QVariant movecmd)
{
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();

    mtx_.lock();
    if (mdc.taskcmd_type == TaskStatus::T_ESTOP)
    {
        thread_pause_flag_ = true;
        access_index_ = AccessProcessIndex::WAIT;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP)
    {
        thread_pause_flag_ = true;
        access_index_ = AccessProcessIndex::WAIT;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_CANCEL)
    {
        if (!p_shard_data_->current_lift_state_)
        {
            thread_pause_flag_ = true;
            access_index_ = AccessProcessIndex::WAIT;
        }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_GOON)
    {
        access_index_ = AccessProcessIndex::WAIT;
        thread_pause_flag_ = false;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_END)
    {
        thread_pause_flag_ = true;
        access_index_ = AccessProcessIndex::WAIT;
    }
    mtx_.unlock();
    LOG(INFO) << "调用了门禁命令";
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       接收门禁闸机乘梯共享类指令的槽函数
 * * @input:       ntask:门禁闸机乘梯共享类指令
 * * @output:      无
 * * @return:      void：无返回
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccesspointAction::slot_NewTask(const QString ntask)
{
    p_shard_data_->fault_code_.B0607 = false;
    thread_pause_flag_ = false;
    LOG(INFO) << "收到了门禁或者闸机命令";
    mtx_.lock();
    // 解包
    QJsonDocument jsdoc = QJsonDocument::fromJson(ntask.toUtf8());
    if (!jsdoc.isNull())
    {
        if (jsdoc.isObject())
        {
            QJsonObject job = jsdoc.object();
            start_point_.x = job["sx"].toDouble();
            start_point_.y = job["sy"].toDouble();
            goal_point_.x = job["gx"].toDouble();
            goal_point_.y = job["gy"].toDouble();
            access_index_ = AccessProcessIndex::STEP1;
            LOG(INFO) << "收到了门禁或者闸机命令,start_point_.x:" << start_point_.x << ",start_point_.y:" << start_point_.y << ",goal_point_.x:" << goal_point_.x << ",goal_point_.y:" << goal_point_.y;
        }
        else
        {
            p_shard_data_->fault_code_.B0607 = true;
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
            access_index_ = AccessProcessIndex::WAIT;
            LOG(ERROR) << "jsdoc.isnoObject()";
            thread_pause_flag_ = true;
        }
    }
    else
    {
        p_shard_data_->fault_code_.B0607 = true;
        p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
        access_index_ = AccessProcessIndex::WAIT;
        LOG(ERROR) << "jsdoc.isNull()";
        thread_pause_flag_ = true;
    }
    mtx_.unlock();
}
/**********************************************************************
 * * @function:    callback_ElevatorResult 
 * * @brief:       获取门禁或闸机状态
 * * @input:       msg:闸机状态
 * * @output:      无
 * * @return:      void：无返回
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccesspointAction::callback_ElevatorResult(const std_msgs::String::ConstPtr &msg)
{
    static bool flg_sensor=true;
    running_state_ = msg->data;
    if (access_index_ < AccessProcessIndex::STEP2 || access_index_ > AccessProcessIndex::STEP11) {
        if (running_state_ == "FREE"||running_state_ == "OVER") {
            if(flg_sensor)
            {
                SetVehicleStatus("over");
                flg_sensor=false;
            }
        }else if(running_state_ == "TURN_AROUND"){
            SetVehicleStatus("turn");
            flg_sensor=true;
        }
        else {
            SetVehicleStatus("lift");
            flg_sensor=true;
        }
    }
}
/**********************************************************************
 * * @function:    SetVehicleStatus 
 * * @brief:       获取车状态
 * * @input:       msg:闸机状态
 * * @output:      无
 * * @return:      void：无返回
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccesspointAction::SetVehicleStatus(const std::string& new_status)
{
        std_msgs::String msg;
        msg.data = new_status;
        pub_cmd_sensor_.publish(msg);
}
/**********************************************************************
 * * @function:    MainLoop 
 * * @brief:       定时器线程执行任务
 * * @input:       
 * * @output:      无
 * * @return:      
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
// 定时器线程执行任务
void AccesspointAction::MainLoop()
{
    /**
     * step1 调用全局规划器，获取全局路径数据集；得到闸机区域角点坐标
     * step2 从数据集中得到第一个进入闸机区域的点
     * step3 计算出闸机区域的入口点和出口点
     * step4 依次执行
     **/

    static int s_aborate_cnt = 0;
    static int s_time_cnt = 0;
    if (s_aborate_cnt > 60000)
    {
        s_aborate_cnt = 0;
    }
    if (s_time_cnt > 60000)
    {
        s_time_cnt = 0;
    }

    switch (access_index_)
    {
    case AccessProcessIndex::WAIT: // 等待
    {
        // 20240918 c_add 过门禁启用超声波避停
        if (start_ultrasonic_flag_)
        {
            LOG(INFO) << "已经过完门禁或闸机,关闭超声波避停";
            start_ultrasonic_flag_ = false;
            std_msgs::String msg;
            msg.data = "stop";
            pub_ultrasonic_avoidance_.publish(msg);
            SetVehicleStatus("over");
        }
        // 20240918 c_add 过门禁启用超声波避停
    }
    break;
    case AccessProcessIndex::STEP1:
    {
        s_aborate_cnt = 0;
        s_time_cnt = 0;
        p_shard_data_->fault_code_.B0606 = false;

        // TODO:获取当前地图的所有门禁闸机点
        check_access_points_.clear();
        sort_access_points_.clear();
        all_area_points_.clear();
        sort_area_points_.clear();
        
        string current_map = p_shard_data_->GetCurrentMap();
        int accessret = p_shard_data_->GetAccessPoint(current_map, check_access_points_);
        LOG(INFO) << "STEP1:检查到有 " << check_access_points_.size() << " 个门禁点";
        for (size_t i = 0; i < check_access_points_.size(); i++)
        {
            LOG(INFO) << "STEP1:有门禁点: " << check_access_points_[i].point_name;
        }
        if (accessret == FaultCode::TRUE)
        { // 有门禁闸机点，开始过门禁闸机
            // 1.生成各个门禁闸机区域
            // 2.检查规划的全局路径是否穿越门禁闸机，并且排布顺序，生成各个门禁闸机的出入点
            // 3.循环接STEP2:

            // 1.生成各个门禁闸机区域

            // // 初始化marker
            // visualization_msgs::Marker access_gate_marker;
            // access_gate_marker.header.frame_id = "map";
            // access_gate_marker.ns = "access_gate";
            // access_gate_marker.id = 0;
            // access_gate_marker.type = visualization_msgs::Marker::POINTS;
            // access_gate_marker.action = visualization_msgs::Marker::ADD;
            // access_gate_marker.scale.x = 0.1;
            // access_gate_marker.scale.y = 0.1;
            // access_gate_marker.color.a = 1.0;
            // access_gate_marker.color.r = 0.0;
            // access_gate_marker.color.g = 1.0;
            // access_gate_marker.color.b = 0.0;

            for (size_t i = 0; i < check_access_points_.size(); i++)
            {
                access_point_.x = check_access_points_[i].x;
                access_point_.y = check_access_points_[i].y;
                access_point_.yaw = check_access_points_[i].yaw;
                std::vector<PointStruct> access_area_points = GetAccessArea4Point(access_length_, access_width_, access_point_);
                all_area_points_.push_back(access_area_points);
                // access_gate_marker.points.push_back(AddPointToMarker(access_area_points[0].x, access_area_points[0].y));
                // access_gate_marker.points.push_back(AddPointToMarker(access_area_points[1].x, access_area_points[1].y));
                // access_gate_marker.points.push_back(AddPointToMarker(access_area_points[2].x, access_area_points[2].y));
                // access_gate_marker.points.push_back(AddPointToMarker(access_area_points[3].x, access_area_points[3].y));
                // access_gate_marker.points.push_back(AddPointToMarker(access_area_points[4].x, access_area_points[4].y));
                // access_gate_marker.points.push_back(AddPointToMarker(access_area_points[5].x, access_area_points[5].y));
                // access_gate_marker.points.push_back(AddPointToMarker(access_area_points[6].x, access_area_points[6].y));
                // access_gate_marker.points.push_back(AddPointToMarker(access_area_points[7].x, access_area_points[7].y));
            }

            // access_gate_marker.header.stamp = ros::Time::now();
            // pub_access_gate_marker_.publish(access_gate_marker);
            // LOG(INFO) << "STEP1:Access or Gate points published as markers");

            // 2.检查规划的全局路径是否穿越门禁闸机，并且排布顺序，生成各个门禁闸机的出入点
            nav_msgs::GetPlan srv;
            // 获取全局规划路径的路点集合
            srv.request.start.header.frame_id = "map";
            srv.request.start.pose.position.x = start_point_.x;
            srv.request.start.pose.position.y = start_point_.y;
            srv.request.start.pose.position.z = GlobalPlannerType::NO_YAW;
            srv.request.start.pose.orientation.w = 1.0;

            srv.request.goal.header.frame_id = "map";
            srv.request.goal.pose.position.x = goal_point_.x;
            srv.request.goal.pose.position.y = goal_point_.y;
            srv.request.goal.pose.position.z = GlobalPlannerType::NO_YAW;
            srv.request.goal.pose.orientation.w = 1.0;

            srv.request.tolerance = 0.1;

            int ret = CallPlanningService(service_client_, srv, all_area_points_);
            if (ret == 0)
            {
                // 不经过门禁闸机区域，结束返回至门禁闸机乘梯共享类中
                access_index_ = AccessProcessIndex::WAIT;
                p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
                LOG(INFO) << "STEP1:导航不需要穿过门禁闸机，返回成功";
                thread_pause_flag_ = true;
                p_shard_data_->fault_code_.B0606 = false;
            }else if (ret == 1)
            {
                access_index_ = AccessProcessIndex::STEP2;
                LOG(INFO) << "STEP1:导航需要穿过门禁闸机，按序执行";
            }else if (ret == -1)
            {
                break;
            }
        }
        else
        { // 没有门禁闸机点
            access_index_ = AccessProcessIndex::WAIT;
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
            LOG(INFO) << "STEP1:没有门禁闸机点，直接返回成功";
            thread_pause_flag_ = true;
            p_shard_data_->fault_code_.B0606 = false;
            break;
        }
    }
    break;
    case AccessProcessIndex::STEP2:
    {
        // 请求移动到门禁或闸机入口处
        MoveDataCmd mdc;
        mdc.taskcmd_type = TaskStatus::T_LOCALE;
        PoseData pose;
        pose.x = sort_area_points_[0][0].x;
        pose.y = sort_area_points_[0][0].y;
        pose.yaw = sort_area_points_[0][0].yaw;
        pose.type = GlobalPlannerType::NORMAL;
        mdc.goal.push_back(pose);
        QVariant qvr;
        qvr.setValue(mdc);
        emit signal_MoveCmd(qvr);
        access_index_ = AccessProcessIndex::STEP3;
        // 此处导航状态切换为去门禁或者闸机入口状态
        emit signal_PubStatus("GOTO_ACCESS_in");
        SetVehicleStatus("over");   
        LOG(INFO) << "准备去门禁或者闸机入口处，坐标为：" << sort_area_points_[0][0].x << " , " << sort_area_points_[0][0].y << " , " << sort_area_points_[0][0].yaw;
    }
    break;
    case AccessProcessIndex::STEP3:
    {
        // 成功移动到门禁或者闸机入口处，将门禁或者闸机进行打开
        if (p_shard_data_->move_status_ == MoveStatus::ARRIVE)
        {
            // 计算现在与目标点的位姿之差
            p_shard_data_->target_distance_ = std::sqrt(std::pow(sort_area_points_[0][0].x - p_shard_data_->current_pose_.x, 2) + std::pow(sort_area_points_[0][0].y - p_shard_data_->current_pose_.y, 2));
            // 导航到达了门禁或者闸机入口处，目标距离 <= 0.28，符合精度
            if (p_shard_data_->target_distance_ <= 0.28)
            {
                // 重置move_action导航状态
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                LOG(INFO) << "到达门禁或者闸机入口成功";
                // 成功到达门禁或者闸机入口，切换到下一步，打开门禁或者闸机
                access_index_ = AccessProcessIndex::STEP5;
                s_aborate_cnt = 0;
                s_time_cnt = 0;
            }
            // 导航到达了门禁或者闸机入口处，但精度不够，准备进入精确控制类
            if (p_shard_data_->target_distance_ < 2.12 && p_shard_data_->target_distance_ > 0.28)
            {
                // 重置move_action导航状态
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                LOG(INFO) << "底盘到达门禁或者闸机入口处,精度不满足要求，误差距离为: " << p_shard_data_->target_distance_;
                // 设置门禁或者闸机入口点，进行精确控制
                MoveDataCmd mdc;
                PoseData pose;
                pose.x = sort_area_points_[0][0].x;
                pose.y = sort_area_points_[0][0].y;
                pose.yaw = sort_area_points_[0][0].yaw;
                pose.type = GlobalPlannerType::NORMAL;
                mdc.goal.push_back(pose);
                QVariant qvr;
                qvr.setValue(mdc);
                emit signal_AccurateControl(qvr);
                // 切换到等待精确控制结果状态，精确控制完成后再切为STEP5或者错误终止
                access_index_ = AccessProcessIndex::STEP12;
            }
            // 导航到达了门禁或者闸机入口处，但精度差距很大，重新发送门禁或者闸机入口点进行导航
            if (p_shard_data_->target_distance_ >= 2.12)
            {
                LOG(INFO) << "底盘到达门禁或者闸机入口处,精度差距很大，误差距离为: " << p_shard_data_->target_distance_;
                // move_action导航状态转化为ABORTED，重新发送门禁或者闸机入口点进行导航
                p_shard_data_->move_status_ = MoveStatus::ABORTED;
            }
        }
        // move_action导航到门禁或者闸机入口处失败，重新发送门禁或者闸机入口点进行导航
        if (p_shard_data_->move_status_ == MoveStatus::ABORTED)
        {
            // 重置move_action导航状态
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            if (s_aborate_cnt >= p_shard_data_->nav_resend_time_)
            {
                s_time_cnt = 0;
                s_aborate_cnt = 0;
                p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_ABORTED;
                LOG(INFO) << "move_action导航到门禁或者闸机入口处导航失败第 " << s_aborate_cnt << " 次，无法导航成功，中止导航";
                access_index_ = AccessProcessIndex::WAIT;
                emit signal_PubStatus("GOTO_ACCESS_in_failed");
                SetVehicleStatus("over"); 
                thread_pause_flag_ = true;
            }
            else
            {
                // 重新发送门禁或者闸机入口点进行导航
                s_aborate_cnt++;
                access_index_ = AccessProcessIndex::STEP4;
                // 20250728 c_add 处理导航失败的策略，先清空障碍层，延时重新发点
                std_srvs::Empty srv;
                LOG(INFO) << "move_action导航到门禁或者闸机入口处导航失败第 " << s_aborate_cnt << " 次，重新发送目标点";
                if(!clear_costmap_client_.waitForExistence(ros::Duration(10)))
                {
                    LOG(ERROR) << "clear_costmap died";
                }     
                clear_costmap_client_.call(srv);
                s_time_cnt = 0;
            }
        }
    }
    break;
    case AccessProcessIndex::STEP4:
    {
        s_time_cnt++;
        // 等待50*100ms=5s重新规划一次
        if (s_time_cnt % 50 == 0)
        {
            if (car_type_ == "DR-01")
            {
                PublishVoice("EncounterPerdestrian");
            }
            else
            {
                // PublishVoice("NoPass");
            }
            // 重新发送目标点
            access_index_ = AccessProcessIndex::STEP2;
            LOG(INFO) << "move_action导航到门禁或者闸机入口处导航失败，清空代价地图成功，重新发送目标点";
        }
    }
    break;
    case AccessProcessIndex::STEP5:
    {
        // 到达门禁或者闸机入口成功，置位状态
        emit signal_PubStatus("GOTO_ACCESS_in_success");
        SetVehicleStatus("acc"); 
        // 20240918 c_add 过门禁或者闸机启用超声波避停
        LOG(INFO) << "开始过门禁或者闸机,打开超声波进行避停";
        std_msgs::String msg;
        msg.data = "start";
        pub_ultrasonic_avoidance_.publish(msg);
        start_ultrasonic_flag_ = true;
        // 20240918 c_add 过门禁或者闸机启用超声波避停
        // 获取当前所在的楼层号
        std::string floor_no = GetFloorNo(p_shard_data_->current_map_);
        // 门禁或者闸机常开门指令
        std::string cmd_type = "long_open_door";
        robot_msgs::Elevator srv;
        srv.request.type = cmd_type;
        srv.request.aim_floor = std::atoi(floor_no.c_str());
        srv.request.pose.name = sort_access_points_[0].point_name;
        LOG(INFO) << "srv.request.aim_floor " << srv.request.aim_floor << " 楼 " << srv.request.pose.name << " 常开门";
        // 请求门禁或者闸机常开门
        if(!client_access_.waitForExistence(ros::Duration(10)))
        {
            LOG(ERROR) << "srv_elevator died";
        } 
        if (client_access_.call(srv))
        {
            std::string response_status = srv.response.status;
            size_t pos = response_status.find("failed");
            if (pos != response_status.npos)
            {
                emit signal_PubStatus("GOTO_ACCESS_opendoor_failed");
                SetVehicleStatus("acc"); 
                p_shard_data_->fault_code_.B0606 = true;
                p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
                access_index_ = AccessProcessIndex::WAIT;
                LOG(ERROR) << "请求门禁或者闸机开门服务成功，但是返回failed: " << response_status;
                thread_pause_flag_ = true;
            }
            else
            {
                // 请求门禁或者闸机开门服务成功，等待开门结果
                emit signal_PubStatus("GOTO_ACCESS_opendoor");
                SetVehicleStatus("acc"); 
                p_shard_data_->fault_code_.B0606 = false;
                LOG(INFO) << "请求门禁或者闸机开门服务成功，等待开门结果: " << response_status;
                access_index_ = AccessProcessIndex::STEP6;
                running_state_ = "";
                //StartKeepDoorTimer();
            }
        }
        else
        {
            emit signal_PubStatus("GOTO_ACCESS_opendoor_failed");
            SetVehicleStatus("acc"); 
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
            access_index_ = AccessProcessIndex::WAIT;
            LOG(ERROR) << "请求门禁或者闸机开门服务失败";
            p_shard_data_->fault_code_.B0606 = true;
            thread_pause_flag_ = true;
        }
    }
    break;
    case AccessProcessIndex::STEP6:
    {
        if (running_state_ == "OVER")
        {
            access_index_ = AccessProcessIndex::STEP7;
            p_shard_data_->fault_code_.B0606 = false;
            LOG(INFO) << "门禁或者闸机常开成功，准备去门禁或者闸机出口点";
            emit signal_PubStatus("GOTO_ACCESS_opendoor_success");
            SetVehicleStatus("acc"); 
        }
        else if (running_state_ == "FAULT")
        {
            emit signal_PubStatus("GOTO_ACCESS_opendoor_failed");
            SetVehicleStatus("acc"); 
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
            access_index_ = AccessProcessIndex::WAIT;
            p_shard_data_->fault_code_.B0606 = true;
            LOG(INFO) << "门禁或者闸机常开失败，状态为FAULT";
            thread_pause_flag_ = true;
        }
    }
    break;
    case AccessProcessIndex::STEP7:
    {
        // 临时加的等待开门时间
        static int s_wait_access_open = 0;
        if (s_wait_access_open < access_open_time_*10)
        {
            s_wait_access_open++;
            break;
        }

        s_wait_access_open = 0;
        access_index_ = AccessProcessIndex::STEP8;
        emit signal_PubStatus("GOTO_ACCESS_out");
        SetVehicleStatus("acc"); 
        LOG(INFO) << "门禁或者闸机常开成功，准备去门禁或者闸机出口点，调用窄通道的程序";
    }
    break;
    case AccessProcessIndex::STEP8:
    {
        narrow_path::CmdVelStr cmd_vel;
        geometry_msgs::Pose2D accessin, accessout;
        accessin.x = sort_area_points_[0][0].x;
        accessin.y = sort_area_points_[0][0].y;
        accessin.theta = sort_area_points_[0][0].yaw;
        accessout.x = sort_area_points_[0][1].x;
        accessout.y = sort_area_points_[0][1].y;
        accessout.theta = sort_area_points_[0][1].yaw;

        if (this->HasObstacle())
        {
            // 有障碍物，发布零速度
            narrow_path::CmdVelStr stop_cmd;
            stop_cmd.linear = 0.0;
            stop_cmd.angular = 0.0;
            PublishVelocity(stop_cmd);
            this->SetWaitingObstacle(true); 
            StartKeepDoorTimer();
            // 定时器已经在运行，会每20秒自动发送开门命令
            LOG(INFO) << "检测到障碍物，机器人停止，等待障碍物清除，门禁保持开启";
            static ros::Time last_voice_time = ros::Time(0);
            ros::Time now = ros::Time::now();
            if ((now - last_voice_time).toSec() >= 5.0)
            {
                PublishVoice("NoPass");
                last_voice_time = now;
                LOG(INFO) << "播放语音提示：NoPass";
            }
            
            // 不切换状态，继续等待
            break;
        }else{
            this->SetWaitingObstacle(false);
        }

        bool result = Control(cmd_vel, accessin, accessout);
        PublishVelocity(cmd_vel);
        if (result)
        {
            access_index_ = AccessProcessIndex::STEP10;
            LOG(INFO) << "到达门禁或者闸机出口成功";
        }
    }
    break;
    case AccessProcessIndex::STEP9:
    {
        // TODO
    }
    break;
    case AccessProcessIndex::STEP10:
    {
        StopKeepDoorTimer();

        emit signal_PubStatus("GOTO_ACCESS_out_success");
        SetVehicleStatus("over"); 
        // 20240918 c_add 过门禁启用超声波避停
        if (start_ultrasonic_flag_)
        {
            LOG(INFO) << "已经过完门禁或者闸机,关闭超声波避停";
            start_ultrasonic_flag_ = false;
            std_msgs::String msg;
            msg.data = "stop";
            pub_ultrasonic_avoidance_.publish(msg);
        }
        // 20240918 c_add 过门禁启用超声波避停
        // 获取当前所在的楼层号
        std::string floor_no = GetFloorNo(p_shard_data_->current_map_);
        // 门禁或者闸机常开门关闭指令
        std::string cmd_type = "close_door";
        robot_msgs::Elevator srv;
        srv.request.type = cmd_type;
        srv.request.aim_floor = std::atoi(floor_no.c_str());
        srv.request.pose.name = sort_access_points_[0].point_name;
        LOG(INFO) << "srv.request.aim_floor " << srv.request.aim_floor << " 楼 " << srv.request.pose.name << " 常开门关闭";
        // 请求门禁或者闸机常开门关闭
        if(!client_access_.waitForExistence(ros::Duration(10)))
        {
            LOG(ERROR) << "srv_elevator died";
        }  
        if (client_access_.call(srv))
        {
            LOG(INFO) << "请求门禁或者闸机关门服务成功，等待关门结果";
            std::string response_status = srv.response.status;
            size_t pos = response_status.find("failed");
            if (pos != response_status.npos)
            {
                emit signal_PubStatus("GOTO_ACCESS_closedoor_failed");
                SetVehicleStatus("over"); 
                p_shard_data_->fault_code_.B0606 = true;
                p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
                access_index_ = AccessProcessIndex::WAIT;
                LOG(ERROR) << "请求门禁或者闸机关门服务成功，但是返回failed: " << response_status;
                thread_pause_flag_ = true;
            }
            else
            {
                // 请求门禁或者闸机关门服务成功，等待关门结果
                emit signal_PubStatus("GOTO_ACCESS_closedoor");
                SetVehicleStatus("over"); 
                p_shard_data_->fault_code_.B0606 = false;
                LOG(INFO) << "请求门禁或者闸机关门服务成功，等待关门结果: " << response_status;
                access_index_ = AccessProcessIndex::STEP11;
                running_state_ = "";
            }
        }
        else
        {
            emit signal_PubStatus("GOTO_ACCESS_closedoor_failed");
            SetVehicleStatus("over"); 
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
            access_index_ = AccessProcessIndex::WAIT;
            LOG(ERROR) << "请求门禁或者闸机关门服务失败";
            p_shard_data_->fault_code_.B0606 = true;
            thread_pause_flag_ = true;
        }
        this->SetWaitingObstacle(false);
    }
    break;
    case AccessProcessIndex::STEP11:
    {
        if (running_state_ == "OVER")
        {
            StopKeepDoorTimer();
            if (sort_area_points_.size() - 1 > 0)
            {
                this->SetWaitingObstacle(false);
                LOG(INFO) << "门禁或者闸机关闭成功，但是还剩余 " << sort_area_points_.size() - 1 << " 个门禁闸机需要通过，继续执行下一个门禁闸机过程";
                sort_area_points_.erase(sort_area_points_.begin());
                sort_access_points_.erase(sort_access_points_.begin());
                access_index_ = AccessProcessIndex::STEP2;
            }
            else
            {
                this->SetWaitingObstacle(false);
                LOG(INFO) << "门禁或者闸机关闭成功，门禁过程结束";
                emit signal_PubStatus("GOTO_ACCESS_closedoor_success");
                SetVehicleStatus("over"); 
                if(p_shard_data_->curr_lift_point_type_=="back"){
                    emit signal_PubStatus("GOTO_back");
                }else{
                    emit signal_PubStatus("GOTO_"+p_shard_data_->curr_lift_point_name_);
                }
                //emit signal_PubStatus(p_shard_data_->now_nav_status_);
                p_shard_data_->fault_code_.B0606 = false;
                access_index_ = AccessProcessIndex::WAIT;
                p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
                thread_pause_flag_ = true;
            }
        }
        else if (running_state_ == "FAULT")
        {
            emit signal_PubStatus("GOTO_ACCESS_closedoor_failed");
            SetVehicleStatus("over"); 
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
            access_index_ = AccessProcessIndex::WAIT;
            p_shard_data_->fault_code_.B0606 = true;
            LOG(INFO) << "门禁或者闸机关闭失败，状态为FAULT";
            thread_pause_flag_ = true;
        }
    }
    break;
    case AccessProcessIndex::STEP12:
    {
        if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            access_index_ = AccessProcessIndex::STEP5;
            LOG(INFO) << "精确控制成功";
        }
        else if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_ABORTED;
            access_index_ = AccessProcessIndex::WAIT;
            LOG(INFO) << "精确控制丢弃";
            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_FAILED)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_FAILED;
            access_index_ = AccessProcessIndex::WAIT;
            LOG(INFO) << "精确控制失败";
            thread_pause_flag_ = true;
        }
    }
    break;
    case AccessProcessIndex::STEP13:
    {
        // TODO
    }
    break;
    default:
        break;
    }
}
