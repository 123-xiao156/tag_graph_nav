/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	accurate_control.cpp
 * * @description:  门禁、乘梯
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "back_home.h"

BackHome::BackHome(ros::NodeHandle nh) : nh_(nh)
{
    int nav_version;
    nh_.param<int>("nav_version", nav_version, 1);  //#1move_base导航，2nav_base导航
    if(nav_version==1)
    {
        nav_node_="/move_base";
    }
    if(nav_version==2)
    {
        nav_node_="/task_base";
    }  
    clear_costmap_client_ = nh_.serviceClient<std_srvs::Empty>(nav_node_+"/clear_costmaps");
    client_originpoint_ = nh_.serviceClient<robot_msgs::ElevatorPoint>("/map_point");
    pub_cmd_vel_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
    pub_voice_ = nh_.advertise<robot_msgs::Voice>("/voiceplay", 10);
    nh_.param("car_type", car_type_, std::string("UC"));
    // 20250902 c_add 添加乘梯功能关闭时返航选取当前地图返航点功能
    nh_.param<bool>("lift", autolift_, false);
    nh_.param<std::string>("yamlpath", nav_yaml_path_, "");
}

// 初始化，创建线程
void BackHome::Init()
{
    interval_ms_ = 100;
    std::thread t(&BackHome::TimerThread, this, interval_ms_);
    t.detach();
}

// 线程开始
void BackHome::TimerThread(int16_t interval_ms)
{
    while (ros::ok())
    {
        if (!thread_pause_flag_)
        {
            MainLoop();
        }
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
/**********************************************************************
 * * @function:    PublishVoice 
 * * @brief:       发布语音
 * * @input:       data: 语音名称
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void BackHome::PublishVoice(std::string name)
{
    robot_msgs::Voice msg;
    msg.info_volume = 70;    // 音量70%
    msg.info_type = "voice"; // 播放语音
    msg.info_data = name;    // 语音名称，见语音列表
    pub_voice_.publish(msg);
}
/**********************************************************************
 * * @function:    ReadDefaultMap 
 * * @brief:       读取默认地图
 * * @input:       
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
std::string BackHome::ReadDefaultMap()
{
    std::string name;
    try {//临时的处理办法，TODO:统一由database来完成，防止多文件同时读写冲突
        YAML::Node config = YAML::LoadFile(nav_yaml_path_);
        if(config["default_map"])
        {
            name = config["default_map"].as<std::string>();
        }
    } catch (const YAML::Exception& e) {
        std::cerr << "YAML Error: " << e.what() << std::endl;
    }
    return name;
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       接收interface_action发送的指令
 * * @input:       movecmd:运动状态
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void BackHome::slot_NewCmd(QVariant movecmd)
{
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();

    if (mdc.taskcmd_type == TaskStatus::T_ESTOP)
    {
        thread_pause_flag_ = true;
        process_index_ = BackHomeIndex::STEP0;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP)
    {
        thread_pause_flag_ = true;
        process_index_ = BackHomeIndex::STEP0;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_CANCEL)
    {
        if (!p_shard_data_->current_lift_state_)
        {
            thread_pause_flag_ = true;
            process_index_ = BackHomeIndex::STEP0;
        }
        else{
            LOG(INFO) << "back_home 乘梯过程中忽略取消命令";
            return; // 直接返回，不处理取消命令
        }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_GOON)
    {
        process_index_ = BackHomeIndex::STEP0;
        thread_pause_flag_ = false;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_END)
    {
        if (!p_shard_data_->current_lift_state_)
        {
            thread_pause_flag_ = true;
            process_index_ = BackHomeIndex::STEP0;
        }
        else{
            LOG(INFO) << "乘梯过程中忽略结束命令";
            return; // 直接返回，不处理取消命令
        }
    }
    LOG(INFO) << "back_home slot_NewCmd接收到interface_action的新指令" << mdc.taskcmd_type;
}
/**********************************************************************
 * * @function:    SetCmd 
 * * @brief:       从navcontrol的TASK_HANDOUT调用此命令，设置返航任务
 * * @input:       cmd_type: 命令类型字符串 pdata: 目标位置和姿态数据
 * * @output:      更新共享数据状态和任务参数
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void BackHome::SetCmd(std::string cmd_type, PoseData pdata)
{
    LOG(INFO) << "back_home SetCmd 被调用，current_lift_state_=" << p_shard_data_->current_lift_state_;

    if (p_shard_data_->current_lift_state_)
    {
        LOG(INFO) << "在返航点乘梯状态不再立即执行指令，等待乘梯状态结束继续执行最后一次发的指令";
        p_shard_data_->continue_state_ = true;
        p_shard_data_->storage_cmd_type = cmd_type;
        p_shard_data_->storage_pdata = pdata;
        thread_pause_flag_ = false;
        process_index_ = BackHomeIndex::STEP0;
    }
    else
    {
        LOG(INFO) << "navcontrol调用back_home的SetCmd发送指令进行导航";
        robot_msgs::ElevatorPoint srv;
        // 20250902 c_add 添加乘梯功能关闭时返航选取当前地图返航点功能
        if (autolift_)
        {
            srv.request.request_mapname = ReadDefaultMap();
            LOG(INFO) << "通过/map_point服务订阅默认地图上的back点的位置" << srv.request.request_mapname;
        }
        else
        {
            srv.request.request_mapname = p_shard_data_->current_map_;
            LOG(INFO) << "通过/map_point服务订阅当前地图上的back点的位置" << srv.request.request_mapname;
        }
        srv.request.point_type = "back";
        if(!client_originpoint_.waitForExistence(ros::Duration(10)))
        {
            LOG(ERROR) << "srv originpoint_ died";
        }     
        if (client_originpoint_.call(srv) && srv.response.response_state == "ok")
        {
            LOG(INFO) << "通过/map_point服务订阅back点的位置";
            p_shard_data_->fault_code_.B0417 = false;
            // 赋值返航点信息
            back_point_.map = srv.response.orign_point.MapName;
            back_point_.type = NORMAL;
            back_point_.x = std::atof(srv.response.orign_point.X.c_str());
            back_point_.y = std::atof(srv.response.orign_point.Y.c_str());
            back_point_.yaw = std::atof(srv.response.orign_point.YAW.c_str());

            p_shard_data_->target_distance_ = std::sqrt(std::pow(back_point_.x - sub_current_pose_.x, 2) + std::pow(back_point_.y - sub_current_pose_.y, 2));
            if (p_shard_data_->target_distance_ <= 0.28)
            {
                LOG(INFO) << "底盘已在back点 back_point.x " << back_point_.x << " back_point.y " << back_point_.y << " current_pose.x " << sub_current_pose_.x << " current_pose.y " << sub_current_pose_.y;
                std::this_thread::sleep_for(std::chrono::seconds(3));
            }
            thread_pause_flag_ = false;
            process_index_ = BackHomeIndex::STEP1;

            if (car_type_ == "DR-01")
            {
                PublishVoice("BackHint");
            }
        }
        else
        {
            LOG(INFO) << "通过/map_point服务订阅back点的位置,未订阅到back点";
            emit signal_PubStatus("GOTO_BACK_failed");
            p_shard_data_->fault_code_.B0417 = true;
            thread_pause_flag_ = true;
        }
    }
}
/**********************************************************************
 * * @function:    MainLoop 
 * * @brief:       定时器线程执行任务
 * * @input:       
 * * @output:      
 * * @return:      
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
// 定时器线程执行任务
void BackHome::MainLoop()
{
    static int s_aborate_cnt = 0;
    static int s_num = 0;
    static int s_time_cnt = 0;
    if (s_aborate_cnt > 60000)
    {
        s_aborate_cnt = 0;
    }
    if (s_num >= 60000)
    {
        s_num = 0;
    }
    if (s_time_cnt > 60000)
    {
        s_time_cnt = 0;
    }

    switch (process_index_)
    {
    case BackHomeIndex::STEP0:
    {
        if (p_shard_data_->continue_state_)
        {
            LOG(INFO) << "在乘梯状态，等待乘梯完成后再执行新指令";
            if (p_shard_data_->access_lift_shared_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
            {
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;
                LOG(INFO) << "STEP0:等待乘梯完成，完成了开始继续最新的任务";
                p_shard_data_->current_lift_state_ = false;
                p_shard_data_->continue_state_ = false;
                SetCmd(p_shard_data_->storage_cmd_type, p_shard_data_->storage_pdata);
                break;
            }
        }
    }
    break;
    // 请求门禁闸机和乘梯
    case BackHomeIndex::STEP1:
    {
        s_aborate_cnt = 0;
        s_time_cnt = 0;
        s_num = 0;
        p_shard_data_->current_lift_state_flag_ = true;
        // 请求门禁闸机和乘梯命令
        MoveDataCmd mdc;
        mdc.taskcmd_type = TaskStatus::T_LOCALE;
        PoseData pose;
        pose.x = back_point_.x;
        pose.y = back_point_.y;
        pose.yaw = back_point_.yaw;
        pose.type = back_point_.type;
        pose.map = back_point_.map;
        mdc.goal.push_back(pose);
        QVariant qvr;
        qvr.setValue(mdc);
        // 信号槽，请求门禁闸机和乘梯
        emit signal_AccessLiftCmd(qvr);
        process_index_ = BackHomeIndex::STEP2;
        LOG(INFO) << "STEP1:请求门禁闸机和乘梯，目标地图名称为: " << back_point_.map;
    }
    break;
    // 等待门禁闸机和乘梯的结果
    case BackHomeIndex::STEP2:
    {
        if (s_num % 50 == 0)
        {
            LOG(INFO) << "STEP2:正在等待门禁闸机和乘梯的结果";
        }
        s_num++;
        // 门禁闸机和乘梯的结果
        if (p_shard_data_->access_lift_shared_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        {
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;
            process_index_ = BackHomeIndex::STEP10;
            LOG(INFO) << "STEP2:门禁闸机和乘梯通过";
            if (p_shard_data_->continue_state_)
            {
                p_shard_data_->current_lift_state_ = false;
                p_shard_data_->continue_state_ = false; 
                thread_pause_flag_ = true; 
                LOG(INFO) << "STEP2:门禁闸机和乘梯通过，但是在乘梯时最新发送的指令是normal点，开始进行返航任务";
            }
        }
        else if (p_shard_data_->access_lift_shared_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        {
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_ABORTED;
            process_index_ = BackHomeIndex::STEP0;
            p_shard_data_->current_lift_state_ = false;
            p_shard_data_->current_lift_state_flag_ = false;
            LOG(INFO) << "STEP2:门禁闸机和乘梯中止";
        }
        else if (p_shard_data_->access_lift_shared_nav_status_.goal_status == NavStatus::NAV_FAILED)
        {
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_FAILED;
            process_index_ = BackHomeIndex::STEP0;
            p_shard_data_->current_lift_state_ = false;
            p_shard_data_->current_lift_state_flag_ = false;
            LOG(INFO) << "STEP2:门禁闸机和乘梯失败";
        }
    }
    break;
    case BackHomeIndex::STEP9:
    {
        s_time_cnt++;
        // 等待50*100ms=5s重新规划一次
        if (s_time_cnt % 50 == 0)
        {
            if (car_type_ == "DR-01")
            {
                PublishVoice("EncounterPerdestrian");
            }
            else
            {
                // PublishVoice("NoPass");
            }
            // 重新发送目标点
            process_index_ = BackHomeIndex::STEP10;
            LOG(INFO) << "move_action导航到返航点导航失败，清空代价地图后，重新发送目标点";
        }
    }
    break;
    // 门禁闸机和乘梯完成，开始发送目标点
    case BackHomeIndex::STEP10:
    {
        p_shard_data_->current_lift_state_ = false;
        p_shard_data_->current_lift_state_flag_ = false;

        // 目标点
        MoveDataCmd mdc;
        mdc.taskcmd_type = TaskStatus::T_LOCALE;
        PoseData pose;
        pose.x = back_point_.x;
        pose.y = back_point_.y;
        pose.yaw = back_point_.yaw;
        pose.type = back_point_.type;
        pose.map = back_point_.map;
        mdc.goal.push_back(pose);
        QVariant qvr;
        qvr.setValue(mdc);
        // 信号槽，请求move_action，进行路径规划
        emit signal_MoveCmd(qvr);
        process_index_ = BackHomeIndex::STEP11;
        LOG(INFO) << "STEP10:门禁闸机和乘梯完成，开始发送目标点";
    }
    break;
    // 等待移动到目标点的结果
    case BackHomeIndex::STEP11:
    {
        if (p_shard_data_->move_status_ == MoveStatus::ARRIVE)
        {
            // 计算现在与目标点的位姿之差
            p_shard_data_->target_distance_ = std::sqrt(std::pow(back_point_.x - p_shard_data_->current_pose_.x, 2) + std::pow(back_point_.y - p_shard_data_->current_pose_.y, 2));
            // 导航到达了返航点，目标距离 <= 0.28，符合精度
            if (p_shard_data_->target_distance_ <= 0.28)
            {
                s_aborate_cnt = 0;
                s_time_cnt = 0;
                // 重置move_action导航状态
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                LOG(INFO) << "底盘已到返航点，并且精度满足要求<=0.28";
                process_index_ = BackHomeIndex::STEP0;
                p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
                thread_pause_flag_ = true;
            }
            // 导航到达了返航点，但精度不够，准备进入精确控制类
            if (p_shard_data_->target_distance_ < 2.12 && p_shard_data_->target_distance_ > 0.28)
            {
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                LOG(INFO) << "底盘到返航点，精度不满足要求，需进入精细导航，误差距离为: " << p_shard_data_->target_distance_;
                // 设置返航点，进行精确控制
                MoveDataCmd mdc;
                PoseData pose;
                pose.x = back_point_.x;
                pose.y = back_point_.y;
                pose.yaw = back_point_.yaw;
                pose.type = back_point_.type;
                pose.map = back_point_.map;
                mdc.goal.push_back(pose);
                QVariant qvr;
                qvr.setValue(mdc);
                // 切换到等待精确控制结果状态
                emit signal_AccurateControl(qvr);
                process_index_ = BackHomeIndex::STEP12;
            }

            // 导航到达了返航点，但精度差距很大，重新发送返航点进行导航
            if (p_shard_data_->target_distance_ >= 2.12)
            {
                LOG(INFO) << "底盘到达返航点,精度差距很大，误差距离为: " << p_shard_data_->target_distance_;
                p_shard_data_->move_status_ == MoveStatus::ABORTED;
            }
        }
        else if (p_shard_data_->move_status_ == MoveStatus::ABORTED)
        {
            // 重置move_action导航状态
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            if (s_aborate_cnt >= p_shard_data_->nav_resend_time_)
            {
                s_aborate_cnt = 0;
                s_time_cnt = 0;
                p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_FAILED;
                LOG(INFO) << "导航失败第 " << s_aborate_cnt << " 次，无法导航成功，中止导航";
                process_index_ = BackHomeIndex::STEP0;
                thread_pause_flag_ = true;
            }
            else
            {
                s_aborate_cnt++;
                process_index_ = BackHomeIndex::STEP9;
                LOG(INFO) << "STEP11:导航失败第 " << s_aborate_cnt << " 次";
                // 清理障碍层，重新发送
                std_srvs::Empty srv;
                if (!clear_costmap_client_.waitForExistence(ros::Duration(10)))
                {
                    LOG(ERROR) << "clear_costmap died";
                }
                clear_costmap_client_.call(srv);
                s_time_cnt = 0;
            }
        }
    }
    break;
    case BackHomeIndex::STEP12:
    {
        if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
            process_index_ = BackHomeIndex::STEP0;
            LOG(INFO) << "精确控制成功";
            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_ABORTED;
            process_index_ = BackHomeIndex::STEP0;
            LOG(INFO) << "精确控制中止";
            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_FAILED)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_FAILED;
            process_index_ = BackHomeIndex::STEP0;
            LOG(INFO) << "精确控制失败";
            thread_pause_flag_ = true;
        }
    }
    break;
    default:
        break;
    }
}
