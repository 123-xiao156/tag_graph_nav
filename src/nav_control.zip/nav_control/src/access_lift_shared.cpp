/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	access_lift_shared.cpp
 * * @description:  门禁、乘梯
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "access_lift_shared.h"

AccessLiftShared::AccessLiftShared(ros::NodeHandle nh) : nh_(nh)
{
    int nav_version;
    nh_.param<int>("nav_version", nav_version, 1);  //#1move_base导航，2nav_base导航
    if(nav_version==1)
    {
        nav_node_="/move_base";
    }
    if(nav_version==2)
    {
        nav_node_="/task_base";
    }   
    clear_costmap_client_ = nh_.serviceClient<std_srvs::Empty>(nav_node_+"/clear_costmaps");
    // 20250716 c_add 添加乘梯成功后，检查是否代价地图切换完成
    sub_global_costmap_iimt_updates_ = nh_.subscribe(nav_node_+"/global_costmap/costmap_iimt_updates", 10, &AccessLiftShared::globalcostmapupdateCB, this);
    sub_only_static_costmap_iimt_updates_ = nh_.subscribe(nav_node_+"/only_static_costmap/costmap_iimt_updates", 10, &AccessLiftShared::onlystaticcostmapupdateCB, this);
    pub_voice_ = nh_.advertise<robot_msgs::Voice>("/voiceplay", 10);
    srv_database_ = nh_.serviceClient<robot_msgs::Database_data>("/database_operate");
    nh_.param("car_type", car_type_, std::string("UC"));
    nh_.param<bool>("auto_cal_liftpoint", new_method_lift_, false);
    nh_.param<double>("dis_lift_to_door", new_method_lift_distance_, 1.5);
}
/**********************************************************************
 * * @function:    globalcostmapupdateCB 
 * * @brief:       全局代价地图更新回调函数 添加乘梯成功后，检查是否代价地图切换完成
 * * @input:       msg: 代价地图
 * * @output:      更新内部代价地图数据状态
 * * @return:      void：无返回值
 * * @author：     chentao
 * * @date：       20250716
 * **********************************************************************/
void AccessLiftShared::globalcostmapupdateCB(const geometry_msgs::PoseStamped& msg)
{
    globalcostmapupdatedata_.x = msg.pose.position.x;
    globalcostmapupdatedata_.y = msg.pose.position.y;
    globalcostmapupdatedata_.stamp = msg.header.stamp;
    //std::cout << "globalcostmapupdateCB: x= " << globalcostmapupdatedata_.x << " , y= " << globalcostmapupdatedata_.y << " , stamp= " << globalcostmapupdatedata_.stamp << std::endl;
}
/**********************************************************************
 * * @function:    onlystaticcostmapupdateCB 
 * * @brief:       全局代价地图更新回调函数，添加乘梯成功后检查代价地图切换完成状态
 * * @input:       msg: 包含位姿信息的代价地图更新消息
 * * @output:      更新内部代价地图数据状态
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccessLiftShared::onlystaticcostmapupdateCB(const geometry_msgs::PoseStamped& msg)
{
    onlystaticcostmapupdatedata_.x = msg.pose.position.x;
    onlystaticcostmapupdatedata_.y = msg.pose.position.y;
    onlystaticcostmapupdatedata_.stamp = msg.header.stamp;
    //std::cout << "onlystaticcostmapupdateCB: x= " << onlystaticcostmapupdatedata_.x << " , y= " << onlystaticcostmapupdatedata_.y << " , stamp= " << onlystaticcostmapupdatedata_.stamp << std::endl;
}

// 初始化，创建线程
void AccessLiftShared::Init()
{
    interval_ms_ = 100;
    std::thread t(&AccessLiftShared::TimerThread, this, interval_ms_);
    t.detach();
}

// 线程开始
void AccessLiftShared::TimerThread(int16_t interval_ms)
{
    while (ros::ok())
    {
        if (!thread_pause_flag_)
        {
            MainLoop();
        }
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
/**********************************************************************
 * * @function:    PublishVoice 
 * * @brief:       发布音频
 * * @input:       msg: 音频名称
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccessLiftShared::PublishVoice(std::string name)
{
    robot_msgs::Voice msg;
    msg.info_volume = 70;    // 音量70%
    msg.info_type = "voice"; // 播放语音
    msg.info_data = name;    // 语音名称，见语音列表
    pub_voice_.publish(msg);
}
/**********************************************************************
 * * @function:    YawNormalize 
 * * @brief:       归一化角度到(−π,π]
 * * @input:       yaw: 角度
 * * @output:      
 * * @return:      double：返回归一化角度
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
double AccessLiftShared::YawNormalize(double yaw)
{
    while (yaw > M_PI)
    {
        yaw -= 2 * M_PI;
    }
    while (yaw < -M_PI)
    {
        yaw += 2 * M_PI;
    }
    return yaw;
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       处理新的移动命令，执行相应的任务控制
 * * @input:       movecmd: 包含任务命令数据的QVariant对象
 * * @output:      根据命令类型设置相应的线程控制标志
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccessLiftShared::slot_NewCmd(QVariant movecmd)
{
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();

    if (mdc.taskcmd_type == TaskStatus::T_ESTOP)
    {
        thread_pause_flag_ = true;
        process_index_ = ProcessIndex::STEP0;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP)
    {
        thread_pause_flag_ = true;
        process_index_ = ProcessIndex::STEP0;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_CANCEL)
    {
        if (!p_shard_data_->current_lift_state_flag_)
        {
            thread_pause_flag_ = true;
            process_index_ = ProcessIndex::STEP0;
        }
        else{
            LOG(INFO) << "access_lift_shared 乘梯过程中忽略取消命令";
            return; // 直接返回，不处理取消命令
        }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_GOON)
    {
        process_index_ = ProcessIndex::STEP0;
        thread_pause_flag_ = false;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_END)
    {
        if (!p_shard_data_->current_lift_state_)
        {
            thread_pause_flag_ = true;
            process_index_ = ProcessIndex::STEP0;
        }
        else{
            LOG(INFO) << "access_lift_shared 乘梯过程中忽略结束命令";
            return; // 直接返回，不处理取消命令
        }
    }
    LOG(INFO) << "access_lift_shared slot_NewCmd接收到interface_action的新指令" << mdc.taskcmd_type;
}
/**********************************************************************
 * * @function:    slot_SetCmd 
 * * @brief:       从navcontrol的信号槽调用此命令，返航点和普通点请求门禁闸机乘梯共享类
 * * @input:       movecmd: 包含任务命令数据的QVariant对象
 * * @output:      根据命令类型设置相应的线程控制标志
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccessLiftShared::slot_SetCmd(QVariant movecmd)
{
    mtx_.lock();
    MoveDataCmd pdata;
    pdata = movecmd.value<MoveDataCmd>();
    if(pdata.goal.size()==0)return;
    goal_point_.map = pdata.goal[0].map;
    goal_point_.type = pdata.taskcmd_type;
    goal_point_.x = pdata.goal[0].x;
    goal_point_.y = pdata.goal[0].y;
    goal_point_.yaw = pdata.goal[0].yaw;
    thread_pause_flag_ = false;
    process_index_ = ProcessIndex::STEP1;
    mtx_.unlock();
    LOG(INFO) << "access_lift_shared 乘梯共享类被调用了，map_name为：" << pdata.goal[0].map << "," << goal_point_.x << ", goalx:" << goal_point_.x << ", goaly:" << goal_point_.y;
}
/**********************************************************************
 * * @function:    SendtoAccessAction 
 * * @brief:       门禁闸机乘梯共享类请求门禁闸机动作
 * * @input:       sx: 起始点x坐标
 * *               sy: 起始点y坐标  
 * *               gx: 目标点x坐标
 * *               gy: 目标点y坐标
 * * @output:      发送信号给门禁闸机处理模块
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccessLiftShared::SendtoAccessAction(double sx, double sy, double gx, double gy)
{
    QJsonObject jobj;
    jobj.insert("sx", sx);
    jobj.insert("sy", sy);
    jobj.insert("gx", gx);
    jobj.insert("gy", gy);
    QJsonDocument jdoc(jobj);
    QByteArray bty = jdoc.toJson();
    QString j_str = QString::fromUtf8(bty);

    emit signal_toAccesssAction(j_str);
}
/**********************************************************************
 * * @function:    SendtoLiftAction 
 * * @brief:       门禁闸机乘梯共享类请求乘梯动作
 * * @input:       ax: 电梯点x坐标
 * *               ay: 电梯点y坐标
 * *               ayaw: 电梯点朝向角度
 * *               floornumber: 目标楼层号
 * * @output:      发送信号给乘梯处理模块
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccessLiftShared::SendtoLiftAction(double ax, double ay, double ayaw, std::string floornumber)
{
    QJsonObject jobj;
    jobj.insert("l_x", ax);
    jobj.insert("l_y", ay);
    jobj.insert("l_yaw", ayaw);
    jobj.insert("floornumber", floornumber.c_str());
    jobj.insert("l_map", goal_point_.map.c_str());
    QJsonDocument jdoc(jobj);
    QByteArray bty = jdoc.toJson();
    QString j_str = QString::fromUtf8(bty);

    emit signal_toLiftAction(j_str);
}
/**********************************************************************
 * * @function:    MainLoop 
 * * @brief:       乘梯定时器线程执行任务
 * * @input:       
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
// 定时器线程执行任务
void AccessLiftShared::MainLoop()
{
    switch (process_index_)
    {
        static int s_aborate_cnt = 0;
        static int s_time_cnt = 0;
        if (s_aborate_cnt > 60000)
        {
            s_aborate_cnt = 0;
        }
        if (s_time_cnt > 60000)
        {
            s_time_cnt = 0;
        }

    case ProcessIndex::STEP0:
    {
    }
    break;
    // 首先检查是否需要乘梯
    case ProcessIndex::STEP1:
    {
        need_lift_ = false; // 复位是否需要乘梯标志
        p_shard_data_->lift_nav_status_.goal_status = NavStatus::NAV_IDLE;
        p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
        // 复位乘梯相关错误码
        p_shard_data_->fault_code_.B0418 = false; // 无法找到乘梯点
        p_shard_data_->fault_code_.B0416 = false; // 不能找到楼层号
        p_shard_data_->fault_code_.B0605 = false; // 目标楼层与乘梯的楼层不一致
        p_shard_data_->fault_code_.B0490 = false; // 未查询到当前地图楼层号
        p_shard_data_->fault_code_.B0491 = false; // 未查询到目标地图楼层号
        p_shard_data_->fault_code_.B0492 = false; // 未查询到device内容
        p_shard_data_->fault_code_.B0493 = false; // 查询到device内容不是json格式
        p_shard_data_->fault_code_.B0494 = false; // 查询到device内容不是json的数组格式
        p_shard_data_->fault_code_.B0495 = false; // 没有找到当前楼层和目标楼层与之对应的乘梯点
        p_shard_data_->fault_code_.B0496 = false; // 需要乘梯，无法找到当前地图的乘梯点
        p_shard_data_->fault_code_.B0497 = false; // 需要乘梯，无法找到目标地图的乘梯点

        // 获取当前地图
        string current_map = p_shard_data_->GetCurrentMap();
        // 判断是否在同一张地图上，从而是否需要乘梯
        if (current_map != goal_point_.map)
        {
            LOG(INFO) << "access_lift_shared STEP1:需要乘梯现在的地图名称为：" << current_map << "目标的地图名称为：" << goal_point_.map;
            need_lift_ = true;

            std::string current_floor_liftname = "";
            std::string goal_floor_liftname = "";

            std::string current_floor = "";
            size_t current_second_pos = current_map.find('_', current_map.find('_') + 1);
            size_t current_third_pos = current_map.find('_', current_second_pos + 1);
            if (current_second_pos != std::string::npos && current_third_pos != std::string::npos && current_second_pos < current_third_pos)
            {
                // 提取第二个'_'和第三个'_'之间的字符串
                current_floor = current_map.substr(current_second_pos + 1, current_third_pos - current_second_pos - 2);
            }
            else
            {
                p_shard_data_->fault_code_.B0490 = true; // 未查询到当前地图楼层号
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                process_index_ = ProcessIndex::STEP0;
                LOG(INFO) << "access_lift_shared STEP1:未查询到当前地图楼层号";
                thread_pause_flag_ = true;
                break;
            }

            std::string goal_floor = "";
            size_t goal_second_pos = goal_point_.map.find('_', goal_point_.map.find('_') + 1);
            size_t goal_third_pos = goal_point_.map.find('_', goal_second_pos + 1);
            if (goal_second_pos != std::string::npos && goal_third_pos != std::string::npos && goal_second_pos < goal_third_pos)
            {
                // 提取第二个'_'和第三个'_'之间的字符串
                goal_floor = goal_point_.map.substr(goal_second_pos + 1, goal_third_pos - goal_second_pos - 2);
            }
            else
            {
                p_shard_data_->fault_code_.B0491 = true; // 未查询到目标地图楼层号
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                process_index_ = ProcessIndex::STEP0;
                LOG(INFO) << "access_lift_shared STEP1:未查询到目标地图楼层号";
                thread_pause_flag_ = true;
                break;
            }
            LOG(INFO) << "access_lift_shared STEP1:提取到的当前楼层号: " << current_floor << " 与目标楼层号: " << goal_floor;

            robot_msgs::Database_data srv;
            srv.request.request_type = 4;
            srv.request.request_data = "device";
            if(!srv_database_.waitForExistence(ros::Duration(10)))
            {
                LOG(ERROR) << "database_operate died";
            }  
            if (srv_database_.call(srv))
            {
                if (srv.response.response_type == 0)
                {
                    p_shard_data_->fault_code_.B0492 = true; // 未查询到device内容
                    p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                    process_index_ = ProcessIndex::STEP0;
                    LOG(INFO) << "access_lift_shared STEP1:未查询到device内容";
                    thread_pause_flag_ = true;
                    break;
                }

                Json::Value v;
                if (IsJson(srv.response.response_data, v))
                {
                    LOG(INFO) << "access_lift_shared STEP1:Device IsJson";
                }
                else
                {
                    p_shard_data_->fault_code_.B0493 = true; // 查询到device内容不是json格式
                    p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                    process_index_ = ProcessIndex::STEP0;
                    LOG(INFO) << "access_lift_shared STEP1:RequestElevatorIOTable device not json";
                    thread_pause_flag_ = true;
                    break;
                }

                if (!v["device"].isArray())
                {
                    p_shard_data_->fault_code_.B0494 = true; // 查询到device内容不是json的数组格式
                    p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                    process_index_ = ProcessIndex::STEP0;
                    LOG(INFO) << "access_lift_shared STEP1:RequestElevatorIOTable device not array";
                    thread_pause_flag_ = true;
                    break;
                }

                Json::Value v1 = v["device"];
                for (auto &s : v1)
                {
                    if (std::stoi(s["floor"].asString()) == std::stoi(current_floor) && std::stod(s["elevator_height"].asString()) != 0)
                    {
                        current_floor_liftname = s["point"].asString();
                        LOG(INFO) << "access_lift_shared STEP1:找到当前楼层的乘梯点: " << current_floor_liftname;
                        unsigned int device_address = std::stoi(s["device_address"].asString().substr(2, 2), nullptr, 16);
                        unsigned int device_channel = std::stoi(s["device_channel"].asString().substr(2, 2), nullptr, 16);
                        for (auto &s : v1)
                        {
                            if (std::stoi(s["floor"].asString()) == std::stoi(goal_floor) &&
                                std::stod(s["elevator_height"].asString()) != 0 &&
                                std::stoi(s["device_address"].asString().substr(2, 2), nullptr, 16) == device_address &&
                                std::stoi(s["device_channel"].asString().substr(2, 2), nullptr, 16) == device_channel)
                            {
                                goal_floor_liftname = s["point"].asString();
                                LOG(INFO) << "access_lift_shared STEP1:找到目标楼层的乘梯点: " << goal_floor_liftname;
                                break;
                            }
                        }
                    }
                    if (current_floor_liftname != "" && goal_floor_liftname != "")
                    {
                        LOG(INFO) << "access_lift_shared STEP1:率先提取到的当前楼层乘梯点: " << current_floor_liftname << " 与目标楼层乘梯点: " << goal_floor_liftname;
                        break;
                    }
                }

                if (!(current_floor_liftname != "" && goal_floor_liftname != ""))
                {
                    p_shard_data_->fault_code_.B0495 = true; // 没有找到当前楼层和目标楼层与之对应的乘梯点
                    p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                    process_index_ = ProcessIndex::STEP0;
                    LOG(INFO) << "access_lift_shared STEP1:没有找到当前楼层和目标楼层与之对应的乘梯点";
                    thread_pause_flag_ = true;
                    break;
                }
            }

            // 拿到当前地图的乘梯点
            FaultCode ret = p_shard_data_->GetLiftPoint(current_map, current_floor_liftname, currentMap_lift_point_);
            if (ret != FaultCode::TRUE)
            {
                // 无法获取当前地图乘梯点，请检查是否设置乘梯点，报错
                process_index_ = ProcessIndex::STEP0;
                p_shard_data_->fault_code_.B0496 = true; // 需要乘梯，无法找到当前地图的乘梯点
                LOG(ERROR) << "access_lift_shared STEP1:需要乘梯，无法找到当前地图的乘梯点,当前地图名称为：" << current_map;
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                thread_pause_flag_ = true;
                break;
            }
            else
            {
                p_shard_data_->fault_code_.B0496 = false;
                LOG(INFO) << "access_lift_shared STEP1:需要乘梯，找到了当前地图的乘梯点：" << currentMap_lift_point_.x << "," << currentMap_lift_point_.y << "," << currentMap_lift_point_.yaw;
                // 20250905 c_add 添加新乘梯点打点方式后读取乘梯点
                if (new_method_lift_)
                {
                    currentMap_lift_point_.x += new_method_lift_distance_ * std::cos(currentMap_lift_point_.yaw);
                    currentMap_lift_point_.y += new_method_lift_distance_ * std::sin(currentMap_lift_point_.yaw);
                    currentMap_lift_point_.yaw = YawNormalize(currentMap_lift_point_.yaw + M_PI);
                    LOG(INFO) << "access_lift_shared STEP1:需要乘梯，新乘梯点打点方式找到了当前地图的乘梯点：" << currentMap_lift_point_.x << "," << currentMap_lift_point_.y << "," << currentMap_lift_point_.yaw;
                }
            }

            // 拿到目标地图的乘梯点
            FaultCode ret2 = p_shard_data_->GetLiftPoint(goal_point_.map, goal_floor_liftname, goalMap_lift_point_);
            if (ret2 != FaultCode::TRUE)
            {
                // 无法获取目标地图乘梯点，请检查是否设置乘梯点，报错
                process_index_ = ProcessIndex::STEP0;
                p_shard_data_->fault_code_.B0497 = true; // 需要乘梯，无法找到目标地图的乘梯点
                LOG(ERROR) << "access_lift_shared STEP1:需要乘梯，无法找到目标地图的乘梯点,目标地图名称为：" << goal_point_.map;
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                thread_pause_flag_ = true;
                break;
            }
            else
            {
                process_index_ = ProcessIndex::STEP2;
                p_shard_data_->fault_code_.B0497 = false;
                LOG(INFO) << "access_lift_shared STEP1:需要乘梯，找到了目标地图的乘梯点：" << goalMap_lift_point_.x << "," << goalMap_lift_point_.y << "," << goalMap_lift_point_.yaw;
                // 20250905 c_add 添加新乘梯点打点方式后读取乘梯点
                if (new_method_lift_)
                {
                    goalMap_lift_point_.x += new_method_lift_distance_ * std::cos(goalMap_lift_point_.yaw);
                    goalMap_lift_point_.y += new_method_lift_distance_ * std::sin(goalMap_lift_point_.yaw);
                    goalMap_lift_point_.yaw = YawNormalize(goalMap_lift_point_.yaw + M_PI);
                    LOG(INFO) << "access_lift_shared STEP1:需要乘梯，新乘梯点打点方式找到了目标地图的乘梯点：" << goalMap_lift_point_.x << "," << goalMap_lift_point_.y << "," << goalMap_lift_point_.yaw;
                }
            }
        }
        else
        {
            need_lift_ = false;
            process_index_ = ProcessIndex::STEP2;
            LOG(INFO) << "access_lift_shared STEP1:首先判断到不需要乘梯，然后转到STEP2检查是否需要过门禁闸机";
        }
    }
    break;
    // // 检查是否通过门禁
    // case ProcessIndex::STEP2:
    // {
    //     p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
    //     PoseData pinfo;
    //     std::vector<PoseData> access_points;
    //     string current_map = p_shard_data_->GetCurrentMap();
    //     // 通过判断是否有门禁闸机点来判断是否需要通过门禁闸机
    //     // int ret = p_shard_data_->GetAccessPoint(current_map, pinfo);
    //     int ret = p_shard_data_->GetAccessPoint(current_map, access_points);
    //     for (size_t i = 0; i < access_points.size(); i++)
    //     {
    //         LOG(INFO) << "access_lift_shared STEP2:有门禁点: " << access_points[i].point_name;
    //     }
        
    //     if (need_lift_)
    //     { // 需要乘梯
    //         // 1.请求门禁闸机类
    //         // 2.等待门禁闸机状态
    //         // 3.请求乘梯类
    //         // 4.等待乘梯状态
    //         // 5.请求门禁闸机类
    //         // 6.等待门禁闸机状态
    //         // 判断当前地图是否有闸机
    //         if (ret == FaultCode::TRUE)
    //         { // 有闸机点，则进行闸机点
    //             // 通过共享数据来进行传递
    //             // 调用闸机服务来处理
    //             SendtoAccessAction(pinfo.x, pinfo.y, pinfo.yaw,
    //                                p_shard_data_->current_pose_.x, p_shard_data_->current_pose_.y, currentMap_lift_point_.x, currentMap_lift_point_.y);
    //             process_index_ = ProcessIndex::STEP3;
    //             LOG(INFO) << "access_lift_shared 有门禁点,需要乘梯，需要通过闸机";
    //         }
    //         else
    //         { // 没有闸机点，直接导航去乘梯点
    //             process_index_ = ProcessIndex::STEP9;
    //             LOG(INFO) << "access_lift_shared 没有门禁点,需要乘梯，不需要通过闸机";
    //         }

    //         //                PoseData pd;
    //         //                pd.map=currentMap_lift_point_.map;
    //         //                pd.type=currentMap_lift_point_.type;
    //         //                pd.x = currentMap_lift_point_.x;
    //         //                pd.yaw = currentMap_lift_point_.yaw;
    //         //                QVariant qvr;
    //         //                qvr.setValue(pd);
    //         //                emit signal_AccessCmd(qvr);//请求门禁槽
    //         //
    //         //                process_index_ = ProcessIndex::STEP3;
    //     }
    //     else
    //     { // 不需要乘梯
    //         // 1.请求门禁闸机类
    //         // 2.等待门禁闸机状态
    //         if (ret == FaultCode::TRUE)
    //         { // 有闸机点，则进行闸机点
    //             // 通过共享数据来进行传递
    //             // 调用闸机服务来处理
    //             SendtoAccessAction(pinfo.x, pinfo.y, pinfo.yaw,
    //                                p_shard_data_->current_pose_.x, p_shard_data_->current_pose_.y, goal_point_.x, goal_point_.y);
    //             process_index_ = ProcessIndex::STEP3;
    //             LOG(INFO) << "access_lift_shared 有门禁点,不需要乘梯，需要通过闸机";
    //         }
    //         else
    //         {
    //             p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
    //             LOG(INFO) << "access_lift_shared 没有门禁点,不需要乘梯，不需要通过闸机";
    //             process_index_ = ProcessIndex::STEP0;
    //             thread_pause_flag_ = true; // 停止该线程
    //         }
    //         //                PoseData pd;
    //         //                pd.map=goal_point_.map;
    //         //                pd.type=goal_point_.type;
    //         //                pd.x = goal_point_.x;
    //         //                pd.yaw = goal_point_.yaw;
    //         //                QVariant qvr;
    //         //                qvr.setValue(pd);
    //         //                emit signal_AccessCmd(qvr);//请求门禁槽
    //         //                process_index_ = ProcessIndex::STEP3;
    //     }

    //     // to lift action 两个参数 ，成梯点，目标楼层
    //     // 获取目标楼层
    //     //            std::string floor_number = "0F";
    //     //            p_shard_data_->GetFloorNumber(p_shard_data_->default_map_,floor_number);
    //     //            SendtoLiftAction(currentMap_lift_point_.x,currentMap_lift_point_.y,currentMap_lift_point_.yaw,floor_number);
    //     //            process_index_ = ProcessIndex::STEP3;
    // }
    // break;
    // 检查是否通过门禁闸机
    case ProcessIndex::STEP2:
    {
        p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;

        if (need_lift_)
        { // 需要乘梯
            // 1.请求门禁闸机类
            // 2.等待门禁闸机状态
            // 3.请求乘梯类
            // 4.等待乘梯状态
            // 5.请求门禁闸机类
            // 6.等待门禁闸机状态
            SendtoAccessAction(p_shard_data_->current_pose_.x, p_shard_data_->current_pose_.y, currentMap_lift_point_.x, currentMap_lift_point_.y);
            process_index_ = ProcessIndex::STEP3;
            LOG(INFO) << "access_lift_shared STEP2:需要乘梯，首先调用门禁闸机功能";
        }
        else
        { // 不需要乘梯
            // 1.请求门禁闸机类
            // 2.等待门禁闸机状态
            SendtoAccessAction(p_shard_data_->current_pose_.x, p_shard_data_->current_pose_.y, goal_point_.x, goal_point_.y);
            process_index_ = ProcessIndex::STEP3;
            LOG(INFO) << "access_lift_shared STEP2:不需要乘梯，直接调用门禁闸机功能";
        }
    }
    break;
    // 等待门禁闸机状态
    case ProcessIndex::STEP3:
    {
        if (p_shard_data_->access_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        {
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
            if (need_lift_)
            {
                process_index_ = ProcessIndex::STEP9;
                LOG(INFO) << "access_lift_shared STEP3:通过门禁闸机成功,需要乘梯,去当前地图乘梯点进行乘梯";
            }
            else
            {
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
                LOG(INFO) << "access_lift_shared STEP3:通过门禁闸机成功,不需要乘梯,继续执行后续任务";
                process_index_ = ProcessIndex::STEP0;
                thread_pause_flag_ = true;
            }
        }
        else if (p_shard_data_->access_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        {
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_ABORTED;
            process_index_ = ProcessIndex::STEP0;
            LOG(ERROR) << "access_lift_shared STEP3:通过门禁闸机中止";
            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->access_nav_status_.goal_status == NavStatus::NAV_FAILED)
        {
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
            process_index_ = ProcessIndex::STEP0;
            LOG(ERROR) << "access_lift_shared STEP3:通过门禁闸机失败";
            thread_pause_flag_ = true;
        }
    }
    break;
    case ProcessIndex::STEP4:
    {
        if (p_shard_data_->current_lift_state_flag_)
        {
            LOG(INFO) << "access_lift_shared STEP4:此时准备进入乘梯状态";
            p_shard_data_->current_lift_state_flag_ = false;
            p_shard_data_->current_lift_state_ = true;
        }

        emit signal_PubStatus("GOTO_liftpoint_success");
        // 获取目标楼层的地图号
        std::string floor_number = "0F";
        FaultCode get_floor = p_shard_data_->GetFloorNumber(goal_point_.map, floor_number);
        if (get_floor == FaultCode::TRUE)
        {
            SendtoLiftAction(goalMap_lift_point_.x, goalMap_lift_point_.y, goalMap_lift_point_.yaw, floor_number);
            process_index_ = ProcessIndex::STEP5;
            p_shard_data_->fault_code_.B0416 = false;
            LOG(INFO) << "access_lift_shared STEP4:成功获取目标楼层，请求乘梯,目标楼层为：" << goal_point_.map;
            pre_costmapupdatedata_ = globalcostmapupdatedata_;
        }
        else
        {
            LOG(INFO) << "access_lift_shared STEP4:获取目标楼层失败，目标楼层为：" << goalMap_lift_point_.map;
            process_index_ = ProcessIndex::STEP0;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
            p_shard_data_->fault_code_.B0416 = true;
            p_shard_data_->current_lift_state_ = false;
            thread_pause_flag_ = true;
        }
    }
    // 等待乘梯状态
    case ProcessIndex::STEP5:
    {
        if (p_shard_data_->lift_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        {
            p_shard_data_->lift_nav_status_.goal_status = NavStatus::NAV_IDLE;
            process_index_ = ProcessIndex::STEP6;
            LOG(INFO) << "access_lift_shared STEP5:乘梯完成";
            p_shard_data_->current_lift_state_ = false;
            first_flag_ = false;
        }
        else if (p_shard_data_->lift_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        {
            p_shard_data_->lift_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_ABORTED;
            process_index_ = ProcessIndex::STEP0;
            LOG(ERROR) << "access_lift_shared STEP5:乘梯中止";
            p_shard_data_->current_lift_state_ = false;
            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->lift_nav_status_.goal_status == NavStatus::NAV_FAILED)
        {
            p_shard_data_->lift_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
            process_index_ = ProcessIndex::STEP0;
            LOG(ERROR) << "access_lift_shared STEP5:乘梯失败";
            p_shard_data_->current_lift_state_ = false;
            thread_pause_flag_ = true;
        }
    }
    break;
    // 乘梯后检查是否通过门禁闸机
    case ProcessIndex::STEP6:
    {
        static int s_current_map = 0;
        s_current_map++;
        string current_map = p_shard_data_->GetCurrentMap();
        if (current_map == goal_point_.map)
        {
            // 20250716 c_add 添加乘梯成功后，检查是否代价地图切换完成
            if (!first_flag_)
            {
                pre_stamp_ = ros::Time::now();
                first_flag_ = true;
            }
            if ((pre_costmapupdatedata_.x != globalcostmapupdatedata_.x || 
                 pre_costmapupdatedata_.y != globalcostmapupdatedata_.y || 
                 (globalcostmapupdatedata_.stamp - pre_stamp_).toSec() > 5.0) && 
                (pre_costmapupdatedata_.x != onlystaticcostmapupdatedata_.x || 
                 pre_costmapupdatedata_.y != onlystaticcostmapupdatedata_.y || 
                 (onlystaticcostmapupdatedata_.stamp - pre_stamp_).toSec() > 5.0))
            {
                process_index_ = ProcessIndex::STEP7;
                LOG(INFO) << "access_lift_shared STEP6:乘梯成功，楼层一致";
                s_current_map = 0;
                p_shard_data_->fault_code_.B0605 = false;
                first_flag_ = false;
            }
        }
        else
        {
            // 100*100ms=10s
            if (s_current_map > 100)
            { 
                s_current_map = 0;
                process_index_ = ProcessIndex::STEP0;
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
                p_shard_data_->fault_code_.B0605 = true;
                LOG(ERROR) << "access_lift_shared STEP6:乘梯成功，但与目标楼层不一致";
                first_flag_ = false;
                thread_pause_flag_ = true;
            }
        }
    }
    break;
    // // 乘梯后检查是否通过门禁
    // case ProcessIndex::STEP7:
    // {
    //     p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
    //     PoseData pinfo;
    //     std::vector<PoseData> access_points;
    //     string current_map = p_shard_data_->GetCurrentMap();
    //     // 通过判断是否有闸机点来判断是否需要通过闸机
    //     // int ret = p_shard_data_->GetAccessPoint(goal_point_.map, pinfo);
    //     int ret = p_shard_data_->GetAccessPoint(goal_point_.map, access_points);
    //     for (size_t i = 0; i < access_points.size(); i++)
    //     {
    //         LOG(INFO) << "access_lift_shared STEP2:有门禁点: " << access_points[i].point_name;
    //     }
        
    //     // 1.请求门禁类
    //     if (ret == FaultCode::TRUE)
    //     { // 有闸机点，则进行闸机点
    //         // 通过共享数据来进行传递
    //         // 调用闸机服务来处理
    //         SendtoAccessAction(pinfo.x, pinfo.y, pinfo.yaw,
    //                            p_shard_data_->current_pose_.x, p_shard_data_->current_pose_.y, goal_point_.x, goal_point_.y);
    //         process_index_ = ProcessIndex::STEP8;
    //         LOG(INFO) << "access_lift_shared 有门禁点，需要通过闸机";
    //     }
    //     else
    //     {
    //         p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
    //         LOG(INFO) << "access_lift_shared 没有门禁点,不需要通过闸机";
    //         process_index_ = ProcessIndex::STEP0;
    //         thread_pause_flag_ = true; // 停止该线程
    //     }
    // }
    // break;
    // 乘梯后检查是否通过门禁闸机
    case ProcessIndex::STEP7:
    {
        p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;

        SendtoAccessAction(p_shard_data_->current_pose_.x, p_shard_data_->current_pose_.y, goal_point_.x, goal_point_.y);
        process_index_ = ProcessIndex::STEP8;
        LOG(INFO) << "access_lift_shared STEP7:乘梯后，直接调用门禁闸机功能";
    }
    break;
    // 等待门禁闸机状态
    case ProcessIndex::STEP8:
    {
        if (p_shard_data_->access_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        {
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_SUCCESS;
            LOG(INFO) << "access_lift_shared STEP8:通过门禁闸机成功,继续执行后续任务";
            process_index_ = ProcessIndex::STEP0;
            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->access_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        {
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_ABORTED;
            process_index_ = ProcessIndex::STEP0;
            LOG(ERROR) << "access_lift_shared STEP8:通过门禁闸机中止";
            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->access_nav_status_.goal_status == NavStatus::NAV_FAILED)
        {
            p_shard_data_->access_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
            process_index_ = ProcessIndex::STEP0;
            LOG(ERROR) << "access_lift_shared STEP8:通过门禁闸机失败";
            thread_pause_flag_ = true;
        }
    }
    break;
    // 去当前地图的乘梯点
    case ProcessIndex::STEP9:
    {
        s_aborate_cnt = 0;
        s_time_cnt = 0;
        // 移动到乘梯点
        MoveDataCmd mdc;
        mdc.taskcmd_type = TaskStatus::T_LOCALE;
        PoseData pose;
        pose.x = currentMap_lift_point_.x;
        pose.y = currentMap_lift_point_.y;
        pose.yaw = currentMap_lift_point_.yaw;
        pose.type = GlobalPlannerType::NORMAL;
        mdc.goal.push_back(pose);
        QVariant qvr;
        // 此处状态切换为乘梯状态
        emit signal_PubStatus("GOTO_liftpoint");
        {
            lift_pose_.x = currentMap_lift_point_.x;
            lift_pose_.y = currentMap_lift_point_.y;
            lift_pose_.yaw = currentMap_lift_point_.yaw;
        }
        qvr.setValue(mdc);
        emit signal_MoveCmd(qvr);
        process_index_ = ProcessIndex::STEP10;
        LOG(INFO) << "access_lift_shared STEP9:开始去当前地图的乘梯点，坐标为：" << currentMap_lift_point_.x << "," << currentMap_lift_point_.y << "," << currentMap_lift_point_.yaw;
    }
    break;
    case ProcessIndex::STEP10:
    {
        if (p_shard_data_->move_status_ == MoveStatus::ARRIVE)
        {
            // 计算现在与目标点的位姿之差
            p_shard_data_->target_distance_ = std::sqrt(std::pow(lift_pose_.x - p_shard_data_->current_pose_.x, 2) + std::pow(lift_pose_.y - p_shard_data_->current_pose_.y, 2));
            if (p_shard_data_->target_distance_ <= 0.28)
            {
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                LOG(INFO) << "access_lift_shared STEP10:到达乘梯点成功";
                emit signal_PubStatus("GOTO_liftpoint_success");
                if(p_shard_data_->curr_lift_point_type_=="back"){
                    emit signal_PubStatus("GOTO_back");
                }else{
                    emit signal_PubStatus("GOTO_"+p_shard_data_->curr_lift_point_name_);
                }
                //emit signal_PubStatus(p_shard_data_->now_nav_status_);
                process_index_ = ProcessIndex::STEP4;
                s_aborate_cnt = 0;
                s_time_cnt = 0;
            }
            // 导航到达了，但精度不够
            if (p_shard_data_->target_distance_ < 2.12 && p_shard_data_->target_distance_ > 0.28)
            {
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                LOG(INFO) << "access_lift_shared STEP10:底盘到达乘梯点,精度不满足要求,进入精细导航: x: " << std::abs(lift_pose_.x - p_shard_data_->current_pose_.x) << " y: " << std::abs(lift_pose_.y - p_shard_data_->current_pose_.y);

                MoveDataCmd mdc;
                PoseData pose;
                pose.x = lift_pose_.x;
                pose.y = lift_pose_.y;
                pose.yaw = lift_pose_.yaw;
                pose.type = GlobalPlannerType::NORMAL;
                mdc.goal.push_back(pose);
                QVariant qvr;
                qvr.setValue(mdc);
                emit signal_AccurateControl(qvr);
                process_index_ = ProcessIndex::STEP12;
            }
            // 导航到达了，但精度差距很大
            if (p_shard_data_->target_distance_ >= 2.12)
            {
                LOG(INFO) << "access_lift_shared STEP10:底盘到达乘梯点,且离乘梯点过远,重发乘梯点: x: " << std::abs(lift_pose_.x - p_shard_data_->current_pose_.x) << " y: " << std::abs(lift_pose_.y - p_shard_data_->current_pose_.y);
                p_shard_data_->move_status_ = MoveStatus::ABORTED;
            }
        }
        else if (p_shard_data_->move_status_ == MoveStatus::ABORTED)
        {
            // 重置move_action导航状态
            p_shard_data_->move_status_ = MoveStatus::IDLE;
            if (s_aborate_cnt >= p_shard_data_->nav_resend_time_)
            {
                s_time_cnt = 0;
                s_aborate_cnt = 0;
                p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_ABORTED;
                LOG(INFO) << "access_lift_shared STEP10:move_action导航到乘梯点导航失败第 " << s_aborate_cnt << " 次，无法导航成功，中止导航";
                process_index_ = ProcessIndex::STEP0;
                emit signal_PubStatus("GOTO_liftpoint_failed");
                thread_pause_flag_ = true;
            }
            else
            {
                s_aborate_cnt++;
                process_index_ = ProcessIndex::STEP11;
                // 20250728 c_add 处理导航失败的策略，先清空障碍层，延时重新发点
                std_srvs::Empty srv;
                LOG(INFO) << "access_lift_shared STEP10:move_action导航到乘梯点导航失败第 " << s_aborate_cnt << " 次，重新发送目标点";
                if(!clear_costmap_client_.waitForExistence(ros::Duration(10)))
                {
                    LOG(ERROR) << "access_lift_shared clear_costmap died";
                }   
                clear_costmap_client_.call(srv);
                s_time_cnt = 0;
            }
        }
    }
    break;
    case ProcessIndex::STEP11:
    {
        s_time_cnt++;
        // 等待50*100ms=5s重新规划一次
        if (s_time_cnt % 50 == 0)
        {
            if (car_type_ == "DR-01")
            {
                PublishVoice("EncounterPerdestrian");
            }
            else
            {
                // PublishVoice("NoPass");
            }
            // 重新发送目标点
            process_index_ = ProcessIndex::STEP9;
            LOG(INFO) << "access_lift_shared STEP11:move_action导航到乘梯点导航失败，清空代价地图后，重新发送目标点";
        }
    }
    break;
    case ProcessIndex::STEP12:
    {
        if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            process_index_ = ProcessIndex::STEP4;
            LOG(INFO) << "access_lift_shared STEP12:乘梯点精确控制成功";
        }
        else if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_ABORTED;
            process_index_ = ProcessIndex::STEP0;
            LOG(INFO) << "access_lift_shared STEP12:乘梯点精确控制中止";
            thread_pause_flag_ = true;
        }
        else if (p_shard_data_->accurate_control_nav_status_.goal_status == NavStatus::NAV_FAILED)
        {
            p_shard_data_->accurate_control_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->access_lift_shared_nav_status_.goal_status = NavStatus::NAV_FAILED;
            process_index_ = ProcessIndex::STEP0;
            LOG(INFO) << "access_lift_shared STEP12:乘梯点精确控制失败";
            thread_pause_flag_ = true;
        }
    }
    break;
    default:
        break;
    }
}
