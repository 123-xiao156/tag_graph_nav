/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	shard_data.cpp
 * * @description:  门禁、乘梯、覆盖，乘梯动作
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "shard_data.h"

ShardData::ShardData() : tf_listener_(tf_buffer_)
{
    nh_.param<bool>("debug", debug_, true);
    nh_.param<int>("nav_resend_time", nav_resend_time_, 50);
    nh_.param<std::string>("database", new_of_old_database_, "old");

    //sub_robot_pose_ = nh_.subscribe<geometry_msgs::Pose>("/robot_pose", 10, &ShardData::callback_RobotPosepose, this);
    sub_laser_ = nh_.subscribe("/camera_to_scan", 10, &ShardData::callback_RobotLaser, this);
    // 获取激光雷达到机器人坐标系的变换
    ros::Rate rate(1.0);
	while (nh_.ok())
	{
    	try{
			T_laser2base_ = tf_buffer_.lookupTransform("base_link", "laser_link",
                               ros::Time(0),ros::Duration(1.0));
                               break;
    		}
    	catch (tf2::TransformException &ex) {
      		//ROS_WARN("%s",ex.what());
      		ros::Duration(1.0).sleep();
      		continue;
    		}
		rate.sleep();
	}

    timer_ = new QTimer(this);
    connect(timer_, SIGNAL(timeout()), this, SLOT(Run()));
    timer_->start(50);

    LOG(INFO) << "shard_data 读到了参数 debug:" << debug_ << " ,nav_resend_time_: " << nav_resend_time_ << " ,new_of_old_database_: " << new_of_old_database_;
}

// 循环订阅
void ShardData::Run(){
    try{
			T_base2map_ = tf_buffer_.lookupTransform("map", "base_link",
                               ros::Time::now(),ros::Duration(2.0));
            current_pose_.x = T_base2map_.transform.translation.x;
            current_pose_.y = T_base2map_.transform.translation.y;
            // 提取旋转（四元数转欧拉角）
            tf2::Quaternion q(
                T_base2map_.transform.rotation.x,
                T_base2map_.transform.rotation.y,
                T_base2map_.transform.rotation.z,
                T_base2map_.transform.rotation.w
            );
            tf2::Matrix3x3 m(q);
            double roll, pitch,yaw;
            m.getRPY(roll, pitch, yaw);           
            current_pose_.yaw=yaw;    
            nav_progress_.current_pose=  current_pose_; 
        }
    catch (tf2::TransformException &ex) {
        //ROS_WARN("%s",ex.what());
        ros::Duration(1.0).sleep();
        }
    ros::spinOnce();
}
/**********************************************************************
 * * @function:    callback_RobotPosepose 
 * * @brief:       机器人位置回调函数，接收并处理机器人位姿数据
 * * @input:       msg: 机器人位姿消息
 * * @output:      更新当前机器人位姿信息
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void ShardData::callback_RobotPosepose(const geometry_msgs::Pose msg)
{
    if (!isnan(msg.position.x) && !isnan(msg.position.y) &&
        !isnan(msg.orientation.w) && !isnan(msg.orientation.z))
    {
        current_pose_.x = msg.position.x;
        current_pose_.y = msg.position.y;
        current_pose_.yaw = tf::getYaw(msg.orientation);
    }
}
/**********************************************************************
 * * @function:    callback_RobotLaser 
 * * @brief:       机器人激光雷达回调函数，处理激光扫描数据
 * * @input:       msg: 激光雷达扫描数据
 * * @output:      计算最近障碍物距离
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void ShardData::callback_RobotLaser(const sensor_msgs::LaserScan::ConstPtr &msg)
{
    if (!msg)
    {
        // 检查消息指针是否为空
        closest_obstacle_distance_ = 1000.0;
        return;
    }

    // 遍历激光数据并转换到 base_link
    std::vector<float> valid_ranges;
    for (size_t i = 0; i < msg->ranges.size(); ++i)
    {
        float range = msg->ranges[i];
        if (!std::isnan(range) && !std::isinf(range))
        {
            // 激光角度
            float angle = msg->angle_min + i * msg->angle_increment;

            // 在 laser_link 中计算点位置
            geometry_msgs::PointStamped laser_point, base_point;
            laser_point.header.stamp = msg->header.stamp;  // 时间同步
            laser_point.header.frame_id = "laser_link";    // 激光雷达坐标系
            laser_point.point.x = range * cos(angle);
            laser_point.point.y = range * sin(angle);
            laser_point.point.z = 0.0;

            // 转换到 base_link
            try
            {
                tf2::doTransform(laser_point, base_point, T_laser2base_);

                // 计算点到原点的距离
                float transformed_range = hypot(base_point.point.x, base_point.point.y);
                valid_ranges.push_back(transformed_range);
            }
            catch (tf2::TransformException &ex)
            {
                //ROS_WARN_THROTTLE(1.0, "Transform failed: %s", ex.what());
                closest_obstacle_distance_ = 1000.0;
                return;
            }
        }
    }

    if (valid_ranges.empty())
    {
        // 检查有效范围是否为空
        closest_obstacle_distance_ = 1000.0;
        return;
    }

    closest_obstacle_distance_ = *std::min_element(valid_ranges.begin(), valid_ranges.end());
}
