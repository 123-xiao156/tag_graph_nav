/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	cover_action.cpp
 * * @description:  门禁、乘梯、覆盖
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "cover_action.h"

CoverAction::~CoverAction()
{
    thread_pause_flag_=true;
    ros::shutdown();
}
CoverAction::CoverAction(ros::NodeHandle nh):nh_(nh)
{
    Init();
}
void CoverAction::Init()
{

    interval_ms_ = 50;
    nh_.param("DWAPlannerROS/max_vel_x", max_linear_velocity_, 0.4);
    //nh_.param("DWAPlannerROS/max_vel_theta", max_angular_velocity_, 0.5);
    //nh_.param("DWAPlannerROS/min_vel_x", min_linear_velocity_, 0.01);
    //nh_.param("DWAPlannerROS/min_vel_theta", min_angular_velocity_, 0.1);
    nh_.param("DWAPlannerROS/acc_lim_theta", max_acc_angular_, 2.0);
    nh_.param("DWAPlannerROS/acc_lim_x", max_acc_linear_, 0.4);    
    nh_.param("footprint_threshold", footprint_threshold_, 0.15);
    nh_.param("robot_radius", robot_radius_, 0.4);
    nh_.param("forward_distance", forward_distance_, 0.3);
    nh_.param<int>("obstacle_avoidave_method", obstacle_avoidave_method_, 1);//0:避停；1：避让    
    nh_.param<bool>("use_camera", use_camera_, true); 
    int nav_;
    nh_.param<int>("nav_version", nav_, 1); //#1move_base导航，2nav_base导航
    min_angular_velocity_=0.0; 
    footprint_radius_ = robot_radius_ + footprint_threshold_;
    max_linear_velocity_/=1.4;//覆盖区域减速处理，比导航速度略慢，0.6---0.42
    min_linear_velocity_=0.0;
    max_acc_linear_/=1.4;
    max_angular_velocity_=0.5;
    //std::cout<<" ------------------------------------------testparam"<<max_linear_velocity_<<" "<<min_linear_velocity_<<" "<<max_angular_velocity_<<" "<<min_angular_velocity_<<" "<<max_acc_angular_<<" "<<robot_radius_ <<std::endl;
    assist_point_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/assist_point", 1);
    pub_line_=nh_.advertise<visualization_msgs::Marker>("/ref_line", 1);
    cover_pub_ = nh_.advertise<nav_msgs::Path>("/cover_path", 1);
    if(use_camera_) scan_sub_ = nh_.subscribe("/scan", 1, &CoverAction::ScanCallback, this); 
    else scan_sub_ = nh_.subscribe("/camera_to_scan", 1, &CoverAction::ScanCallback, this); 
    string nav_node="";
    if(nav_==1)
    {
        nav_node="/move_base";
    }
    if(nav_==2)
    {
        nav_node="/task_base";
    }
    local_costmap_sub_ = nh_.subscribe(nav_node+"/local_costmap/costmap", 1, &CoverAction::LocalCostmapCallback, this); //20241220 添加避障
    global_costmap_sub_ = nh_.subscribe(nav_node+"/global_costmap/costmap", 1, &CoverAction::GlobalCostmapCallback, this); //20241220 添加避障
    //test
    pub_costmap_=nh_.advertise<nav_msgs::OccupancyGrid>("/test_costmap", 1);
    //pub_aabb_path_=nh_.advertise<nav_msgs::Path>("/AABB_path", 1);
    pub_log_ = nh_.advertise<std_msgs::String>("/journal",10,true);
    std::thread t(&CoverAction::TimerThread,this,interval_ms_);
    t.detach();
    cb_reconfigure_ = boost::bind(&CoverAction::ReconfigureCB, this, _1, _2);
    config_server_.setCallback(cb_reconfigure_);

}
/**********************************************************************
 * * @function:    ReconfigureCB 
 * * @brief:       动态参数重配置回调函数，根据配置启用或禁用动态覆盖导航功能
 * * @input:       config: 导航控制配置参数 level: 参数变更级别
 * * @output:      初始化或释放相关的ROS发布器、订阅器和资源
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::ReconfigureCB(nav_control::NavControlConfig& config, uint32_t level)
{
  
    use_dynamic_cover_ = config.use_dynamic_cover;
    //ROS_INFO("Dynamic Config Start%d",use_dynamic_cover_);
    if(use_dynamic_cover_)
    {
        tf_.reset(new tf2_ros::Buffer());
        tfl_.reset(new tf2_ros::TransformListener(*tf_));
        assist_point_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/assist_point", 1);
        pub_line_=nh_.advertise<visualization_msgs::Marker>("/ref_line", 1);
        if(use_camera_) scan_sub_ = nh_.subscribe("/scan", 1, &CoverAction::ScanCallback, this); 
        else scan_sub_ = nh_.subscribe("/camera_to_scan", 1, &CoverAction::ScanCallback, this); 
        pub_log_ = nh_.advertise<std_msgs::String>("/journal",10,true);
       cover_pub_=nh_.advertise<nav_msgs::Path>("/cover_path",10);
       pub_nav_status_=nh_.advertise<std_msgs::String>("/nav_status",10);
       pub_nav_progress_=nh_.advertise<std_msgs::String>("/nav_progress",10);
       sub_pose_ = nh_.subscribe("/amcl_pose", 2, &CoverAction::AmclPoseCB, this);
      //sub_scan_ = nh_.subscribe<sensor_msgs::LaserScan>("/scan", 1, &CoverAction::ScanCB, this); 
      sub_scan_ = new message_filters::Subscriber<sensor_msgs::LaserScan>(nh_, "/scan", 100);
      scan_filter_ = new tf2_ros::MessageFilter<sensor_msgs::LaserScan>(*sub_scan_,
                                                             *tf_,
                                                             "map",
                                                             100,
                                                             nh_);
      scan_filter_->registerCallback(boost::bind(&CoverAction::ScanCB,this, _1));
      std::thread t_map(&CoverAction::MapThread,this, interval_s_); // 创建定时器线程
      t_map.detach();
    }
}
/**********************************************************************
 * * @function:    TimerThread 
 * * @brief:       覆盖导航定时器线程，周期性执行导航任务
 * * @input:       interval_ms: 线程执行间隔时间（毫秒）
 * * @output:      无
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::TimerThread(int16_t interval_ms)
{
    while(ros::ok()){
        if(!thread_pause_flag_){
            //work
            Execute();
        }
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
/**********************************************************************
 * * @function:    ScanCallback 
 * * @brief:       激光雷达扫描数据回调函数，处理原始激光数据并转换为点云坐标
 * * @input:       msg: 激光雷达扫描数据的常量指针
 * * @output:      更新内部点云数据
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::ScanCallback(const sensor_msgs::LaserScan::ConstPtr &msg)
{
    static bool first_scan = true;
    if (first_scan)
    {
        try
        {
            tf_listener_.waitForTransform("base_link", "laser_link", ros::Time(0), ros::Duration(3.0));
            tf_listener_.lookupTransform("base_link", "laser_link", ros::Time(0), transform_base_link_to_laser_link_);
        }
        catch (tf::TransformException &ex)
        {
            //ROS_ERROR("Failed to lookup transform: %s", ex.what());
            return;
        }
        first_scan = false;
        point_cloud_.resize(msg->ranges.size());
    }
    LaserScanToPoseList(msg, point_cloud_);
}
/**********************************************************************
 * * @function:    LocalCostmapCallback 
 * * @brief:       局部代价地图回调
 * * @input:       msg: 地图信息
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::LocalCostmapCallback(const nav_msgs::OccupancyGrid::ConstPtr &msg)
{
    //把未知也设为禁行，防止回字型障碍
    nav_msgs::OccupancyGrid costmap=*msg;
    for(size_t i=0;i< costmap.data.size();i++)
    {
        //if(costmap.data[i]==-1)
        if(costmap.data[i]!=0)
        {
           costmap.data[i]=100;     
        }
    }
    {
        std::lock_guard<std::mutex> guard(path_mutex_);
        local_costmap_.data.clear();
        local_costmap_=costmap;
        ListenTF("map", "base_link", current_pose_);
        //nav_msgs::OccupancyGrid ref_costmap=OverlayRobotOnMap(*msg,current_pose_,robot_radius_);
        pub_costmap_.publish(local_costmap_);
    }
    
    //ListenTF("map", "base_link", current_pose_);
    //nav_msgs::OccupancyGrid ref_costmap=OverlayRobotOnMap(*msg,current_pose_,robot_radius_);
    //pub_costmap_.publish(ref_costmap);
     
}
/**********************************************************************
 * * @function:    GlobalCostmapCallback 
 * * @brief:       全局代价地图回调
 * * @input:       msg: 地图信息
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::GlobalCostmapCallback(const nav_msgs::OccupancyGrid::ConstPtr &msg)
{
    //把未知也设为禁行，防止回字型障碍
    nav_msgs::OccupancyGrid costmap=*msg;
    for(size_t i=0;i< costmap.data.size();i++)
    {
        if(costmap.data[i]!=0)
        {
           costmap.data[i]=100;     
        }
    }
    {
        std::lock_guard<std::mutex> guard(path_mutex_);
        global_costmap_.data.clear();
        global_costmap_=costmap;
        //ListenTF("map", "base_link", current_pose_);
        //nav_msgs::OccupancyGrid ref_costmap=OverlayRobotOnMap(*msg,current_pose_,robot_radius_);
        //pub_costmap_.publish(global_costmap_);
    }
    
     
}
/**********************************************************************
 * * @function:    GetPlan 
 * * @brief:       获取目标点
 * * @input:       
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::GetPlan()
{
    result_makeplan_=MakePlan();
    taskCompleted_=true;
}
/**********************************************************************
 * * @function:    MakePlan 
 * * @brief:       路径规划函数，生成从当前位置到局部目标点的导航路径
 * * @input:       无
 * * @output:      更新局部路径和覆盖路径
 * * @return:      bool: 返回路径规划是否成功
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool CoverAction::MakePlan()
{
    std::lock_guard<std::mutex> guard(path_mutex_);
    //一般局部就可以规划出来
    if(MakePlan(current_pose_,local_goal_,local_costmap_,local_path_)||MakePlan(current_pose_,local_goal_,global_costmap_,local_path_))
    {
        cover_path_.poses.erase(cover_path_.poses.begin(),cover_path_.poses.begin()+floor(local_goal_.theta));
        cover_path_.poses.insert(cover_path_.poses.begin(),local_path_.poses.begin(),local_path_.poses.end()); 
        //std::cout<<"make plan success local_path_ "<<local_path_.poses.size()<<" index "<<local_goal_.theta<<std::endl;
        return true;
    }
    else
    {
        local_path_.poses.clear();
        //std::cout<<"makeplan failed... currentx="<<current_pose_.x<<"currenty="<<current_pose_.y<<"goalx="<<local_goal_.x<<"y="<<local_goal_.y<<std::endl;
        //cover_path_.poses.erase(cover_path_.poses.begin(),cover_path_.poses.begin()+1);
        return false;
    }
    return false;
}
/**
 * 检查小车与costmap障碍是否碰撞
 * 
 */
/**********************************************************************
 * * @function:    CheckCollision 
 * * @brief:       检查小车与costmap障碍是否碰撞
 * * @input:       local_costmap：局部地图,global_costmap：全局地图,path：路径
 * * @output:      
 * * @return:      bool
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool CoverAction::CheckCollision(const nav_msgs::OccupancyGrid& local_costmap,const nav_msgs::OccupancyGrid& global_costmap,nav_msgs::Path& path)
{
    bool flg_collision=false;
    //等待控制脱离碰撞,防止定位抖动导致重复进入
    //if(flg_collision_) return flg_collision_;
    {
        std::lock_guard<std::mutex> guard(path_mutex_);
        //costmap规划
        //计算机器人在costmap上的投影
        //ListenTF("map", "base_link", current_pose_);
        if((obstacle_avoidave_method_==1) && (cover_path_.poses.size()>0))
        {//遍历路径与costmap相交的点，作为goal
            std::vector<geometry_msgs::Pose2D> intersection_point;
            bool flg_intersection=CheckObstacleIntersection(cover_path_,global_costmap,intersection_point);
            if(flg_intersection && intersection_point.at(0).theta<2 ) 
            {
                flg_collision=true;
                local_path_.poses.clear();
                local_goal_=intersection_point.size()>=2?intersection_point.at(1):current_pose_;
                //std::cout << "存在障碍，交点" <<intersection_point.at(0).x<<" "<<intersection_point.at(0).y<<" index "<<intersection_point.at(0).theta<<" local_goal_ "<<
                //local_goal_.x<<" "<<local_goal_.y<< std::endl;
            }
        }
    }
    return flg_collision; 

}
/**********************************************************************
 * * @function:    IsPointInObstacle 
 * * @brief:       检查给定点是否位于代价地图的障碍物区域内
 * * @input:       point: 要检查的二维位姿点 costmap: 代价地图数据
 * * @output:      无
 * * @return:      bool: true表示点在障碍物内，false表示点可通行或超出地图范围
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool CoverAction::IsPointInObstacle(const geometry_msgs::Pose2D& point, const nav_msgs::OccupancyGrid& costmap) {
        double resolution = costmap.info.resolution;
        double originX = costmap.info.origin.position.x;
        double originY = costmap.info.origin.position.y;

        size_t mapX = static_cast<size_t>((point.x - originX) / resolution);
        size_t mapY = static_cast<size_t>((point.y - originY) / resolution);

        if (mapX < 0 || mapX >= costmap.info.width || mapY < 0 || mapY >= costmap.info.height) {
            return false;  // 超出地图范围，认为不碰撞
        }

        int index = mapY * costmap.info.width + mapX;
        return costmap.data[index] > 0;  // 这里假设大于0表示有障碍物，可根据实际定义调整
    }
/**********************************************************************
 * * @function:    CheckObstacleIntersection 
 * * @brief:       计算路径与障碍物的交点边界，检测路径穿过的障碍物区域
 * * @input:       path: 待检查的路径 costmap: 代价地图数据
 * * @output:      intersection_point: 存储路径与障碍物边界交点的容器
 * * @return:      bool: 返回路径是否与障碍物有交点
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool CoverAction::CheckObstacleIntersection(const nav_msgs::Path& path, const nav_msgs::OccupancyGrid& costmap,std::vector<geometry_msgs::Pose2D>& intersection_point) {
        bool inObstacleRegion = false;
        intersection_point.clear();
        geometry_msgs::Pose2D currentPoint,last_point,pose;
        last_point.x=0.;
        last_point.y=0.;
        last_point.theta=0;
        for (size_t i = 0; i < path.poses.size(); ++i) {
            currentPoint.x = path.poses[i].pose.position.x;
            currentPoint.y = path.poses[i].pose.position.y;
            currentPoint.theta=i;//临时的处理办法
            bool IsCurrentPointInObstacle = IsPointInObstacle(currentPoint, costmap);
            if (IsCurrentPointInObstacle &&!inObstacleRegion) {
                // 刚进入障碍物区域，记录当前点为交点边界的起始点
                intersection_point.push_back(i>0?last_point:currentPoint);
                inObstacleRegion = true;
                //std::cout<<"rudian i:"<<i<<""<<intersection_point.at(0).x<<" "<<intersection_point.at(0).y<<std::endl;
            } else if (!IsCurrentPointInObstacle && inObstacleRegion) {
                pose.x=path.poses[i].pose.position.x;
                pose.y=path.poses[i].pose.position.y;
                pose.theta=i;
                intersection_point.push_back(pose);
                inObstacleRegion = false;
                //std::cout<<"chudian i:"<<i<<""<<intersection_point.at(0).x<<" "<<intersection_point.at(0).y<<std::endl;
                break;
            }
            last_point=currentPoint;
        }

        return!intersection_point.empty();
}
/**********************************************************************
 * * @function:    CheckObstacleIntersection 
 * * @brief:       检查机器人当前位置是否与障碍物相交，考虑机器人半径
 * * @input:       robotPose: 机器人当前位置 robotRadius: 机器人半径（米） costmap: 代价地图数据
 * * @output:      无
 * * @return:      bool: true表示机器人与障碍物相交，false表示安全
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool CoverAction::CheckObstacleIntersection(const geometry_msgs::Pose2D& robotPose, double robotRadius, const nav_msgs::OccupancyGrid& costmap) {
    double resolution = costmap.info.resolution;
    double originX = costmap.info.origin.position.x;
    double originY = costmap.info.origin.position.y;
    int width = costmap.info.width;
    int height = costmap.info.height;

    double robotX = robotPose.x;
    double robotY = robotPose.y;

    // 遍历costmap的每个栅格
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            double mapX = x * resolution + originX;
            double mapY = y * resolution + originY;
            // 计算该栅格位置与机器人位置的距离
            double dist = distanceBetweenPoints(robotX, robotY, mapX, mapY);
            // 获取当前栅格在costmap中的值，判断是否为障碍物（这里假设大于0表示有障碍物，可根据实际定义调整）
            int index = y * width + x;
            if (costmap.data[index] > 0 && dist <= robotRadius) {
                return true;
            }
        }
    }

    return false;
}
/**********************************************************************
 * * @function:    OverlayRobotOnMap 
 * * @brief:       将机器人位置和尺寸叠加到代价地图上，生成包含机器人占据区域的新地图
 * * @input:       map: 原始代价地图 pose: 机器人当前位置 radius: 机器人半径（米）
 * * @output:      返回包含机器人占据区域的新代价地图
 * * @return:      nav_msgs::OccupancyGrid: 叠加机器人后的新地图
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
nav_msgs::OccupancyGrid CoverAction::OverlayRobotOnMap(const nav_msgs::OccupancyGrid& map, const geometry_msgs::Pose2D& pose, double radius) {
    nav_msgs::OccupancyGrid newMap = map;  // 复制原始地图，用于修改并返回
    // 获取地图的相关参数
    int width = map.info.width;
    int height = map.info.height;
    double resolution = map.info.resolution;
    double originX = map.info.origin.position.x;
    double originY = map.info.origin.position.y;

    // 计算机器人在地图中的坐标（以像素为单位）
    //int robotX = static_cast<int>((pose.x - originX) / resolution);
    //int robotY = static_cast<int>((pose.y - originY) / resolution);

    // 遍历地图的每个像素点
    for (int y = 0; y < height; ++y) {
        for (int x = 0; x < width; ++x) {
            // 计算该像素点相对于机器人位置的距离（以米为单位）
            double dx = (x * resolution + originX) - pose.x;
            double dy = (y * resolution + originY) - pose.y;
            double distance = std::sqrt(dx * dx + dy * dy);

            // 判断该点是否在机器人轮廓内（距离小于等于半径）
            if (distance <= radius) {
                int index = y * width + x;
                newMap.data[index] = 100;  // 将在机器人轮廓内的点标记为占用（可根据实际需求调整占用值）
            }
        }
    }

    return newMap;
}
/**********************************************************************
 * * @function:    LaserScanToPoseList 
 * * @brief:       将激光雷达扫描数据转换为世界坐标系下的点云坐标列表
 * * @input:       scan_msg: 激光雷达扫描数据的常量指针
 * * @output:      laser_points: 存储转换后的点云坐标
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::LaserScanToPoseList(const sensor_msgs::LaserScan::ConstPtr &scan_msg, std::vector<Point> &laser_points)
{
    unsigned int i = 0;
    Point laser_point;//,ref_point_r,ref_point_l;
    std::lock_guard<std::mutex> guard(line_mutex_);
    ref_line_.clear();
    laser_points.clear();//20241204修复内存增长
    Line line;
    Point point;
    point.x=0.0;
    point.y=0.0;
    line.start=point;
    for (double b = scan_msg->angle_min; b <= scan_msg->angle_max; b += scan_msg->angle_increment)
    {   
        if(isinf(scan_msg->ranges[i] ) ||isnan(scan_msg->ranges[i])){
    	i++;continue;}
        if (scan_msg->ranges[i] >= scan_msg->range_min && scan_msg->ranges[i] < scan_msg->range_max)
        {
            // 这里添加坐标系变换TransformCoordinate(tf_base_laser_link,laser_pose);
            tf::Point laser_pose(scan_msg->ranges[i] * std::cos(b), scan_msg->ranges[i] * std::sin(b), 0);
            // laser_pose=transform_base_link_to_laser_link_*laser_pose;
            laser_point.x = transform_base_link_to_laser_link_.getOrigin().x() + scan_msg->ranges[i] * std::cos(b);
            laser_point.y = transform_base_link_to_laser_link_.getOrigin().y() + scan_msg->ranges[i] * std::sin(b);
            laser_points.push_back(laser_point);
            if(fabs(b)< M_PI/2.&& pow(laser_point.x,2)+pow(laser_point.y,2)<pow(footprint_radius_,2)) 
            {
                line.end=laser_point;
                ref_line_.push_back(line);
            }
        }
        i++;
    }
    PublishLineMarker(ref_line_);
}
/**********************************************************************
 * * @function:    PublishLineMarker 
 * * @brief:       发布线段标记到RViz进行可视化显示
 * * @input:       line: 线段数据向量
 * * @output:      发布visualization_msgs::Marker消息到ROS话题
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::PublishLineMarker(std::vector<Line> &line)
{
    if(line.size()==0)return;//||marke_color.size()==0
    visualization_msgs::Marker marker_msg;
    marker_msg.ns = "line";
    marker_msg.id = 0;
    marker_msg.type = visualization_msgs::Marker::LINE_LIST;
    marker_msg.scale.x = 0.05;
    marker_msg.color.a = 1.0;//0.5;
    marker_msg.color.r = 1.f;
    marker_msg.color.g = 0.f;
    marker_msg.color.b = 0.f;
    for(auto &it:line)
    {
        geometry_msgs::Point p;
        p.x = it.start.x;
        p.y = it.start.y;
        p.z = 0;
        marker_msg.points.push_back(p);
        p.x = it.end.x;
        p.y = it.end.y;
        p.z = 0;
        marker_msg.points.push_back(p);
    }

    marker_msg.header.frame_id = "base_link";
    marker_msg.header.stamp = ros::Time::now();
    marker_msg.pose.orientation.w = 1.0;
    pub_line_.publish(marker_msg);
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       接收interface_action发送的指令
 * * @input:       movecmd:运动状态
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::slot_NewCmd(QVariant movecmd)
{
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();
    mtx_.lock();
    if(mdc.taskcmd_type == TaskStatus::T_ESTOP){
        execute_index_=EXECUTE_STATUS::WAIT;
        thread_pause_flag_ = true;//这个地方与其他地方相反 线程暂停
		//if(use_dynamic_cover_)start_map_=true;
    }else if(mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP){
        execute_index_=EXECUTE_STATUS::WAIT;
        thread_pause_flag_ = true;
		//if(use_dynamic_cover_)start_map_=true;
    }else if(mdc.taskcmd_type == TaskStatus::T_CANCEL){
        execute_index_=EXECUTE_STATUS::WAIT;
        thread_pause_flag_ = true;
		if(use_dynamic_cover_)start_map_=false;
    }else if(mdc.taskcmd_type == TaskStatus::T_GOON){
        execute_index_=EXECUTE_STATUS::WAIT;
        thread_pause_flag_ = false;
		//if(use_dynamic_cover_)start_map_=true;
    }else if (mdc.taskcmd_type == TaskStatus::T_END)
    {
        execute_index_=EXECUTE_STATUS::WAIT;
        thread_pause_flag_ = true;
        if (use_dynamic_cover_)start_map_=false;
    }
    
    mtx_.unlock();
    //std::cout<<"coveraction recv new cmd:"<<std::endl;
}

void CoverAction::SetCmd(std::string cmd_type)
{

}
/**********************************************************************
 * * @function:    RequireArea 
 * * @brief:       请求计算区域面积
 * * @input:       
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::RequireArea()
{
	if(p_shard_data_==nullptr)return;
	mtx_.lock();
	std::queue<PointInfo> area=p_shard_data_->allarea_queue_;
	mtx_.unlock();
	float clean_area=0.;
	while(!area.empty())
	{
	clean_area+=CalculateArea(area.front().point_array);
	area.pop();
	}
	p_shard_data_->clean_area_=clean_area;
	PublishLog("INFO;COVER;all area:" + std::to_string(clean_area));

}
/**********************************************************************
 * * @function:    SetCmd 
 * * @brief:       从navcontrol的TASK_HANDOUT调用此命令，设置返航任务
 * * @input:       cmd_type: 命令类型字符串 pdata: 目标位置和姿态数据
 * * @output:      更新共享数据状态和任务参数
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::SetCmd(std::string cmd_type,std::vector<PoseData> &pdata)
{
    mtx_.lock();
    p_shard_data_->nav_progress_.dis_to_end=-1;
    if(p_shard_data_->debug_)
    {
        std::string s = ":";
        for (auto point:pdata)s += std::to_string(point.x) + " " + std::to_string(point.y) + ";";
        PublishLog("INFO;COVER;rec cmd:" + cmd_type + s);
    }
    if(cmd_type=="new_goal" && pdata.size()>0){//方法限制，只允许4个点
        //1.生成覆盖区域存储、
        vec_cov_points_.clear();
        path_.clear();
        vec_cover_.clear();
        if(!use_dynamic_cover_)
        {
            {
                std::lock_guard<std::mutex> guard(path_mutex_);   
                if(p_cov_area_!=nullptr)
                {
                    cover_path_=CoveragePath(pdata);
                    // PoseData point;
                    // point.x=cover_path_.poses[0].pose.position.x;
                    // point.y=cover_path_.poses[0].pose.position.y;
                    // point.yaw=tf::getYaw(cover_path_.poses[0].pose.orientation);
                    // vec_cov_points_.push_back(point);
                    PoseData p;
                    for(auto point:cover_path_.poses)
                    {
                        p.x=point.pose.position.x;
                        p.y=point.pose.position.y;
                        p.yaw=tf::getYaw(point.pose.orientation);   
                        p.type=GlobalPlannerType::NO_YAW;
                        vec_cov_points_.push_back(p);
                    }
                }
                if(p_shard_data_->debug_) {
                    std::string s = ":";
                    for (auto point:cover_path_.poses) s += std::to_string(point.pose.position.x) + " " + std::to_string(point.pose.position.y) + ";";
                    PublishLog("INFO;COVER; cover path:" + s);
                }
            }
            totoal_areas_=CalculateArea(pdata);
        }
        else 
        {
            //将pdata的x,y,存储在vec_cov_points_
            vec_cov_points_=pdata;
            std::string s = ":";
            Vec2d p;
            for (auto point:vec_cov_points_)
            {
                s += std::to_string(point.x) + " " + std::to_string(point.y) + ";";
                p[0]=point.x;
                p[1]=point.y;
                vec_cover_.push_back(p);
            }
            if(p_shard_data_->debug_) {PublishLog("INFO;COVER; cover side:" + s);
            }
            //统计2.
            // //TODO,合并接口后，区域统计跟随传过来的区域数量更改
            // nav_progress_.current_index++;
            // nav_progress_.num_areas=nav_progress_.current_index;
            // nav_progress_.current_area_name="null";
            // nav_progress_.current_area=vec_cover_;
            p_mapping_->SetMappingCover(vec_cover_);
            p_plan_->totoal_areas_=0.0;
            //形成封闭多边形
            vec_cov_points_.push_back(vec_cov_points_[0]);
            
        }
        start_time_ = std::chrono::steady_clock::now(); // 记录开始时间
        //2.执行
        p_shard_data_->coverpoint_nav_status_.goal_status =NavStatus::NAV_RUN;
        path_index_=0;
        taskCompleted_=true;
        execute_index_=EXECUTE_STATUS::SEND;
        thread_pause_flag_ = false;
    }
    else {
        p_shard_data_->fault_code_.B0603=true;
        thread_pause_flag_ = true;
    }
    mtx_.unlock();
}
/**计算覆盖路经**/
void CoverAction::CalculateCoveragePath(std::vector<PoseData> &pdata)
{

}
/**********************************************************************
 * * @function:    Execute 
 * * @brief:       执行覆盖区域导航任务的主函数，管理覆盖导航的状态机
 * * @input:       无
 * * @output:      控制机器人移动，更新导航状态
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::Execute()
{
    static bool arrived_first_point=false;
    static unsigned int cnt_retry=0;
    static auto start=std::chrono::high_resolution_clock::now();//机器人不动检测
    static CmdVelStr cmd_vel;
    switch (execute_index_)
    {
        case EXECUTE_STATUS::SEND:
        {
            MoveDataCmd mdc;
            PoseData pose;
            for(auto&point:cover_path_.poses)
            {
                pose.type=GlobalPlannerType::COVERAGE;
                pose.x = point.pose.position.x;
                pose.y = point.pose.position.y;
                pose.yaw = tf::getYaw(point.pose.orientation);
                mdc.goal.push_back(pose);
            }
            mdc.taskcmd_type = TaskStatus::T_LOCALE;
            QVariant qvr;
            qvr.setValue(mdc);
            emit signal_MoveCmd(qvr);
            p_shard_data_->move_status_ =MoveStatus::IDLE;//IDLE=0,ACTIVATION,RUNNING,ARRIVE,ESTOP,CANCEL,FAULT,ABORTED
            execute_index_=EXECUTE_STATUS::RUN;
            start=std::chrono::high_resolution_clock::now();
            // MoveDataCmd mdc;//目标点
            // mdc.taskcmd_type = TaskStatus::T_LOCALE;
            // mdc.goal.x = current_point_.x;
            // mdc.goal.y = current_point_.y;
            // mdc.goal.yaw = current_point_.yaw;
            // //if(!start_map_ && path_index_>0)mdc.goal.type = GlobalPlannerType::TWO_POINTS_CLEAN;//current_point_.type;
            // //else mdc.goal.type = GlobalPlannerType::NO_YAW;
            // mdc.goal.type = GlobalPlannerType::NO_YAW;
            // QVariant qvr;
            // qvr.setValue(mdc);
            // emit signal_MoveCmd(qvr);
            // p_shard_data_->move_status_ =MoveStatus::IDLE;//IDLE=0,ACTIVATION,RUNNING,ARRIVE,ESTOP,CANCEL,FAULT,ABORTED
            // execute_index_=EXECUTE_STATUS::RUN;
            // start=std::chrono::high_resolution_clock::now();
            // if(p_shard_data_->debug_) PublishLog("INFO;COVER; current/total:" + std::to_string(path_index_)+"/"+std::to_string(vec_cov_points_.size())+" pointtype:"+std::to_string(mdc.goal.type));
            // arrived_first_point=false;
        }break;
        case EXECUTE_STATUS::RUN:
        {
            /*cover_pub_.publish(cover_path_);
            if(!use_dynamic_cover_ && arrived_first_point)
            {
                if(FollowCoverPath(cmd_vel))
                {
                    execute_index_ = EXECUTE_STATUS::FINISHED;
                }
                signal_CmdVel(cmd_vel);
            }
            else*/
            {
                if(p_shard_data_->move_status_ == MoveStatus::CANCEL)//放在最前
                {
                    if(p_shard_data_->debug_) PublishLog("INFO;COVER; cancle");
                    thread_pause_flag_ = true;
                    break;
                }
                if(p_shard_data_->move_status_ == MoveStatus::ESTOP)//放在最前
                {
                    if(p_shard_data_->debug_) PublishLog("INFO;COVER; stop");
                    thread_pause_flag_ = true;
                    break;
                }
                if(p_shard_data_->move_status_ == MoveStatus::ARRIVE) {//action成功到达
                    /*if(!use_dynamic_cover_)
                    {
                        arrived_first_point=true;
                        //break;
                    }
                    cnt_retry=0;
                    if(use_dynamic_cover_&&path_index_==0)
                    {
                        WakeUpMapping();
                    // start_time_ = std::chrono::steady_clock::now(); // 记录开始时间
                    }
                    if (path_index_ < vec_cov_points_.size()) {
                        path_index_++;
                        execute_index_ = EXECUTE_STATUS::SEND;
                    } else execute_index_ = EXECUTE_STATUS::FINISHED;
                    if(p_shard_data_->debug_) PublishLog("INFO;COVER; arrived.");
                    */
                    execute_index_ = EXECUTE_STATUS::FINISHED;  
                    if(p_shard_data_->debug_) PublishLog("INFO;COVER; arrived.");
                }
                // else if(p_shard_data_->move_status_ == MoveStatus::ACTIVATION)//激活
                // {
                //     thread_pause_flag_=false;
                //     execute_index_ = EXECUTE_STATUS::SEND;
                //     if(p_shard_data_->debug_) PublishLog("INFO;COVER; ACTIVATION");
                // }
                else if(p_shard_data_->move_status_ == MoveStatus::ABORTED)//失败
                {
                    /*if(use_dynamic_cover_&&path_index_==0)
                    {
                        WakeUpMapping();
                    // start_time_ = std::chrono::steady_clock::now(); // 记录开始时间
                    }*/
                    // if (path_index_ < vec_cov_points_.size()) {
                    //     path_index_++;
                    //     execute_index_ = EXECUTE_STATUS::SEND;
                    // } else execute_index_ = EXECUTE_STATUS::FINISHED;
                    if(p_shard_data_->debug_) PublishLog("INFO;COVER; NAV ABORTED.");
                    execute_index_ = EXECUTE_STATUS::FINISHED;//20251118覆盖异常，不认为是整体的导航任务失败
                }
            }
            auto now = std::chrono::high_resolution_clock::now();
            auto duration = now - start;
            double s= std::chrono::duration_cast<std::chrono::milliseconds>(duration).count()/1000.0;
            if(params_.dont_move_check )
            {
                if(!CheckIfMoved(robot_pose_)&&s>params_.time_out)
                {
                    execute_index_= EXECUTE_STATUS::FAILED;
                    //std::cout<<"robot dont move,point"<<std::to_string(path_index_)<<std::endl;
                }
                else start=std::chrono::high_resolution_clock::now();
            }
        }break;
        case EXECUTE_STATUS::FINISHED:
        {
            if(use_dynamic_cover_&&start_map_)
            {   
            	 start_map_=false;       
                if(p_mapping_==nullptr && p_mapping_->occu_image_.empty()) return ;
                cv::imwrite("cover.png",p_mapping_->occu_image_);
                int radius=int(0.3*p_mapping_->mapping_params_.resolution);
                if(p_plan_== nullptr)return;
                p_plan_->plan(p_mapping_->occu_image_,radius);//轨迹与边界的距离，ps:不一定等于机器人半径
                std::vector<Vec2d> path_image=p_plan_->vec_path_;
                //统计1.总面积
                //nav_progress_.total_areas=p_plan_->totoal_areas_;
                //vec_cov_points_.clear();
                //转成位置点，发布覆盖路经和区域,然后执行路经导航
                PoseData point;
                Vec2d image_point;
                path_index_=vec_cov_points_.size();//
                for(size_t i=0;i<path_image.size();i++)
                {
                    image_point=p_mapping_->Image2World(path_image[i]);
                    point.x=image_point[0];
                    point.y=image_point[1];
                    vec_cov_points_.emplace_back(point);
                    //path_.emplace_back(point);
                }
                execute_index_ = EXECUTE_STATUS::SEND;
            }
            else
            {
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                if(p_shard_data_->debug_) PublishLog("INFO;COVER; cover finished");
                p_shard_data_->coverpoint_nav_status_.goal_status =NavStatus::NAV_SUCCESS;
                thread_pause_flag_ = true;
            }
        }break;
        case EXECUTE_STATUS::FAILED:
        {
            p_shard_data_->move_status_ = MoveStatus::IDLE;//action复位
            p_shard_data_->coverpoint_nav_status_.goal_status =NavStatus::NAV_FAILED;
            thread_pause_flag_ = true;
            if(p_shard_data_->debug_) PublishLog("INFO;COVER; cover failed");
            // if(cnt_retry<5)
            // {
            // 	execute_index_ = EXECUTE_STATUS::SEND;
            // 	cnt_retry++;
            // }

        }break;
        default:
            break;
    }
    if(execute_index_== EXECUTE_STATUS::SEND|| execute_index_==EXECUTE_STATUS::RUN)
    {
        //auto elapsed_time = std::chrono::duration_cast<std::chrono::seconds>(
        //std::chrono::steady_clock::now() - start_time_).count();
        //统计任务耗时
        ////std::cout << "elapsed_time: " << elapsed_time <<"s"<< std::endl;
        //PublishNavStatus("running");
    }
    //统计任务进展
    //CountNavProgress();
    if(use_dynamic_cover_)PublishPlan(vec_cov_points_);
}


/**********************************************************************
 * * @function:    CalculateMap 
 * * @brief:       同步帧
 * * @input:       
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::CalculateMap()
{
    if (flg_received_scan_)
    { 
        if(p_scan_==nullptr || p_mapping_==nullptr) {}//ROS_WARN("nullptr scan||map");
        else p_mapping_->ProcessScan(p_scan_);
        //ROS_INFO("ProcessScan");
        flg_received_scan_=false;
    }
}
/**********************************************************************
 * * @function:    MapThread 
 * * @brief:       建图线程
 * * @input:       duration: 时间
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
// 建图线程
void CoverAction::MapThread(int duration) {

    auto start_time = std::chrono::steady_clock::now(); // 记录开始时间
    while (ros::ok())
    {
    	//ROS_INFO("mapping...................................................................................................");
        {
        std::mutex mtx;
        std::unique_lock<std::mutex> lock(mtx); //20240508防止锁崩溃
        cv_mapping_.wait(lock, [this]{ return start_map_; });
        }
        auto elapsed_time = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start_time).count();
        CalculateMap();
        if (elapsed_time < duration) std::this_thread::sleep_for(std::chrono::milliseconds(duration-elapsed_time));
        start_time = std::chrono::steady_clock::now();
        

    }
};
/**********************************************************************
 * * @function:    AmclPoseCB 
 * * @brief:       重定位回调
 * * @input:       msg ：amcl_pose数据
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::AmclPoseCB(const geometry_msgs::PoseWithCovarianceStamped &msg) 
{
    if(!isnan(msg.pose.pose.position.x) && !isnan(msg.pose.pose.position.y)&&
        !isnan(msg.pose.pose.orientation.w)&& !isnan(msg.pose.pose.orientation.z))
    {
        //ROS_INFO("AmclPose CB");
        robot_pose_.x= msg.pose.pose.position.x;
        robot_pose_.y=msg.pose.pose.position.y;
        tf::Quaternion tf_q(msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, 
        msg.pose.pose.orientation.z, msg.pose.pose.orientation.w);
        robot_pose_.yaw= tf::getYaw(tf_q);
        //current_pose_info_.x 
        //current_pose_info_.y = msg.pose.pose.position.y;
    } 
} 
/**********************************************************************
 * * @function:    ScanCB 
 * * @brief:       激光雷达回调函数
 * * @input:       msg: 激光雷达数据
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::ScanCB(const sensor_msgs::LaserScan::ConstPtr &msg)
{
    if(p_scan_==nullptr)return;
    {
        std::unique_lock<std::mutex> lock(mtx_);
        //ROS_INFO("SCAN CB");
        //监听当前位置
        sensor_msgs::LaserScan::ConstPtr p=msg;
        p_scan_->scan=msg;
        geometry_msgs::PoseStamped ident,laser_pose;
        ident.header.frame_id = msg->header.frame_id;
        ident.header.stamp = ros::Time();
        tf2::toMsg(tf2::Transform::getIdentity(), ident.pose);
        try
        {
        this->tf_->transform(ident, laser_pose, "map");
        }
        catch(tf2::TransformException& e)
        {
        //ROS_ERROR("Couldn't transform from %s to map, "
         //           "even though the message notifier is in use",
         //           msg->header.frame_id.c_str());
        return;
        }
        geometry_msgs::Quaternion q=laser_pose.pose.orientation;
        double yaw=atan2(2 * (q.w * q.z + q.x * q.y), 1 - 2 * (q.y * q.y + q.z * q.z));
        //std::cerr<<"scan"<<laser_pose.pose.position.x<<" "<<laser_pose.pose.position.y<<" "<<yaw<<std::endl;
        SE2 se2 = SE2::trans( Eigen::Vector2d(laser_pose.pose.position.x, laser_pose.pose.position.y) ) * SE2::rot(yaw);
        p_scan_->pose=se2;
        flg_received_scan_=true;
    }
}
/**********************************************************************
 * * @function:    CheckIfMoved 
 * * @brief:       查看是否运动
 * * @input:       pos: 当前位姿
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool CoverAction::CheckIfMoved(Pose pos)
   {

      static Pose last_pose;
      double distance =hypot(pos.x - last_pose.x, pos.y - last_pose.y);
      if(fabs(distance)>1e-1||fabs(pos.yaw - last_pose.yaw)>1e-1)
      {
         last_pose=pos;
         return true;
      }
      return false;
   
   }
/**********************************************************************
 * * @function:    GetLocalPath 
 * * @brief:       根据起点和目标点生成等间距插值的局部路径
 * * @input:       start: 起始点位置和朝向 goal: 目标点位置和朝向 dis: 路径点间距（米）
 * * @output:      返回生成的路径对象
 * * @return:      nav_msgs::Path: 生成的局部路径
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
nav_msgs::Path CoverAction::GetLocalPath(const geometry_msgs::Pose2D &start, const geometry_msgs::Pose2D &goal,const double &dis) 
{
    nav_msgs::Path path;
    path.header.frame_id = "map"; // 假设坐标系为map
    path.header.stamp = ros::Time::now();
    // 计算起点和终点之间的总距离
    double total_distance = sqrt(pow(goal.x - start.x, 2) + pow(goal.y - start.y, 2));
    // 确定需要多少个间隔来覆盖总距离
    int num_points = floor(total_distance / dis);
    if(num_points==0)return path;
    ////std::cout<<"total_distance"<<total_distance<< " dis"<<dis<<std::endl;
    // 计算插值步长
    double step_x = num_points==0?goal.x - start.x:(goal.x - start.x) / num_points;
    double step_y = num_points==0?goal.y - start.y:(goal.y - start.y) / num_points;
    double step_theta = num_points==0?goal.theta - start.theta:(goal.theta - start.theta) / num_points;
    // 生成路径点
    for (int i = 0; i <= num_points; i++) {
        geometry_msgs::PoseStamped pose;
        pose.header = path.header;
        pose.pose.position.x = start.x + step_x * i;
        pose.pose.position.y = start.y + step_y * i;
        pose.pose.orientation = tf::createQuaternionMsgFromYaw(start.theta + step_theta * i);
        path.poses.push_back(pose);
        //std::cout<<"push_back "<<pose.pose.position.x<<" "<<pose.pose.position.y<<std::endl;
    }
    // 更新dis为实际使用的间隔
    //dis = total_distance / num_points;
    ////std::cout << "global path size:" << path.poses.size() << std::endl;
    return path;
}
/**********************************************************************
 * * @function:    CoveragePath 
 * * @brief:       生成多边形区域的连续覆盖路径
 * * @input:       polygon: 多边形区域的顶点数据
 * * @output:      返回生成的覆盖路径
 * * @return:      nav_msgs::Path: 覆盖整个多边形区域的路径
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
nav_msgs::Path CoverAction::CoveragePath(std::vector<PoseData> &polygon)
{
    
    std::vector<Point> cov_points;
    nav_msgs::Path cov_path,local_path;
    cov_path.header.frame_id="map";
    cov_path.header.stamp=ros::Time::now();
    geometry_msgs::PoseStamped poses;
    poses.header.frame_id="map";
    poses.header.stamp=ros::Time::now();
    poses.pose.position.z=0.;
    //if(polygon.size()<4)
    {
        for(auto&p:polygon)
        {
            poses.pose.position.x=p.x;
            poses.pose.position.y=p.y;
            poses.pose.orientation=tf::createQuaternionMsgFromYaw(p.yaw);
            cov_path.poses.push_back(poses);
        }
        return cov_path;
    }
    bool ret=p_cov_area_->GetCoverPath(polygon,cov_points,footprint_radius_);
    /*geometry_msgs::Pose2D start,goal;
    for(int i=0;i<cov_points.size()-1;i++)
    {
        start.x=cov_points[i].x;
        start.y=cov_points[i].y;
        goal.x=cov_points[i+1].x;
        goal.y=cov_points[i+1].y;
        local_path=GetLocalPath(start,goal,0.05);
        cov_path.poses.insert(cov_path.poses.end(),local_path.poses.begin(),local_path.poses.end()); 
    }*/
   //使用move_base避障
    for(auto&p:cov_points)
    {
        poses.pose.position.x=p.x;
        poses.pose.position.y=p.y;
        poses.pose.orientation=tf::createQuaternionMsgFromYaw(p.yaw);
        cov_path.poses.push_back(poses);
    }
    return cov_path;
}
/**********************************************************************
 * * @function:    ListenTF 
 * * @brief:       监听指定坐标系间的TF变换并获取位姿信息
 * * @input:       target: 目标坐标系名称 source: 源坐标系名称
 * * @output:      pose: 转换后的位姿信息
 * * @return:      bool: true表示成功获取变换，false表示失败
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool CoverAction::ListenTF(std::string target, std::string source, geometry_msgs::Pose2D &pose)
{
    try
    {
        tf_listener_.waitForTransform(target, source, ros::Time(0), ros::Duration(3.0));
        tf_listener_.lookupTransform(target, source, ros::Time(0), transform_base_link_to_map_);
    }
    catch (tf::TransformException &ex)
    {
        //ROS_ERROR("Failed to lookup transform: %s", ex.what());
        return false;
    }
    pose.x = transform_base_link_to_map_.getOrigin().x();
    pose.y = transform_base_link_to_map_.getOrigin().y();
    pose.theta = tf::getYaw(transform_base_link_to_map_.getRotation());
    return true;
}
/**********************************************************************
 * * @function:    checkFuture 
 * * @brief:       检查异步任务完成状态并执行后续清理操作
 * * @input:       无
 * * @output:      发布语音提示，清理路径数据，设置任务完成标志
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::checkFuture(){//(std::future<void>& future) {
    // 等待异步任务完成
    //future.wait();
    signal_PubVoice("NoPass");
    sleep(5);
    //删除队头.这里可能删的太慢
    //if(!cover_path_.poses.empty())cover_path_.poses.erase(cover_path_.poses.begin());

    // 任务完成后，设置标志
    taskCompleted_=true;
    ////std::cout << "end .-------------------------------" <<cover_path_.poses.size()<< std::endl;

}
/**********************************************************************
 * * @function:    IsCollision 
 * * @brief:       检查给定位姿是否与代价地图中的障碍物发生碰撞
 * * @input:       pose: 要检查的二维位姿 costmap: 代价地图数据
 * * @output:      无
 * * @return:      bool: true表示发生碰撞，false表示安全或超出地图范围
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool CoverAction::IsCollision(const geometry_msgs::Pose2D& pose, const nav_msgs::OccupancyGrid& costmap) {
    double resolution = costmap.info.resolution;
    double originX = costmap.info.origin.position.x;
    double originY = costmap.info.origin.position.y;

    size_t mapX = static_cast<int>((pose.x - originX) / resolution);
    size_t mapY = static_cast<int>((pose.y - originY) / resolution);

    if (mapX < 0 || mapX >= costmap.info.width || mapY < 0 || mapY >= costmap.info.height) {
        return false;  // 超出地图范围，认为不碰撞
    }

    int index = mapY * costmap.info.width + mapX;
    return costmap.data[index] > 0;
}
/**********************************************************************
 * * @function:    SmoothPath 
 * * @brief:       使用滑动窗口平均法对路径进行平滑处理
 * * @input:       path: 原始路径数据 windowSize: 滑动窗口大小
 * * @output:      返回平滑后的路径
 * * @return:      nav_msgs::Path: 平滑处理后的路径
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
nav_msgs::Path CoverAction::SmoothPath(const nav_msgs::Path& path, int windowSize) {
    nav_msgs::Path smoothedPath;
    int pathSize = path.poses.size();
    // 确保窗口大小合理，防止超出路径范围
    if (windowSize > pathSize) {
        windowSize = pathSize;
    }
    geometry_msgs::PoseStamped smoothedPose;
    for (int i = 0; i < pathSize; ++i) {
        smoothedPose=path.poses[0];
        int startIndex = std::max(0, i - windowSize / 2);
        int endIndex = std::min(pathSize - 1, i + windowSize / 2);
        double sumX = 0.0;
        double sumY = 0.0;
        // 计算窗口内坐标的总和
        for (int j = startIndex; j <= endIndex; ++j) {
            sumX += path.poses[j].pose.position.x;
            sumY += path.poses[j].pose.position.y;
        }
        int numPointsInWindow = endIndex - startIndex + 1;
        // 计算平均坐标作为平滑后的坐标
        smoothedPose.pose.position.x = sumX / numPointsInWindow;
        smoothedPose.pose.position.y = sumY / numPointsInWindow;
        smoothedPath.poses.push_back(smoothedPose);
    }
    return smoothedPath;
}
/**********************************************************************
 * * @function:    MakePlan 
 * * @brief:       在代价地图中生成从起点到目标点的可行路径
 * * @input:       start: 起始点位置 goal: 目标点位置 costmap: 代价地图数据
 * * @output:      newPath: 生成的可行路径
 * * @return:      bool: 返回路径规划是否成功
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
//local_costmap只能处理局部小障碍
bool CoverAction::MakePlan(const geometry_msgs::Pose2D& start, const geometry_msgs::Pose2D& goal, const nav_msgs::OccupancyGrid& costmap, nav_msgs::Path& newPath) {
    newPath.poses.clear();
    //检查越界
    if (!IsGoalInCostmap(goal, costmap)) {
        //ROS_WARN("目标点不在成本地图内部");
        return false;
    }
    // 设置路径消息的坐标参考系
    nav_msgs::Path path;
    bool flg_get_path=false;
    path.header.frame_id = costmap.header.frame_id;
    geometry_msgs::PoseStamped pose;
    pose.header.frame_id = costmap.header.frame_id;
    pose.pose.position.z = 0.;
    pose.pose.orientation.w=1.0;
    // 存储所有节点的指针，方便查找和更新代价等操作，以地图坐标为索引
    std::vector<std::vector<Node*>> nodes;
    int width = costmap.info.width;
    int height = costmap.info.height;
    // 初始化节点
    for (int y = 0; y < height; ++y) {
        std::vector<Node*> row;
        for (int x = 0; x < width; ++x) {
            geometry_msgs::Pose2D pose;
            pose.x = x * costmap.info.resolution + costmap.info.origin.position.x;
            pose.y = y * costmap.info.resolution + costmap.info.origin.position.y;
            row.push_back(new Node(pose));
        }
        nodes.push_back(row);
    }
    // 起点和终点对应的节点指针
    Node* startNode = nodes[std::round((start.y - costmap.info.origin.position.y) / costmap.info.resolution)][std::round((start.x - costmap.info.origin.position.x) / costmap.info.resolution)];
    Node* goalNode = nodes[std::round((goal.y - costmap.info.origin.position.y) / costmap.info.resolution)][std::round((goal.x - costmap.info.origin.position.x) / costmap.info.resolution)];
    startNode->g = 0;
    startNode->f = startNode->g + startNode->h;
    std::priority_queue<Node*, std::vector<Node*>, CompareNodeCost> pq;
    pq.push(startNode);
    while(!pq.empty()) {
        Node* current = pq.top();
        pq.pop();
        ////std::cout<<"current cost="<<current->cost<< "pose "<<current->pose.x<<" "<<current->pose.y<<std::endl;
        if (current == goalNode) {
            // 如果找到了目标节点，回溯构建路径
            Node* node = current;
            while (node!= nullptr) {
                pose.pose.position.x = node->pose.x;
                pose.pose.position.y = node->pose.y;
                path.poses.push_back(pose);
                node = node->prev;
            }
            std::reverse(path.poses.begin(), path.poses.end());
            flg_get_path=true;
            break;
        }
        // 检查当前节点周围的邻居节点
        int x = std::round((current->pose.x - costmap.info.origin.position.x) / costmap.info.resolution);
        int y = std::round((current->pose.y - costmap.info.origin.position.y) / costmap.info.resolution);
        std::vector<std::pair<int, int>> directions = { {0, 1}, {0, -1}, {1, 0}, {-1, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1} };
        for (const auto& dir : directions) {
            int newX = x + dir.first;
            int newY = y + dir.second;
            if (newX >= 0 && newX < width && newY >= 0 && newY < height) {
                Node* neighbor = nodes[newY][newX];
                double newCost = current->g +(dir.first *dir.second == 0 ? 1:1.41);//
                if(newCost<neighbor->g &&!IsCollision(neighbor->pose, costmap)) {//
                    // 如果新的代价更小且没有碰撞，更新邻居节点的代价和前驱节点
                    neighbor->g = newCost;
                    neighbor->h = Heuristic(neighbor->pose, goalNode->pose, costmap); 
                    neighbor->f = neighbor->g + neighbor->h;
                    neighbor->prev = current;
                    pq.push(neighbor);
                }
            }
        }
    }
    for (auto& row : nodes) {
        for (auto node_ptr : row) {
            delete node_ptr;
        }
    }
    nodes.clear();
    if(flg_get_path)
    {
        newPath=SmoothPath(path, 7);
        return true;
    }
    else
    {
        // 如果队列为空还没找到目标，说明无法规划出路径
        //ROS_WARN("无法找到到达目标的可行路径");
        return false;
    }
    return false;
}
// 使用广度优先搜索来查找路径的函数
/*bool CoverAction::MakePlan(const geometry_msgs::Pose2D& start, const geometry_msgs::Pose2D& goal, const nav_msgs::OccupancyGrid& costmap, nav_msgs::Path& newPath)
{
    newPath.poses.clear();
    //检查越界
    if (!IsGoalInCostmap(goal, costmap)) {
        //ROS_WARN("目标点不在成本地图内部");
        return false;
    }
    // 设置路径消息的坐标参考系
    nav_msgs::Path path;
    bool flg_get_path=false;
    path.header.frame_id = costmap.header.frame_id;
    geometry_msgs::PoseStamped pose;
    pose.header.frame_id = costmap.header.frame_id;
    pose.pose.position.z = 0.;
    pose.pose.orientation.w=1.0;
    std::vector<std::vector<Node*>> nodes;
    int width = costmap.info.width;
    int height = costmap.info.height;
    // 初始化节点
    for (int y = 0; y < height; ++y) {
        std::vector<Node*> row;
        for (int x = 0; x < width; ++x) {
            geometry_msgs::Pose2D pose;
            pose.x = x * costmap.info.resolution + costmap.info.origin.position.x;
            pose.y = y * costmap.info.resolution + costmap.info.origin.position.y;
            row.push_back(new Node(pose));
        }
        nodes.push_back(row);
    }
    // 起点和终点对应的节点指针
    Node* startNode = nodes[std::round((start.y - costmap.info.origin.position.y) / costmap.info.resolution)][std::round((start.x - costmap.info.origin.position.x) / costmap.info.resolution)];
    Node* goalNode = nodes[std::round((goal.y - costmap.info.origin.position.y) / costmap.info.resolution)][std::round((goal.x - costmap.info.origin.position.x) / costmap.info.resolution)];
    // 用于BFS的队列，存储待探索的节点
    std::queue<Node*> bfsQueue;
    bfsQueue.push(startNode);
    // 标记节点是否已被访问过，避免重复访问
    std::vector<std::vector<bool>> visited(height, std::vector<bool>(width, false));
    visited[std::round((start.y - costmap.info.origin.position.y) / costmap.info.resolution)][std::round((start.x - costmap.info.origin.position.x) / costmap.info.resolution)] = true;
    while (!bfsQueue.empty()) {
        Node* current = bfsQueue.front();
        bfsQueue.pop();

        if (current == goalNode) {
            // 如果找到了目标节点，回溯构建路径
            Node* node = current;
            while (node!= nullptr) {
                pose.pose.position.x = node->pose.x;
                pose.pose.position.y = node->pose.y;
                path.poses.push_back(pose);
                node = node->prev;
            }
            std::reverse(path.poses.begin(), path.poses.end());
            return true;
        }

        // 检查当前节点周围的邻居节点
        int x = std::round((current->pose.x - costmap.info.origin.position.x) / costmap.info.resolution);
        int y = std::round((current->pose.y - costmap.info.origin.position.y) / costmap.info.resolution);
        std::vector<std::pair<int, int>> directions = { {0, 1}, {0, -1}, {1, 0}, {-1, 0}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1} };

        for (const auto& dir : directions) {
            int newX = x + dir.first;
            int newY = y + dir.second;
            if (newX >= 0 && newX < width && newY >= 0 && newY < height) {
                Node* neighbor = nodes[newY][newX];
                if (!visited[newY][newX] &&!IsCollision(neighbor->pose, costmap)) {
                    // 如果邻居节点未被访问且没有碰撞，标记为已访问，设置前驱节点，加入队列
                    visited[newY][newX] = true;
                    neighbor->prev = current;
                    bfsQueue.push(neighbor);
                }
            }
        }
    }
    for (auto& row : nodes) {
        for (auto node_ptr : row) {
            delete node_ptr;
        }
    }
    nodes.clear();
    if(flg_get_path)
    {
        newPath=SmoothPath(path, 7);
        return true;
    }
    else
    {
        // 如果队列为空还没找到目标，说明无法规划出路径
        //ROS_WARN("无法找到到达目标的可行路径");
        return false;
    }
    return false;
}*/

/**********************************************************************
 * * @function:    PlayVoice 
 * * @brief:       播放"无法通过"语音提示并管理播放状态
 * * @input:       
 * * @output:      发布语音信号，更新播放状态标志
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void CoverAction::PlayVoice()
{
    //unsigned int cnt_times_voice=0;
    play_finished_=false;
    signal_PubVoice("NoPass");
    //std::cout<<"play voice..."<<std::endl;

    sleep(5);
    play_finished_=true;
    // cnt_times_voice++;
    // }
}
/**********************************************************************
 * * @function:    EstimateCurvature 
 * * @brief:       计算路径起始段的曲率，用于评估路径弯曲程度
 * * @input:       path_points: 路径点序列
 * * @output:      
 * * @return:      double: 返回路径曲率估计值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
double CoverAction::EstimateCurvature(const nav_msgs::Path& path_points) {
    if (path_points.poses.size() < 5) {
        return 0.0; // 路径点过少，认为曲率为0
    }
    std::vector<geometry_msgs::PoseStamped> relevant_poses(path_points.poses.begin(), path_points.poses.begin() + 5);
    /*geometry_msgs::Pose2D v1 = CalculateVector(relevant_poses[0].pose.position, relevant_poses[3].pose.position);
    geometry_msgs::Pose2D v2 = CalculateVector(relevant_poses[3].pose.position, relevant_poses[5].pose.position);
    double crossProduct = v1.x * v2.y - v1.y * v2.x;
    double lengthProduct = VectorLength(v1) * VectorLength(v2);
    double curvature = lengthProduct > 0.? crossProduct / lengthProduct:0.0;
    return std::abs(curvature);
    */
    int n = relevant_poses.size();
    Eigen::MatrixXd A(n, 3);
    Eigen::VectorXd y(n);

    for (int i = 0; i < n; ++i) {
        A(i, 0) = relevant_poses[i].pose.position.x * relevant_poses[i].pose.position.x;
        A(i, 1) = relevant_poses[i].pose.position.x;
        A(i, 2) = 1;
        y(i) = relevant_poses[i].pose.position.y;
    }

    // 通过最小二乘法求解拟合系数
    Eigen::VectorXd result = (A.transpose() * A).ldlt().solve(A.transpose() * y);

    double yPrime = 2 * result[0] * relevant_poses[3].pose.position.x + result[1];
    double yDoublePrime = 2 * result[0];

    return std::abs(yDoublePrime) / std::pow(1 + yPrime * yPrime, 1.5);

}
/**
 * 20241126跟随全局路径
 */
/**********************************************************************
 * * @function:    FollowCoverPath 
 * * @brief:       控制机器人跟随覆盖路径，包含速度控制和状态管理
 * * @input:       cmd_vel: 速度控制命令
 * * @output:      cmd_vel: 更新后的速度控制命令
 * * @return:      bool: 返回路径跟随是否成功
 * * @author：     jiangcuihuan
 * * @date：       20241126
 * **********************************************************************/
bool CoverAction::FollowCoverPath(CmdVelStr &cmd_vel)
{
    static unsigned int cnt_times_voice=0;
    static bool flg_turn_around=false;//转弯标志
    static CmdVelStr last_vel;
    static std::thread checker,thread_voice;
    static auto start = std::chrono::high_resolution_clock::now();
    auto now = std::chrono::high_resolution_clock::now();
    auto duration = now - start;
    double dt= std::chrono::duration_cast<std::chrono::milliseconds>(duration).count()/1000.0;
    start = std::chrono::high_resolution_clock::now();
    last_vel=cmd_vel;
    {
        std::lock_guard<std::mutex> guard(path_mutex_);
        if(cover_path_.poses.size()==0)
        {
            cmd_vel.linear = 0.0;
            cmd_vel.angular = 0.0;
            start = std::chrono::high_resolution_clock::now();
            //std::cout<<"cover_path_.poses.size()=0 "<<std::endl;
            return true;
        }
        cover_pub_.publish(cover_path_);
    }
    //std::lock_guard<std::mutex> guard(path_mutex_);
    ListenTF("map", "base_link", current_pose_);//已经在上面获取过tf了
    nav_msgs::Path* ref_path=&cover_path_;
    double curvature = EstimateCurvature(*ref_path);
    double pre_look_ahead_distance = (curvature > forward_distance_/0.3 || curvature<0.01 ?forward_distance_:0.15);
    double near_dis;
    for (size_t i = 0; i < ref_path->poses.size(); i++)
    {
		near_dis=sqrt(pow(ref_path->poses[i].pose.position.x-current_pose_.x, 2) + pow(ref_path->poses[i].pose.position.y-current_pose_.y, 2));
    	if (ref_path->poses.size()>0 && (isnan(near_dis)||near_dis < pre_look_ahead_distance)){
    	ref_path->poses.erase(ref_path->poses.begin());
    	i--;
    	}
    	else break;
    }
    flg_collision_=CheckCollision(local_costmap_,global_costmap_,cover_path_);  
    if(!flg_collision_) 
    {
        result_makeplan_=false;//复位
        play_finished_=true;
        cnt_times_voice=0;
    }
    //添加避停,统计超时时间后，清掉前方一段范围的路点
    {
        std::lock_guard<std::mutex> guard(line_mutex_);
        if((flg_collision_||ref_line_.size()>0) && (obstacle_avoidave_method_==0))
        {
            cmd_vel.linear=0;
            cmd_vel.angular=0;
            if(taskCompleted_)
            {
                taskCompleted_=false;
                
                checker=std::thread([this]() { this->checkFuture();});//定时调语音、清除路径
                checker.detach();
            }
            ////std::cout<<"stop .ref_line_.size()"<<ref_line_.size()<<std::endl;
            start = std::chrono::high_resolution_clock::now();
            return false;
        }
        else if(flg_collision_ && (obstacle_avoidave_method_==1))
        {//等待local_path_规划出来
            if(!result_makeplan_)
            {
                if(taskCompleted_)
                {
                    taskCompleted_=false;
                    checker=std::thread([this]() { this->GetPlan();});
                    checker.detach();
                }
                if(play_finished_)
                {
                    if(cnt_times_voice>3)
                    {
                        cnt_times_voice=0;
                        std::lock_guard<std::mutex> guard(path_mutex_);
                        //播放3次，仍然规划失败，则放弃这段
                        //std::cout<<"erase "<<local_goal_.theta<<std::endl;
                        cover_path_.poses.erase(cover_path_.poses.begin(),cover_path_.poses.begin()+floor(local_goal_.theta));
                        return false;
                    }
                    cnt_times_voice++;
                    thread_voice=std::thread([this]() { this->PlayVoice();});
                    thread_voice.detach();
                }
                //std::cout<<"stop... "<<std::endl;
                cmd_vel.linear=0.;
                cmd_vel.angular=0.;
                return false;
            }
        }
        else
        {
            taskCompleted_=true;  
            //result_makeplan_=false; 
        }

    }

    //跟随路径
    tf::Vector3 source_point(ref_path->poses[0].pose.position.x,ref_path->poses[0].pose.position.y,0);
    tf::Vector3 tran_point=transform_base_link_to_map_.inverse()*source_point;
    geometry_msgs::PoseStamped look_ahead_point;
    look_ahead_point.pose.position.x=tran_point[0];
    look_ahead_point.pose.position.y=tran_point[1];
    look_ahead_point.pose.orientation.w=1;
    double look_ahead_angle=atan2(look_ahead_point.pose.position.y, look_ahead_point.pose.position.x);
    //std::cout<<curvature<<"pre_look_ahead_distance"<<pre_look_ahead_distance<<"look_ahead_angle "<<look_ahead_angle 
    //<<"look_ahead_pointx "<<look_ahead_point.pose.position.x<<"vel linear "<<cmd_vel.linear<<" angular "<<cmd_vel.angular<<std::endl;

    //转弯结束再跟随
    if(fabs(look_ahead_point.pose.position.x)<=0.05 ||fabs(look_ahead_angle)-M_PI/8.>0.1 ||(fabs(look_ahead_angle)-M_PI/16.>0.1&&flg_turn_around))//
    {
        flg_turn_around=true;
        //控制转弯
        cmd_vel.angular = 0.5 * look_ahead_angle;
        cmd_vel.linear=0.0;
        //cmd_vel.linear-=max_acc_linear_*dt;
        //cmd_vel.linear = cmd_vel.linear > min_linear_velocity_ ? cmd_vel.linear : min_linear_velocity_;
        //控制加速度
        double a_angular=(cmd_vel.angular-last_vel.angular)/dt;
        if(fabs(a_angular)>max_acc_angular_)cmd_vel.angular=last_vel.angular+(a_angular>0?max_acc_angular_:-max_acc_angular_)*dt;
        cmd_vel.angular = fabs(cmd_vel.angular) > min_angular_velocity_ ? cmd_vel.angular : cmd_vel.angular > 0. ? min_angular_velocity_                                                                                               : -min_angular_velocity_;
        cmd_vel.angular = fabs(cmd_vel.angular) > max_angular_velocity_ ? cmd_vel.angular > 0. ? max_angular_velocity_ : -max_angular_velocity_ : cmd_vel.angular;

        //std::cout<<" turn "<<cmd_vel.angular<<std::endl;
        start = std::chrono::high_resolution_clock::now();
        return false;
    }
    flg_turn_around=false;
    // 控制跟随预瞄点
    cmd_vel.linear = fabs(look_ahead_point.pose.position.x)<=0.05 ? 0.0:2.0 * look_ahead_point.pose.position.x;//distanceBetweenPoints(0.,0.,look_ahead_point.pose.position.x,look_ahead_point.pose.position.y);
    cmd_vel.angular = 0.8 * look_ahead_angle;
        //控制加速度
    double a_angular=(cmd_vel.angular-last_vel.angular)/dt;
    if(fabs(a_angular)>max_acc_angular_)cmd_vel.angular=last_vel.angular+(a_angular>0?max_acc_angular_:-max_acc_angular_)*dt;
    cmd_vel.angular = fabs(cmd_vel.angular) > min_angular_velocity_ ? cmd_vel.angular : cmd_vel.angular > 0 ? min_angular_velocity_                                                                                         : -min_angular_velocity_;
    cmd_vel.angular = fabs(cmd_vel.angular) > max_angular_velocity_ ? cmd_vel.angular > 0 ? max_angular_velocity_ : -max_angular_velocity_ : cmd_vel.angular;

    //控制加速度
    double a_linear=(cmd_vel.linear-last_vel.linear)/dt;
    if(fabs(a_linear)>max_acc_linear_)cmd_vel.linear=last_vel.linear+(a_linear>0?max_acc_linear_:-max_acc_linear_)*dt;
    cmd_vel.linear = cmd_vel.linear > min_linear_velocity_ ? cmd_vel.linear : min_linear_velocity_;
    cmd_vel.linear = cmd_vel.linear > max_linear_velocity_ ? max_linear_velocity_ : cmd_vel.linear;
    start = std::chrono::high_resolution_clock::now();
    ////std::cout<<"cmd_vel "<< look_ahead_point.pose.position.x<<"linear "<<cmd_vel.linear<<" angular "<<cmd_vel.angular<<std::endl;
    return false;

    
}

