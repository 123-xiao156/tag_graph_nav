/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	database_action.cpp
 * * @description:  门禁、乘梯、覆盖
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "database_action.h"

DatabaseAction::DatabaseAction(ros::NodeHandle nh):nh_(nh)
{
    db_client_ = nh_.serviceClient<robot_msgs::DataBase>("/database_operate");
}

void DatabaseAction::Init()
{
    // 第一次加载数据
    p_shard_data_->update_waypointlist_flag = true;
    interval_ms_ = 500;
    std::thread t(&DatabaseAction::TimerThread,this,interval_ms_);
    t.detach();
}
/**********************************************************************
 * * @function:    TimerThread 
 * * @brief:       覆盖导航定时器线程，周期性执行导航任务
 * * @input:       interval_ms: 线程执行间隔时间（毫秒）
 * * @output:      无
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void DatabaseAction::TimerThread(int16_t interval_ms)
{
    while(ros::ok()){
        if(p_shard_data_->update_waypointlist_flag){
            ReadMaplist(p_shard_data_->maplist_);
            ReadAllWaypointList(p_shard_data_->maplist_,p_shard_data_->waypoint_list_);
            p_shard_data_->update_waypointlist_flag = false;
        }
        ros::spinOnce();
        // 500ms轮询一次
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
/**********************************************************************
 * * @function:    ReadDataBase 
 * * @brief:       调用数据库服务读取数据，包含服务可用性检查和错误处理
 * * @input:       cs: 数据库服务客户端 r_type: 数据库请求类型 r_data: 数据库请求数据
 * * @output:      data_content: 从数据库返回的数据内容
 * * @return:      FaultCode: 返回操作结果状态码
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
FaultCode DatabaseAction::ReadDataBase(ros::ServiceClient cs,DB_Type r_type,std::string r_data,std::string &data_content)
{
    if(!cs.waitForExistence(ros::Duration(10)))
    {
        return FaultCode::U0412;
    }
    robot_msgs::DataBase srv;
    srv.request.request_type = r_type;
    srv.request.request_data = r_data;  
    if (cs.call(srv)){
        data_content = srv.response.response_data;
    }else{
        return FaultCode::U0412;
    }
    return FaultCode::TRUE;
}
/**********************************************************************
 * * @function:    ReadMaplist 
 * * @brief:       从数据库读取地图列表信息
 * * @input:       
 * * @output:      maplist: 存储地图名称和对应数据库表名的映射
 * * @return:      FaultCode: 返回操作结果状态码
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
FaultCode DatabaseAction::ReadMaplist(std::unordered_map<std::string,std::string> &maplist)
{
    FaultCode ret{FaultCode::TRUE};
    std::string data_content = "";
    ret = ReadDataBase(db_client_,DB_Type::EXECL_NAME,"",data_content);
    if(ret == FaultCode::TRUE){
        ret = TableDataAnalysis(data_content,maplist);
    }
    return ret;
}
/**********************************************************************
 * * @function:    ReadAllWaypointList 
 * * @brief:       从数据库读取所有地图的路点列表信息
 * * @input:       maplist: 地图名称和数据库表名的映射
 * * @output:      waypointlist: 存储所有路点数据的容器
 * * @return:      FaultCode: 返回操作结果状态码
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
FaultCode DatabaseAction::ReadAllWaypointList(const std::unordered_map<std::string,std::string> maplist,umap &waypointlist)
{
    p_shard_data_->waypoint_list_.clear();
    FaultCode ret{FaultCode::TRUE};
    std::string data_content = "";
    for(auto it = maplist.begin();it != maplist.end();++it){
        string map_name = it->first;      //地图名
        string execl_name = it->second;   //数据库列表名
        ret = ReadDataBase(db_client_,DB_Type::EXECL_READ,execl_name,data_content);
        if(ret == FaultCode::TRUE){
            ret = WaypointDataAnalysis(data_content,execl_name,map_name,waypointlist);
            if(ret != FaultCode::TRUE){
                return ret;
            }
        }
    }
    return ret;
}
/**********************************************************************
 * * @function:    TableDataAnalysis 
 * * @brief:       JSON字符串解释出地图列表单存入地图列表容器
 * * @input:       data_content: 数据库返回JSON字符串  
 * * @output:      maplist: 数据库返回JSON字符串
 * * @return:      FaultCode: 返回操作结果状态码
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
FaultCode DatabaseAction::TableDataAnalysis(const std::string &data_content,std::unordered_map<std::string,std::string> &maplist)
{
    Json::Value root;
    const auto rawJsonLength = static_cast<int>(data_content.length());
    JSONCPP_STRING err;
    Json::CharReaderBuilder builder;
    const std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
//    std::cout << "table list : " << data_content << std::endl;
    if (!reader->parse(data_content.c_str(), data_content.c_str() + rawJsonLength, &root,
                        &err)) {
        //std::cout << "error" << std::endl;
        return FaultCode::U0412;
    }
    Json::Value::Members jm = root.getMemberNames();//获取表名
    int len = jm.size();
    if(len < 1  ||  (len >= 1 && jm[0] != "tableList")) {
        return FaultCode::U0412;
    }
    maplist.clear();
    if(root["tableList"].isArray()) 
    {
        int size_t = root["tableList"].size(); 
        std::string map_name;
        std::string t_name;
        for(int i = 0;i < size_t;i++) 
        {
            if(p_shard_data_->new_of_old_database_=="new"){//新数据库
                map_name = root["tableList"][i]["pointlistname"].asString();
                t_name = root["tableList"][i]["pointlistname"].asString();
                maplist[map_name] = t_name;
            }else{
                map_name = root["tableList"][i]["linkmap"].asString();
                t_name = root["tableList"][i]["pointlistname"].asString();
                maplist[map_name] = t_name;
            }

        }
    }

    return FaultCode::TRUE;  
}
/**********************************************************************
 * * @function:    WaypointDataAnalysis 
 * * @brief:       JSON字符串解释出地图路点列表单中的路点数据存入路点列表容器
 * * @input:       数据库返回JSON字符串，列表名，地图名  
 * * @output:      路点列表容器
 * * @return:      FaultCode: 返回操作结果状态码
 * * @author：     wangyong
 * * @date：       20231115
 * **********************************************************************/
FaultCode DatabaseAction::WaypointDataAnalysis(const std::string &data_content,const std::string execl_name,const std::string map_name,umap &list)
{
    // robot_msgs::Database_data srv;
    // srv.request.request_type = DB_Type::EXECL_READ;
    // srv.request.request_data = execl_name;
    // if(database_client_.call(srv))
    // {

    // Json::Value v,v1,v2;
    // Json::Reader reader;
    // if (!reader.parse(data_content, v)||v[execl_name].isNull())
    // {
    //     return false; 
    // }
    Json::Value root;
    const auto rawJsonLength = static_cast<int>(data_content.length());
    JSONCPP_STRING err;
    Json::CharReaderBuilder builder;
    const std::unique_ptr<Json::CharReader> reader(builder.newCharReader());
//    std::cout << "table list : " << data_content << std::endl;
    
    if (!reader->parse(data_content.c_str(), data_content.c_str() + rawJsonLength, &root,&err)) {
        //std::cout << "error" << std::endl;
        return FaultCode::U0412;
    }


    int8_t si=root[execl_name].size();//路点的个数
    std::vector<PointInfo> vec_pointdata;
    for(auto& s:root[execl_name])
    {
        PointInfo point; 

        point.point_name= s["pointname"].asString();
        point.point_map=map_name;
        std::string tmp = s["pointtype"].asString();
        point.point_type = tmp;
        /**************位姿数据改成字符串*******************/
           //example:{"table_name(map_name)":[{"pointname":"","pointtype":"",\
           "posedata":"pointa(x,y,yaw);pointb;pointc;..."},{...}]};

        /***********end***************/
        if(p_shard_data_->new_of_old_database_=="new"){//新数据库
            string pose_data = s["point_array"].asString();
            Tokens pose_list;
            pose_list = p_shard_data_->split(pose_data,';');

            int t_size = pose_list.size();
            for(int i = 0;i<t_size;i++){
                string sub_pose = pose_list[i];

                Tokens subpose_list;
                subpose_list = p_shard_data_->split(sub_pose,',');
                PoseData temp;

                temp.x = std::atof(subpose_list[0].c_str());
                temp.y = std::atof(subpose_list[1].c_str());
                temp.yaw = std::atof(subpose_list[2].c_str());
                point.point_array.push_back(temp);
            }

        }
        else{
            if(tmp=="cover"){


//            point.point_a.x = s["Ax"].asDouble();
//            point.point_a.y = s["Ay"].asDouble();
//            point.point_a.yaw = s["Ayaw"].asDouble();
//
//            point.point_b.x = s["Bx"].asDouble();
//            point.point_b.y = s["By"].asDouble();
//            point.point_b.yaw = s["Byaw"].asDouble();
//
//            point.point_c.x = s["Cx"].asDouble();
//            point.point_c.y = s["Cy"].asDouble();
//            point.point_c.yaw = s["Cyaw"].asDouble();
//
//            point.point_d.x = s["Dx"].asDouble();
//            point.point_d.y = s["Dy"].asDouble();
//            point.point_d.yaw = s["Dyaw"].asDouble();

                PoseData temp;

                temp.x = s["Ax"].asDouble();
                temp.y = s["Ay"].asDouble();
                temp.yaw = s["Ayaw"].asDouble();
                point.point_array.push_back(temp);

                temp.x = s["Bx"].asDouble();
                temp.y = s["By"].asDouble();
                temp.yaw = s["Byaw"].asDouble();
                point.point_array.push_back(temp);

                temp.x = s["Cx"].asDouble();
                temp.y = s["Cy"].asDouble();
                temp.yaw = s["Cyaw"].asDouble();
                point.point_array.push_back(temp);

                temp.x = s["Dx"].asDouble();
                temp.y = s["Dy"].asDouble();
                temp.yaw = s["Dyaw"].asDouble();
                point.point_array.push_back(temp);

            }else if(tmp=="access"){//门禁(闸机)点，带有控制板通讯地址
                PoseData temp;

                temp.x = s["Ax"].asDouble();
                temp.y = s["Ay"].asDouble();
                temp.yaw = s["Ayaw"].asDouble();
                point.point_array.push_back(temp);
                //other
            }else if(tmp=="left"){//乘梯点，带有控制板通讯地址
                PoseData temp;

                temp.x = s["Ax"].asDouble();
                temp.y = s["Ay"].asDouble();
                temp.yaw = s["Ayaw"].asDouble();
                point.point_array.push_back(temp);
                //other
            }else{ //普通点，原点，切换点
                PoseData temp;

                temp.x = s["Ax"].asDouble();
                temp.y = s["Ay"].asDouble();
                temp.yaw = s["Ayaw"].asDouble();
                point.point_array.push_back(temp);
            }

        }
        vec_pointdata.push_back(point);

//        std::cout<<"all :"<<point.point_type<<" "<<point.point_map <<std::endl;
    }

    list.insert({map_name,vec_pointdata});   
    return FaultCode::TRUE;
}
/**********************************************************************
 * * @function:    TargetEffectivenessCheck 
 * * @brief:       检查目标点是否存在
 * * @input:       目标名，地图名， 
 * * @output:      目标的详细信息
 * * @return:      FaultCode: 返回操作结果状态码
 * * @author：     wangyong
 * * @date：       20231115
 * **********************************************************************/
FaultCode DatabaseAction::TargetEffectivenessCheck(const string target_name,const string map_name,umap &list,PointInfo &point)
{
    //通过地图找到对应的路点容器，在通过marke标记查找具体的信息
    auto it = list.find(map_name);
    if(it != list.end()){
        auto vt = it->second; 
        auto tt = vt.begin();
        while (tt != vt.end())
        {
            if((*tt).point_name == target_name){
                point = (*tt);
                return FaultCode::TRUE;
            }
            *tt++;
        }
    }
    return FaultCode::U0414;
}