/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	move_action.cpp
 * * @description:  门禁、乘梯、覆盖，乘梯动作
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "move_action.h"

// 20240506______________________________________y add
// 定义一个静态变量来表示是否已经录制过
static bool is_recorded = false;
/**********************************************************************
 * * @function:    MoveAction 
 * * @brief:       移动动作类构造函数，初始化ROS节点句柄和通信接口
 * * @input:       nh: ROS节点句柄
 * * @output:      初始化发布器、订阅器和服务客户端
 * * @return:      无
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
MoveAction::MoveAction(ros::NodeHandle nh):nh_(nh),movebase_client_("move_base", true)
{
    nh_.param<int>("nav_version", nav_, 1); //#1move_base导航，2nav_base导航
    sub_odom_ = nh_.subscribe("/odom", 1,&MoveAction::callback_RobotVel,this);
    sub_currentmap_=nh_.subscribe("/current_map",10,&MoveAction::callback_CurrentMap,this);
    // 20240506______________________________________y add
    if(nav_==1)
    {
        sub_movebase_status_ = nh_.subscribe<actionlib_msgs::GoalStatusArray>("/move_base/status",10,&MoveAction::callback_movebase_status,this);
    }
    pub_fault_ = nh_.advertise<std_msgs::String>("ugv_fault",10);
    pub_nav_exception_ = nh_.advertise<std_msgs::Bool>("/nav_exception", 5);
    pub_cmd_vel_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
    pub_cmd_sensor_= nh_.advertise<std_msgs::String>("/cmd_sensor", 10);
    //20251018
    if(nav_==2)
    {
        sub_nav_info_ = nh_.subscribe("/system_info",1, &MoveAction::NavInfoCB, this);
        ac_client_ = new actionlib::SimpleActionClient<robot_msgs::TaskAction>("task_list", true);
        task_client_ = nh_.serviceClient<robot_msgs::TaskService>("/task_service");
    }
}
void MoveAction::Init()
{
    interval_ms_ = 100;
    std::thread t(&MoveAction::TimerThread,this,interval_ms_);//100ms一次
    t.detach();
}
/**********************************************************************
 * * @function:    TimerThread 
 * * @brief:       定时器线程函数，周期性执行主循环
 * * @input:       interval_ms: 线程执行间隔（毫秒）
 * * @output:      周期性调用MainLoop函数
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::TimerThread(int16_t interval_ms)
{
    while(ros::ok()){
        MainLoop();
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
MoveAction::~MoveAction()
{

}
/**********************************************************************
 * * @function:    slot_StatusMsg 
 * * @brief:       状态消息槽函数，处理状态和故障消息
 * * @input:       msg: 消息内容 msg_type: 消息类型（1-故障消息，其他-状态消息）
 * * @output:      发布日志或故障代码
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::slot_StatusMsg(const QString msg,const int msg_type)
{
    if(msg_type != 1){
        LOG(INFO) << msg.toStdString();
    }else{
        PublishFaultCode(msg.toStdString());
    }
    
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       新命令槽函数，处理简单字符串命令
 * * @input:       cmd: 命令字符串
 * * @output:      更新移动索引状态
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::slot_NewCmd(QString cmd)
{
    std::string tmp = cmd.toStdString();
    if(tmp=="newgoal"){
        move_index_ = MoveIndex::MOVE;
    }else if(tmp=="estop"){
        move_index_ = MoveIndex::ESTOP;
    }else if(tmp=="cancel"){
        //qDEBUG()<<"slot_NewCmd:cancel"<<endl;
        move_index_ = MoveIndex::CANCEL;
    }else if(tmp=="goon"){
        move_index_ = MoveIndex::GOON;
    }
}
/**********************************************************************
 * * @function:    slot_MoveCmd 
 * * @brief:       移动命令槽函数，处理详细导航命令
 * * @input:       movecmd: 包含移动命令数据的QVariant对象
 * * @output:      更新目标点信息和移动状态
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::slot_MoveCmd(QVariant movecmd)
{//
    LOG(INFO) << "收到了导航命令";
    p_shard_data_->move_status_ = MoveStatus::IDLE;//移动状态为到达
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();
    if(mdc.taskcmd_type == TaskStatus::T_LOCALE){//坐标数据
        move_index_ = MoveIndex::MOVE;//移动
        if(mdc.goal.size()==0)return;
        goal_.clear();
        goal_=mdc.goal;
    }else if(mdc.taskcmd_type == TaskStatus::T_ESTOP){//停止
        move_index_ = MoveIndex::ESTOP;
    }else if(mdc.taskcmd_type == TaskStatus::T_CANCEL){//取消
        //qDEBUG()<<"slot_MoveCmd:cancel"<<endl;
        move_index_ = MoveIndex::CANCEL;
    }else if(mdc.taskcmd_type == TaskStatus::T_GOON){//继续
        move_index_ = MoveIndex::GOON;
    }
//     //std::cout<<tmp<<std::endl;
}
/**********************************************************************
 * * @function:    NavInfoCB 
 * * @brief:       导航信息回调函数，接收系统信息状态
 * * @input:       msg: 系统信息消息
 * * @output:      更新导航状态
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::NavInfoCB(const std_msgs::UInt16ConstPtr &msg)
{//不适合远距离规划，当前5hz，30m长度，0.2*420=84s才规划出来jch？？？？
    //101 105
    //ROS_INFO("info received:%d",msg->data);
    // if(msg->data>=101 && msg->data<=105)
    // {
    //     p_shard_data_->now_nav_status_="running";
    // }
}
/**********************************************************************
 * * @function:    DoneCb 
 * * @brief:       动作完成回调函数，处理导航任务完成状态
 * * @input:       state: 动作状态
 * * @input:       result: 任务结果
 * * @output:      更新导航状态
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::DoneCb(const actionlib::SimpleClientGoalState &state, const robot_msgs::TaskResultConstPtr &result) {//jch这里怎么没有回调？？？？
  if (state == actionlib::SimpleClientGoalState::SUCCEEDED) {
    p_shard_data_->now_nav_status_="success";
    SetVehicleStatus("over");
    LOG(INFO) << "导航成功";
  } else if (state == actionlib::SimpleClientGoalState::ABORTED) {
    p_shard_data_->now_nav_status_="failed";
    LOG(INFO) << "导航失败";
  } else {
    LOG(INFO) << "导航异常";
  }
}
/**********************************************************************
 * * @function:    ActiveCb 
 * * @brief:       动作激活回调函数，处理导航任务开始状态
 * * @input:       无
 * * @output:      更新导航状态为运行中
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::ActiveCb() {
  p_shard_data_->now_nav_status_="running";
}
/**
 * uint8 STATUS_PAUSING = 0 # 常量
uint8 STATUS_RUNNING = 1 # 常量
#get getAlternativePlan failed 
uint8 STATUS_ABORTED_GAP = 2 # 常量
#dwa failed
uint8 STATUS_ABORTED_DWA = 3 # 常量
int32 status                         #若为进出电梯,1.进电梯失败 2.出了电梯门;其他为0
int32 current_task_index
int32 current_task_real_index        #机器人实际完成的任务点数(减去跳过的路径点数)
int32 total_task_step
float32 total_length
float32 dis_to_end
 */
/**********************************************************************
 * * @function:    FeedbackCb 
 * * @brief:       动作反馈回调函数，处理导航任务进度反馈
 * * @input:       feedback: 任务反馈信息
 * * @output:      更新导航状态和进度信息
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::FeedbackCb(const robot_msgs::TaskFeedbackConstPtr &feedback) {
    //LOG(INFO) << "feedback";
    //std::cout<<"feedback"<< feedback->status<<" total_length:"<<feedback->total_length<<" dis_to_end:"<<feedback->dis_to_end <<std::endl;
    if(feedback->status>=101 && feedback->status<=105)
    {
        p_shard_data_->now_nav_status_="running";
    }
    p_shard_data_->nav_progress_.total_length=feedback->total_length;
    //p_shard_data_->nav_progress_.dis_to_end=feedback->dis_to_end;
    p_shard_data_->nav_progress_.dis_to_end = static_cast<double>(feedback->dis_to_end);
}
/**********************************************************************
 * * @function:    SendSingleGoal 
 * * @brief:       发送单目标点导航任务
 * * @input:       goal: 目标点位姿
 * * @output:      发送动作目标到导航系统
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::SendSingleGoal(const geometry_msgs::PoseStamped::ConstPtr &goal)
{
    robot_msgs::TaskGoal action_goal;
    std::string goal_str;
    try {
        json pose;
        pose["x"] = goal->pose.position.x;
        pose["y"] = goal->pose.position.y;
        pose["theta"] = tf::getYaw(goal->pose.orientation);
        json unit;
        unit["action"] = "";
        unit["type"] = "free_goal";
        unit["nav_type"] = "free_goal";
        unit["poses"] = json::array();
        unit["poses"].clear();
        unit["poses"].push_back(pose);
        json path;
        path["id"] = 0;
        path["data"].push_back(unit);
        goal_str = path.dump();
    } catch (json::exception &e) {
        LOG(WARNING) << __FILE__ << __FUNCTION__ << __LINE__ << e.what();
    }
    action_goal.task = goal_str;
    std::cout << "single goal publish to task_base"<<std::endl;
    ac_client_->sendGoal(action_goal, boost::bind(&MoveAction::DoneCb, this, _1, _2),
        boost::bind(&MoveAction::ActiveCb, this),
        boost::bind(&MoveAction::FeedbackCb, this, _1));
}
/**********************************************************************
 * * @function:    SendFixGoal 
 * * @brief:       发送固定路径导航任务
 * * @input:       goal: 目标点位姿
 * * @output:      发送固定路径动作目标
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::SendFixGoal(const geometry_msgs::PoseStamped::ConstPtr &goal)
{
    robot_msgs::TaskGoal action_goal;
    std::string goal_str;
    try {
      json pose;
      pose["x"] = goal->pose.position.x;
      pose["y"] = goal->pose.position.y;
      pose["theta"] = tf::getYaw(goal->pose.orientation);

      json unit;
      unit["action"] = "";
      unit["type"] = "fix_path";
      unit["nav_type"] = "fix_line";
      unit["poses"] = json::array();
      unit["poses"].clear();
      unit["poses"].push_back(pose);

      json path;
      path["id"] = 0;
      path["data"].push_back(unit);
      goal_str = path.dump();
    } catch (json::exception &e) {
      LOG(WARNING) << __FILE__ << __FUNCTION__ << __LINE__ << e.what();
    }
    action_goal.task = goal_str;
    //LOG(INFO) << "fix goal publish to task_base";
    ac_client_->sendGoal(action_goal, boost::bind(&MoveAction::DoneCb, this, _1, _2),
        boost::bind(&MoveAction::ActiveCb, this),
        boost::bind(&MoveAction::FeedbackCb, this, _1));
}
/**********************************************************************
 * * @function:    SendCoverage 
 * * @brief:       发送覆盖区域导航任务
 * * @input:       coverage_path: 覆盖路径
 * * @output:      发送覆盖区域动作目标
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::SendCoverage(const nav_msgs::PathConstPtr &coverage_path)
{
  robot_msgs::TaskGoal action_goal;
  std::string goal_str;
  try {
    json unit;
    unit["action"] = "";
    unit["type"] = "area";
    unit["nav_type"] = "area";
    unit["poses"] = json::array();
    unit["poses"].clear();
    for (const auto &pose_stamped : coverage_path->poses) {
      json pose;
      pose["x"] = pose_stamped.pose.position.x;
      pose["y"] = pose_stamped.pose.position.y;
      pose["theta"] = tf::getYaw(pose_stamped.pose.orientation);
      unit["poses"].push_back(pose);
      //LOG(INFO) << "x:" << pose_stamped.pose.position.x << "y:" << pose_stamped.pose.position.y;
    }
    LOG(INFO) << "发送了" << coverage_path->poses.size() << "个点的覆盖区域任务";
    json path;
    path["id"] = 0;
    path["data"].push_back(unit);
    goal_str = path.dump();
  } catch (json::exception &e) {
    LOG(WARNING) << __FILE__ << __FUNCTION__ << __LINE__ << e.what();
  }
  action_goal.task = goal_str;
  //LOG(INFO) << "Coverage Goal publish to task_base";
    ac_client_->sendGoal(action_goal, boost::bind(&MoveAction::DoneCb, this, _1, _2),
        boost::bind(&MoveAction::ActiveCb, this),
        boost::bind(&MoveAction::FeedbackCb, this, _1));

}
//暂不支持
void MoveAction::SendFollowLine(const nav_msgs::PathConstPtr &line)
{
  robot_msgs::TaskGoal action_goal;
  std::string goal_str;
  try {
    json unit;
    unit["action"] = "";
    unit["type"] = "follow_line";
    unit["nav_type"] = "follow_line";
    unit["poses"] = json::array();
    unit["poses"].clear();
    for (const auto &pose_stamped : line->poses) {
      json pose;
      pose["x"] = pose_stamped.pose.position.x;
      pose["y"] = pose_stamped.pose.position.y;
      pose["theta"] = tf::getYaw(pose_stamped.pose.orientation);
      unit["poses"].push_back(pose);
      //LOG(INFO) << "x:" << pose_stamped.pose.position.x << "y:" << pose_stamped.pose.position.y;
    }
    json path;
    path["id"] = 0;
    path["data"].push_back(unit);
    goal_str = path.dump();
  } catch (json::exception &e) {
    LOG(WARNING) << __FILE__ << __FUNCTION__ << __LINE__ << e.what();
  }
  action_goal.task = goal_str;
  //LOG(INFO) << "Coverage Goal publish to task_base";
    ac_client_->sendGoal(action_goal, boost::bind(&MoveAction::DoneCb, this, _1, _2),
        boost::bind(&MoveAction::ActiveCb, this),
        boost::bind(&MoveAction::FeedbackCb, this, _1));

}
/**********************************************************************
 * * @function:    SendCoverage 
 * * @brief:       发送固定路径导航任务
 * * @input:       nav_msgs::Path目标路径
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::SendFixGoal(const nav_msgs::PathConstPtr &path)
{
  robot_msgs::TaskGoal action_goal;
  std::string goal_str;
  try {
    json unit;
    unit["action"] = "";
    unit["type"] = "clean_edge_follow";
    unit["nav_type"] = "clean_edge_follow";
    unit["poses"] = json::array();
    unit["poses"].clear();
    for (const auto &pose_stamped : path->poses) {
      json pose;
      pose["x"] = pose_stamped.pose.position.x;
      pose["y"] = pose_stamped.pose.position.y;
      pose["theta"] = tf::getYaw(pose_stamped.pose.orientation);
      unit["poses"].push_back(pose);
      //LOG(INFO) << "x:" << pose_stamped.pose.position.x << "y:" << pose_stamped.pose.position.y;
    }
    json m;
    m["id"] = 0;
    m["data"].push_back(unit);
    goal_str = m.dump();
  } catch (json::exception &e) {
    LOG(WARNING) << __FILE__ << __FUNCTION__ << __LINE__ << e.what();
  }
  action_goal.task = goal_str;
  //LOG(INFO) << "Coverage Goal publish to task_base";
    ac_client_->sendGoal(action_goal, boost::bind(&MoveAction::DoneCb, this, _1, _2),
        boost::bind(&MoveAction::ActiveCb, this),
        boost::bind(&MoveAction::FeedbackCb, this, _1));

}
/**********************************************************************
 * * @function:    SendCoverage 
 * * @brief:       发送固定路径导航任务
 * * @input:       nav_msgs::Path目标路径
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::SendFixGoalCover(const nav_msgs::PathConstPtr &path)
{
  robot_msgs::TaskGoal action_goal;
  std::string goal_str;
  try {
    json unit;
    unit["action"] = "";
    unit["type"] = "fix_path";
    unit["nav_type"] = "fix_line";
    unit["poses"] = json::array();
    unit["poses"].clear();
    for (const auto &pose_stamped : path->poses) {
      json pose;
      pose["x"] = pose_stamped.pose.position.x;
      pose["y"] = pose_stamped.pose.position.y;
      pose["theta"] = tf::getYaw(pose_stamped.pose.orientation);
      unit["poses"].push_back(pose);
      //LOG(INFO) << "x:" << pose_stamped.pose.position.x << "y:" << pose_stamped.pose.position.y;
    }
    json m;
    m["id"] = 0;
    m["data"].push_back(unit);
    goal_str = m.dump();
  } catch (json::exception &e) {
    LOG(WARNING) << __FILE__ << __FUNCTION__ << __LINE__ << e.what();
  }
  action_goal.task = goal_str;
  //LOG(INFO) << "Coverage Goal publish to task_base";
    ac_client_->sendGoal(action_goal, boost::bind(&MoveAction::DoneCb, this, _1, _2),
        boost::bind(&MoveAction::ActiveCb, this),
        boost::bind(&MoveAction::FeedbackCb, this, _1));

}
//主循环
void MoveAction::MainLoop()
{
    switch(move_index_)
    {
        case MoveIndex::WAIT://等待
            break;
        case MoveIndex::MOVE://send goal
        {
            FaultCode ret = MoveGoal(goal_);
            if(ret == FaultCode::TRUE){//MoveGoal请求moebase成功
                move_index_ = MoveIndex::STATUS;//等待action状态
                p_shard_data_->move_status_ = MoveStatus::RUNNING;//移动
                LOG(INFO) << "MoveGoal running";
            }else{
                // std::cout << "ERROR;navtask_node;等待move_base actionserver启动" << std::endl;
                // LOG(ERROR) << "等待move_base actionserver启动";
            }
        }
            break;
        case MoveIndex::STATUS://get status 等待action状态
        {
            if(nav_==1 && movebase_client_.getState() == actionlib::SimpleClientGoalState::SUCCEEDED
                || nav_==2 && p_shard_data_->now_nav_status_=="success"){//成功。移动状态变为到达
                move_index_=MoveIndex::WAIT;//状态置位
                p_shard_data_->move_status_ = MoveStatus::ARRIVE;//移动状态为到达
                LOG(INFO) << "导航成功";
            }else if(nav_==1 && movebase_client_.getState() == actionlib::SimpleClientGoalState::ABORTED
                ||nav_==2 && p_shard_data_->now_nav_status_=="failed"){//规划失败
                p_shard_data_->move_status_ = MoveStatus::ABORTED;//移动状态为到达
                move_index_=MoveIndex::WAIT;//规划失败,等待
                LOG(INFO) << "规划失败";
                //规划失败，是全局还是局部，原因：
                /*
                定位？判断定位是否出现问题，如果是定位出现问题，取消导航，上报主控处置。
                人群围观？检测是否有人群围观，语音辅助，静止等待。
                代价地图未清空？检查机器人是否陷入障碍物中，对模型内的障碍进行局部清除
                狭窄区域？判断是否由于环境变换造成的狭窄区域，启用狭窄区域模式
                通道上有障碍物？取消任务，上报任务失败原因
                其他
                */
            }
            
        }
            break;
        case MoveIndex::ESTOP://estop 停止
            {
                if(nav_==1)
                {
                    movebase_client_.cancelGoal();
                }
                if(nav_==2)
                {
                    robot_msgs::TaskService srv;
                    srv.request.actionIndex=0;//REQUEST_PAUSE = 0,REQUEST_START = 1,REQUEST_QUIT = 2,
                    if(task_client_.call(srv))
                    {
                        //srv.response.succeeded;//反馈编码？等待完善
                    }
                }
                move_index_ = MoveIndex::WAIT;//状态为停止
                p_shard_data_->move_status_ = MoveStatus::ESTOP;//移动状态为停止
            }
            break;
        case MoveIndex::GOON://goon 继续
            {
                if(nav_==1)
                {
                    move_index_ = MoveIndex::MOVE;
                }
                if(nav_==2)
                {
                    robot_msgs::TaskService srv;
                    srv.request.actionIndex=1;//REQUEST_PAUSE = 0,REQUEST_START = 1,REQUEST_QUIT = 2,
                    if(task_client_.call(srv))
                    {
                        move_index_ = MoveIndex::STATUS;
                        //srv.response.succeeded;//反馈编码？等待完善
                        LOG(INFO) << "REQUEST_START";
                    }
                }
                p_shard_data_->move_status_ = MoveStatus::RUNNING;
            }
            break;
        case MoveIndex::CANCEL://cancel 取消
            if (!p_shard_data_->current_lift_state_)
            {
                // movebase_client_.cancelGoal();
                if(nav_==2)
                {
                    robot_msgs::TaskService srv;
                    srv.request.actionIndex=2;//REQUEST_PAUSE = 0,REQUEST_START = 1,REQUEST_QUIT = 2,
                    if(task_client_.call(srv))
                    {
                        //srv.response.succeeded;//反馈编码？等待完善
                    }
                }
                move_index_ = MoveIndex::WAIT;
                p_shard_data_->move_status_ = MoveStatus::CANCEL;
            }
            break;
    }
}
/**********************************************************************
 * * @function:    MoveGoal 
 * * @brief:       移动到指定目标点
 * * @input:       x: 目标点x坐标 y: 目标点y坐标 yaw: 目标点朝向 point_type: 点类型（普通、狭窄、贴边等）
 * * @output:      发送导航目标
 * * @return:      FaultCode: 返回操作结果状态码
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
//移动到目标点
FaultCode MoveAction::MoveGoal(const std::vector<PoseData>& cmd_goal)
{
    if(cmd_goal.size()==0)return FaultCode::U0414;
    if(nav_==1)
    {
        /****NORMAL = 0,    NARROW = 1,    EDGE_CLEAN = 2,    TWO_POINTS_CLEAN = 3,
         *     NO_YAW = 4,    NARROW_NO_YAW = 5,    EDGE_CLEAN_NO_YAW = 6, */
        if (! movebase_client_.waitForServer()){
    //        //std::cout << "MoveToGoalPoint , xGoal : " << xGoal <<", yGoal : " << yGoal << ", yaw :" << yaw << std::endl;
            // std::cout << "ERROR;navtask_node;等待move_base actionserver启动" << std::endl;
            // LOG(ERROR) << "等待move_base actionserver启动";
            return FaultCode::FALSE;
        }
        move_base_msgs::MoveBaseGoal goal;
        //指定地图参考系
        goal.target_pose.header.frame_id = "map";
        goal.target_pose.header.stamp = ros::Time::now();
        //移动目标设定位姿 xyz和四元数
        goal.target_pose.pose.position.x = cmd_goal[0].x;
        goal.target_pose.pose.position.y = cmd_goal[0].y;
        goal.target_pose.pose.position.z= cmd_goal[0].type;
    //
    //    goal.target_pose.pose.orientation.x = 0.0;
    //    goal.target_pose.pose.orientation.y = 0.0;
        goal.target_pose.pose.orientation=tf::createQuaternionMsgFromYaw(cmd_goal[0].yaw);
        if(!isQuaternionValid(goal.target_pose.pose.orientation)){
        goal.target_pose.pose.orientation.z = 0;
        goal.target_pose.pose.orientation.w = 1;
        }
        movebase_client_.sendGoal(goal);//请求movebase
    }
    if(nav_==2)
    {/***   NORMAL = 0,//普通点
            NARROW = 1,//狭窄
            EDGE_CLEAN = 2,//贴边点
            TWO_POINTS_CLEAN = 3,//两点直线
            NO_YAW = 4,//没有方向
            NARROW_NO_YAW = 5,//狭窄没有方向
            EDGE_CLEAN_NO_YAW = 6//贴边点没有方向 
    */
                // 处理多点路径
        if(cmd_goal.size() > 1 && cmd_goal[0].type == GlobalPlannerType::FIX_PATH)
        {
            LOG(INFO) << "处理多点固定路径，点数: " << cmd_goal.size();
            
            boost::shared_ptr<nav_msgs::Path> path(new nav_msgs::Path);
            path->header.frame_id = "map";
            path->header.stamp = ros::Time::now();
            
            for(auto& pose : cmd_goal)
            {
                geometry_msgs::PoseStamped pose_stamped;
                pose_stamped.header = path->header;
                pose_stamped.pose.position.x = pose.x;
                pose_stamped.pose.position.y = pose.y;
                pose_stamped.pose.position.z = 0.0;
                pose_stamped.pose.orientation = tf::createQuaternionMsgFromYaw(pose.yaw);
                path->poses.push_back(pose_stamped);
            }
            SetVehicleStatus("edge");
            SendFixGoal(path);  // 发送完整路径
            return FaultCode::TRUE;
        }else if(cmd_goal.size() > 1 && cmd_goal[0].type == GlobalPlannerType::COVER_PATH)
        {
            LOG(INFO) << "处理多点固定路径，点数: " << cmd_goal.size();
            
            boost::shared_ptr<nav_msgs::Path> path(new nav_msgs::Path);
            path->header.frame_id = "map";
            path->header.stamp = ros::Time::now();
            
            for(auto& pose : cmd_goal)
            {
                geometry_msgs::PoseStamped pose_stamped;
                pose_stamped.header = path->header;
                pose_stamped.pose.position.x = pose.x;
                pose_stamped.pose.position.y = pose.y;
                pose_stamped.pose.position.z = 0.0;
                pose_stamped.pose.orientation = tf::createQuaternionMsgFromYaw(pose.yaw);
                path->poses.push_back(pose_stamped);
            }
            
            SendFixGoalCover(path);  // 发送完整路径
            return FaultCode::TRUE;
        }
        else if(cmd_goal[0].type!=GlobalPlannerType::COVERAGE)
        {
            boost::shared_ptr<geometry_msgs::PoseStamped> goal(new geometry_msgs::PoseStamped);
            goal->header.frame_id="map";
            goal->header.stamp=ros::Time::now();
            goal->pose.position.x=cmd_goal[0].x;
            goal->pose.position.y=cmd_goal[0].y;
            goal->pose.position.z=0.0;
            goal->pose.orientation=tf::createQuaternionMsgFromYaw(cmd_goal[0].yaw);
            SendSingleGoal(goal);
        }
        else
        {
            boost::shared_ptr<nav_msgs::Path> goal(new nav_msgs::Path);
            goal->header.frame_id="map";
            goal->header.stamp=ros::Time::now();
            geometry_msgs::PoseStamped goal_pose;
            goal_pose.header=goal->header;
            for(auto& pose:cmd_goal)
            {
                goal_pose.pose.position.x=pose.x;
                goal_pose.pose.position.y=pose.y;
                goal_pose.pose.position.z=0.;
                goal_pose.pose.orientation=tf::createQuaternionMsgFromYaw(pose.yaw);
                goal->poses.push_back(goal_pose);
            }
            SendCoverage(goal);
            //SendFollowLine(goal);
            //SendFixGoal(goal);
        }
        //SendFixGoal(const geometry_msgs::PoseStamped::ConstPtr &goal)
        //SendCoverage(const nav_msgs::PathConstPtr &coverage_path);
    }
    return FaultCode::TRUE;
}
/**********************************************************************
 * * @function:    isQuaternionValid 
 * * @brief:       检查四元数是否有效
 * * @input:       q: 四元数
 * * @output:      无
 * * @return:      bool: true表示有效，false表示无效
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
bool MoveAction::isQuaternionValid(const geometry_msgs::Quaternion& q)
{
    if(!std::isfinite(q.x) || !std::isfinite(q.y) || !std::isfinite(q.z) || !std::isfinite(q.w)){
      //ROS_ERROR("Quaternion has nans or infs... discarding as a navigation goal");
      return false;
    }

    tf2::Quaternion tf_q(q.x, q.y, q.z, q.w);

    if(tf_q.length2() < 1e-6){
      //ROS_ERROR("Quaternion has length close to zero... discarding as navigation goal");
      return false;
    }

    tf_q.normalize();

    tf2::Vector3 up(0, 0, 1);

    double dot = up.dot(up.rotate(tf_q.getAxis(), tf_q.getAngle()));

    if(fabs(dot - 1) > 1e-3){
      //ROS_ERROR("Quaternion is invalid... for navigation the z-axis of the quaternion must be close to vertical.");
      return false;
    }

    return true;
}
/**********************************************************************
 * * @function:    callback_RobotVel 
 * * @brief:       机器人速度回调函数，接收里程计数据
 * * @input:       msg: 里程计消息
 * * @output:      更新机器人速度信息
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::callback_RobotVel(const nav_msgs::Odometry::ConstPtr &msg)
{
    //robot_speed_.linear_x=msg->twist.twist.linear.x;
    //robot_speed_.angular_z=msg->twist.twist.angular.z;
}
/**********************************************************************
 * * @function:    callback_CurrentMap 
 * * @brief:       当前地图回调函数，接收地图切换信息
 * * @input:       msg: 地图名称消息
 * * @output:      更新当前地图信息
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::callback_CurrentMap(const std_msgs::String::ConstPtr &msg)
{
    std::string robot_map = msg->data;
    if(p_shard_data_->current_map_!= robot_map && robot_map != "")
    {
    	//std::cout << "curr_map_ : " << p_shard_data_->current_map_ << ",robot_map : " << robot_map << std::endl;
        p_shard_data_->current_map_ = robot_map;
//        p_shard_data_->SetCurrentMap(robot_map);
    } 
}
/**********************************************************************
 * * @function:    callback_movebase_status 
 * * @brief:       move_base状态回调函数，监控导航状态
 * * @input:       msg: 动作状态数组
 * * @output:      更新导航异常标志
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::callback_movebase_status(const actionlib_msgs::GoalStatusArray::ConstPtr& msg)
{
    if(!msg->status_list.empty())
    {
       if(msg->status_list.size() < 2)
       {
            status = msg->status_list[0].status;
            if((status == 2 || status == 4 || status == 5) && is_recorded == true)
            {
                nav_exception_flag_ = true;
                is_recorded = true;
                //WakeUpNavException();

                std_msgs::Bool m;
                m.data = false;
                pub_nav_exception_.publish(m);
            }else if(status == 0 || status == 1 || status == 3|| status == 6 || 
            status == 7 || status == 8 || status == 9 )
            {
                nav_exception_flag_ = false;
                is_recorded = true;
            }
       }else{
            nav_exception_flag_ = false;
            is_recorded = true;
       } 
    }else{
        nav_exception_flag_ = false;
        is_recorded = true;
    }
}
/**********************************************************************
 * * @function:    PublishFaultCode 
 * * @brief:       发布故障代码信息
 * * @input:       data: 故障代码
 * * @output:      发布故障消息
 * * @return:      void：无返回值
 * * @author：     wangyong
 * * @date：       20231115
 * **********************************************************************/
void MoveAction::PublishFaultCode(const std::string& data)
{
    std_msgs::String msg;
    msg.data = data;
    pub_fault_.publish(msg);
}
/**********************************************************************
 * * @function:    PublishVelocity 
 * * @brief:       发布速度控制命令
 * * @input:       data: 速度控制数据
 * * @output:      发布速度消息
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::PublishVelocity(CmdVelStr& data)
{
    geometry_msgs::Twist msg;
    msg.angular.z = data.angular;
    msg.linear.x = data.linear;
    pub_cmd_vel_.publish(msg);
};
/**********************************************************************
 * * @function:    slot_CmdVel 
 * * @brief:       速度命令槽函数，处理速度控制命令
 * * @input:       data: 速度控制数据
 * * @output:      发布速度消息
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void MoveAction::slot_CmdVel(CmdVelStr data)
{
    PublishVelocity(data);
};
/**********************************************************************
 * * @function:    SetVehicleStatus 
 * * @brief:       获取车状态
 * * @input:       msg:闸机状态
 * * @output:      无
 * * @return:      void：无返回
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void MoveAction::SetVehicleStatus(const std::string& new_status)
{
        std_msgs::String msg;
        msg.data = new_status;
        pub_cmd_sensor_.publish(msg);
}