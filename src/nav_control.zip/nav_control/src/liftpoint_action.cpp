/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	interface_action.cpp
 * * @description:  门禁、乘梯、覆盖，乘梯动作
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "liftpoint_action.h"

LiftpointAction::LiftpointAction(ros::NodeHandle nh):nh_(nh)
{
    client_elevator_ = nh_.serviceClient<robot_msgs::Elevator>("/srv_elevator");//请求门禁
    sub_running_result_ = nh_.subscribe<std_msgs::String>("/elevator_status", 2, &LiftpointAction::callback_ElevatorResult, this);//订阅乘梯门禁话题
}
/**********************************************************************
 * * @function:    callback_ElevatorResult 
 * * @brief:       乘梯状态回调函数，接收乘梯模块的运行状态
 * * @input:       msg: 乘梯状态消息
 * * @output:      更新内部运行状态变量
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void LiftpointAction::callback_ElevatorResult(const std_msgs::String::ConstPtr &msg)
{
    running_state_ = msg->data;
}
/**********************************************************************
 * * @function:    Init 
 * * @brief:       初始化乘梯动作模块，启动定时器线程
 * * @input:       无
 * * @output:      启动主循环线程
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void LiftpointAction::Init()
{
    interval_ms_ = 100;
    std::thread t(&LiftpointAction::TimerThread,this,interval_ms_);
    t.detach();
}
/**********************************************************************
 * * @function:    TimerThread 
 * * @brief:       定时器线程函数，周期性执行主循环
 * * @input:       interval_ms: 线程执行间隔（毫秒）
 * * @output:      周期性调用MainLoop函数
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void LiftpointAction::TimerThread(int16_t interval_ms)
{
    while(ros::ok()){
        if(!thread_pause_flag_){
            //work
            MainLoop();
        }
        ros::spinOnce();
        
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       处理新的控制命令槽函数
 * * @input:       movecmd: 包含移动命令数据的QVariant对象
 * * @output:      更新线程状态和乘梯状态，发布状态信号
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void LiftpointAction::slot_NewCmd(QVariant movecmd)
{
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();

    if(mdc.taskcmd_type == TaskStatus::T_ESTOP){
        if((lift_status_==LiftStatus::STEP1)||(lift_status_==LiftStatus::STEP2)){//正在乘梯过程中
            emit signal_PubStatus("STOP_RUNNING");
            lift_stop_=true;
            LOG(INFO) << "liftpoint_action，在乘梯时发送暂停命令";
        }else{
            thread_pause_flag_ = true;
            lift_status_ = LiftStatus::INIT;
            emit signal_PubStatus("STOP");
        }
        if (thread_pause_flag_== false){
            robot_msgs::Elevator srv;
            srv.request.type = "stop";
            if(!client_elevator_.waitForExistence(ros::Duration(10)))
            {
                LOG(ERROR) << "srv_elevator died";
            }
            if (client_elevator_.call(srv))
            {
                std::string response_status = srv.response.status;
                LOG(INFO) << "service RESPONSE " << response_status;
            }
            else
            {
                LOG(ERROR) << "service call failed";
            }

        }

    }else if(mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP){
        if((lift_status_==LiftStatus::STEP1)||(lift_status_==LiftStatus::STEP2)){//正在乘梯过程中
            emit signal_PubStatus("STOP_RUNNING");
            lift_stop_=true;
            LOG(INFO) << "accesspoint_action,liftpoint_action，在乘梯时发送暂停命令";
        }else{
            thread_pause_flag_ = true;
            lift_status_ = LiftStatus::INIT;
            emit signal_PubStatus("STOP");
        }
    }else if(mdc.taskcmd_type == TaskStatus::T_CANCEL){
        if((lift_status_==LiftStatus::STEP1)||(lift_status_==LiftStatus::STEP2)){//正在乘梯过程中
            emit signal_PubStatus("CANCEL_RUNNING");
            p_shard_data_->lift_cancel_=true;
            LOG(INFO) << "accesspoint_action,liftpoint_action，在乘梯时发送取消命令";
        }else{
            emit signal_PubStatus("CANCEL");
            thread_pause_flag_ = true;
            lift_status_ = LiftStatus::INIT;
        }
    }else if(mdc.taskcmd_type == TaskStatus::T_GOON){
        lift_status_ = LiftStatus::INIT;
        thread_pause_flag_ = false;
    }else if (mdc.taskcmd_type == TaskStatus::T_END)
    {
        if (thread_pause_flag_ == false)
        {
            robot_msgs::Elevator srv;
            srv.request.type = "cancel";
            if(!client_elevator_.waitForExistence(ros::Duration(10)))
            {
                LOG(ERROR) << "srv_elevator died";
            }
            if (client_elevator_.call(srv))
            {
                std::string response_status = srv.response.status;
                LOG(INFO) << "service RESPONSE " << response_status;
            }
            else
            {
                LOG(ERROR) << "请求乘梯停止没有响应Failed to call elevator service.";
            }
        }
        emit signal_PubStatus("CANCEL");
        thread_pause_flag_ = true;
        lift_status_ = LiftStatus::INIT;
        
        
    }
    
    //std::cout<<"liftpoint recv new cmd:"<<std::endl;
}
//接收navcontrol指令的public接口
void LiftpointAction::SetCmd(std::string cmd_type)
{

}
//接收navcontrol指令的public接口
void LiftpointAction::SetCmd(std::string cmd_type,PoseData pdata)
{
    mtx_.lock();

    mtx_.unlock();
}
/**********************************************************************
 * * @function:    slot_NewTask 
 * * @brief:       处理新任务槽函数，解析乘梯任务数据
 * * @input:       ntask: 包含乘梯任务信息的JSON字符串
 * * @output:      更新目标点信息和乘梯状态，启动乘梯流程
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void LiftpointAction::slot_NewTask(const QString ntask)
{
    //解包
    thread_pause_flag_=false;
    QJsonDocument jsdoc = QJsonDocument::fromJson(ntask.toUtf8());
    if(!jsdoc.isNull()){
        if(jsdoc.isObject()){
            QJsonObject job = jsdoc.object();
            goal_point_.x = job["l_x"].toDouble();
            goal_point_.y = job["l_y"].toDouble();
            goal_point_.yaw = job["l_yaw"].toDouble();
            goal_point_.map = job["l_map"].toString().toStdString();
            floor_number_ = job["floornumber"].toString().toStdString();
            LOG(INFO) << "收到了乘梯信号: goal_point_.x：" << goal_point_.x << ", goal_point_.y:" << goal_point_.y << ", goal_point_.yaw:" << goal_point_.yaw << ", floor_number_:" << floor_number_ << ", map_:" << goal_point_.map;
            goal_point_.yaw=YawNormalize(goal_point_.yaw+M_PI);
            lift_status_ = LiftStatus::STEP1;

        }else{
            p_shard_data_->fault_code_.B0607=true;
            p_shard_data_->lift_nav_status_.goal_status=NavStatus::NAV_FAILED;
            lift_status_ = LiftStatus::INIT;
            LOG(ERROR) << "jsdoc.isnoObject()";
            thread_pause_flag_=true;
        }
    }else{
        p_shard_data_->fault_code_.B0607=true;
        p_shard_data_->lift_nav_status_.goal_status=NavStatus::NAV_FAILED;
        lift_status_ = LiftStatus::INIT;
        LOG(ERROR) << "jsdoc.isNull()";
        thread_pause_flag_=true;
    }

}
/**********************************************************************
 * * @function:    YawNormalize 
 * * @brief:       归一化角度到(-π, π]区间
 * * @input:       yaw: 原始角度值
 * * @output:      无
 * * @return:      double: 归一化后的角度值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
double LiftpointAction::YawNormalize(double yaw) {
    while (yaw > M_PI) {
        yaw -= 2 * M_PI;
    }
    while (yaw < -M_PI) {
        yaw += 2 * M_PI;
    }
    return yaw;
}
/**********************************************************************
 * * @function:    GetFloorNo 
 * * @brief:       从地图名称中提取楼层号 地图名称格式：jc_B1_4F_area1 → 提取"4F"
 * * @input:       map_name: 地图名称字符串
 * * @output:      无
 * * @return:      std::string: 提取的楼层号，默认返回"0F"      
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
std::string LiftpointAction::GetFloorNo(std::string map_name)
{
    std::string floor_no = "0F";
    char split_c = '_';
    std::vector<std::string> str_results;
    if (map_name == ""){
        LOG(ERROR) << "map_name is null.";
        return floor_no;
    }
    size_t pos = map_name.find(split_c);
    // 返回npos说明没有找到这个字符
    while (pos != map_name.npos)
    {
        std::string temp = map_name.substr(0, pos);
        str_results.push_back(temp);
        map_name = map_name.substr(pos + 1, map_name.size());
        pos = map_name.find(split_c);
    }
    if(str_results.size() > 2)
    {
        floor_no = str_results[2].substr(0, str_results[2].length() - 1);
        //std::cout << "floor no : " << floor_no <<std::endl;
        LOG(ERROR) << "floor no : " << floor_no;
        return floor_no;
    } else {
        LOG(WARNING) << map_name << "  did not find the floor number";
        return floor_no;
    }
}
/**********************************************************************
 * * @function:    MainLoop 
 * * @brief:       乘梯动作主循环，实现乘梯状态机 使用状态机管理乘梯流程：初始化→请求乘梯→等待乘梯完成
 * * @input:       无
 * * @output:      控制乘梯流程，更新导航状态
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void LiftpointAction::MainLoop()
{
    switch (lift_status_)
    {
    case LiftStatus::INIT:
        if(lift_status_ == LiftStatus::STEP1){
            //得到乘梯点及目标楼层，先到达乘梯点，然后调用乘梯服务

        }
        break;
    case LiftStatus::STEP1:
    {
        std::string tmp_string = "";
        robot_msgs::Elevator srv;
        srv.request.type = "start";
        //获取目标楼层编号
        int current_floor = std::atoi(floor_number_.c_str());
        srv.request.aim_floor = current_floor;
        //获取当前楼层编号
        std::string floor_no = GetFloorNo(p_shard_data_->current_map_);//获取现在的楼层号 1 2 3
        srv.request.current_floor = std::atoi(floor_no.c_str());
//            //std::cout << "srv.request.current_floor : "<< std::to_string(srv.request.current_floor) << std::endl;
        robot_msgs::Point aim_outer_lift_point;
        //20231202jiangcuihuan 乘梯点处切图
        aim_outer_lift_point.name = goal_point_.map;
        aim_outer_lift_point.x = goal_point_.x;
        aim_outer_lift_point.y =goal_point_.y;
        aim_outer_lift_point.yaw =goal_point_.yaw;
        LOG(INFO) << "aim_map:" << aim_outer_lift_point.name
                   <<" x=" << aim_outer_lift_point.x
                   <<" y=" << aim_outer_lift_point.y
                   <<" yaw=" << aim_outer_lift_point.yaw
                   <<" current_floor=" << srv.request.current_floor
                   <<" aim_floor=" << srv.request.aim_floor;

        srv.request.pose = aim_outer_lift_point;
        if(!client_elevator_.waitForExistence(ros::Duration(10)))
        {
            LOG(ERROR) << "srv_elevator died";
        }
        if (client_elevator_.call(srv))
        {
            std::string response_status = srv.response.status;
            LOG(INFO) << "service RESPONSE " << response_status;
            size_t pos = response_status.find("failed");
            if (pos != response_status.npos) // 调乘梯失败
            {
                //打印报错日志
                p_shard_data_->fault_code_.B0601 = true;
                lift_status_ = LiftStatus::STEP2;
                LOG(ERROR) << "请求乘梯有响应 但返回的是失败";
            }
            else{
                p_shard_data_->fault_code_.B0601 =false;
                running_state_="";//20231107jiang 复位状态
                lift_status_ = LiftStatus::STEP2;
                LOG(INFO) << "请求乘梯成功,等待乘梯状态";
                // running_state_

            }
        }
        else  {
            p_shard_data_->fault_code_.B0601 =true;
            p_shard_data_->lift_nav_status_.goal_status=NavStatus::NAV_FAILED;
            lift_status_ = LiftStatus::INIT;
            LOG(ERROR) << "请求乘梯没有响应Failed to call elevator service.";
            thread_pause_flag_=true;
        }


    }
        break;
    case LiftStatus::STEP2:
    {
        static std::string lift_status="";
        if(lift_status!=running_state_)
        {
            lift_status=running_state_;
            emit signal_PubStatus("GOTO_LIFT_"+running_state_);
        }
        if(running_state_ == "OVER"){
            if((!p_shard_data_->lift_cancel_)&&(!lift_stop_)){
                lift_status_ = LiftStatus::INIT;
                p_shard_data_->lift_nav_status_.goal_status=NavStatus::NAV_SUCCESS;
                p_shard_data_->fault_code_.B0606=false;
                LOG(INFO) << "乘梯成功";
                if(p_shard_data_->curr_lift_point_type_=="back"){
                    emit signal_PubStatus("GOTO_back");
                }else{
                    emit signal_PubStatus("GOTO_"+p_shard_data_->curr_lift_point_name_);
                }
                //emit signal_PubStatus(p_shard_data_->now_nav_status_);
                thread_pause_flag_=true;
            }else{//这时已经发送了cancel
                lift_status_ = LiftStatus::INIT;
                p_shard_data_->lift_nav_status_.goal_status=NavStatus::NAV_SUCCESS;
                p_shard_data_->fault_code_.B0606=false;
                if(p_shard_data_->lift_cancel_){
                    lift_status_ = LiftStatus::INIT;
                    emit signal_PubStatus("CANCEL");
                    LOG(INFO) << "在乘梯时发送取消命令，乘梯已经成功";
                    p_shard_data_->lift_cancel_= false;//复位
                    if (p_shard_data_->current_lift_state_)
                    {
                        LOG(INFO) << "在乘梯时发送新指令，乘梯已经成功,可以执行下一个命令";
                        p_shard_data_->access_lift_shared_nav_status_.goal_status=NavStatus::NAV_SUCCESS;
                    }
                    thread_pause_flag_=true;
                }else if(lift_stop_){
                    lift_status_ = LiftStatus::INIT;
                    emit signal_PubStatus("STOP");
                    LOG(INFO) << "在乘梯时发送暂停命令，乘梯已经成功";
                    lift_stop_= false;//复位
                    thread_pause_flag_=true;

                }
            }

        }else if(running_state_ == "FAULT"){
            p_shard_data_->lift_nav_status_.goal_status=NavStatus::NAV_FAILED;
            lift_status_ = LiftStatus::INIT;
            p_shard_data_->fault_code_.B0606=true;
            LOG(INFO) << "乘梯失败，状态为FAULT";
            thread_pause_flag_=true;
        }

    }
        break;
    case LiftStatus::FAILED:
        {
            
        }
        break;
    default:
        break;
    }
}