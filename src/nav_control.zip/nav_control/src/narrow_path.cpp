/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	narrow_path.cpp
 * * @description:   1.遇障碍避让 2.路径平滑 3.无碰撞地通过闸或窄通道 4.沿中间线行驶
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include <iostream>
#include "narrow_path.h"
using namespace narrow_path;
NarrowPath::NarrowPath(ros::NodeHandle nh) : nh_(nh)
{
    nh_.param("max_linear_velocity", max_linear_velocity_, 0.6);
    nh_.param("max_angular_velocity", max_angular_velocity_, 0.3);
    nh_.param("min_linear_velocity", min_linear_velocity_, 0.0);
    nh_.param("min_angular_velocity", min_angular_velocity_, 0.0);

    nh_.param("footprint_threshold", footprint_threshold_, 0.05);
    nh_.param("robot_radius", robot_radius_, 0.3);
    nh_.param("detect_angle", detect_angle_, M_PI / 2); // M_PI/4
    nh_.param("forward_distance", forward_distance_, 1.0);
    //过门禁距离判断阈值
    nh_.param("judge_depth", judge_depth_, 0.525);
    int nav_;
    nh_.param<int>("nav_version", nav_, 1); //#1move_base导航，2nav_base导航
	if(nav_==1)
    {
        nav_node_="/move_base";
    }
    if(nav_==2)
    {
        nav_node_="/task_base";
    }
    cmd_vel_pub_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 1);
    assist_point_pub_ = nh_.advertise<geometry_msgs::PoseStamped>("/assist_point", 1);
    footprint_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/footprint", 1);
    ref_footprint_pub_ = nh_.advertise<visualization_msgs::MarkerArray>("/ref_footprint", 1);
    // real_footprint_pub_=nh_.advertise<visualization_msgs::MarkerArray>("/real_footprint",1);
    path_sub_ = nh_.subscribe(nav_node_+"/DWAPlannerROS/eb_global_plan", 1, &NarrowPath::PathCallback, this);
    service_client_ = (nav_node_=="/task_base") ?
                        nh_.serviceClient<robot_msgs::GetPlanService>(nav_node_+"/make_plan"):
                        nh_.serviceClient<nav_msgs::GetPlan>(nav_node_+"/make_plan");

    test_pub_ = nh_.advertise<sensor_msgs::LaserScan>("/trans_scan", 1);
    scan_sub_ = nh_.subscribe("/scan", 1, &NarrowPath::ScanCallback, this); // 应改为scan

    // sub_goal_ = nh_.subscribe("/move_base_simple/goal", 1, &NarrowPath::GoalCallback, this);
    sub_clicked_point_ = nh_.subscribe("/clicked_point", 1, &NarrowPath::ClickedPointCallback, this);
    sub_camera_to_scan_ = nh_.subscribe<sensor_msgs::LaserScan>("/camera_to_scan", 1, &NarrowPath::CameraToScanCB, this);

    detect_angle_ = atan(detect_angle_);
    footprint_radius_ = robot_radius_ + footprint_threshold_;
    robot_r_ = 0.02;

    move_step_ = 0;
    vel_index_ = 0;
    flg_obstacle_ = false;
    is_waiting_obstacle_ = false;
}
NarrowPath::~NarrowPath() {}
/**********************************************************************
 * * @function:    PublishFootprint 
 * * @brief:       rviz显示机器人壳体footprint
 * * @input:       footprint: 足迹数据向量 footprint_pub: 足迹发布器
 * * @output:      发布可视化标记数组
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::PublishFootprint(std::vector<Footprint> &footprint, ros::Publisher &footprint_pub)
{
    visualization_msgs::MarkerArray footprint_msg;
    footprint_msg.markers.resize(footprint.size());

    visualization_msgs::MarkerArray heading_msg;
    heading_msg.markers.resize(footprint.size());
    std::string marker_heading_name_space = "footprint";
    marker_heading_name_space.append("_heading");

    // convert elastic band to msg
    for (unsigned int i = 0; i < ((unsigned int)footprint.size()); i++)
    {
        FootprintToMarker(footprint[i], footprint_msg.markers[i], i, red);
    }
    // publish
    footprint_pub.publish(footprint_msg);
}
/**********************************************************************
 * * @function:    ClickedPointCallback 
 * * @brief:       RViz点击点回调函数，接收用户点击的路径点
 * * @input:       msg: 点击点消息
 * * @output:      更新点击点集合
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::ClickedPointCallback(const geometry_msgs::PointStampedConstPtr &msg)
{
    //ROS_INFO("clicked point: x: %f, y: %f", msg->point.x, msg->point.y);
    if (clicked_points_.size() >= 2)
    {
        clicked_points_.clear();
    }
    geometry_msgs::Pose2D point;
    point.x = msg->point.x;
    point.y = msg->point.y;
    point.theta = 5.;
    clicked_points_.push_back(point);
}
/**********************************************************************
 * * @function:    FootprintToMarker 
 * * @brief:       将足迹数据转换为RViz标记
 * * @input:       footprint: 足迹数据 marker: 输出标记 i: 标记索引 marker_color: 标记颜色
 * * @output:      填充标记数据
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::FootprintToMarker(Footprint &footprint, visualization_msgs::Marker &marker, unsigned int &i, Color marker_color)
{
    geometry_msgs::Pose2D tmp_pose2d;
    // header
    marker.header.stamp = ros::Time::now();
    marker.header.frame_id = footprint.center.header.frame_id;

    // identifier and cmds
    marker.ns = "footprint";
    marker.id = i;
    marker.type = visualization_msgs::Marker::SPHERE;
    marker.action = visualization_msgs::Marker::ADD;

    // body
    marker.pose = footprint.center.pose;
    // get theta-angle to display as elevation
    PoseToPose2D(footprint.center.pose, tmp_pose2d);
    marker.pose.position.z = 0; // tmp_pose2d.theta * getCircumscribedRadius(*costmap_ros_);
    // scale ~ diameter --> is 2x radius ~ radius
    marker.scale.x = 2.0 * footprint.radius;
    marker.scale.y = 2.0 * footprint.radius;
    marker.scale.z = 2.0 * footprint.radius;

    // color (rgb)
    marker.color.r = 0.0f;
    marker.color.g = 0.0f;
    marker.color.b = 0.0f;
    switch (marker_color)
    {
    case red:
    {
        marker.color.r = 1.0f;
        break;
    }
    case green:
    {
        marker.color.g = 1.0f;
        break;
    }
    case blue:
    {
        marker.color.b = 1.0f;
        break;
    }
    }
    // transparency (alpha value < 1 : displays marker transparent)
    marker.color.a = 0.75;

    // lifetime of this marker
    marker.lifetime = ros::Duration(100);
}
void NarrowPath::PathCallback(const nav_msgs::Path::ConstPtr &msg)
{
    // global_path_ptr = msg;
    // ShowRobotPath(msg, footprint_radius_);
}
/**********************************************************************
 * * @function:    ShowRobotPath 
 * * @brief:       显示机器人路径足迹
 * * @input:       msg: 路径数据 radius: 足迹半径
 * * @output:      发布路径足迹可视化
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::ShowRobotPath(const nav_msgs::Path &msg, double &radius)
{
    // path转footprint
    std::vector<Footprint> footprints;
    Footprint footprint;
    for (int i = 0; i < msg.poses.size(); i++)
    {
        footprint.center.header = msg.poses[i].header;
        footprint.center.pose = msg.poses[i].pose;
        footprint.radius = radius;
        footprints.push_back(footprint);
    }
    PublishFootprint(footprints, footprint_pub_);
}
/**********************************************************************
 * * @function:    PublishAssistPoints 
 * * @brief:       发布辅助点到RViz可视化
 * * @input:       无
 * * @output:      发布左右辅助点和中间辅助点
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::PublishAssistPoints()
{
    std::vector<Footprint> footprints;
    Footprint footprint;
    footprint.center.header.frame_id = "base_link"; // 这里应该改为base_link
    footprint.center.header.stamp = ros::Time::now();
    footprint.center.pose.position.x = point_left_.x;
    footprint.center.pose.position.y = point_left_.y;
    footprint.center.pose.orientation.w = 1.0f;
    footprint.radius = 0.1f;
    footprints.push_back(footprint);
    footprint.center.pose.position.x = point_right_.x;
    footprint.center.pose.position.y = point_right_.y;
    footprint.center.pose.orientation.w = 1.0f;
    footprint.radius = 0.1f;
    footprints.push_back(footprint);
    // footprint.center.pose.position.x = assist_point_.x;
    // footprint.center.pose.position.y = assist_point_.y;
    // footprint.center.pose.orientation=tf::createQuaternionMsgFromYaw(assist_point_.theta);
    // // tf2::Quaternion quaternion;
    // // tf2::createQuaternionMsgFromYaw(assist_point_.theta,quaternion);
    // // footprint.center.pose.orientation.x = quaternion.x();
    // // footprint.center.pose.orientation.y = quaternion.y();
    // // footprint.center.pose.orientation.z = quaternion.z();
    // // footprint.center.pose.orientation.w = quaternion.w();
    // footprint.radius = 0.1f;
    // footprints.push_back(footprint);
    PublishFootprint(footprints, ref_footprint_pub_);
    // 发布辅助点
    geometry_msgs::PoseStamped p;
    p.header.stamp = ros::Time::now();
    p.header.frame_id = "base_link"; // 这里应该改为base_link
    p.pose.position.x = assist_point_.x;
    p.pose.position.y = assist_point_.y;
    p.pose.orientation = tf::createQuaternionMsgFromYaw(assist_point_.theta);
    assist_point_pub_.publish(p);
}
/**********************************************************************
 * * @function:    ScanCallback 
 * * @brief:       激光雷达扫描数据回调函数
 * * @input:       msg: 激光扫描数据
 * * @output:      处理扫描数据并计算辅助点
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/

void NarrowPath::ScanCallback(const sensor_msgs::LaserScan::ConstPtr &msg)
{
    static bool first_scan = true;
    if (first_scan)
    {
        try
        {
            tf_listener_.waitForTransform("base_link", "laser_link", ros::Time(0), ros::Duration(3.0));
            tf_listener_.lookupTransform("base_link", "laser_link", ros::Time(0), transform_base_link_to_laser_link_);
        }
        catch (tf::TransformException &ex)
        {
            // LOG(ERROR) << "Failed to lookup transform: %s" << ex.what();
            return;
        }
        first_scan = false;
        point_cloud_.resize(msg->ranges.size());
    }
    // LaserScanToPoseList(msg, point_cloud_);
    // GetAssistPoint(point_cloud_);
    // PublishAssistPoints();
    // CmdVelStr cmd_vel;
    // bool a=GoThroughAG(assist_point_,forward_distance_,cmd_vel);
}
/**********************************************************************
 * * @function:    CalculateFootprint 
 * * @brief:       根据雷达，计算footprint的边界
 * * @input:       msg: 激光扫描数据
 * * @input:       pose: 机器人位姿
 * * @output:      无
 * * @return:      double: 返回足迹边界值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
double NarrowPath::CalculateFootprint(const sensor_msgs::LaserScan::ConstPtr &msg, const geometry_msgs::Pose2D &pose)
{
    return 0;
}
/**********************************************************************
 * * @function:    FollowPath 
 * * @brief:       pass控制跟随路径，，注意：这里应控制小车的起点与闸机之间一定角度内，行人无法穿越
 * * @input:       point_cloud: 点云数据 cmd_vel: 速度控制命令
 * * @output:      更新速度控制命令
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::FollowPath(const std::vector<Point> &point_cloud, CmdVelStr &cmd_vel)
{
    static geometry_msgs::Pose2D goal;
    move_step_ = 2;
    switch (move_step_)
    {
    case 0:
        // 等待scan数据上来
        if (point_cloud.size() == 0)
        {
            break;
        }
        if (ListenTF("odom", "base_link", current_pose_))
        {
            GetAssistPoint(point_cloud);
            // 发布辅助点
            PublishAssistPoints();
            goal.x = assist_point_.x + current_pose_.x;
            goal.y = assist_point_.y + current_pose_.y;
            goal.theta = assist_point_.theta + current_pose_.theta;
            goal.theta = goal.theta < 0 ? goal.theta + 2 * M_PI : (goal.theta > 2 * M_PI ? goal.theta - 2 * M_PI : goal.theta);
            //std::cout << "scan online goal x " << goal.x << " y" << goal.y << " theta" << goal.theta << std::endl;
            move_step_ = 1;
        }
    case 1: /* moveto assist point */
            // 控制先转向，运动到辅助点,再转头（90度？），使车头垂直于闸机两端点连线
        if (ListenTF("odom", "base_link", current_pose_))
        {

            if (MoveToGoal(goal, current_pose_, cmd_vel))
            {
                move_step_ = 2;
                //std::cout << "GoThroughAG..." << std::endl;
            }
        }
        break;
    case 2: /* gostraight */
        GetAssistPoint(point_cloud);
        // 发布辅助点
        PublishAssistPoints();
        if (GoThroughAG(assist_point_, forward_distance_, cmd_vel))
        {
            move_step_ = 3;
        }
        break;
    default:
        break;
    }
}
/**********************************************************************
 * * @function:    GetAssistPoint 
 * * @brief:       获取辅助点，计算通道中间点
 * * @input:       point_cloud: 点云数据
 * * @output:      更新左右边界点和辅助点
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::GetAssistPoint(const std::vector<Point> &point_cloud)
{
    // 计算相交点，调整运动参考
    // pass：交点在右侧，左转点的90度；反之，右转点的90度---》直行，直到到达对面交点--》调整方向为
    // 计算车头，左右两侧45度内最近的点pl,pr。
    double min_2_right = std::numeric_limits<double>::max();
    double min_2_left = std::numeric_limits<double>::max();
    double point_2, theta;
    for (auto point : point_cloud)
    {
        theta = (!isnan(point.x) && point.x != 0) ? atan2(point.y, point.x) : 0;
        // ROS_INFO("theta:%f;point.x:%f;point.y:%f",theta,point.x,point.y);
        if (theta > -1.0 && theta < 0) // 车头右侧
        {
            point_2 = point.x * point.x + point.y * point.y;
            min_2_right = point_2 < min_2_right ? (point_right_ = point, point_2) : min_2_right;
        }
        if (theta > 0 && theta < 1.0) // 车头左侧
        {
            point_2 = point.x * point.x + point.y * point.y;
            min_2_left = point_2 < min_2_left ? (point_left_ = point, point_2) : min_2_left;
        }
    }
    // 计算中垂点point_right_,point_left_
    Point mid_point;
    mid_point.x = (point_right_.x + point_left_.x) / 2;
    mid_point.y = (point_right_.y + point_left_.y) / 2;
    // 计算辅助点（point_right_,point_left_的斜率slope）
    double slope = (point_right_.x != point_left_.x) ? (point_right_.y - point_left_.y) / (point_right_.x - point_left_.x) : std::numeric_limits<double>::max();
    theta = (!isnan(slope) && slope != 0) ? atan(-1. / slope) : 0;
    double range = sqrt(mid_point.x * mid_point.x + mid_point.y * mid_point.y);
    assist_point_.x = mid_point.x; // range*cos(theta)*sin(theta);
    assist_point_.y = mid_point.y; // range*sin(theta)*sin(theta);
    assist_point_.theta = theta;
    // ROS_INFO("assist_point_:%f,%f;point_left_:%f,%f;point_right_:%f,%f,range:%f",
    // assist_point_.x,assist_point_.y,point_left_.x,point_left_.y,point_right_.x,point_right_.y,range);
}
/**********************************************************************
 * * @function:    MoveToGoal 
 * * @brief:       移动到目标点的控制函数
 * * @input:       target_point: 目标点位姿
 * * @input:       current_pose: 当前位姿
 * * @input:       vel: 速度控制命令
 * * @input:       threshold_dis: 距离阈值
 * * @input:       threshold_angle: 角度阈值
 * * @output:      更新速度控制命令
 * * @return:      bool: 返回是否到达目标点
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
bool NarrowPath::MoveToGoal(const geometry_msgs::Pose2D &target_point, const geometry_msgs::Pose2D &current_pose, CmdVelStr &vel, double threshold_dis, double threshold_angle)
{
    static double last_delta_angle = 0.0;
    // 计算角速度
    geometry_msgs::Pose2D direction;
    direction.x = target_point.x - current_pose.x;
    direction.y = target_point.y - current_pose.y;
    direction.theta = target_point.theta - current_pose.theta;
    double angle_ref = atan2(direction.y, direction.x); //-pi,pi
    double dis_delta = sqrt(pow(direction.x, 2) + pow(direction.y, 2));
    double delta_angle = AngleDiff(current_pose.theta, angle_ref); // angles::shortest_angular_distance(,);//-pi,pi
    switch (vel_index_)
    {
    case 0: // 旋转
    {
        if (fabs(delta_angle) > threshold_angle)
        {
            vel.angular = 2.0 * delta_angle;
            vel.angular = (fabs(vel.angular) > max_angular_velocity_ ? (vel.angular > 0 ? max_angular_velocity_ : -max_angular_velocity_) : vel.angular);
        }
        else
        {
            vel.angular = 0.0;
            vel_index_++;
        }
        vel.linear = 0.0;
    }
    break;
    case 1: // 直行
    {
        if (dis_delta > threshold_dis && fabs(delta_angle) < M_PI / 2)
        {
            vel.linear = std::min(max_linear_velocity_, std::max(min_linear_velocity_, 1.3 * dis_delta)); // 在终点限速
            vel.angular = 3.0 * delta_angle;
            vel.angular = (fabs(vel.angular) > max_angular_velocity_ ? (vel.angular > 0 ? max_angular_velocity_ : -max_angular_velocity_) : vel.angular);
            last_delta_angle = delta_angle;
        }
        else
        {
            vel.linear = 0.0;
            vel.angular = 0.0;
            vel_index_++;
            last_delta_angle = 0.0;
        }
    }
    break;
    case 2: // 旋转，使方向与目标点方向一致
    {
        double delta = AngleDiff(current_pose.theta, target_point.theta);
        if (fabs(delta) > threshold_angle)
        {
            vel.linear = 0.0;
            vel.angular = delta; // 20240410修复加速度太大，防止急停不充分，影响识别
            vel.angular = (fabs(vel.angular) > max_angular_velocity_ ? (vel.angular > 0 ? max_angular_velocity_ : -max_angular_velocity_) : vel.angular);
        }
        else
        {
            vel.linear = 0.0;
            vel.angular = 0.0;
            vel_index_++;
            return true;
        }
    }
    break;
    default:
        break;
    }
    return false;
}
/**********************************************************************
 * * @function:    GoThroughAG 
 * * @brief:       通过闸机或狭窄通道的控制函数
 * * @input:       target_point: 目标辅助点 distance: 前进距离 cmd_vel: 速度控制命令
 * * @output:      更新速度控制命令
 * * @return:      bool: 返回是否通过完成
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
bool NarrowPath::GoThroughAG(const geometry_msgs::Pose2D &target_point, double &distance, CmdVelStr &cmd_vel)
{
    // 检查是否有障碍物
    if (flg_obstacle_)
    {
        // 有障碍物，停止运动
        cmd_vel.linear = 0.0;
        cmd_vel.angular = 0.0;
        is_waiting_obstacle_ = true;
        LOG(WARNING) << "检测到障碍物! 停止运动";
        return false;
    }
    
    // 障碍物已清除，重置等待状态
    if (is_waiting_obstacle_)
    {
        is_waiting_obstacle_ = false;
        LOG(INFO) << "障碍物已清除，恢复通过门禁";
    }
    
    // 计算预瞄点的距离
    double pre_look_ahead_distance = sqrt(std::pow(target_point.x, 2) + std::pow(target_point.y, 2));
    // 计算预瞄点的角度
    double pre_look_ahead_angle = atan2(target_point.y, target_point.x);

    if (fabs(detect_angle_) > fabs(pre_look_ahead_angle) && distance > pre_look_ahead_distance)
    {
        // 控制跟随预瞄点
        cmd_vel.linear = 1.0 * pre_look_ahead_distance;
        cmd_vel.linear = cmd_vel.linear > min_linear_velocity_ ? cmd_vel.linear : min_linear_velocity_;
        cmd_vel.linear = cmd_vel.linear > max_linear_velocity_ ? max_linear_velocity_ : cmd_vel.linear;
        cmd_vel.angular = -1.0 * pre_look_ahead_angle;
        cmd_vel.angular = fabs(cmd_vel.angular) > min_angular_velocity_ ? cmd_vel.angular : cmd_vel.angular > 0 ? min_angular_velocity_
                                                                                                                : -min_angular_velocity_;
        cmd_vel.angular = fabs(cmd_vel.angular) > max_angular_velocity_ ? cmd_vel.angular > 0 ? max_angular_velocity_ : -max_angular_velocity_ : cmd_vel.angular;
        //std::cout << "pre_look_ahead_distance: " << pre_look_ahead_distance
        //          << " pre_look_ahead_angle" << pre_look_ahead_angle
        //          << " linear" << cmd_vel.linear
        //          << " angular" << cmd_vel.angular << std::endl;
        return false;
    }
    else
    {
        cmd_vel.linear = 0.0;
        cmd_vel.angular = 0.0;
        //std::cout << "end----------------pre_look_ahead_distance: " << pre_look_ahead_distance
        //          << " pre_look_ahead_angle" << pre_look_ahead_angle << std::endl;
        return true;
    }
    return false;
}
/**********************************************************************
 * * @function:    LaserScanToPoseList 
 * * @brief:       将激光雷达数据转换为点云坐标列表
 * * @input:       scan_msg: 激光扫描数据 laser_points: 输出点云坐标
 * * @output:      填充点云坐标数据
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::LaserScanToPoseList(const sensor_msgs::LaserScan::ConstPtr &scan_msg, std::vector<Point> &laser_points)
{
    unsigned int i = 0;
    Point laser_point;
    // test_msg=*scan_msg;
    //  test_msg.header.frame_id="base_link";
    //  test_msg.header.stamp=ros::Time::now();
    //  test_msg.ranges.resize(scan_msg->ranges.size());
    for (double b = scan_msg->angle_min; b <= scan_msg->angle_max; b += scan_msg->angle_increment)
    {
        if (scan_msg->ranges[i] >= scan_msg->range_min && scan_msg->ranges[i] < scan_msg->range_max)
        {
            // 这里添加坐标系变换TransformCoordinate(tf_base_laser_link,laser_pose);
            tf::Point laser_pose(scan_msg->ranges[i] * std::cos(b), scan_msg->ranges[i] * std::sin(b), 0);
            // laser_pose=transform_base_link_to_laser_link_*laser_pose;
            laser_point.x = transform_base_link_to_laser_link_.getOrigin().x() + scan_msg->ranges[i] * std::cos(b);
            laser_point.y = transform_base_link_to_laser_link_.getOrigin().y() + scan_msg->ranges[i] * std::sin(b);
            laser_points.push_back(laser_point);
            // //std::cout << "scanx: " << laser_pose[0] << ",scany: " << laser_pose[1]
            //           << "x: " << laser_point.x << ",y: " << laser_point.y << std::endl;
            // test_msg.ranges[i]=sqrt(pow(laser_point.x,2)+pow(laser_point.y,2));
        }
        // else test_msg.ranges[i]=0;
        i++;
    }
    // test_pub_.publish(test_msg);
    // //std::cout << "laser_points.size() : " << laser_points.size() << std::endl;
}
/**********************************************************************
 * * @function:    ListenTF 
 * * @brief:       监听TF变换并获取位姿信息
 * * @input:       target: 目标坐标系 source: 源坐标系 pose: 输出位姿
 * * @output:      填充位姿数据
 * * @return:      bool: 返回变换是否成功
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
bool NarrowPath::ListenTF(std::string target, std::string source, geometry_msgs::Pose2D &pose)
{
    try
    {
        tf_listener_.waitForTransform(target, source, ros::Time(0), ros::Duration(3.0));
        tf_listener_.lookupTransform(target, source, ros::Time(0), transform_base_link_to_odom_);
    }
    catch (tf::TransformException &ex)
    {
        // LOG(ERROR) << "Failed to lookup transform: %s" << ex.what();
        return false;
    }

    pose.x = transform_base_link_to_odom_.getOrigin().x();
    pose.y = transform_base_link_to_odom_.getOrigin().y();
    pose.theta = tf::getYaw(transform_base_link_to_odom_.getRotation());
    return true;
}
/**
 * 方案二
 * 全局规划+局部跟随
 */
/***
 *
 * nav_msgs/Path
std_msgs/Header header
  uint32 seq
  time stamp
  string frame_id
geometry_msgs/PoseStamped[] poses
  std_msgs/Header header
    uint32 seq
    time stamp
    string frame_id
  geometry_msgs/Pose pose
    geometry_msgs/Point position
      float64 x
      float64 y
      float64 z
    geometry_msgs/Quaternion orientation
      float64 x
      float64 y
      float64 z
      float64 w

 */
/**********************************************************************
 * * @function:    GetPath 
 * * @brief:       获取全局规划路径
 * * @input:       start: 起始点 goal: 目标点
 * * @output:      更新全局路径数据
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NarrowPath::GetPath(const geometry_msgs::Pose2D &start, const geometry_msgs::Pose2D &goal)
{
    if(nav_node_=="/task_base")
    {
        robot_msgs::GetPlanService srv;
        // step1 获取全局规划路径的路点集合
        srv.request.start.header.frame_id = "map";
        srv.request.start.pose.position.x = start.x;
        srv.request.start.pose.position.y = start.y;
        srv.request.start.pose.position.z = GlobalPlannerType::NO_YAW;
        srv.request.start.pose.orientation.w = 1.0;

        srv.request.goal.header.frame_id = "map";
        srv.request.goal.pose.position.x = goal.x;
        srv.request.goal.pose.position.y = goal.y;
        srv.request.goal.pose.position.z = GlobalPlannerType::NO_YAW;
        srv.request.goal.pose.orientation.w = 1.0;

        srv.request.tolerance = 0.1;
        if(!service_client_.waitForExistence(ros::Duration(10)))
        {
            LOG(ERROR) << "make plan died";
        } 
        if(service_client_.call(srv))
        {
            global_path_ = srv.response.plan;
        }
    }
    else
    {
        nav_msgs::GetPlan srv;
        // step1 获取全局规划路径的路点集合
        srv.request.start.header.frame_id = "map";
        srv.request.start.pose.position.x = start.x;
        srv.request.start.pose.position.y = start.y;
        srv.request.start.pose.position.z = GlobalPlannerType::NO_YAW;
        srv.request.start.pose.orientation.w = 1.0;

        srv.request.goal.header.frame_id = "map";
        srv.request.goal.pose.position.x = goal.x;
        srv.request.goal.pose.position.y = goal.y;
        srv.request.goal.pose.position.z = GlobalPlannerType::NO_YAW;
        srv.request.goal.pose.orientation.w = 1.0;

        srv.request.tolerance = 0.1;
        if(!service_client_.waitForExistence(ros::Duration(10)))
        {
            LOG(ERROR) << "make plan died";
        } 
        if(service_client_.call(srv))
        {
            global_path_ = srv.response.plan;
        }
    }
}
/**********************************************************************
 * * @function:    FollowPath 
 * * @brief:       跟随全局路径的控制函数（路径版本）
 * * @input:       current_pose: 当前位姿 cmd_vel: 速度控制命令
 * * @output:      更新速度控制命令
 * * @return:      bool: 返回是否完成路径跟随
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
bool NarrowPath::FollowPath(const geometry_msgs::Pose2D &current_pose, CmdVelStr &cmd_vel)
{
    if (global_path_.poses.size() == 0)
    {
        return true;
    }
    // 把距离机器人小与一定距离的路径点去除，然后，下一个路径点作为目标点
    for (int i = 0; i < global_path_.poses.size(); i++)
    {
        if (sqrt(pow(global_path_.poses[i].pose.position.x - current_pose.x, 2) + pow(global_path_.poses[i].pose.position.y - current_pose.y, 2)) < 0.3)
        {
            for (int j = 0; j <= i; j++)
            {
                global_path_.poses.erase(global_path_.poses.begin() + j);
            }
            // global_path_.poses.erase(global_path_.poses.begin()+i);
        }
    }
    // 跟随目标点
    geometry_msgs::PoseStamped target_point;//= global_path_.poses[0];
    tf::Vector3 source_point(global_path_.poses[0].pose.position.x,global_path_.poses[0].pose.position.y,0);
    tf::Vector3  tran_point=transform_base_link_to_odom_.inverse()*source_point;
    target_point.pose.position.x=tran_point[0];
    target_point.pose.position.y=tran_point[1];
    target_point.pose.orientation.w=1;
      /*//坐标系转换到base_link
      double yaw0=atan2(current_pose.y, current_pose.x);
  target_point.pose.position.x=global_path_.poses[0].pose.position.x*cos(yaw0)+global_path_.poses[0].pose.position.y*sin(yaw0)+current_pose.x;
  target_point.pose.position.y=-global_path_.poses[0].pose.position.x*sin(yaw0)+global_path_.poses[0].pose.position.y*cos(yaw0)+current_pose.y;
  target_point.pose.orientation.w=1;  */
      
      
      
     // double theta=
/* target_point.pose.position.x= (global_path_.poses[0].pose.position.x-current_pose.x)*cos(current_pose.theta)+(global_path_.poses[0].pose.position.y-current_pose.y)*sin(current_pose.theta);
 target_point.pose.position.y= -(global_path_.poses[0].pose.position.x-current_pose.x)*sin(current_pose.theta)+(global_path_.poses[0].pose.position.y-current_pose.y)*cos(current_pose.theta);  
 target_point.pose.orientation.w=1;*/
    
    
    
    //std::cout << "target_point x: " << global_path_.poses[0].pose.position.x << "target_point y: " << global_path_.poses[0].pose.position.y<< std::endl;
    //std::cout << "current_pose x: " << current_pose.x << "current_pose y: " << current_pose.y << "current_pose yaw: " << atan2(current_pose.y, current_pose.x) << std::endl;
    // 计算预瞄点的距离
    double pre_look_ahead_distance = sqrt(std::pow(target_point.pose.position.x, 2) + std::pow(target_point.pose.position.y, 2));//
    //sqrt(std::pow(global_path_.poses[0].pose.position.x - current_pose.x, 2) + std::pow(global_path_.poses[0].pose.position.y - current_pose.y, 2));
    // 计算预瞄点的角度
    double yaw = tf2::getYaw(target_point.pose.orientation);
    double pre_look_ahead_angle =atan2(target_point.pose.position.y, target_point.pose.position.x);//-atan2(current_pose.y, current_pose.x);// yaw - current_pose.theta; // 
    // if(fabs(detect_angle_) >fabs(pre_look_ahead_angle) && distance > pre_look_ahead_distance)
    if (pre_look_ahead_distance < 0.8)
    {
        // 控制跟随预瞄点
        cmd_vel.linear = 1.0 * pre_look_ahead_distance;
        cmd_vel.linear = cmd_vel.linear > min_linear_velocity_ ? cmd_vel.linear : min_linear_velocity_;
        cmd_vel.linear = cmd_vel.linear > max_linear_velocity_ ? max_linear_velocity_ : cmd_vel.linear;
        cmd_vel.angular = 1.0 * tan(pre_look_ahead_angle);
        cmd_vel.angular = fabs(cmd_vel.angular) > min_angular_velocity_ ? cmd_vel.angular : cmd_vel.angular > 0 ? min_angular_velocity_
                                                                                                                : -min_angular_velocity_;
        cmd_vel.angular = fabs(cmd_vel.angular) > max_angular_velocity_ ? cmd_vel.angular > 0 ? max_angular_velocity_ : -max_angular_velocity_ : cmd_vel.angular;
        //std::cout << "pre_look_ahead_distance: " << pre_look_ahead_distance
        //          << " pre_look_ahead_angle" << pre_look_ahead_angle
        //          << " linear" << cmd_vel.linear
        //          << " angular" << cmd_vel.angular << std::endl;
        return false;
    }
    else
    {
        cmd_vel.linear = 0.0;
        cmd_vel.angular = 0.0;
        //std::cout << "end----------------pre_look_ahead_distance: " << pre_look_ahead_distance
        //          << " pre_look_ahead_angle" << pre_look_ahead_angle << std::endl;
        return true;
    }
    return false;
}
void NarrowPath::CameraToScanCB(const sensor_msgs::LaserScan::ConstPtr &msg)
{
    if (nullptr == msg)
    {
        flg_obstacle_ = false;
        return;
    }

    std::vector<float> valid_ranges;
    for (float range : msg->ranges)
    {
        if (!std::isnan(range) && !std::isinf(range))
        {
            valid_ranges.push_back(range);
        }
    }

    if (valid_ranges.empty())
    {
        flg_obstacle_ = false;
        return;
    }
    
    double min_dis = *std::min_element(valid_ranges.begin(), valid_ranges.end());
    bool new_obstacle_state = (min_dis < judge_depth_);
    
    // 状态变化时打印日志
    if (new_obstacle_state != flg_obstacle_)
    {
        if (new_obstacle_state)
        {
            LOG(WARNING) << "检测到障碍物! 距离=" << min_dis << "m, 机器人停止, 等待障碍物清除";
        }
        else
        {
            LOG(INFO) << "障碍物已清除，继续通过门禁";
        }
    }
    
    flg_obstacle_ = new_obstacle_state;
}




/*bool NarrowPath::FollowPath(const geometry_msgs::Pose2D&  current_pose,CmdVelStr& cmd_vel)
{
  if(global_path_.poses.size()==0){
    return true;
  }
  //把距离机器人小与一定距离的路径点去除，然后，下一个路径点作为目标点
  for(int i =0;i<global_path_.poses.size();i++){
    if(sqrt(pow(global_path_.poses[i].pose.position.x-current_pose.x,2)+pow(global_path_.poses[i].pose.position.y-current_pose.y,2))<0.4){
      for(int j = 0;j <= i;j++)
      {
          global_path_.poses.erase(global_path_.poses.begin()+j);
      }
    }
  }
  //跟随目标点
  geometry_msgs::PoseStamped target_point=global_path_.poses[0];
  geometry_msgs::PoseStamped target_point_in_base;
  target_point.header.frame_id="map";
  static tf2_ros::Buffer tf_buffer;
  static tf2_ros::TransformListener tf_listener(tf_buffer);
  double yaw = 0.0;

  // 等待 transform 可用
    if (!tf_buffer.canTransform("base_link", target_point.header.frame_id, ros::Time(0), ros::Duration(1.0))) {
        //ROS_WARN("Transform from map to base_link not available yet.");
        return false;
    }

    try {
        tf_buffer.transform(target_point, target_point_in_base, "base_link");
        yaw = tf2::getYaw(target_point_in_base.pose.orientation);
    } catch (const tf2::TransformException& ex) {
        // LOG(ERROR) << "Transform error: %s" << ex.what();
        return false;
    }
  
  //std::cout << "target_point_in_base x: " << target_point_in_base.pose.position.x << "target_point_in_base y: " << target_point_in_base.pose.position.y << "target_point_in_base yaw: " << yaw << std::endl;
  // //std::cout << "current_pose x: " << current_pose.x << "current_pose y: " << current_pose.y << "current_pose yaw: " << atan2(current_pose.y, current_pose.x) << std::endl;
//计算预瞄点的距离
  double pre_look_ahead_distance = sqrt(std::pow(target_point_in_base.pose.position.x, 2) + std::pow(target_point_in_base.pose.position.y, 2));
  //计算预瞄点的角度
  //double yaw = tf2::getYaw(target_point.pose.orientation);
  double pre_look_ahead_angle = yaw;//atan2(target_point.pose.position.y, target_point.pose.position.x);
  //if(fabs(detect_angle_) >fabs(pre_look_ahead_angle) && distance > pre_look_ahead_distance)
  if(pre_look_ahead_distance<0.6)
  {
    //控制跟随预瞄点
    cmd_vel.linear = 1.0*pre_look_ahead_distance;
    cmd_vel.linear= cmd_vel.linear>min_linear_velocity_?cmd_vel.linear:min_linear_velocity_;
    cmd_vel.linear = cmd_vel.linear>max_linear_velocity_?max_linear_velocity_:cmd_vel.linear;
    cmd_vel.angular = 1.0*tan(pre_look_ahead_angle);
    cmd_vel.angular = fabs(cmd_vel.angular)>min_angular_velocity_?cmd_vel.angular: cmd_vel.angular>0?min_angular_velocity_:-min_angular_velocity_;
    cmd_vel.angular = fabs(cmd_vel.angular)>max_angular_velocity_?cmd_vel.angular>0?max_angular_velocity_:-max_angular_velocity_:cmd_vel.angular;
    //std::cout<<"pre_look_ahead_distance: "<<pre_look_ahead_distance
    <<" pre_look_ahead_angle"<<pre_look_ahead_angle
    <<" linear"<<cmd_vel.linear
    <<" angular"<<cmd_vel.angular  <<std::endl;
    return false;
  }
  else
  {
    cmd_vel.linear = 0.0;
    cmd_vel.angular = 0.0;
    //std::cout<<"end----------------pre_look_ahead_distance: "<<pre_look_ahead_distance
    <<" pre_look_ahead_angle"<<pre_look_ahead_angle<<std::endl;
    return true;
  }
return false;

}*/

















// bool NarrowPath::Control(CmdVelStr& cmd_vel)
/**********************************************************************
 * * @function:    Control 
 * * @brief:       狭窄路径导航主控制函数
 * * @input:       cmd_vel: 速度控制命令
 * * @input:       accessin: 入口点
 * * @input:       accessout: 出口点
 * * @output:      更新速度控制命令和导航状态
 * * @return:      bool: 返回导航是否完成
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
bool NarrowPath::Control(CmdVelStr &cmd_vel, geometry_msgs::Pose2D &accessin, geometry_msgs::Pose2D &accessout)
{
    static geometry_msgs::Pose2D goal;
    // nav_msgs::Path::ConstPtr global_path_trans_=&global_path_;
    ShowRobotPath(global_path_, robot_r_);
    switch (move_step_)
    {
    case 0:
        clicked_points_.clear();
        clicked_points_.push_back(accessin);
        clicked_points_.push_back(accessout);
        if (clicked_points_.size() < 2)
        {
            //std::cout << "wait point" << std::endl;
            break;
        }
        if (ListenTF("map", "base_link", current_pose_))
        {
            GetPath(clicked_points_.at(0), clicked_points_.at(1));
            move_step_ = 1;
        }
        break;
    case 1:
    {
        if (ListenTF("map", "base_link", current_pose_))
        {
            if (FollowPath(current_pose_, cmd_vel))
            {
                move_step_ = 0;
                return true;
            }
        }
    }
    case 2:
    {
        // 等待下一次过门禁
    }
    break;
    default:
        break;
    }
    return false;
}
