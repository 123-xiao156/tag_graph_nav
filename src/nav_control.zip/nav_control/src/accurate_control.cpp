/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	accurate_control.cpp
 * * @description:  门禁、乘梯
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "accurate_control.h"
AccurateControl::AccurateControl(ros::NodeHandle nh):nh_(nh)
{
    pub_cmd_vel_ = nh_.advertise<geometry_msgs::Twist>("/cmd_vel", 10);
    pub_voice_ = nh_.advertise<robot_msgs::Voice>("/voiceplay", 10);
    
    nh_.param("car_type", car_type_, std::string("UC"));
    nh_.param("goto_back_dis", goto_back_dis_, 0.4);
    int nav_version;
    nh_.param<int>("nav_version", nav_version, 1);  //#1move_base导航，2nav_base导航
    if(nav_version==1)
    {
        nav_node_="/move_base";
        //20251024消息类型变更
        check_point_cost_client_ = nh_.serviceClient<robot_msgs::JudgePose>(nav_node_+"/judge_pose");
    }
    if(nav_version==2)
    {
        nav_node_="/task_base";
        //20251024消息类型变更
        check_point_cost_client_ = nh_.serviceClient<robot_msgs::JudgePose>(nav_node_+"/judge_pose");
    } 
    clear_costmap_client_ = nh_.serviceClient<std_srvs::Empty>(nav_node_+"/clear_costmaps");
}

void AccurateControl::Init()
{
    interval_ms_ = 100;
    std::thread t(&AccurateControl::TimerThread,this,interval_ms_);
    t.detach();
}

void AccurateControl::TimerThread(int16_t interval_ms)
{
    while(ros::ok()){
        if(!thread_pause_flag_){
            //work
            MainLoop();
        }
        ros::spinOnce();
        std::this_thread::sleep_for(std::chrono::milliseconds(interval_ms));
    }
}

void AccurateControl::MainLoop()
{
    switch (control_status_)
    {
        case ControlStatus::INIT:
            {

            }
            break;
        case ControlStatus::ADJUST_ANGLE:
        {
            if (first_adjust_angular_flag_ == 0)
            {
                // 计算调整角度
                double bp_length = std::sqrt(std::pow(aim_point_.x -p_shard_data_->current_pose_.x, 2) + std::pow(aim_point_.y - p_shard_data_->current_pose_.y, 2));

                if ((aim_point_.x - p_shard_data_->current_pose_.x) >= 0)
                {
                    if ((aim_point_.y - p_shard_data_->current_pose_.y) <= 0)
                    {
                        modify_raw_ = -abs(acos((aim_point_.x - p_shard_data_->current_pose_.x) / bp_length));
                    }
                    else
                    {
                        modify_raw_ = abs(acos((aim_point_.x - p_shard_data_->current_pose_.x) / bp_length));
                    }
                }
                else
                {
                    if ((aim_point_.y - p_shard_data_->current_pose_.y) <= 0)
                    {
                        modify_raw_ = -abs(acos((aim_point_.x - p_shard_data_->current_pose_.x) / bp_length));
                    }
                    else
                    {
                        modify_raw_ = abs(acos((aim_point_.x - p_shard_data_->current_pose_.x) / bp_length));
                    }
                }
                angular_adjust_.angular.z = (modify_raw_ - p_shard_data_->current_pose_.yaw > 0) ? 0.3 : -0.3;
                first_adjust_angular_flag_++;
            }
            else{
                // 开始执行调整角度
                // qDebug()<<"发布了速度1"<<endl;
                pub_cmd_vel_.publish(angular_adjust_);
                // std::cout << "计算得到所需调整至角度 " << modify_raw_ << " 当前角度 " << current_pose_.yaw << " 调节速度 " << angular_adjust_.angular.z << std::endl;
                if (fabs(modify_raw_ - p_shard_data_->current_pose_.yaw) < 0.05)
                {
                    first_adjust_angular_flag_ = 0;
                    angular_adjust_.angular.z = 0.0;
                    // qDebug()<<"发布了速度2"<<endl;
                    pub_cmd_vel_.publish(angular_adjust_);
                    // std::cout << "完成调整至角度 " << modify_raw_ << " 当前角度 " << current_pose_.yaw << " 索引号 " << backstate_index_ << std::endl;
                    LOG(INFO) << "finished to adjust angle " << modify_raw_ << " current angle " << p_shard_data_->current_pose_.yaw << " index " << control_status_;
                    control_status_=ControlStatus::VOICE;
                    wait_voice_flag_ = 0;
                }
            }

        }
            break;
        case ControlStatus::VOICE:
        {
            int costmap_occu_data = 254;
            // 20250108 添加检查点的代价值
            if(nav_node_=="/move_base")
            {
                robot_msgs::JudgePose srv;
                srv.request.pose.pose.position.x = aim_point_.x;
                srv.request.pose.pose.position.y = aim_point_.y;
                srv.request.using_global_costmap = true;
                if(!check_point_cost_client_.waitForExistence(ros::Duration(10)))
                {
                    LOG(ERROR) << "check_point_cost died";
                }   
                if (check_point_cost_client_.call(srv))
                {
                    costmap_occu_data = srv.response.value;
                }
            }
            if(nav_node_=="/task_base")
            {
                robot_msgs::JudgePose srv;
                srv.request.pose.pose.position.x = aim_point_.x;
                srv.request.pose.pose.position.y = aim_point_.y;
                srv.request.using_global_costmap = true;
                if(!check_point_cost_client_.waitForExistence(ros::Duration(10)))
                {
                    LOG(ERROR) << "check_point_cost died";
                }   
                if (check_point_cost_client_.call(srv))
                {
                    costmap_occu_data = srv.response.value;
                }
            }            
            wait_voice_flag_ += 1;
            if ((wait_voice_flag_ % 30) == 0)
            {
                std_srvs::Empty srv;
                if(!clear_costmap_client_.waitForExistence(ros::Duration(10)))
                {
                    LOG(ERROR) << "clear_costmap died";
                }    
                if (clear_costmap_client_.call(srv)) LOG(INFO) << "obstacle on the  aim point NoPass, clear costmap";
                LOG(INFO) << "obstacle on the  aim point NoPass, occupancy value " << costmap_occu_data;
                if(car_type_ == "DR-01") {
                    PublishVoice("EncounterPerdestrian");
                } else {
                    PublishVoice("NoPass");
                }
            }

            //等待障碍物移开，如果没有移开，就一直等待
            //没有被占据(0-254,254障碍，253内切障碍)
            if (costmap_occu_data <= 250 && costmap_occu_data >= 0)
            {
                wait_voice_flag_ = 0;
                //移动去目标点
                control_status_=ControlStatus::MOVE_TO_AIM;
            }
        }
            break;

        case ControlStatus::MOVE_TO_AIM:
        {
            //障碍物被移开了
            // 当back点不被占据时，开始向back点运动
            if (p_shard_data_->closest_obstacle_distance_ > goto_back_dis_)//障碍物的最小距离
            {
                wait_voice_flag_ = 0;
                if (!CalculateVelocity(velocity_cmd_, p_shard_data_->current_pose_, aim_point_))
                {
                    LOG(INFO) << "retry move to point";
                    //qDEBUG()<<"发布了速度3  x："<<velocity_cmd_.linear.x<<",z:"<<velocity_cmd_.angular.z<<endl;
                    pub_cmd_vel_.publish(velocity_cmd_);
                }
                else
                {///成功到达
                    p_shard_data_->accurate_control_nav_status_.goal_status=NavStatus::NAV_SUCCESS;//成功到达
                    thread_pause_flag_=true;
                    control_status_=ControlStatus::INIT;
                    vel_index_=0;
                    LOG(INFO) << "BackState() success arrive aim point";

                }
            }
            else if (p_shard_data_->closest_obstacle_distance_ <= goto_back_dis_ && p_shard_data_->closest_obstacle_distance_ > 0)
            {
                LOG(INFO) << "obstacle again,stop robot until it leave, distance : " << p_shard_data_->closest_obstacle_distance_;
                velocity_cmd_.linear.x = 0;
                velocity_cmd_.angular.z = 0;
                //qDEBUG()<<"发布了速度4"<<endl;
                pub_cmd_vel_.publish(velocity_cmd_);
                wait_voice_flag_ += 1;
                if ((wait_voice_flag_ % 30) == 0)
                {
                    if(car_type_ == "DR-01") {
                        PublishVoice("EncounterPerdestrian");
                    } else {
                        PublishVoice("NoPass");
                    }
                }
            }

        }
            break;
        default:
            break;
    }
}
/**********************************************************************
 * * @function:    PublishVoice 
 * * @brief:       发布语音
 * * @input:       data: 语音名称
 * * @output:      
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240125
 * **********************************************************************/
void AccurateControl::PublishVoice(std::string name)
{
    robot_msgs::Voice msg;
    msg.info_volume = 70;    // 音量70%
    msg.info_type = "voice"; // 播放语音
    msg.info_data = name;    // 语音名称，见语音列表
    pub_voice_.publish(msg);
}
/**********************************************************************
 * * @function:    Convert 
 * * @brief:       将世界坐标系中的点坐标转换为代价地图的占据值
 * * @input:       x: 世界坐标系x坐标 y: 世界坐标系y坐标
 * * @output:      无
 * * @return:      int: 返回代价地图中的占据值，-100表示坐标超出地图范围
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
int AccurateControl::Convert(double x, double y)
{
    double map_resolution = global_costmap_data_->info.resolution;
    geometry_msgs::Pose map_origin = global_costmap_data_->info.origin;

    int grid_x = static_cast<int>((x - map_origin.position.x) / map_resolution);
    int grid_y = static_cast<int>((y - map_origin.position.y) / map_resolution);

    if (grid_x >= 0 && grid_x < global_costmap_data_->info.width &&
        grid_y >= 0 && grid_y < global_costmap_data_->info.height)
    {

        int index = grid_y * global_costmap_data_->info.width + grid_x;
        int occupancy_value = global_costmap_data_->data[index];
        return occupancy_value;
    }
    else
    {
        return -100;
    }
}

/**********************************************************************
 * * @function:    CalculateVelocity 
 * * @brief:       根据当前位置和目标位置计算控制速度，实现两阶段控制策略
 * * @input:       currentPose: 当前位置和姿态 targetPose: 目标位置和姿态 threshold_dis: 距离阈值 threshold_angle: 角度阈值
 * * @output:      vel: 计算出的线速度和角速度
 * * @return:      bool: 返回是否到达目标位置
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool AccurateControl::CalculateVelocity(geometry_msgs::Twist &vel, const PoseData &currentPose, const PoseData &targetPose, double threshold_dis, double threshold_angle)
{
    static double last_delta_angle = 0.0;
    double middle_x = targetPose.x - currentPose.x;
    double middle_y = targetPose.y - currentPose.y;
    double middle_yaw = targetPose.yaw - currentPose.yaw;

    double angle_ref = atan2(middle_y, middle_x);
    double dis_delta = sqrt(pow(middle_x, 2) + pow(middle_y, 2));
    double delta_angle = AngleDiff(currentPose.yaw, angle_ref);

    switch (vel_index_)
    {
        case 0:
        {
            //先计算角度 转一定角度
            if (fabs(delta_angle) > threshold_angle)
            {
                vel.angular.z = 1.0 * delta_angle;
                vel.angular.z = (fabs(vel.angular.z) > 0.3 ? (vel.angular.z > 0 ? 0.3 : -0.3) : vel.angular.z);
            }
            else
            {
                vel.angular.z = 0.0;
                vel_index_++;
            }
            vel.linear.x = 0.0;
            // std::cout << "0:delta:" << delta_angle << "ref:" << angle_ref << "current:" << currentPose.theta << "angular" << vel.angular.z << std::endl;
        }
            break;

        case 1:
        {
            //角度和线速度一起调节
            if (dis_delta > threshold_dis && fabs(delta_angle) < M_PI / 2)
            {
                vel.linear.x = std::min(0.3, std::max(0.1, 1.3 * dis_delta));
                vel.angular.z = 3.0 * delta_angle;
                vel.angular.z = (fabs(vel.angular.z) > 0.3 ? (vel.angular.z > 0 ? 0.3 : -0.3) : vel.angular.z);
                last_delta_angle = delta_angle;
            }
            else
            {
                vel.linear.x = 0.0;
                vel.angular.z = 0.0;
                vel_index_++;
                last_delta_angle = 0.0;
            }
            // std::cout << "1:angle_delta:" << delta_angle << "angular" << vel.angular.z
            //           << "dis_delta" << dis_delta << "linear" << vel.linear << std::endl;
            // std::cout << "current_pose:" << currentPose.x << " " << currentPose.y << " " << currentPose.theta << std::endl;
        }
            break;

        case 2:
        {
            //调节角度
            double delta = AngleDiff(currentPose.yaw, targetPose.yaw);
            if (fabs(delta) > threshold_angle)
            {
                vel.linear.x = 0.0;
                vel.angular.z = 1.0 * delta;
                vel.angular.z = (fabs(vel.angular.z) > 0.3 ? (vel.angular.z > 0 ? 0.3 : -0.3) : vel.angular.z);
            }
            else
            {
                vel.linear.x = 0.0;
                vel.angular.z = 0.0;
                vel_index_++;
                return true;
            }
            // std::cout << "2:" << delta << "angular" << vel.angular.z << std::endl;
        }
            break;

        default:
            break;
    }
    return false;
}
/**********************************************************************
 * * @function:    InitAccurateControl 
 * * @brief:       初始化精准控制模块的状态和标志位
 * * @input:       无
 * * @output:      重置所有控制状态和标志位到初始值
 * * @return:      void: 无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccurateControl::InitAccurateControl(){
    control_status_ = ControlStatus::INIT;
    first_adjust_angular_flag_ = 0;
    costmap_refresh_ = 1;
    wait_voice_flag_ = 0;
    costmap_occu_flag_ = 0;
    vel_index_=0;
}
/**********************************************************************
 * * @function:    slot_SetCmd 
 * * @brief:       设置精准控制命令的槽函数，从导航模块调用
 * * @input:       movecmd: 包含移动命令数据的QVariant对象
 * * @output:      更新目标点信息和控制状态
 * * @return:      void: 无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccurateControl::slot_SetCmd(QVariant movecmd)
{
    InitAccurateControl();
    mtx_.lock();
    ////    MoveDataCmd pdata;
    MoveDataCmd pdata;
    pdata=movecmd.value<MoveDataCmd>();
    if(pdata.goal.size()==0)return;
    aim_point_.x = pdata.goal[0].x;
    aim_point_.y = pdata.goal[0].y;
    aim_point_.yaw = pdata.goal[0].yaw;
    thread_pause_flag_ = false;
    control_status_= ControlStatus::ADJUST_ANGLE;
    vel_index_=0;
    mtx_.unlock();
    LOG(INFO) << "精确控制共享类被调用了:" << aim_point_.x << ", goalx:" << aim_point_.x << ", goaly:" << aim_point_.y;
//    //赋值普通点信息
//    mtx_.lock();
//    goal_point_.map = pdata.map;
//    goal_point_.type = pdata.type;
//    goal_point_.x = pdata.x;
//    goal_point_.y = pdata.y;
//    goal_point_.yaw = pdata.yaw;
//    thread_pause_flag_ = false;
//    process_index_ = ProcessIndex::STEP1;
//    mtx_.unlock();
}

/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       设置精准控制命令的槽函数，从导航模块调用
 * * @input:       movecmd: 包含移动命令数据的QVariant对象
 * * @output:      更新目标点信息和控制状态
 * * @return:      void: 无返回值
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
void AccurateControl::slot_NewCmd(QVariant movecmd) {
    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();

    if (mdc.taskcmd_type == TaskStatus::T_ESTOP) {
        thread_pause_flag_ = true;
        control_status_ = ControlStatus::INIT;
    } else if (mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP) {
        thread_pause_flag_ = true;
        control_status_ = ControlStatus::INIT;
    } else if (mdc.taskcmd_type == TaskStatus::T_CANCEL) {
        if (!p_shard_data_->current_lift_state_)
        {
            thread_pause_flag_ = true;
            control_status_ = ControlStatus::INIT;
        }
    } else if (mdc.taskcmd_type == TaskStatus::T_GOON) {
        control_status_ = ControlStatus::INIT;
        thread_pause_flag_ = false;
    }else if (mdc.taskcmd_type == TaskStatus::T_END)
    {
        thread_pause_flag_ = true;
        control_status_ = ControlStatus::INIT;
    }
    
}