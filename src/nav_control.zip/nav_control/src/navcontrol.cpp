/***********************************************************************
 * * @copyright (C) 2025, 江苏集萃智能制造技术研究所有限公司
 * * @file NAME: 	shard_data.cpp
 * * @description:  门禁、乘梯、覆盖，乘梯动作
 * * @version:  	0.0.63
 * * @authors:  	创新产品中心-江苏集萃智能制造技术研究所有限公司
 * * @date:  	    2025-11-05
 * **********************************************************************/
#include "navcontrol.h"
#include <iostream>

NavControl::NavControl(ros::NodeHandle nh) : nh_(nh)
{
    // 注册自定义类型QVariant
    qRegisterMetaType<QVariant>("QVariant");
    path_processing_mode_ = false;
    current_processing_path_type_ = "";
    should_reset_cleanedarea_ = true;  // 默认需要重置
}

// 这段代码是NavControl类的Init成员函数实现，主要负责初始化NavControl对象中的各个成员变量和设置对象之间的信号和槽连接。
void NavControl::Init()
{
    nh_.param<bool>("lift", autolift_, false);
    nh_.param("robot_radius", robot_radius_, 0.4);
    //清扫半径类参数
    nh_.param<double>("wash_radius", wash_radius_, 0.4);      // 洗地模式半径
    nh_.param<double>("brush_radius", brush_radius_, 0.3);    // 扫地模式半径
    nh_.param<double>("mop_radius", mop_radius_, 0.4);        // 尘推模式半径
    nh_.param<double>("saction_radius", saction_radius_, 0.4);// 吸尘模式半径
    nh_.param<double>("all_status", all_status_radius_, 0.4);// 四和一半径
    nh_.param<bool>("if_use_estop", if_use_estop_, false);
    effective_robot_radius_ = robot_radius_;
    current_passed_point_id_ = 0;
    last_passed_point_id_ = 0;
    has_current_passed_id_ = false;
    nh_.param("DWAPlannerROS/max_vel_x", max_linear_velocity_, 0.6);
    nh_.param<std::string>("car_type",car_type_, "UC");
    // 发布日志、导航状态及故障信息
    pub_nav_status_ = nh_.advertise<std_msgs::String>("/navcontrol_status", 10);
    pub_error_ = nh_.advertise<std_msgs::String>("/ugv_fault", 5);
    // 20250529 c_add 三合一乘梯添加start/end点进行开关外设
    clear_io_service_ = nh_.serviceClient<robot_msgs::Cmd>("/srv_task_autolift");
    srv_draw_cpath_ = nh_.serviceClient<robot_msgs::Web>("/srv_teach_path");  // 请求覆盖路径和示教路径服务，用于获取所有的路径点用于计算面积
    // 20250606 c_add 取消导航后，单独起线程延迟1秒失能电机
    pub_motor_ = nh_.advertise<std_msgs::Bool>("/set_motor_enable", 5);
    pub_nav_progress_=nh_.advertise<std_msgs::String>("/nav_progress",10);
    sub_io_status_ = nh_.subscribe("/io_status", 10, &NavControl::ioStatusCallback, this);
    //io_data_all_pub_ = nh_.advertise<std_msgs::String>("/io_serial_all", 10, true);
    //sub_motorjstop_ = nh_.subscribe<std_msgs::Bool>("/emergency_stop", 2, &NavControl::motorJstopCallback, this);
    sub_motorjstop_ = nh_.subscribe("/emergency_stop", 10, &NavControl::motorJstopCallback, this);

    // 初始化机器人初始状态为默认状态
    {
        std::lock_guard<std::mutex> lock(robot_status_mutex_);
        robot_status_msg_.data = "DEFAULT";
    }
    // 20250922 c_add 初始化task_index_状态，防止程序启动时直接进入到分发路点状态后报错
    task_index_ = Task_Index::TASK_IDLE;

    /*
     * 使用ActionFactory模板工厂类为各种动作创建实例，包括返回起点、覆盖动作、接口动作、接入点动作、升降点动作、常规点动作、数据库动作和移动动作。
     * 这些实例通过传入ROS节点句柄(nh_)进行构造，以便它们可以在ROS环境中正常工作。
     */
    p_access_lift_shared_ = ActionFactory<AccessLiftShared>::CreateAction(nh_);     // 门禁闸机乘梯共享类
    p_access_action_ = ActionFactory<AccesspointAction>::CreateAction(nh_);         // 门禁闸机类
    p_accurate_control_shared_ = ActionFactory<AccurateControl>::CreateAction(nh_); // 精确控制类
    p_back_home_ = ActionFactory<BackHome>::CreateAction(nh_);                      // 返航点类
    p_cover_action_ = ActionFactory<CoverAction>::CreateAction(nh_);                // 覆盖点类
    p_database_action_ = ActionFactory<DatabaseAction>::CreateAction(nh_);          // 数据库类
    p_interface_action_ = ActionFactory<InterfaceAction>::CreateAction(nh_);        // 接口类
    p_lift_action_ = ActionFactory<LiftpointAction>::CreateAction(nh_);             // 乘梯类
    p_move_action_ = ActionFactory<MoveAction>::CreateAction(nh_);                  // move_action类
    p_normal_action_ = ActionFactory<NormalpointAction>::CreateAction(nh_);         // 普通marker点类
    p_teach_action_ = ActionFactory<TeachAction>::CreateAction(nh_);      // 示教路径类
    p_cover_path_action_ = ActionFactory<CoverPathAction>::CreateAction(nh_);//覆盖路径类

    // 设置共享数据(p_shard_data_)到每个动作对象，为了让这些动作对象能够访问和操作共享的状态和数据
    p_access_lift_shared_->SetShardData(p_shard_data_);
    p_access_action_->SetShardData(p_shard_data_);
    p_accurate_control_shared_->SetShardData(p_shard_data_);
    p_back_home_->SetShardData(p_shard_data_);
    p_cover_action_->SetShardData(p_shard_data_);
    p_database_action_->SetShardData(p_shard_data_);
    p_interface_action_->SetShardData(p_shard_data_);
    p_lift_action_->SetShardData(p_shard_data_);
    p_move_action_->SetShardData(p_shard_data_);
    p_normal_action_->SetShardData(p_shard_data_);
    p_teach_action_->SetShardData(p_shard_data_);
    p_cover_path_action_->SetShardData(p_shard_data_);

    // 绑定信号槽函数，Qt::DirectConnection, 发送者和接受者不在同一个线程里，需要使用该参数，否则不能接收到信号
    // interface_action_类传过来的控制信号，分发给各个类
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), this,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_access_lift_shared_,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_access_action_,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_accurate_control_shared_,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_back_home_,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_cover_action_,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_lift_action_,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_normal_action_,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_teach_action_,
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_MoveCmd(QVariant)), p_cover_path_action_, 
                     SLOT(slot_NewCmd(const QVariant)), Qt::DirectConnection);//覆盖路径类

    // navcontrol接收信号，发布导航状态
    QObject::connect(p_access_lift_shared_, SIGNAL(signal_PubStatus(std::string)), this,
                     SLOT(slot_PubNavStatus(std::string)), Qt::DirectConnection);
    QObject::connect(p_access_action_, SIGNAL(signal_PubStatus(std::string)), this,
                     SLOT(slot_PubNavStatus(std::string)), Qt::DirectConnection);
    QObject::connect(p_interface_action_, SIGNAL(signal_PubStatus(std::string)), this,
                     SLOT(slot_PubNavStatus(std::string)), Qt::DirectConnection);
    QObject::connect(p_lift_action_, SIGNAL(signal_PubStatus(std::string)), this,
                     SLOT(slot_PubNavStatus(std::string)), Qt::DirectConnection);
    QObject::connect(p_back_home_, SIGNAL(signal_PubStatus(std::string)), this,
                     SLOT(slot_PubNavStatus(std::string)), Qt::DirectConnection);
    QObject::connect(p_teach_action_, SIGNAL(signal_PubStatus(std::string)), this,
                     SLOT(slot_PubNavStatus(std::string)), Qt::DirectConnection);//示教路径类
    QObject::connect(p_cover_path_action_, SIGNAL(signal_PubStatus(std::string)), this, 
                     SLOT(slot_PubNavStatus(std::string)), Qt::DirectConnection);//覆盖路径类

    // navcontrol和各个类请求move_action类进行规划控制
    QObject::connect(this, SIGNAL(signal_MoveCmd(QVariant)), p_move_action_,
                     SLOT(slot_MoveCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_access_lift_shared_, SIGNAL(signal_MoveCmd(QVariant)), p_move_action_,
                     SLOT(slot_MoveCmd(QVariant)), Qt::DirectConnection);
    QObject::connect(p_access_action_, SIGNAL(signal_MoveCmd(QVariant)), p_move_action_,
                     SLOT(slot_MoveCmd(QVariant)), Qt::DirectConnection);
    QObject::connect(p_back_home_, SIGNAL(signal_MoveCmd(QVariant)), p_move_action_,
                     SLOT(slot_MoveCmd(QVariant)), Qt::DirectConnection);
    QObject::connect(p_cover_action_, SIGNAL(signal_MoveCmd(QVariant)), p_move_action_,
                     SLOT(slot_MoveCmd(QVariant)), Qt::DirectConnection);
    QObject::connect(p_normal_action_, SIGNAL(signal_MoveCmd(QVariant)), p_move_action_,
                     SLOT(slot_MoveCmd(QVariant)), Qt::DirectConnection);
    QObject::connect(p_teach_action_, SIGNAL(signal_MoveCmd(QVariant)), p_move_action_,
                     SLOT(slot_MoveCmd(QVariant)), Qt::DirectConnection);
    QObject::connect(p_cover_path_action_, SIGNAL(signal_MoveCmd(QVariant)), p_move_action_, 
                     SLOT(slot_MoveCmd(QVariant)), Qt::DirectConnection);

    // 返航点和普通点请求门禁闸机乘梯共享类
    QObject::connect(p_back_home_, SIGNAL(signal_AccessLiftCmd(QVariant)), p_access_lift_shared_,
                     SLOT(slot_SetCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_normal_action_, SIGNAL(signal_AccessLiftCmd(QVariant)), p_access_lift_shared_,
                     SLOT(slot_SetCmd(const QVariant)), Qt::DirectConnection);

    // 门禁闸机乘梯共享类请求门禁闸机类和乘梯类
    QObject::connect(p_access_lift_shared_, SIGNAL(signal_toAccesssAction(QString)), p_access_action_,
                     SLOT(slot_NewTask(const QString)), Qt::DirectConnection);
    QObject::connect(p_access_lift_shared_, SIGNAL(signal_toLiftAction(QString)), p_lift_action_,
                     SLOT(slot_NewTask(const QString)), Qt::DirectConnection);

    // 乘梯、门禁闸机、返航需要调用位置精确控制类
    QObject::connect(p_access_lift_shared_, SIGNAL(signal_AccurateControl(QVariant)), p_accurate_control_shared_,
                     SLOT(slot_SetCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_access_action_, SIGNAL(signal_AccurateControl(QVariant)), p_accurate_control_shared_,
                     SLOT(slot_SetCmd(const QVariant)), Qt::DirectConnection);
    QObject::connect(p_back_home_, SIGNAL(signal_AccurateControl(QVariant)), p_accurate_control_shared_,
                     SLOT(slot_SetCmd(const QVariant)), Qt::DirectConnection);

    // 请求cover类的面积
    QObject::connect(this, SIGNAL(signal_RequireArea()), p_cover_action_,
                     SLOT(RequireArea()), Qt::DirectConnection);

    // 20241127 cover_action
    QObject::connect(p_cover_action_, SIGNAL(signal_CmdVel(CmdVelStr)), p_move_action_,
                     SLOT(slot_CmdVel(CmdVelStr)), Qt::DirectConnection);
    QObject::connect(p_cover_action_, SIGNAL(signal_PubVoice(std::string)), p_interface_action_,
                     SLOT(slot_PubVoice(std::string)), Qt::DirectConnection);
    //示教路径类
    QObject::connect(p_teach_action_, SIGNAL(signal_CmdVel(CmdVelStr)), p_move_action_,
                     SLOT(slot_CmdVel(CmdVelStr)), Qt::DirectConnection);
    // QObject::connect(p_teach_action_, SIGNAL(signal_ReqPeripheralCtrl(std::string)), this,
    //                  SLOT(slot_ReqPeripheralCtrl(std::string)), Qt::DirectConnection);//示教路径打开外设类
    //覆盖路径类
    QObject::connect(p_cover_path_action_, SIGNAL(signal_CmdVel(CmdVelStr)), p_move_action_, 
                     SLOT(slot_CmdVel(CmdVelStr)), Qt::DirectConnection);
    // QObject::connect(p_cover_path_action_, SIGNAL(signal_ReqPeripheralCtrl(std::string)), this,
    //                  SLOT(slot_ReqPeripheralCtrl(std::string)), Qt::DirectConnection);//覆盖路径打开外设类

    // 子类节点初始化、启动
    p_access_lift_shared_->Init();
    p_access_action_->Init();
    p_accurate_control_shared_->Init();
    p_back_home_->Init();
    // p_cover_action_->Init();
    p_database_action_->Init();
    p_interface_action_->Init();
    p_lift_action_->Init();
    p_move_action_->Init();
    p_normal_action_->Init();
    p_teach_action_->Init();
    p_cover_path_action_->Init();

    // 发布导航状态和导航故障码定时器
    init_timer_ = new QTimer(this);
    connect(init_timer_, &QTimer::timeout, this, &NavControl::slot_RosRun);
    init_timer_->start(20);
}
/**********************************************************************
 * * @function:    slot_PubNavStatus 
 * * @brief:       发布导航状态话题的槽函数
 * * @input:       status: 导航状态字符串
 * * @output:      发布导航状态消息
 * * @return:      void：无返回值
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NavControl::slot_PubNavStatus(std::string status)
{
    std::lock_guard<std::mutex> lock(robot_status_mutex_);
    robot_status_msg_.data = status;
    pub_nav_status_.publish(robot_status_msg_);
    LOG(INFO) << "收到了命令,发布导航状态话题，robot_status_msg_：" << status;
}
/**********************************************************************
 * * @function:    slot_RosRun 
 * * @brief:       定时器回调函数，周期性发布导航状态和故障码
 * * @input:       无
 * * @output:      发布导航状态和故障信息
 * * @return:      void：无返回值 
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NavControl::slot_RosRun()
{
    static int s_pub = 0;
    if (s_pub >= 100000)
    {
        s_pub = 0;
    }

    // 25Hz的频率自动发布导航状态话题
    if (s_pub % 2 == 0)
    {
        std::lock_guard<std::mutex> lock(robot_status_mutex_);
        pub_nav_status_.publish(robot_status_msg_);
    }


    // if (s_pub % 60 == 0)
    // {
    //     std_msgs::String msg;
    //     msg.data = "all_plan_areas: " + std::to_string(allarea_) +
    //                ";cleaned_areas: " + std::to_string(cleanedarea_) +
    //                ";all_point_number: " + std::to_string(all_point_number_) +
    //                ";now_num_area: " + std::to_string(exed_point_number_) +
    //                ";point_name: " + now_send_point_info_.point_name +
    //                ";map_name: " + now_send_point_info_.point_map;
    // }

    // 1Hz的频率发布导航故障码
    if (s_pub % 50 == 0)
    {   // 统计覆盖区域
        CountNavProgress();
        std_msgs::String msg;
        msg.data = "nav_control:";
        if (p_shard_data_->fault_code_.B0410)
            msg.data += "B0410,";
        if (p_shard_data_->fault_code_.B0411)
            msg.data += "B0411,";
        if (p_shard_data_->fault_code_.B0412)
            msg.data += "B0412,";
        if (p_shard_data_->fault_code_.B0413)
            msg.data += "B0413,";
        if (p_shard_data_->fault_code_.B0414)
            msg.data += "B0414,";
        if (p_shard_data_->fault_code_.B0415)
            msg.data += "B0415,";
        if (p_shard_data_->fault_code_.B0416)
            msg.data += "B0416,";
        if (p_shard_data_->fault_code_.B0417)
            msg.data += "B0417,";
        if (p_shard_data_->fault_code_.B0418)
            msg.data += "B0418,";
        if (p_shard_data_->fault_code_.B0419)
            msg.data += "B0419,";
        if (p_shard_data_->fault_code_.B0602)
            msg.data += "B0602,";
        if (p_shard_data_->fault_code_.B0603)
            msg.data += "B0603,";
        if (p_shard_data_->fault_code_.B0604)
            msg.data += "B0604,";
        if (p_shard_data_->fault_code_.B0490)
            msg.data += "B0490,";
        if (p_shard_data_->fault_code_.B0491)
            msg.data += "B0491,";
        if (p_shard_data_->fault_code_.B0492)
            msg.data += "B0492,";
        if (p_shard_data_->fault_code_.B0493)
            msg.data += "B0493,";
        if (p_shard_data_->fault_code_.B0494)
            msg.data += "B0494,";
        if (p_shard_data_->fault_code_.B0495)
            msg.data += "B0495,";
        if (p_shard_data_->fault_code_.B0496)
            msg.data += "B0496,";
        if (p_shard_data_->fault_code_.B0497)
            msg.data += "B0497,";
        if (p_shard_data_->fault_code_.B0498)
            msg.data += "B0498,";
        if (msg.data.length() > 12)
        {
            pub_error_.publish(msg);
        }
    }

    s_pub++;
}
/**
 * 
 * 统计任务进展
 */
void NavControl::CountNavProgress()
{
    if (p_shard_data_->move_status_ != MoveStatus::RUNNING) {
        return;
    }
    if (now_send_point_info_.point_type == "cover_path") {
        MonitorCoverPathProgress();
    }
    static int call_count = 0;
    call_count++;
    if (call_count % 10 == 0) {  // 每10次调用输出一次调试信息
        LOG(INFO) << "cleanedarea_=" << cleanedarea_ << ", exed_point_number_=" << exed_point_number_;
    }
    p_shard_data_->nav_progress_.current_index = exed_point_number_ + 1;
    PointInfo current_point = now_send_point_info_;
    
    if (now_send_point_info_.point_type == "cover_path" || now_send_point_info_.point_type == "teach_path") 
    {
        UpdateCurrentPassedPointId();
        // 确保路径信息已计算
        if (p_shard_data_->current_path_info_.is_calculated && 
            p_shard_data_->current_path_info_.point_name == now_send_point_info_.point_name) 
        {
            double current_path_length = p_shard_data_->current_path_info_.path_length;
            double current_path_area = p_shard_data_->current_path_info_.path_area;
            
            double dis_to_end = p_shard_data_->nav_progress_.dis_to_end;
            // 获取剩余距离
            std::cout<<"dis_to_end:"<<p_shard_data_->nav_progress_.dis_to_end<<std::endl;
            // 处理无效的剩余距离值
            if (dis_to_end <= 0 || dis_to_end > current_path_length * 2) {
                // 如果 dis_to_end 无效（0、-1 或异常大的值），使用路径总长
                dis_to_end = current_path_length;
                LOG(WARNING) << "检测到无效的剩余距离值: " << p_shard_data_->nav_progress_.dis_to_end << ", 使用路径总长: "  << current_path_length;
            }else if(dis_to_end > current_path_length * 0.8){
                p_shard_data_->at_start_=true;
                p_shard_data_->at_end_=false;
                LOG(INFO) << "at_start_:" << p_shard_data_->at_start_ << "at_end_:" << p_shard_data_->at_end_;
            }
            dis_to_end = std::clamp(dis_to_end, 0.0, current_path_length);
            
            // 计算当前路径完成比例
            double current_path_completed_ratio = 0.0;
            if (current_path_length > 0) {
                current_path_completed_ratio = (current_path_length - dis_to_end) / current_path_length;
                current_path_completed_ratio = std::clamp(current_path_completed_ratio, 0.0, 1.0);
            }
            
            // 计算当前路径已完成的面积
            double current_path_completed_area = current_path_area * current_path_completed_ratio;
            
            // 总已完成面积 = 已完成的路径总面积 + 当前路径已完成的部分
            double total_completed_area = cleanedarea_ + current_path_completed_area;
            
            // 计算剩余面积
            double total_area = p_shard_data_->nav_progress_.total_areas;
            double remaining_area = std::max(0.0, total_area - total_completed_area);
            if(remaining_area > 0 && remaining_area < p_shard_data_->nav_progress_.last_areas)
		    {
		        p_shard_data_->nav_progress_.last_areas = remaining_area;
		    }
            //p_shard_data_->nav_progress_.last_areas = remaining_area;
            
            /*ROS_INFO("DEBUG;路径 %s 进度: 起点=%d, 终点=%d, 已完成=%.1f%%, 当前完成面积=%.2f/%.2fm², 累计完成=%.2f/%.2fm²", 
                    now_send_point_info_.point_name.c_str(),
                    has_started ? 1 : 0,
                    has_finished ? 1 : 0,
                    current_path_completed_ratio * 100.0,
                    current_path_completed_area, current_path_area,
                    total_completed_area, total_area);*/
            LOG(INFO) << "路径 " << now_send_point_info_.point_name << " 进度: 已完成=" << current_path_completed_ratio * 100.0 << ", 当前完成面积=" << current_path_completed_area << "/" << current_path_area << ", 累计完成=" << total_completed_area << "/" << total_area;

            
            // 如果到达终点，更新标志
            //if (has_finished) {
                // 根据路径类型重置标志
                if (now_send_point_info_.point_type == "cover_path") {
                    p_shard_data_->is_cover_path_start_ = false;
                    p_shard_data_->is_cover_path_end_ = false;
                } else if (now_send_point_info_.point_type == "teach_path") {
                    p_shard_data_->is_teach_path_start_ = false;
                    p_shard_data_->is_teach_path_end_ = false;
                }
            //}
        }
    } else {
        // 普通点的处理逻辑
        double dis_to_end = p_shard_data_->nav_progress_.dis_to_end;
        double total_length = p_shard_data_->nav_progress_.total_length;
        //std::cout<<"cover dis_to_end:"<<p_shard_data_->nav_progress_.dis_to_end<<std::endl;
        //std::cout<<"cover total_length:"<<p_shard_data_->nav_progress_.total_length<<std::endl;
        // 普通点：检查是否有距离信息，如果没有则不计算
        if (total_length <= 0) {
            return;
        }
        
        double last_areas = p_shard_data_->nav_progress_.total_areas -
                (cleanedarea_ +
                    (total_length - (dis_to_end > 0 ? dis_to_end : total_length)) * effective_robot_radius_
                );
        
        if(last_areas > 0 && last_areas < p_shard_data_->nav_progress_.last_areas)
        {
            p_shard_data_->nav_progress_.last_areas = last_areas;
        }
    }
    
    // 更新其他进度信息
    p_shard_data_->nav_progress_.current_area_name = now_send_point_info_.point_name;
    auto end = std::chrono::high_resolution_clock::now();
    int sec = std::chrono::duration_cast<std::chrono::seconds>(end - task_starttime_).count();
    p_shard_data_->nav_progress_.actual_time = std::to_string(sec/60.);
    
    std::string msg = "total_areas:" + std::to_string(p_shard_data_->nav_progress_.total_areas)
            + ";last_areas:" + std::to_string(p_shard_data_->nav_progress_.last_areas)
            + ";num_areas:" + std::to_string(p_shard_data_->nav_progress_.num_areas)
            + ";current_index:" + std::to_string(p_shard_data_->nav_progress_.current_index)
            + ";current_area_name:" + p_shard_data_->nav_progress_.current_area_name
            + ";current_pose:" + std::to_string(p_shard_data_->nav_progress_.current_pose.x)
            + "," + std::to_string(p_shard_data_->nav_progress_.current_pose.y)
            + "," + std::to_string(p_shard_data_->nav_progress_.current_pose.yaw)
            + ";total_time:" + std::to_string(p_shard_data_->nav_progress_.total_time)
            + ";actual_time:" + p_shard_data_->nav_progress_.actual_time;
    
    PublishNavProgress(msg);
}
/**********************************************************************
 * * @function:    slot_NewCmd 
 * * @brief:       接收interface_action发送的指令的槽函数
 * * @input:       movecmd: 包含移动命令数据的QVariant对象
 * * @output:      更新数据库，处理各种导航命令
 * * @return:      void：无返回值
 * * @note:        处理marker点、返航点、位置点、结束、取消、暂停、继续等命令
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NavControl::slot_NewCmd(const QVariant movecmd)
{
    // 接收到interface指令，首先更新一下数据库
    p_database_action_->ReadMaplist(p_shard_data_->maplist_);
    p_database_action_->ReadAllWaypointList(p_shard_data_->maplist_, p_shard_data_->waypoint_list_);

    MoveDataCmd mdc;
    mdc = movecmd.value<MoveDataCmd>();
    LOG(INFO) << "DEBUG;navcontrol收到指令类型:" << mdc.taskcmd_type;
    //qDEBUG() << "navcontrol nav收到了interface的命令" << endl;
    LOG(INFO) << "slot_NewCmd收到了interface的命令,p_shard_data_->move_status_的状态为:" << p_shard_data_->move_status_;

    if (mdc.taskcmd_type == TaskStatus::T_MARKET)
    {
        task_starttime_ = std::chrono::high_resolution_clock::now();
        if (running_flg_)
        {
            // 取消所有任务
            p_move_action_->movebase_client_.cancelAllGoals();
            LOG(INFO) << "slot_NewCmd收到了interface的marker点，但是目前状态为running,首先取消当前任务";
        }
        else
        {
            LOG(INFO) << "slot_NewCmd收到了interface的marker点，目前状态不为running,可以直接执行任务";
        }
        {
            std::lock_guard<std::mutex> lock(robot_status_mutex_);
            robot_status_msg_.data = "FREE";
        }
        task_index_ = Task_Index::TASK_READY;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_BACK)
    {
            // 检查是否在乘梯状态
        if (p_shard_data_->resume_status_ == ResumeStatus::RESUME_PAUSED && 
            p_shard_data_->waiting_for_resume_) {
            LOG(INFO) << "中断续扫状态收到返航命令，准备返航后恢复路径";
            
            // 设置状态为返航中
            p_shard_data_->resume_status_ = ResumeStatus::RESUME_BACK_HOME;
            
            // 清空当前队列，准备返航
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                std::queue<PointInfo> empty;
                std::swap(empty, target_queue_);
            }
            
            // 添加返航点
            PointInfo back_point_info;
            back_point_info.point_type = "back";
            back_point_info.point_name = "INTERRUPT_RESUME_BACK";
            PoseData temp;
            back_point_info.point_array.push_back(temp);
            
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                target_queue_.push(back_point_info);
            }
            
            task_index_ = Task_Index::TASK_HANDOUT;
            LOG(INFO) << "中断续扫状态，设置返航任务";
        }
        else if (p_shard_data_->current_lift_state_)
        {
            LOG(INFO) << "slot_NewCmd收到了interface的返航命令，目前在乘梯状态";
            
            // 不清除当前任务，但设置标志和准备返航任务
            // 不立即清空target_queue_，因为乘梯任务还在进行
            
            // 设置标志，让乘梯完成后执行返航
            p_shard_data_->task_cancel_during_lift_ = true;            
            {
                std::lock_guard<std::mutex> lock(robot_status_mutex_);
                robot_status_msg_.data = "CANCEL_FOR_BACK";
            }
            
            // 创建返航点信息并保存，但不立即放入队列
            PointInfo back_point_info;
            back_point_info.point_type = "back";
            PoseData temp;
            back_point_info.point_array.push_back(temp);
            
            // 保存返航点到待执行任务
            p_shard_data_->pending_back_point_ = back_point_info;  // 需要添加这个成员变量
            
            LOG(INFO) << "乘梯中收到返航命令，保存返航点等待乘梯完成";
            return;  // 立即返回，不执行下面的逻辑
        }
        else{	
            if (running_flg_)
            {
                // 取消所有任务
                p_move_action_->movebase_client_.cancelAllGoals();
                LOG(INFO) << "slot_NewCmd收到了interface的back点，但是目前状态为running,首先取消当前任务";
            }
            else
            {
                LOG(INFO) << "slot_NewCmd收到了interface的back点，目前状态不为running,可以直接执行任务";
            }
            // 任务取消，队列清空，状态置位
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                std::queue<PointInfo> empty0;
                std::swap(empty0, target_queue_);
            }
            std::vector<ApiPointInfo> empty1;
            std::swap(empty1, p_shard_data_->api_recved_target_vector_);
            PointInfo point_info;
            point_info.point_type = "back";
            PoseData temp;
            point_info.point_array.push_back(temp);
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                target_queue_.push(point_info);
            }
            task_index_ = Task_Index::TASK_HANDOUT;
            LOG(INFO) << "设置返航任务，task_index_ = TASK_HANDOUT";
        }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_LOCALE)
    {
        if (running_flg_)
        {
            // 取消所有任务
            p_move_action_->movebase_client_.cancelAllGoals();
            LOG(INFO) << "slot_NewCmd收到了interface的location点，但是目前状态为running,首先取消当前任务";
        }
        else
        {
            LOG(INFO) << "slot_NewCmd收到了interface的location点，目前状态不为running,可以直接执行任务";
        }
        // 任务取消，队列清空，状态置位
        {
            std::lock_guard<std::mutex> lock(target_queue_mutex_);
            std::queue<PointInfo> empty0;
            std::swap(empty0, target_queue_);
        }
        std::vector<ApiPointInfo> empty1;
        std::swap(empty1, p_shard_data_->api_recved_target_vector_);
        PointInfo point_info;
        point_info.point_type = "location";
        PoseData temp;
        temp.x = p_shard_data_->location_point_.x;
        temp.y = p_shard_data_->location_point_.y;
        temp.yaw = p_shard_data_->location_point_.yaw;
        point_info.point_array.push_back(temp);
        {
            std::lock_guard<std::mutex> lock(target_queue_mutex_);
            target_queue_.push(point_info);
        }
        task_index_ = Task_Index::TASK_HANDOUT;
    }
    else if (mdc.taskcmd_type == TaskStatus::T_END)
    {
        LOG(INFO) << "slot_NewCmd收到了interface的T_END";
        p_shard_data_->skip_all_rescan_after_resume_ = false;
        //清理补扫相关状态
        {
            std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
            
            // 清空补扫信息映射
            p_shard_data_->cover_path_rescan_map_.clear();
            
            // 清空待补扫队列
            while (!p_shard_data_->pending_rescan_queue_.empty()) {
                std::string path_name = p_shard_data_->pending_rescan_queue_.front();
                LOG(INFO) << "清空待补扫队列: " << path_name;
                p_shard_data_->pending_rescan_queue_.pop();
            }
            
            // 重置补扫执行标志
            p_shard_data_->is_executing_rescan_ = false;
            p_shard_data_->current_rescan_path_name_.clear();
            
            LOG(INFO) << "已清空所有补扫信息";
        }
        
        // 重置监控状态
        ResetCoverPathMonitor("");
        obstacle_encounter_count_ = 0;
        is_in_obstacle_ = false;
        last_valid_dis_to_end_ = -1;
        consecutive_invalid_count_ = 0;
        // 检查是否在乘梯状态
        if (p_shard_data_->current_lift_state_)
        {
            // 在乘梯状态，不立即取消，只清空队列和存储新任务
            LOG(INFO) << "slot_NewCmd收到了interface的T_END，目前在乘梯状态，不清除任务只清空队列";
            
            // 任务取消，队列清空，状态置位（但不清除乘梯相关状态）
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                std::queue<PointInfo> empty0;
                std::swap(empty0, target_queue_);
            }
            std::vector<ApiPointInfo> empty1;
            std::swap(empty1, p_shard_data_->api_recved_target_vector_);
            p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->teach_success_ = false;
            p_shard_data_->cover_success_ = false;
            p_shard_data_->teach_fault_ = false;
            p_shard_data_->cover_fault_ = false;
            LOG(INFO) << "已重置teachingpath_nav_status_和coverpath_nav_status_为NAV_IDLE";

            // 不停止电机，不发送取消命令到其他模块
            // 只设置状态为CANCEL，但不中断当前乘梯流程
            {
                std::lock_guard<std::mutex> lock(robot_status_mutex_);
                robot_status_msg_.data = "CANCEL_FOR_NEW_TASK";
            }
            
            // 设置标志，让乘梯完成后知道有新的任务
            p_shard_data_->task_cancel_during_lift_ = true;
        }
	else {	
	       if (running_flg_)
            {
                LOG(INFO) << "slot_NewCmd收到了interface的T_END，目前状态为running，发送取消指令movebase_client_.cancelAllGoals()";
                // 取消所有任务
                p_move_action_->movebase_client_.cancelAllGoals();
            }
            else
            {
                LOG(INFO) << "slot_NewCmd收到了interface的T_END，目前状态不为running，不发送取消指令movebase_client_.cancelAllGoals()";
            }

            task_index_ = Task_Index::TASK_IDLE;
            {
                std::lock_guard<std::mutex> lock(robot_status_mutex_);
                robot_status_msg_.data = "CANCEL";
            }
            // 任务取消，队列清空，状态置位
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                std::queue<PointInfo> empty0;
                std::swap(empty0, target_queue_);
            }
            std::vector<ApiPointInfo> empty1;
            std::swap(empty1, p_shard_data_->api_recved_target_vector_);
            p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->teach_success_ = false;
            p_shard_data_->cover_success_ = false;
            p_shard_data_->teach_fault_ = false;
            p_shard_data_->cover_fault_ = false;
            LOG(INFO) << "已重置teachingpath_nav_status_和coverpath_nav_status_为NAV_IDLE";

            MoveDataCmd mdc;
            mdc.taskcmd_type = TaskStatus::T_CANCEL;
            QVariant qvr;
            qvr.setValue(mdc);
            LOG(INFO) << "slot_NewCmd收到了interface的T_END，向move_action发送T_CANCEL";
            emit signal_MoveCmd(qvr);
            // 20250606 c_add 取消导航后，单独起线程延迟1秒失能电机
            auto future = std::async(std::launch::async, [this] {
                std::this_thread::sleep_for(std::chrono::seconds(1));
                LOG(INFO) << "slot_NewCmd收到了interface的T_END，等待一秒后失能电机";
                // 关闭电机
                std_msgs::Bool msg;
                msg.data = false;
                pub_motor_.publish(msg);
            });
	    }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_CANCEL)
    {
        LOG(INFO) << "slot_NewCmd收到了interface的T_CANCEL";
        p_shard_data_->skip_all_rescan_after_resume_ = false;
        //清理补扫相关状态
        {
            std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
            
            // 清空补扫信息映射
            p_shard_data_->cover_path_rescan_map_.clear();
            
            // 清空待补扫队列
            while (!p_shard_data_->pending_rescan_queue_.empty()) {
                std::string path_name = p_shard_data_->pending_rescan_queue_.front();
                LOG(INFO) << "清空待补扫队列: " << path_name;
                p_shard_data_->pending_rescan_queue_.pop();
            }
            
            // 重置补扫执行标志
            p_shard_data_->is_executing_rescan_ = false;
            p_shard_data_->current_rescan_path_name_.clear(); 
            LOG(INFO) << "已清空所有补扫信息";
        }
        
        // 重置监控状态
        ResetCoverPathMonitor("");
        obstacle_encounter_count_ = 0;
        is_in_obstacle_ = false;
        last_valid_dis_to_end_ = -1;
        consecutive_invalid_count_ = 0;
        
        // 只有不在乘梯的时候T_CANCEL才能直接取消所有点的运动
        if (!p_shard_data_->current_lift_state_)
        {
            if (running_flg_)
            {
                LOG(INFO) << "slot_NewCmd收到了interface的T_CANCEL，目前状态为running，发送取消指令movebase_client_.cancelAllGoals()";
                // 取消所有任务
                p_move_action_->movebase_client_.cancelAllGoals();
            }
            else
            {
                LOG(INFO) << "slot_NewCmd收到了interface的T_CANCEL，目前状态不为running，不发送取消指令movebase_client_.cancelAllGoals()";
            }

            task_index_ = Task_Index::TASK_IDLE;
            {
                std::lock_guard<std::mutex> lock(robot_status_mutex_);
                robot_status_msg_.data = "CANCEL";
            }
            // 任务取消，队列清空，状态置位
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                std::queue<PointInfo> empty0;
                std::swap(empty0, target_queue_);
            }
            std::vector<ApiPointInfo> empty1;
            std::swap(empty1, p_shard_data_->api_recved_target_vector_);
            p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->teach_success_ = false;
            p_shard_data_->cover_success_ = false;
            p_shard_data_->teach_fault_ = false;
            p_shard_data_->cover_fault_ = false;
            LOG(INFO) << "已重置teachingpath_nav_status_和coverpath_nav_status_为NAV_IDLE";

            MoveDataCmd mdc;
            mdc.taskcmd_type = TaskStatus::T_CANCEL;
            QVariant qvr;
            qvr.setValue(mdc);
            LOG(INFO) << "slot_NewCmd向move_action发送T_CANCEL";
            emit signal_MoveCmd(qvr);
        }
        else
        {
            // 任务取消，队列清空，状态置位
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                std::queue<PointInfo> empty0;
                std::swap(empty0, target_queue_);
            }
            std::vector<ApiPointInfo> empty1;
            std::swap(empty1, p_shard_data_->api_recved_target_vector_);
            p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
            p_shard_data_->teach_success_ = false;
            p_shard_data_->cover_success_ = false;
            p_shard_data_->teach_fault_ = false;
            p_shard_data_->cover_fault_ = false;
            LOG(INFO) << "已重置teachingpath_nav_status_和coverpath_nav_status_为NAV_IDLE";
            path_processing_mode_ = false;
            current_processing_path_type_.clear();
            LOG(INFO) << "slot_NewCmd收到了interface的T_CANCEL，在乘梯状态发送新指令时，清空路点队列，防止再次重新跑旧路点";
        }
        //cancel_received_ = false;
        // 20250606 c_add 取消导航后，单独起线程延迟1秒失能电机
        auto future = std::async(std::launch::async, [this] {
            std::this_thread::sleep_for(std::chrono::seconds(1));
            LOG(INFO) << "slot_NewCmd收到了interface的T_END，等待一秒后失能电机";
            // 关闭电机
            std_msgs::Bool msg;
            msg.data = false;
            pub_motor_.publish(msg);
        });
    }
    else if (mdc.taskcmd_type == TaskStatus::T_ESTOP)
    {
        //清理补扫相关状态
        {
            std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
            
            // 清空补扫信息映射
            p_shard_data_->cover_path_rescan_map_.clear();
            
            // 清空待补扫队列
            while (!p_shard_data_->pending_rescan_queue_.empty()) {
                std::string path_name = p_shard_data_->pending_rescan_queue_.front();
                LOG(INFO) << "T_CANCEL清空待补扫队列: " << path_name;
                p_shard_data_->pending_rescan_queue_.pop();
            }
            
            // 重置补扫执行标志
            p_shard_data_->is_executing_rescan_ = false;
            p_shard_data_->current_rescan_path_name_.clear();
            
            LOG(INFO) << "已清空所有补扫信息";
        }
        
        // 重置监控状态
        ResetCoverPathMonitor("");
        obstacle_encounter_count_ = 0;
        is_in_obstacle_ = false;
        last_valid_dis_to_end_ = -1;
        consecutive_invalid_count_ = 0;
        
        std::string current_path_type = now_send_point_info_.point_type;
        if (running_flg_ && (current_path_type == "cover_path" || current_path_type == "teach_path"))
            {
                LOG(INFO) << "收到T_ESTOP，立即停止路径执行: " << now_send_point_info_.point_name;
                
                // 1. 立即取消所有运动目标
                p_move_action_->movebase_client_.cancelAllGoals();
                LOG(INFO) << "已发送cancelAllGoals()取消所有运动目标";
                
                // 2. 发送紧急停止命令给move_action
                MoveDataCmd estop_cmd;
                estop_cmd.taskcmd_type = TaskStatus::T_ESTOP;
                QVariant qvr_estop;
                qvr_estop.setValue(estop_cmd);
                emit signal_MoveCmd(qvr_estop);
                LOG(INFO) << "已发送T_ESTOP给move_action";
                
                // 3. 通过共享数据通知路径执行类
                if (current_path_type == "cover_path") {
                    p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_STOP;
                    LOG(INFO) << "设置coverpath_nav_status_为NAV_STOP";
                    
                    // 直接调用CoverPathAction的暂停函数
                    if (p_cover_path_action_) {
                        LOG(INFO) << "调用CoverPathAction的slot_NewCmd暂停";
                        QVariant qv_cmd;
                        MoveDataCmd path_estop_cmd;
                        path_estop_cmd.taskcmd_type = TaskStatus::T_ESTOP;
                        qv_cmd.setValue(path_estop_cmd);
                        p_cover_path_action_->slot_NewCmd(qv_cmd);
                    }
                } 
                else if (current_path_type == "teach_path") {
                    p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_STOP;
                    LOG(INFO) << "设置teachingpath_nav_status_为NAV_STOP";
                    
                    if (p_teach_action_) {
                        LOG(INFO) << "调用TeachAction的slot_NewCmd暂停";

                        QVariant qv_cmd;
                        MoveDataCmd path_estop_cmd;
                        path_estop_cmd.taskcmd_type = TaskStatus::T_ESTOP;
                        qv_cmd.setValue(path_estop_cmd);
                        p_teach_action_->signal_MoveCmd(qv_cmd);
                    }
                }
                
                // 4. 设置移动状态为停止
                p_shard_data_->move_status_ = MoveStatus::ESTOP;
                LOG(INFO) << "设置move_status_为ESTOP";
                
                // 5. 保存中断信息到共享数据
                SaveInterruptedPathInfo(now_send_point_info_);
                
                // 6. 从目标队列中移除当前点（但保存在暂停队列中）
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    if (!target_queue_.empty() && 
                        target_queue_.front().point_name == now_send_point_info_.point_name) {
                        target_queue_.pop();
                        LOG(INFO) << "从目标队列移除当前路径点";
                    }
                }
                
                // 7. 设置状态为中断续扫等待
                p_shard_data_->resume_status_ = ResumeStatus::RESUME_PAUSED;
                p_shard_data_->waiting_for_resume_ = true;
                p_shard_data_->resume_path_type_ = now_send_point_info_.point_type;
                p_shard_data_->resume_path_name_ = now_send_point_info_.point_name;
                
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "PATH_PAUSED_" + now_send_point_info_.point_name + "_WAITING_RESUME";
                }
                
                // 8. 发布停止速度命令
                MoveDataCmd stop_cmd;
                stop_cmd.taskcmd_type = TaskStatus::T_CANCEL;
                QVariant qvr_stop;
                qvr_stop.setValue(stop_cmd);
                emit signal_MoveCmd(qvr_stop);
                
                // 9. 记录日志
                LOG(INFO) << "路径执行已暂停，等待返航和续扫: " << now_send_point_info_.point_name << 
                        ", 已完成" << p_shard_data_->paused_path_info_.completed_ratio * 100.0 << "%";
            }
        else
        {
            if (running_flg_)
            {
                LOG(INFO) << "slot_NewCmd收到了interface的T_ESTOP，目前状态为running，发送取消指令movebase_client_.cancelAllGoals()";
                // 取消所有任务
                p_move_action_->movebase_client_.cancelAllGoals();
            }
            else
            {
                LOG(INFO) << "slot_NewCmd收到了interface的T_ESTOP，目前状态不为running，不发送取消指令movebase_client_.cancelAllGoals()";
            }

            task_index_ = Task_Index::TASK_IDLE;
            {
                if(!motorJstop){
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "STOP_RUNNING";
                    motorJstop=false;
                }
            }
            // T_ESTOP暂停后，存储剩下未执行的路点
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                if (target_queue_.size() > 0)
                {
                    std::queue<PointInfo> empty0;
                    std::swap(empty0, stop_from_target_queue_);
                    // 将target_queue_赋值为stop_from_target_queue_
                    std::swap(target_queue_, stop_from_target_queue_);
                    std::queue<PointInfo> empty2;
                    // 清空原先的任务队列
                    std::swap(empty2, target_queue_);
                    LOG(INFO) << "slot_NewCmd收到了interface的T_ESTOP，target_queue_不为空，存储剩下未执行的路点";
                }
                else
                {
                    LOG(INFO) << "slot_NewCmd收到了interface的T_ESTOP，target_queue_为空，不需要存储剩下未执行的路点";
                }
            }
        }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_GOON)
    {
        // 在运动过程当中，无法进行继续
        if (running_flg_)
        {
            LOG(INFO) << "slot_NewCmd收到了interface的T_GOON，在运动当中，继续命令失效";
        }
        else
        {
            LOG(INFO) << "收到继续命令，检查是否有暂停的路径需要恢复";      
            // 获取当前路径类型
            std::string resume_path_type = p_shard_data_->paused_path_info_.point_info.point_type;
            if (p_shard_data_->resume_status_ == ResumeStatus::RESUME_BACK_HOME && 
                !p_shard_data_->has_paused_path_) {
                LOG(ERROR) << "返航完成但未找到中断的路径信息";
                return;
            }
            
            if (p_shard_data_->resume_status_ == ResumeStatus::RESUME_BACK_HOME && 
                p_shard_data_->has_paused_path_) 
            {
                LOG(INFO) << "返航完成，收到继续命令，恢复中断的路径";
                
                p_shard_data_->resume_status_ = ResumeStatus::RESUME_CONTINUE;
                p_shard_data_->waiting_for_resume_ = false;
                
                // 恢复中断的路径
                if (RestoreInterruptedPath()) {
                    LOG(INFO) << "成功恢复中断的路径";
                }
                return;
            }
        
            else if (p_shard_data_->has_paused_path_)
            {
                p_shard_data_->skip_all_rescan_after_resume_ = true;
        
                std::string paused_path_type = p_shard_data_->paused_path_info_.point_info.point_type;
                std::string paused_path_name = p_shard_data_->paused_path_info_.point_info.point_name;
                LOG(INFO) << "续扫开始，将跳过后续所有覆盖路径的补扫任务";
                
                // 清除当前路径已有的补扫信息
                {
                    std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
                    
                    // 如果是覆盖路径续扫，删除该路径的补扫信息
                    if (paused_path_type == "cover_path") {
                        auto it = p_shard_data_->cover_path_rescan_map_.find(paused_path_name);
                        if (it != p_shard_data_->cover_path_rescan_map_.end()) {
                            it->second.need_rescan = false;
                            it->second.Clear();
                            LOG(INFO) << "已删除当前覆盖路径 " << paused_path_name << " 的补扫信息";
                        }
                    }
                    
                    // 清空待补扫队列
                    while (!p_shard_data_->pending_rescan_queue_.empty()) {
                        std::string path_name = p_shard_data_->pending_rescan_queue_.front();
                        LOG(INFO) << "续扫:清空待补扫队列中的 " << path_name;
                        p_shard_data_->pending_rescan_queue_.pop();
                    }
                }
                
                
                LOG(INFO) << "从路径暂停状态恢复";
                LOG(INFO) << "当前暂停信息 - has_paused_path_=" << p_shard_data_->has_paused_path_ << ", resume_status=" << 
                            p_shard_data_->resume_status_ << ", waiting_for_resume=" << p_shard_data_->waiting_for_resume_;
                PausedPathInfo& paused_info = p_shard_data_->paused_path_info_;
                std::string resume_type = paused_info.point_info.point_type;
                std::string resume_map = paused_info.point_info.point_map;
                std::string resume_name = paused_info.point_info.point_name;
                LOG(INFO) << "调用 " << resume_type << " 的 resume_path 命令: " << resume_map << "/" << resume_name;
                
                if (resume_type == "teach_path") {
                    PoseData pd;
                    pd.path_map = resume_map;
                    pd.path_name = resume_name;
                    if (p_teach_action_) {
                        p_teach_action_->SetCmd("resume_path", pd);
                        LOG(INFO) << "已调用 TeachAction::SetCmd(resume_path)";
                    } else {
                        LOG(ERROR) << " TeachAction 未初始化";
                    }
                } else if (resume_type == "cover_path") {
                    PoseData pd;
                    pd.path_map = resume_map;
                    pd.path_name = resume_name;
                    if (p_cover_path_action_) {
                        p_cover_path_action_->SetCmd("resume_path", pd);
                        LOG(INFO) << "已调用 CoverPathAction::SetCmd(resume_path)";
                    } else {
                        LOG(ERROR) << " CoverPathAction 未初始化";
                    }
                }


                p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_RUN;
                p_shard_data_->now_nav_status_ = "running";
                // 1. 先清空所有队列
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    std::queue<PointInfo> empty;
                    std::swap(empty, target_queue_);
                }
                
                {
                    std::queue<CoverTeachArea> empty;
                    std::swap(empty, p_shard_data_->cover_teach_area_queue_);
                }
                
                // 2. 从paused_path_info_恢复所有路径
                //PausedPathInfo& paused_info = p_shard_data_->paused_path_info_;
                std::queue<CoverTeachArea> temp_queue = paused_info.remaining_paths;
                
                while (!temp_queue.empty()) {
                    const CoverTeachArea& area = temp_queue.front();
                    
                    PointInfo path_point;
                    path_point.point_name = area.point_name;
                    path_point.point_map = area.point_map;
                    path_point.point_type = area.point_type;
                    path_point.point_array = area.path_points;
                    
                    {
                        std::lock_guard<std::mutex> lock(target_queue_mutex_);
                        target_queue_.push(path_point);
                    }
                    
                    p_shard_data_->cover_teach_area_queue_.push(area);
                    LOG(INFO) << "恢复路径: " << area.point_name << " (类型: " << area.point_type << "), 点数=" << area.path_points.size();                    
                    temp_queue.pop();
                }
                
                LOG(INFO) << "共恢复 " << p_shard_data_->cover_teach_area_queue_.size() << " 条路径";
                
                // 3. 设置当前点信息
                if (!target_queue_.empty()) {
                    now_send_point_info_ = target_queue_.front();
                }
                
                // 4. 设置路径处理模式
                path_processing_mode_ = true;
                current_processing_path_type_ = now_send_point_info_.point_type;
                
                // 5. 设置移动状态为运行
                p_shard_data_->move_status_ = MoveStatus::RUNNING;
                
                // 6. 进入路径等待状态
                task_index_ = Task_Index::TASK_PATH_WAITING;
                
                // 7. 发布恢复状态
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name;
                }
                
                // 8. 启动电机
                std_msgs::Bool motor_msg;
                motor_msg.data = true;
                pub_motor_.publish(motor_msg);
                
                // 9. 清除暂停信息（但先不删除，用于恢复执行）
                // 注意：不清除has_paused_path_，让具体的Action类去使用
                
                LOG(INFO) << "成功恢复中断的路径队列，共 " << target_queue_.size() << " 条路径";
                
                return;  // 直接返回，不执行下面的逻辑
            }
            else
            {
                LOG(INFO) << "slot_NewCmd收到了interface的T_GOON，不在运动当中，继续命令生效";
                task_index_ = Task_Index::TASK_IDLE;
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "FREE";
                }
                // T_GOON继续执行剩下未执行的路点stop_from_target_queue_
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    if (stop_from_target_queue_.size() > 0)
                    {
                        // 将stop_from_target_queue_再次赋值给target_queue_
                        std::swap(stop_from_target_queue_, target_queue_);
                        std::queue<PointInfo> empty2;
                        // 清空存储的剩余任务队列
                        std::swap(empty2, stop_from_target_queue_);
                        task_index_ = Task_Index::TASK_HANDOUT;
                        LOG(INFO) << "slot_NewCmd收到了interface的T_GOON，stop_from_target_queue_不为空，继续执行剩下未执行的路点";
                    }
                    else
                    {
                        task_index_ = Task_Index::TASK_FAULT;
                        LOG(INFO) << "slot_NewCmd收到了interface的T_GOON，stop_from_target_queue_为空，无法继续";
                    }
                }
            }
        }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_TASK_ESTOP)
    {
        if (running_flg_)
        {
            LOG(INFO) << "slot_NewCmd收到了interface的T_TASK_ESTOP，目前状态为running，发送取消指令movebase_client_.cancelAllGoals()";
            // 取消所有任务
            p_move_action_->movebase_client_.cancelAllGoals();
        }
        else
        {
            LOG(INFO) << "slot_NewCmd收到了interface的T_TASK_ESTOP，目前状态不为running，不发送取消指令movebase_client_.cancelAllGoals()";
        }

        task_index_ = Task_Index::TASK_IDLE;
        {
            std::lock_guard<std::mutex> lock(robot_status_mutex_);
            robot_status_msg_.data = "STOP_RUNNING";
        }
        // T_TASK_ESTOP暂停后，存储剩下未执行的路点
        {
            std::lock_guard<std::mutex> lock(target_queue_mutex_);
            if (target_queue_.size() > 0)
            {
                std::queue<PointInfo> empty0;
                std::swap(empty0, task_stop_from_target_queue_);
                // 将target_queue_赋值为task_stop_from_target_queue_
                std::swap(target_queue_, task_stop_from_target_queue_);
                std::queue<PointInfo> empty2;
                // 清空原先的任务队列
                std::swap(empty2, target_queue_);
                LOG(INFO) << "slot_NewCmd收到了interface的T_TASK_ESTOP，target_queue_不为空，存储剩下未执行的路点";
            }
            else
            {
                LOG(INFO) << "slot_NewCmd收到了interface的T_TASK_ESTOP，target_queue_为空，不需要存储剩下未执行的路点";
            }
        }
    }
    else if (mdc.taskcmd_type == TaskStatus::T_TASK_GOON)
    {
        // 在运动过程当中，无法进行继续
        if (running_flg_)
        {
            LOG(INFO) << "slot_NewCmd收到了interface的T_TASK_GOON，在运动当中，继续命令失效";
        }
        else
        {
            LOG(INFO) << "slot_NewCmd收到了interface的T_TASK_GOON，不在运动当中，继续命令生效";
            task_index_ = Task_Index::TASK_IDLE;
            {
                std::lock_guard<std::mutex> lock(robot_status_mutex_);
                robot_status_msg_.data = "FREE";
            }
            // T_TASK_GOON继续执行剩下未执行的路点task_stop_from_target_queue_
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                if (target_queue_.size() > 0)
                {
                    // 将task_stop_from_target_queue_再次赋值给target_queue_
                    std::swap(task_stop_from_target_queue_, target_queue_);
                    std::queue<PointInfo> empty2;
                    // 清空存储的剩余任务队列
                    std::swap(empty2, task_stop_from_target_queue_);
                    task_index_ = Task_Index::TASK_HANDOUT;
                    LOG(INFO) << "slot_NewCmd收到了interface的T_TASK_GOON，task_stop_from_target_queue_不为空，继续执行剩下未执行的路点";
                }
                else
                {
                    task_index_ = Task_Index::TASK_FAULT;
                    LOG(INFO) << "slot_NewCmd收到了interface的T_TASK_GOON，task_stop_from_target_queue_为空，无法继续";
                }
            }
        }
     }
   }
/**
 * 计算单条路径的长度（两点之间距离累加）
 * @param points 路径点数组
 * @return 路径总长度（米）
 */
double NavControl::CalculateSinglePathLength(const std::vector<PoseData>& points)
{
    double total_length = 0.0;
    
    if (points.size() < 2) 
    {
        LOG(WARNING) << "路径点数量不足，无法计算长度";
        return 0.0;
    }
    
    // 累加连续两点之间的欧几里得距离
    for (size_t i = 1; i < points.size(); i++) 
    {
        const auto& p1 = points[i-1];
        const auto& p2 = points[i];
        
        double dx = p2.x - p1.x;
        double dy = p2.y - p1.y;
        double segment_length = std::sqrt(dx*dx + dy*dy);
        total_length += segment_length;
    }
    
    return total_length;
}
/**
 * 恢复中断的路径
 */
bool NavControl::RestoreInterruptedPath()
{
    std::lock_guard<std::mutex> lock(p_shard_data_->paused_path_mutex_);
    
    if (!p_shard_data_->has_paused_path_) {
        LOG(ERROR) << "没有可恢复的中断路径";
        return false;
    }
    
    PausedPathInfo& paused_info = p_shard_data_->paused_path_info_;
    
    LOG(INFO) << "开始恢复中断路径，暂停点ID: " << paused_info.paused_point_id;
    
    // 清空当前队列
    {
        std::lock_guard<std::mutex> lock(target_queue_mutex_);
        std::queue<PointInfo> empty;
        std::swap(empty, target_queue_);
    }
    
    // 清空覆盖/示教路径队列
    {
        std::queue<CoverTeachArea> empty;
        std::swap(empty, p_shard_data_->cover_teach_area_queue_);
    }
    
    // 检查是否需要重新请求完整路径数据
    bool need_reload_path = false;
    
    // 如果没有剩余点或剩余点为空，需要重新从数据库加载
    if (paused_info.remaining_points.empty()) {
        need_reload_path = true;
        LOG(INFO) << "剩余点为空，需要重新从数据库加载路径";
    } else if (paused_info.paused_point_id >= paused_info.original_points.size()) {
        need_reload_path = true;
        LOG(INFO) << "暂停点ID超出范围，需要重新从数据库加载路径";
    }
    
    if (need_reload_path) {
        // 重新请求路径数据
        PointInfo reloaded_point;
        if (RequestPathData(paused_info.point_info.point_map, 
                           paused_info.point_info.point_name,
                           paused_info.point_info.point_type,
                           reloaded_point)) {
            
            // 使用新加载的路径点
            paused_info.original_points = reloaded_point.point_array;
            paused_info.remaining_points = GetRemainingPointsFromId(reloaded_point, paused_info.paused_point_id); 
            LOG(INFO) << "重新加载路径成功，获取到 " << paused_info.remaining_points.size() << " 个剩余点";
        } else {
            LOG(ERROR) << "重新加载路径失败，无法恢复";
            return false;
        }
    }
    
    // 恢复剩余路径
    if (!paused_info.remaining_points.empty()) {
        // 创建剩余路径点信息
        PointInfo remaining_path_point;
        remaining_path_point.point_name = paused_info.point_info.point_name;
        remaining_path_point.point_map = paused_info.point_info.point_map;
        remaining_path_point.point_type = paused_info.point_info.point_type;
        remaining_path_point.point_array = paused_info.remaining_points;
        
        // 添加到目标队列
        {
            std::lock_guard<std::mutex> lock(target_queue_mutex_);
            target_queue_.push(remaining_path_point);
        }
        
        // 创建CoverTeachArea
        CoverTeachArea area;
        area.point_name = paused_info.point_info.point_name;
        area.point_map = paused_info.point_info.point_map;
        area.point_type = paused_info.point_info.point_type;
        area.path_points = paused_info.remaining_points;
        area.path_length = paused_info.remaining_length;
        
        p_shard_data_->cover_teach_area_queue_.push(area);
        
        LOG(INFO) << "恢复路径: " << paused_info.point_info.point_name << "，" << "从ID " << paused_info.paused_point_id << " 之后开始，共 " <<
                    paused_info.remaining_points.size() << " 个点，剩余长度" << paused_info.remaining_length << "m";
    }
    
    // 恢复进度统计
    cleanedarea_ = paused_info.completed_area;
    exed_point_number_ = paused_info.current_path_index;
    
    // 重置状态
    task_index_ = Task_Index::TASK_HANDOUT;
    running_flg_ = true;
    
    // 启动电机
    std_msgs::Bool motor_msg;
    motor_msg.data = true;
    pub_motor_.publish(motor_msg);
    
    // 清除暂停信息
    p_shard_data_->has_paused_path_ = false;
    p_shard_data_->resume_status_ = ResumeStatus::RESUME_IDLE;
    
    // 重置经过点ID记录
    has_current_passed_id_ = false;
    last_passed_point_id_ = paused_info.paused_point_id;
    
    LOG(INFO) << "路径恢复成功，开始执行剩余路径";
    return true;
}
/**********************************************************************
 * * @function:    ListenTF 
 * * @brief:       监听指定坐标系间的TF变换并获取位姿信息
 * * @input:       target: 目标坐标系名称 source: 源坐标系名称
 * * @output:      pose: 转换后的位姿信息
 * * @return:      bool: true表示成功获取变换，false表示失败
 * * @author：     jiangcuihuan
 * * @date：       20250716
 * **********************************************************************/
bool NavControl::ListenTF(std::string target, std::string source, geometry_msgs::Pose2D &pose)
{
    try
    {
        tf_listener_.waitForTransform(target, source, ros::Time(0), ros::Duration(3.0));
        tf_listener_.lookupTransform(target, source, ros::Time(0), transform_base_link_to_map_);
    }
    catch (tf::TransformException &ex)
    {
        //ROS_ERROR("Failed to lookup transform: %s", ex.what());
        return false;
    }
    pose.x = transform_base_link_to_map_.getOrigin().x();
    pose.y = transform_base_link_to_map_.getOrigin().y();
    pose.theta = tf::getYaw(transform_base_link_to_map_.getRotation());
    return true;
}
/**
 * 保存中断的路径信息
 */
void NavControl::SaveInterruptedPathInfo(const PointInfo& current_point)
{
    std::lock_guard<std::mutex> lock(p_shard_data_->paused_path_mutex_);
    
    // 获取当前经过的点ID
    double dis_to_end = p_shard_data_->nav_progress_.dis_to_end;
    size_t current_passed_id = GetCurrentPassedPointId(current_point, dis_to_end);
    
    // 如果dis_to_end=-1，使用上一个记录的点ID
    if ((dis_to_end < 0 || std::abs(dis_to_end - (-1.0)) < 0.001) && has_current_passed_id_) {
        current_passed_id = last_passed_point_id_;
        LOG(INFO) << "暂停时dis_to_end=-1，使用上一个记录ID: " << current_passed_id;
    }
    
    // 创建暂停信息
    PausedPathInfo paused_info;
    paused_info.point_info = current_point;
    paused_info.original_points = current_point.point_array;
    paused_info.paused_point_id = current_passed_id;
    paused_info.has_paused_point_id = true;
    
    // 获取机器人当前位置
    geometry_msgs::Pose2D current_pose;
    if (ListenTF("map", "base_link", current_pose)) {
        paused_info.paused_pose_x = current_pose.x;
        paused_info.paused_pose_y = current_pose.y;
    }
    
    // 根据ID获取剩余点
    paused_info.remaining_points = GetRemainingPointsFromId(current_point, current_passed_id);
    
    // 计算剩余长度
    paused_info.remaining_length = CalculateSinglePathLength(paused_info.remaining_points);
    
    // 计算已完成比例
    double total_length = CalculateSinglePathLength(current_point.point_array);
    if (total_length > 0) {
        paused_info.completed_ratio = (total_length - paused_info.remaining_length) / total_length;
        paused_info.completed_ratio = std::clamp(paused_info.completed_ratio, 0.0, 1.0);
    }
    
    // 计算已完成面积
    double total_area = total_length * effective_robot_radius_ * 2.0;
    paused_info.completed_area = total_area * paused_info.completed_ratio;
        
    // 检查是否是多路径模式
    if (target_queue_.size() > 1) {  // 注意：target_queue_ 包含当前正在执行的点
        paused_info.is_multi_path = true;
        paused_info.current_path_index = exed_point_number_;
        
        // 清空原有的剩余路径队列
        std::queue<CoverTeachArea> empty;
        std::swap(empty, paused_info.remaining_paths);
        
        // 先添加当前路径的剩余部分
        if (!paused_info.remaining_points.empty()) {
            CoverTeachArea remaining_area;
            remaining_area.point_name = current_point.point_name;
            remaining_area.point_map = current_point.point_map;
            remaining_area.point_type = current_point.point_type;
            remaining_area.path_points = paused_info.remaining_points;
            remaining_area.path_length = paused_info.remaining_length;
            paused_info.remaining_paths.push(remaining_area);
        }
        
        // 获取原始任务队列的副本
        std::queue<PointInfo> temp_target_queue = target_queue_;
        
        // 跳过第一个点（当前正在执行的点）
        if (!temp_target_queue.empty()) {
            temp_target_queue.pop();
        }
        
        // 添加剩余队列中的完整路径
        while (!temp_target_queue.empty()) {
            const PointInfo& next_point = temp_target_queue.front();
            
            // 查找对应的 CoverTeachArea
            std::queue<CoverTeachArea> temp_area_queue = p_shard_data_->cover_teach_area_queue_;
            bool found = false;
            
            while (!temp_area_queue.empty()) {
                const CoverTeachArea& area = temp_area_queue.front();
                if (area.point_name == next_point.point_name && 
                    area.point_map == next_point.point_map) {
                    
                    // 保存完整的未执行路径
                    paused_info.remaining_paths.push(area);
                    LOG(INFO) << "保存完整未执行路径: " << area.point_name << ", " << "点数=" << area.path_points.size() << ", " << "长度=" << area.path_length;

                    found = true;
                    break;
                }
                temp_area_queue.pop();
            }
            
            if (!found) {
                LOG(WARNING) << "未找到路径对应的覆盖区域: " << next_point.point_name;
            }
            
            temp_target_queue.pop();
        }        
        LOG(INFO) << "多路径模式，共保存 " << paused_info.remaining_paths.size() << " 条剩余路径 (当前路径剩余部分 + " << paused_info.remaining_paths.size() - 1 << " 条完整路径)";
    } else {
        // 单路径模式 - 只保存当前路径的剩余部分
        paused_info.is_multi_path = false;
        
        std::queue<CoverTeachArea> empty;
        std::swap(empty, paused_info.remaining_paths);
        
        if (!paused_info.remaining_points.empty()) {
            CoverTeachArea area;
            area.point_name = current_point.point_name;
            area.point_map = current_point.point_map;
            area.point_type = current_point.point_type;
            area.path_points = paused_info.remaining_points;
            area.path_length = paused_info.remaining_length;
            paused_info.remaining_paths.push(area);
        }        
        LOG(INFO) << "单路径模式，剩余点数=" << paused_info.remaining_points.size() << ", " << "剩余长度=" << paused_info.remaining_length;
    }
        
    // 保存原始任务队列（用于完整恢复）
    {
        std::lock_guard<std::mutex> task_lock(p_shard_data_->original_task_mutex_);
        p_shard_data_->original_task_queue_ = target_queue_;
        p_shard_data_->has_original_task_queue_ = true;
        LOG(INFO) << "保存原始任务队列，剩余 " << target_queue_.size() << " 个任务点";
    }
        
    // 保存到共享数据
    p_shard_data_->paused_path_info_ = paused_info;
    p_shard_data_->has_paused_path_ = true;
    
    LOG(INFO) << "保存中断信息成功: 路径=" << current_point.point_name << ", " << " 暂停点ID=" << current_passed_id << ", " << " 剩余点数=" << paused_info.remaining_points.size() << ", " << " 剩余长度=" << paused_info.remaining_length << "m"; 
}
/**********************************************************************
 * @function:    RequestPathData
 * @brief:       通过服务请求路径数据
 * @input:       map_name: 地图名称
 *               path_name: 路径名称
 *               path_type: 路径类型 ("teach_path" 或 "cover_path")
 *               point_info: 输出的路径信息
 * @output:      填充point_info的point_array
 * @return:      bool: 是否成功获取路径数据
 * @author：     Your Name
 * @date：       2026-01-15
 **********************************************************************/
bool NavControl::RequestPathData(const std::string& map_name, 
                                 const std::string& path_name, 
                                 const std::string& path_type,
                                 PointInfo& point_info)
{
    try 
    {
        // 清理之前的路径点
        point_info.point_array.clear();
        
        robot_msgs::Web srv;
        
        // 根据路径类型设置请求类型
        if (path_type == "teach_path") {
            srv.request.request_type = "Tselect";
        } else if (path_type == "cover_path") {
            srv.request.request_type = "Cselect";
        } else {
            LOG(ERROR) << "未知的路径类型: " << path_type;
            return false;
        }
        
        // 构造JSON格式的请求数据
        QJsonObject request_obj;
        request_obj["map"] = QString::fromStdString(map_name);
        request_obj["path"] = QString::fromStdString(path_name);
        QJsonDocument request_doc(request_obj);
        srv.request.request_data = request_doc.toJson().toStdString();
        
        LOG(INFO) << "请求路径服务，地图: " << map_name << ", 路径: " << path_name;
        
        // 检查服务是否存在
        if (!srv_draw_cpath_.waitForExistence(ros::Duration(3.0))) {
            LOG(ERROR) << "路径服务不存在或未启动";
            return false;
        }
        
        // 调用服务
        if (!srv_draw_cpath_.call(srv)) {
            LOG(ERROR) << "路径服务调用失败";
            return false;
        }
        
        // 检查响应
        if (srv.response.response_type != "success") {
            LOG(ERROR) << "路径服务响应失败: " << srv.response.response_type;
            return false;
        }
        
        // 解析返回的路径数据
        std::string result = srv.response.response_data;
        
        QByteArray json_data = QByteArray::fromStdString(result);
        QJsonDocument doc = QJsonDocument::fromJson(json_data);
        
        if (doc.isNull() || !doc.isObject()) {
            LOG(ERROR) << "解析JSON数据失败";
            return false;
        }
        
        QJsonObject root = doc.object();
        
        if (!root.contains("points") || !root["points"].isArray()) {
            LOG(ERROR) << "JSON中未找到points数组";
            return false;
        }
        
        QJsonArray points_array = root["points"].toArray();
        LOG(INFO) << "解析到 " << points_array.size() << " 个路径点";
        
        // 将路径点保存到 PointInfo 中
        for (const QJsonValue& point_value : points_array)
        {
            if (point_value.isObject())
            {
                QJsonObject point_obj = point_value.toObject();
                
                if (point_obj.contains("x") && point_obj.contains("y"))
                {
                    PoseData pose_data;
                    pose_data.x = point_obj["x"].toString().toDouble();
                    pose_data.y = point_obj["y"].toString().toDouble();
                    pose_data.yaw = 0.0;
                    
                    point_info.point_array.push_back(pose_data);
                }
            }
        }
        
        if (point_info.point_array.empty()) {
            LOG(ERROR) << "解析后路径点为空";
            return false;
        }
        
        LOG(INFO) << "成功保存 " << point_info.point_array.size() << " 个路径点到point_info";
        return true;
        
    } 
    catch (const std::exception& e) 
    {
        LOG(ERROR) << "请求路径数据异常: " << e.what();
        return false;
    }
}
/**********************************************************************
 * @function:    ioStatusCallback
 * @brief:       io_status话题回调，解析外设状态并更新清扫半径
 * @input:       msg: 包含外设状态的JSON字符串
 * @return:      void
 * @author：      
 * @date：        
 **********************************************************************/
void NavControl::ioStatusCallback(const std_msgs::String::ConstPtr& msg)
{
    try {
        std::string json_str = msg->data;
        QByteArray json_data = QByteArray::fromStdString(json_str);
        QJsonDocument doc = QJsonDocument::fromJson(json_data);
        
        if (doc.isNull() || !doc.isObject()) {
            LOG(WARNING) << "解析io_status JSON失败";
            return;
        }
        
        QJsonObject root = doc.object();
        //扫地 洗地 尘推 吸尘 扫洗一体
        QString taskBrush_status,taskWash_status,taskMop_status,taskSaction_status;
        taskBrush_status = root["taskBrush_status"].toString();
        taskWash_status = root["taskWash_status"].toString();
        taskMop_status = root["taskMop_status"].toString();
        taskSaction_status = root["taskSaction_status"].toString(); 
        //读取外设状态
        peripheral_status_.brush_open=(taskBrush_status == "open");
        peripheral_status_.wash_open=(taskWash_status == "open");
        peripheral_status_.mop_open=(taskMop_status == "open");
        peripheral_status_.saction_open=(taskSaction_status == "open"); 
        double old_radius = effective_robot_radius_;
        //根据不同状态设置不同半径
        if (peripheral_status_.brush_open&& (!peripheral_status_.wash_open)){
            effective_robot_radius_ = brush_radius_;
        }
        else if (peripheral_status_.wash_open&& (!peripheral_status_.brush_open)){
            effective_robot_radius_ = wash_radius_;
        }
        else if (peripheral_status_.mop_open){
            effective_robot_radius_ = mop_radius_;
        }
        else if (peripheral_status_.saction_open){
            effective_robot_radius_ = saction_radius_;
        }
        else if (peripheral_status_.brush_open&&peripheral_status_.wash_open){
            effective_robot_radius_ = all_status_radius_;
        }
        if (std::abs(old_radius - effective_robot_radius_) > 0.001) {
           
            LOG(INFO) << "清扫半径从 " << old_radius << " 调整为 " << effective_robot_radius_;
        }
    } catch (const std::exception& e) {
        LOG(ERROR) << "处理io_status回调异常: " << e.what();
    }
}
/**********************************************************************
 * @function:    motorJstopCallback
 * @brief:       /set_motor_jiting话题回调，处理急停状态
 * @input:       msg: 急停状态消息，true表示急停按下，false表示急停释放
 * @return:      void
 * @author：     
 * @date：        
 **********************************************************************/
void NavControl::motorJstopCallback(const std_msgs::UInt16 &msg)
{
    int ret = msg.data;
    bool has_lift_string = (robot_status_msg_.data.find("GOTO_LIFT_") != std::string::npos);
    bool has_acc_string = (robot_status_msg_.data=="GOTO_ACCESS_in_success"||robot_status_msg_.data=="GOTO_ACCESS_opendoor_failed"||robot_status_msg_.data=="GOTO_ACCESS_opendoor"||robot_status_msg_.data=="GOTO_ACCESS_opendoor_success"||robot_status_msg_.data=="GOTO_ACCESS_out");

    if(car_type_=="CD-01"&&(!has_lift_string)&&if_use_estop_) {
        if (ret != last_motor_jstop_state_) {
            last_motor_jstop_state_ = ret;
            
            MoveDataCmd mdc;
            QVariant qvr;
            
            if (ret==1) {
                // 急停按下
                LOG(WARNING) << "检测到急停按下";
                motorJstop=true;
                mdc.taskcmd_type = TaskStatus::T_ESTOP;
            } else {
                // 急停释放
                LOG(INFO) << "释放急停";
                
                // 检查当前状态
                if (task_index_ == Task_Index::TASK_IDLE && 
                    p_shard_data_->move_status_ != MoveStatus::RUNNING && 
                    !has_acc_string) {
                    // 如果已经在空闲状态且没有运行任务，不发送GOON
                    LOG(INFO) << "当前任务已取消";
                    motorJstop=false;
                    return;
                }
                
                // 检查是否收到过取消命令
                /*if (cancel_received_) {
                    LOG(INFO) << "收到过取消,不发送GOON";
                    motorJstop=false;
                    cancel_received_ = false;  // 重置标志
                    return;
                }*/
                
                motorJstop=false;
                mdc.taskcmd_type = TaskStatus::T_GOON;
            }
            
            qvr.setValue(mdc);
            slot_NewCmd(qvr);
        }
    }
}
/**********************************************************************
 * @function:    GetCurrentPassedPointId
 * @brief:       根据dis_to_end和车的位置获取当前经过的路径点ID
 * @input:       point_info: 当前路径信息
 *               dis_to_end: 剩余距离（-1表示使用上一个ID）
 * @return:      当前经过的最后一个路径点ID
 **********************************************************************/
size_t NavControl::GetCurrentPassedPointId(const PointInfo& point_info, double dis_to_end)
{
    const auto& points = point_info.point_array;
    if (points.empty()) {
        LOG(WARNING) << "路径点为空，无法计算经过点ID";
        return 0;
    }
    
    // 如果 dis_to_end == -1，延续上一个ID
    if (dis_to_end < 0 || std::abs(dis_to_end - (-1.0)) < 0.001) {
        if (has_current_passed_id_) {
            LOG(INFO) << "dis_to_end=-1，延续上一个经过点ID: " << last_passed_point_id_;
            return last_passed_point_id_;
        }
        // 如果没有记录，返回0
        LOG(INFO) << "无上一个ID记录，返回ID: 0";
        return 0;
    }
    
    // 计算路径总长度
    double total_length = 0.0;
    std::vector<double> cumulative_lengths;
    cumulative_lengths.push_back(0.0);
    
    for (size_t i = 1; i < points.size(); i++) {
        double dx = points[i].x - points[i-1].x;
        double dy = points[i].y - points[i-1].y;
        double segment_length = std::sqrt(dx*dx + dy*dy);
        total_length += segment_length;
        cumulative_lengths.push_back(total_length);
    }
    
    if (total_length <= 0) {
        return 0;
    }
    
    // 已完成长度
    double completed_length = total_length - dis_to_end;
    completed_length = std::clamp(completed_length, 0.0, total_length);
    
    // 找出已完成长度对应的最后一个点ID
    size_t passed_id = 0;
    for (size_t i = 0; i < cumulative_lengths.size(); i++) {
        if (cumulative_lengths[i] <= completed_length) {
            passed_id = i;
        } else {
            break;
        }
    }  
    LOG(INFO) << "计算经过点ID: total_length=" << total_length << ", dis_to_end=" << dis_to_end << ", completed_length=" << completed_length << ", passed_id=" << passed_id;
    return passed_id;
}

/**********************************************************************
 * @function:    GetCurrentPassedPointIdByPose
 * @brief:       根据机器人实时位置计算当前经过的路径点ID
 * @input:       point_info: 当前路径信息
 * @return:      当前经过的最后一个路径点ID
 **********************************************************************/
size_t NavControl::GetCurrentPassedPointIdByPose(const PointInfo& point_info)
{
    const auto& points = point_info.point_array;
    if (points.empty()) {
        return 0;
    }
    
    // 获取机器人当前位置
    geometry_msgs::Pose2D current_pose;
    if (!ListenTF("map", "base_link", current_pose)) {
        LOG(WARNING) << "无法获取机器人当前位置";
        return has_current_passed_id_ ? last_passed_point_id_ : 0;
    }
    
    // 找到距离机器人最近的路径点ID
    size_t nearest_id = 0;
    double min_distance = std::numeric_limits<double>::max();
    
    for (size_t i = 0; i < points.size(); i++) {
        double dx = points[i].x - current_pose.x;
        double dy = points[i].y - current_pose.y;
        double distance = std::sqrt(dx*dx + dy*dy);
        
        if (distance < min_distance) {
            min_distance = distance;
            nearest_id = i;
        }
    }
    
    LOG(INFO) << "根据位置计算经过点ID: nearest_id=" << nearest_id << ", distance=" << min_distance;
    
    // 如果距离较近，认为已经经过了这个点
    if (min_distance < 0.5) {
        return nearest_id;
    }
    
    return has_current_passed_id_ ? last_passed_point_id_ : 0;
}

/**********************************************************************
 * @function:    UpdateCurrentPassedPointId
 * @brief:       更新当前路径的经过点ID（在CountNavProgress中调用）
 **********************************************************************/
void NavControl::UpdateCurrentPassedPointId()
{
    // 只处理示教路径和覆盖路径
    if (now_send_point_info_.point_type != "teach_path" && 
        now_send_point_info_.point_type != "cover_path") {
        return;
    }
    
    double dis_to_end = p_shard_data_->nav_progress_.dis_to_end;
    
    // 获取当前经过的点ID
    size_t current_id = GetCurrentPassedPointId(now_send_point_info_, dis_to_end);
    
    // 更新记录
    if (current_id != last_passed_point_id_) {
        last_passed_point_id_ = current_id;
        has_current_passed_id_ = true;        
        LOG(INFO) << "经过点ID更新: id=" << current_id << ", dis_to_end=" << dis_to_end;
    }
}

/**********************************************************************
 * @function:    SavePausedPointId
 * @brief:       保存暂停时的路径点ID
 * @input:       current_point: 当前路径信息
 *               passed_id: 当前经过的点ID
 **********************************************************************/
void NavControl::SavePausedPointId(const PointInfo& current_point, size_t passed_id)
{
    std::lock_guard<std::mutex> lock(p_shard_data_->paused_path_mutex_);
    
    p_shard_data_->paused_path_info_.point_info = current_point;
    p_shard_data_->paused_path_info_.original_points = current_point.point_array;
    p_shard_data_->paused_path_info_.paused_point_id = passed_id;
    p_shard_data_->paused_path_info_.has_paused_point_id = true;
    p_shard_data_->has_paused_path_ = true;
    
    // 获取机器人当前位置
    geometry_msgs::Pose2D current_pose;
    if (ListenTF("map", "base_link", current_pose)) {
        p_shard_data_->paused_path_info_.paused_pose_x = current_pose.x;
        p_shard_data_->paused_path_info_.paused_pose_y = current_pose.y;
    }
    LOG(INFO) << "保存暂停点ID: id=" << passed_id << ", 路径名=" << current_point.point_name << ", 总点数=" << current_point.point_array.size();
}

/**********************************************************************
 * @function:    GetRemainingPointsFromId
 * @brief:       根据暂停的ID获取剩余路径点
 * @input:       point_info: 路径信息
 *               start_id: 开始ID（从该ID之后开始，不包括该ID）
 * @return:      剩余路径点
 **********************************************************************/
std::vector<PoseData> NavControl::GetRemainingPointsFromId(const PointInfo& point_info, size_t start_id)
{
    std::vector<PoseData> remaining_points;
    const auto& points = point_info.point_array;
    
    if (points.empty()) {
        LOG(INFO) << "路径点为空，无法获取剩余点";
        return remaining_points;
    }
    
    // 确保start_id在有效范围内
    if (start_id >= points.size()) {
        LOG(WARNING) << "start_id(" << start_id << ")超出范围，使用0";
        start_id = 0;
    }
    
    // 从start_id+1开始添加点（不包含暂停时的点）
    for (size_t i = start_id + 1; i < points.size(); i++) {
        remaining_points.push_back(points[i]);
    }
    LOG(INFO) << "从ID " << start_id << " 之后获取剩余点，共 " << remaining_points.size() << " 个点";
    return remaining_points;
}
/**********************************************************************
 * @function:    ResetCoverPathMonitor
 * @brief:       重置覆盖路径监控状态
 **********************************************************************/
void NavControl::ResetCoverPathMonitor(const std::string& path_name)
{
    last_valid_dis_to_end_ = -1;
    consecutive_invalid_count_ = 0;
    is_in_obstacle_ = false;
    obstacle_encounter_count_ = 0;
    ClearRescanForPath(path_name);
    LOG(INFO) << "补扫监控 开始监控覆盖路径: " << path_name;
}

/**********************************************************************
 * @function:    MonitorCoverPathProgress
 * @brief:       监控覆盖路径进度，检测障碍物导致的漏扫
 **********************************************************************/
void NavControl::MonitorCoverPathProgress()
{
    // 只在执行覆盖路径且不是补扫任务时监控
    if (now_send_point_info_.point_type != "cover_path") {
        return;
    }
    
    // 如果是补扫任务，不进行监控
    if (p_shard_data_->is_executing_rescan_) {
        return;
    }
    
    std::string current_path_name = now_send_point_info_.point_name;
    
    // 检查是否是新的覆盖路径
    static std::string last_monitored_path;
    if (last_monitored_path != current_path_name) {
        ResetCoverPathMonitor(current_path_name);
        last_monitored_path = current_path_name;
        
        // 清空该路径之前的补扫信息
        ClearRescanForPath(current_path_name);
    }
    
    double dis_to_end = p_shard_data_->nav_progress_.dis_to_end;
    
    // 初始化
    if (last_valid_dis_to_end_ < 0 && dis_to_end > 0) {
        last_valid_dis_to_end_ = dis_to_end;
        LOG(INFO) << "补扫监控[" << current_path_name << "] 初始化，起始剩余距离=" << dis_to_end;
        return;
    }
    
    // 检测 dis_to_end 的变化
    if (dis_to_end < 0 || std::abs(dis_to_end - (-1.0)) < 0.001) {
        consecutive_invalid_count_++;
        
        // 第一次遇到-1，说明进入障碍物状态
        if (!is_in_obstacle_ && last_valid_dis_to_end_ > 0) {
            is_in_obstacle_ = true;
            obstacle_encounter_count_++;
            LOG(INFO) << "补扫监控[" << current_path_name << "] 第" << obstacle_encounter_count_ << "次遇到障碍物，障碍物前剩余距离=" << last_valid_dis_to_end_; 
        }
    } else {
        // dis_to_end 恢复正常
        if (is_in_obstacle_ && last_valid_dis_to_end_ > 0) {
            // 障碍物结束，记录漏扫路段
            double obstacle_start_dis = last_valid_dis_to_end_;
            double obstacle_end_dis = dis_to_end;
            LOG(INFO) << "补扫监控[" << current_path_name << "] 第" << obstacle_encounter_count_ << "次障碍物结束，后距离=" << dis_to_end << ", 漏扫长度=" << obstacle_start_dis - obstacle_end_dis;
            RecordMissedSegment(obstacle_start_dis, obstacle_end_dis);
        }
        
        is_in_obstacle_ = false;
        consecutive_invalid_count_ = 0;
        last_valid_dis_to_end_ = dis_to_end;
    }
}

/**********************************************************************
 * @function:    RecordMissedSegment
 * @brief:       记录漏扫路段
 **********************************************************************/
void NavControl::RecordMissedSegment(double start_dis, double end_dis)
{
    std::string current_path_name = now_send_point_info_.point_name;
    const auto& points = now_send_point_info_.point_array;
    
    if (points.empty()) {
        LOG(WARNING) << "补扫监控: 路径点为空，无法记录漏扫";
        return;
    }
    
    int start_id = FindPathIdByRemainingDistance(start_dis, points);
    int end_id = FindPathIdByRemainingDistance(end_dis, points);
    
    if (start_id < 0 || end_id < 0 || start_id >= end_id) {
        LOG(WARNING) << "补扫监控: 无效的路径ID start=" << start_id << ", end=" << end_id;
        return;
    }
    
    std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
    
    // 获取或创建该路径的补扫信息
    CoverPathRescanInfo& info = p_shard_data_->cover_path_rescan_map_[current_path_name];
    info.path_name = current_path_name;
    info.path_map = now_send_point_info_.point_map;
    info.need_rescan = true;
    info.obstacle_encounter_count = obstacle_encounter_count_;
    
    MissedSegment segment;
    segment.occurrence_index = obstacle_encounter_count_;
    segment.start_dis = start_dis;
    segment.end_dis = end_dis;
    segment.start_id = start_id;
    segment.end_id = end_id;
    
    // 提取该路段的点
    for (int id = start_id; id <= end_id && id < static_cast<int>(points.size()); id++) {
        segment.segment_points.push_back(points[id]);
    }
    
    segment.segment_length = CalculateSinglePathLength(segment.segment_points);
    info.missed_segments.push_back(segment);
    LOG(INFO) << "补扫监控[" << current_path_name << "] 记录漏扫路段" << segment.occurrence_index << " id[" << start_id << "-" << end_id << "], 点数=" << segment.segment_points.size() << ", 长度=" << segment.segment_length << "m"; 
}

/**********************************************************************
 * @function:    FindPathIdByRemainingDistance
 * @brief:       根据剩余距离找到对应的路径点ID
 **********************************************************************/
int NavControl::FindPathIdByRemainingDistance(double dis_to_end, 
                                               const std::vector<PoseData>& points)
{
    if (points.empty() || dis_to_end < 0) {
        return -1;
    }
    
    double total_length = 0.0;
    std::vector<double> cumulative_lengths;
    cumulative_lengths.push_back(0.0);
    
    for (size_t i = 1; i < points.size(); i++) {
        double dx = points[i].x - points[i-1].x;
        double dy = points[i].y - points[i-1].y;
        double segment_length = std::sqrt(dx*dx + dy*dy);
        total_length += segment_length;
        cumulative_lengths.push_back(total_length);
    }
    
    if (total_length <= 0) {
        return -1;
    }
    
    double completed_length = std::clamp(total_length - dis_to_end, 0.0, total_length);
    
    for (size_t i = 0; i < cumulative_lengths.size(); i++) {
        if (cumulative_lengths[i] >= completed_length) {
            return static_cast<int>(i);
        }
    }
    
    return static_cast<int>(points.size() - 1);
}
/**********************************************************************
 * @function:    RequestPathDataWithIds
 * @brief:       请求路径数据并解析ID信息，返回按ID排序的map
 **********************************************************************/
bool NavControl::RequestPathDataWithIds(const std::string& map_name,
                                         const std::string& path_name,
                                         std::map<int, PoseData>& id_to_pose)
{
    id_to_pose.clear();
    
    robot_msgs::Web srv;
    srv.request.request_type = "Cselect";
    
    QJsonObject request_obj;
    request_obj["map"] = QString::fromStdString(map_name);
    request_obj["path"] = QString::fromStdString(path_name);
    QJsonDocument request_doc(request_obj);
    srv.request.request_data = request_doc.toJson().toStdString();
    
    LOG(INFO) << "补扫: 请求路径服务 " << map_name << "/" << path_name;
    
    if (!srv_draw_cpath_.waitForExistence(ros::Duration(3.0))) {
        LOG(ERROR) << "补扫: 路径服务不存在";
        return false;
    }
    
    if (!srv_draw_cpath_.call(srv)) {
        LOG(ERROR) << "补扫: 服务调用失败";
        return false;
    }
    
    if (srv.response.response_type != "success") {
        LOG(ERROR) << "补扫: 服务响应失败: " << srv.response.response_type;
        return false;
    }
    
    std::string result = srv.response.response_data;
    QByteArray json_data = QByteArray::fromStdString(result);
    QJsonDocument doc = QJsonDocument::fromJson(json_data);
    
    if (doc.isNull() || !doc.isObject()) {
        LOG(ERROR) << "补扫: JSON解析失败";
        return false;
    }
    
    QJsonObject root = doc.object();
    if (!root.contains("points") || !root["points"].isArray()) {
        LOG(ERROR) << "补扫: JSON中无points数组";
        return false;
    }
    
    QJsonArray points_array = root["points"].toArray();
    
    for (const QJsonValue& point_value : points_array) {
        if (point_value.isObject()) {
            QJsonObject point_obj = point_value.toObject();
            
            if (point_obj.contains("x") && point_obj.contains("y") && point_obj.contains("index")) {
                PoseData pose_data;
                pose_data.x = point_obj["x"].toString().toDouble();
                pose_data.y = point_obj["y"].toString().toDouble();
                pose_data.yaw = 0.0;
                if (point_obj.contains("yaw")) {
                    pose_data.yaw = point_obj["yaw"].toString().toDouble();
                }
                
                int index = point_obj["index"].toString().toInt();
                id_to_pose[index] = pose_data;
            }
        }
    }
    
    LOG(INFO) << "获取到 " << id_to_pose.size() << " 个路径点";
    return !id_to_pose.empty();
}

/**********************************************************************
 * @function:    PrepareRescanForPath
 * @brief:       为指定路径准备补扫任务
 **********************************************************************/
void NavControl::PrepareRescanForPath(const std::string& path_name,
                                       const std::string& path_map,
                                       const std::vector<PoseData>& original_points)
{
    std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
    
    auto it = p_shard_data_->cover_path_rescan_map_.find(path_name);
    if (it == p_shard_data_->cover_path_rescan_map_.end()) {
        LOG(INFO) << "路径 " << path_name << " 无需补扫";
        return;
    }
    
    CoverPathRescanInfo& info = it->second;
    
    if (!info.need_rescan || info.missed_segments.empty()) {
        LOG(INFO) << "路径 " << path_name << " 没有漏扫路段";
        return;
    }
    
    // 请求完整路径数据获取精确的点坐标
    std::map<int, PoseData> id_to_pose;
    if (!RequestPathDataWithIds(path_map, path_name, id_to_pose)) {
        // 如果请求失败，使用原始点
        LOG(WARNING) << "补扫: 请求路径数据失败，使用原始点";
        for (size_t i = 0; i < original_points.size(); i++) {
            id_to_pose[static_cast<int>(i)] = original_points[i];
        }
    }
    
    // 收集所有漏扫路段的路径点
    std::set<int> unique_ids;
    
    for (auto& segment : info.missed_segments) {
        LOG(INFO) << "补扫[" << path_name << "] 处理漏扫路段" << segment.occurrence_index << " id[" << segment.start_id << "-" << segment.end_id << "]";
        // 收集该路段的ID
        for (int id = segment.start_id; id <= segment.end_id; id++) {
            unique_ids.insert(id);
        }
        
        // 提取该路段的点
        segment.segment_points.clear();
        for (int id = segment.start_id; id <= segment.end_id; id++) {
            auto pose_it = id_to_pose.find(id);
            if (pose_it != id_to_pose.end()) {
                segment.segment_points.push_back(pose_it->second);
            }
        }
        
        segment.segment_length = CalculateSinglePathLength(segment.segment_points);
        
        LOG(INFO) << "补扫[" << path_name << "] 路段" << segment.occurrence_index << " 包含 " << segment.segment_points.size() << " 个点, 长度=" << segment.segment_length << "m";
    }
    
    // 按ID顺序合并所有补扫点
    info.all_rescan_points.clear();
    for (int id : unique_ids) {
        auto pose_it = id_to_pose.find(id);
        if (pose_it != id_to_pose.end()) {
            info.all_rescan_points.push_back(pose_it->second);
        }
    }
    
    info.rescan_length = CalculateSinglePathLength(info.all_rescan_points);
    info.rescan_path_name = path_name + "_rescan";
    
    LOG(INFO) << "补扫[" << path_name << "] 准备完成，共" << info.missed_segments.size() << "个漏扫路段，" << info.all_rescan_points.size() << "个补扫点，长度=" << info.rescan_length << "m";
}
void NavControl::InsertRescanTaskToQueue(const std::string& path_name)
{
    //std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
    
    auto it = p_shard_data_->cover_path_rescan_map_.find(path_name);
    if (it == p_shard_data_->cover_path_rescan_map_.end()) {
        LOG(WARNING) << "补扫: 找不到路径 " << path_name << " 的补扫信息";
        return;
    }
    
    CoverPathRescanInfo& info = it->second;
    
    if (!info.need_rescan || info.all_rescan_points.empty() || info.rescan_completed) {
        LOG(INFO) << "InsertRescanTaskToQueue: 路径 " << path_name << " 不需要补扫或已补扫";
        return;
    }
    
    LOG(INFO) << "补扫[" << path_name << "] 创建补扫任务，点数=" << info.all_rescan_points.size();
    
    // 创建补扫路径点信息
    PointInfo rescan_point;
    rescan_point.point_name = info.rescan_path_name;
    rescan_point.point_map = info.path_map;
    rescan_point.point_type = "cover_path";
    rescan_point.point_array = info.all_rescan_points;
    
    // 创建对应的CoverTeachArea
    CoverTeachArea rescan_area;
    rescan_area.point_name = info.rescan_path_name;
    rescan_area.point_map = info.path_map;
    rescan_area.point_type = "cover_path";
    rescan_area.path_points = info.all_rescan_points;
    rescan_area.path_length = info.rescan_length;
    info.rescan_inserted = true;
    // 将补扫任务插入到队列头部（优先执行）
    {
        std::lock_guard<std::mutex> queue_lock(target_queue_mutex_);
        
        // 创建新队列，补扫任务放在最前面
        std::queue<PointInfo> new_queue;
        new_queue.push(rescan_point);
        
        // 将原队列剩余的内容追加
        std::queue<PointInfo> temp_queue = target_queue_;
        while (!temp_queue.empty()) {
            new_queue.push(temp_queue.front());
            temp_queue.pop();
        }
        
        target_queue_ = new_queue;
        
        LOG(INFO) << "补扫[" << path_name << "] 补扫任务已插入队列头部，当前队列长度=" << target_queue_.size();
    }
    
    // 同样更新面积队列
    {
        std::queue<CoverTeachArea> new_area_queue;
        new_area_queue.push(rescan_area);
        
        std::queue<CoverTeachArea> temp_area_queue = p_shard_data_->cover_teach_area_queue_;
        while (!temp_area_queue.empty()) {
            new_area_queue.push(temp_area_queue.front());
            temp_area_queue.pop();
        }
        
        p_shard_data_->cover_teach_area_queue_ = new_area_queue;
    }
    
    // 更新总面积统计
    p_shard_data_->nav_progress_.total_areas += info.rescan_length * effective_robot_radius_ * 2.0;
    p_shard_data_->nav_progress_.num_areas++;
    
    // 标记补扫任务已准备
    p_shard_data_->pending_rescan_queue_.push(path_name);
    
    LOG(INFO) << "补扫[" << path_name << "] 补扫任务插入完成，总面积更新为=" << p_shard_data_->nav_progress_.total_areas;
}

/**********************************************************************
 * @function:    ClearRescanForPath
 * @brief:       清除指定路径的补扫信息
 **********************************************************************/
void NavControl::ClearRescanForPath(const std::string& path_name)
{
    std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
    
    auto it = p_shard_data_->cover_path_rescan_map_.find(path_name);
    if (it != p_shard_data_->cover_path_rescan_map_.end()) {
        it->second.Clear();
    }
}

/**********************************************************************
 * @function:    HasPendingRescan
 * @brief:       检查是否有待执行的补扫任务
 **********************************************************************/
bool NavControl::HasPendingRescan()
{
    std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
    return !p_shard_data_->pending_rescan_queue_.empty();
}
/**********************************************************************
 * * @function:    TaskControl 
 * * @brief:       任务控制主函数，实现导航任务状态机
 * * @input:       无
 * * @output:      控制导航任务流程，分发路点到各模块
 * * @return:      void：无返回值
 * * @note:        包含空闲、准备、分发、正常、等待、故障等多种任务状态
 * *               支持普通点、覆盖点、返航点、门禁点、乘梯点等不同类型
 * * @author：     jiangcuihuan
 * * @date：       20240506
 * **********************************************************************/
void NavControl::TaskControl()
{
    switch (task_index_)
    {
    // 空闲状态
    case Task_Index::TASK_IDLE:
    {
        // 错误码重置
        p_shard_data_->fault_code_.B0602 = false;
        p_shard_data_->fault_code_.B0410 = false;
        running_flg_ = false;
        cancel_received_ = true;
    }
    break;
    // 收到了marker点进入此状态
    case Task_Index::TASK_READY:
    {
        // 错误码重置
        p_shard_data_->fault_code_.B0602 = false;
        running_flg_ = true;
        p_shard_data_->skip_all_rescan_after_resume_ = false;// 新任务开始，重置续扫标志
        // 收到的marker点为空
        if (p_shard_data_->api_recved_target_vector_.size() == 0)
        {
            LOG(ERROR) << "TASK_READY:api_recved_target_vector_任务队列为空，收到的marker点为空";
            task_index_ = Task_Index::TASK_FAULT;
            break;
        }

        static bool first_flag = false;
        static bool second_flag = false;
        // 判断数据库是否更新完数据或者不需要更新数据
        if (p_shard_data_->update_waypointlist_flag)
        {
            LOG(INFO) << "TASK_READY:数据库正在更新数据";
            break;
        }
        else
        {
            LOG(INFO) << "TASK_READY:数据库不需要更新数据或者已经更新完数据库";
        }

        // 对于覆盖点，清空请求面积的队列
        std::queue<PointInfo> empty0;
        std::swap(empty0, p_shard_data_->allarea_queue_);
        allarea_ = 0;
        all_point_number_ = 0;
        exed_point_number_ = 0;
        cleanedarea_ = 0;
        //if (should_reset_cleanedarea_) {
        //    cleanedarea_ = 0;
        //    should_reset_cleanedarea_ = false;  // 重置后设为false
        //    ROS_INFO("DEBUG;TASK_READY: 重置cleanedarea_为0");
        //} else {
        //    ROS_INFO("DEBUG;TASK_READY: 保持cleanedarea_=%.2f", cleanedarea_);
        //}
    
            // 清空目标队列
        {
            std::lock_guard<std::mutex> lock(target_queue_mutex_);
            std::queue<PointInfo> empty_queue;
            std::swap(empty_queue, target_queue_);
        }

        // 通过传入的marker点名称和对应的map信息获取到路点的位置信息，然后存入到路点队列target_queue_
        int size_l = p_shard_data_->api_recved_target_vector_.size();
        LOG(INFO) << "api_recved_target_vector_目标队列长度为=" << size_l;
        //初始化总面积和总长度
        p_shard_data_->current_path_info_.is_calculated = false;
        p_shard_data_->current_path_info_.point_name.clear();
        p_shard_data_->nav_progress_.total_areas = 0.0;
        p_shard_data_->nav_progress_.total_length = 0.0;
        p_shard_data_->at_start_ = false;  // 默认不在起点
        p_shard_data_->at_end_ = false;  // 默认不在终点
        cleanedarea_ = 0;
        //if (should_reset_cleanedarea_) {
        //    cleanedarea_ = 0;
        //    should_reset_cleanedarea_ = false;  // 重置后设为false
        //}
        double total_area_clean = 0.0;
        for (int i = 0; i < size_l; i++)
        {
            // 封装要发出去的路点信息
            PointInfo point_info;
            ApiPointInfo pp = p_shard_data_->api_recved_target_vector_[i];
            string map_name = pp.point_map;
            string table_name = p_shard_data_->maplist_[map_name];
            string marker_name = pp.point_name;
            // 检查是否是小区域清扫点 (area_clean_1/2/3)
            bool is_area_clean = false;
            if (pp.point_type == "cover") {  // interface_action 中设置的类型是 cover
                if (marker_name == "area_clean_1" || 
                    marker_name == "area_clean_2" || 
                    marker_name == "area_clean_3") {
                    is_area_clean = true;
                }
                if (pp.point_name == "area_clean_1") {
                    total_area_clean += 1.0;
                } else if (pp.point_name == "area_clean_2") {
                    total_area_clean += 9.0;
                } else if (pp.point_name == "area_clean_3") {
                    total_area_clean += 25.0;
                }
            }
            
            if (is_area_clean) {
                // 小区域清扫点：直接添加到队列，不需要查询数据库
                point_info.point_name = marker_name;
                point_info.point_map = map_name;
                point_info.point_type = "cover";  // 保持 cover 类型
                
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    target_queue_.push(point_info);
                }
                double area_size = 0.0;
                if (marker_name == "area_clean_1") {
                    area_size = 1.0;
                } else if (marker_name == "area_clean_2") {
                    area_size = 9.0;
                } else if (marker_name == "area_clean_3") {
                    area_size = 25.0;
                }
                
                // 小区域清扫时间估计 
                double area_time = area_size  / (120. * effective_robot_radius_ * max_linear_velocity_);
                p_shard_data_->nav_progress_.total_time += area_time;
                LOG(INFO) << "TASK_READY:添加小区域清扫点到队列 " << marker_name;
                continue;  // 跳过后续的数据库查询逻辑
            }
            //string task = pp.point_task;  // 获取task信息
            //string task = pp.task;
                    // 检查点类型
            if (pp.point_type == "teach_path" || pp.point_type == "cover_path") {
                // 对于路径类型，创建特殊的 PointInfo
                PointInfo point_info;
                point_info.point_name = pp.point_name;
                point_info.point_map = pp.point_map;
                point_info.point_type = pp.point_type;  // "teach_path" 或 "cover_path"
                //point_info.point_task = task;  // 设置task信息
                //point_info.task = pp.task;
                // 获取所有的地图、路径
                CoverTeachArea cover_teach_area; 
                cover_teach_area.point_name = pp.point_name;
                cover_teach_area.point_map = pp.point_map;
                cover_teach_area.point_type = pp.point_type;
                if (RequestPathData(pp.point_map, pp.point_name, pp.point_type, point_info)) {
                    
                    // 保存到共享数据中
                    cover_teach_area.path_points = point_info.point_array;
                    
                    // 计算当前路径的长度
                    double path_length = CalculateSinglePathLength(cover_teach_area.path_points);
                    double path_area = path_length * effective_robot_radius_ * 2.0;  // 面积 = 长度 × 机器人直径
                    
                    // 保存路径长度到结构中
                    cover_teach_area.path_length = path_length;
                    
                    // 累加到总统计
                    p_shard_data_->nav_progress_.total_areas += path_area;
                    p_shard_data_->nav_progress_.total_length += path_length;  // 累加总长度
                    p_shard_data_->nav_progress_.total_time = 5 * p_shard_data_->nav_progress_.total_areas * max_linear_velocity_ / (60. * effective_robot_radius_*2);
                    //p_shard_data_->nav_progress_.last_areas = p_shard_data_->nav_progress_.total_areas;
        
                    
                    // 保存到队列
                    p_shard_data_->cover_teach_area_queue_.push(cover_teach_area);
                    LOG(INFO) << "TASK_READY:路径统计 - 路径数=" << p_shard_data_->cover_teach_area_queue_.size() << ", 总面积=" << p_shard_data_->nav_progress_.total_areas << ", 预计时间=" << p_shard_data_->nav_progress_.total_time << ", cleanedarea_=" << cleanedarea_;
                } 
                else 
                {
                    LOG(ERROR) << "TASK_READY:请求路径数据失败 " << pp.point_name;
                    continue;
                }
                // 将路径点加入目标队列
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    target_queue_.push(point_info);
                }
                LOG(INFO) << "TASK_READY:添加路径点到队列 " << pp.point_name << " (类型: " << pp.point_type << ")";
                continue;
            }
            else if (pp.point_type == "market"){
                string table_name = p_shard_data_->maplist_[map_name];
                // 查找数据库中是否存在请求的目标点
                if (!p_shard_data_->update_waypointlist_flag)
                {
                    second_flag = true;
                }
                int ret = p_shard_data_->TargetEffectivenessCheck(marker_name, table_name, point_info);
                if (ret == fault_true)
                {
                    LOG(INFO) << "TASK_READY:数据库找到了对应的点" << marker_name;
                    // 将路点加入目标队列
                    {
                        std::lock_guard<std::mutex> lock(target_queue_mutex_);
                        target_queue_.push(point_info);
                    }
                    // 如果是覆盖点，把点加入请求所有面积的队列，为了后面计算清洁的总共面积
                    if (point_info.point_type == "cover")
                    {
                        p_shard_data_->allarea_queue_.push(point_info);
                    }
                    p_shard_data_->fault_code_.B0410 = false;
                    first_flag = false;
                }
                else
                {
                    LOG(ERROR) << "TASK_READY:查询数据库没有找到对应的点：" << marker_name;
                    if (!first_flag)
                    {
                        first_flag = true;
                        second_flag = false;
                        // 查询数据库没有找到对应的点，让数据库再次更新数据
                        p_shard_data_->update_waypointlist_flag = true;
                        // 重新检查当前点
                        i--;
                    }
                    else
                    {
                        if (second_flag)
                        {
                            LOG(ERROR) << "TASK_READY:查询数据库没有找到对应的点更新数据库后，再次查询数据库没有找到对应的点：" << marker_name;
                            first_flag = false;
                            // 查询数据库没有找到对应的点，有路点信息错误，清空队列，放弃任务执行
                            {
                                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                                std::queue<PointInfo> empty0;
                                std::swap(empty0, target_queue_);
                            }
                            std::vector<ApiPointInfo> empty1;
                            std::swap(empty1, p_shard_data_->api_recved_target_vector_);
                            std::queue<PointInfo> empty2;
                            std::swap(empty2, p_shard_data_->allarea_queue_);
                            // 状态置为错误状态
                            p_shard_data_->fault_code_.B0410 = true;
                            {
                                std::lock_guard<std::mutex> lock(robot_status_mutex_);
                                robot_status_msg_.data = "QUERY_NO_POINT";
                            }
                            task_index_ = Task_Index::TASK_FAULT;
                            break;
                        }
                        i--;
                    }
                    continue;
                }
            }
        }
        if (p_shard_data_->allarea_queue_.size() > 0)
        {
            // 请求清扫的面积
            emit signal_RequireArea();
            // 一次性请求覆盖点的数量
            all_point_number_ = p_shard_data_->allarea_queue_.size();
            // 计算得到一次性请求覆盖点所对应的清扫面积
            allarea_ = p_shard_data_->clean_area_;
            p_shard_data_->nav_progress_.total_areas =p_shard_data_->clean_area_;
            p_shard_data_->nav_progress_.num_areas=p_shard_data_->allarea_queue_.size();
            p_shard_data_->nav_progress_.total_time=5*p_shard_data_->nav_progress_.total_areas
                        *max_linear_velocity_/(60. * effective_robot_radius_*2);//粗略估计
            p_shard_data_->nav_progress_.last_areas=p_shard_data_->nav_progress_.total_areas;
        }
        if (p_shard_data_->cover_teach_area_queue_.size() > 0)
        {
            // 重置exed_point_number_为0，开始新的计数
            exed_point_number_ = 0;
            
            p_shard_data_->nav_progress_.num_areas = p_shard_data_->cover_teach_area_queue_.size();
            p_shard_data_->nav_progress_.last_areas = p_shard_data_->nav_progress_.total_areas;
            LOG(INFO) << "TASK_READY:路径统计 - 路径数=" << p_shard_data_->cover_teach_area_queue_.size() << 
                        ", 总面积=" << p_shard_data_->nav_progress_.total_areas << ", cleanedarea_=" << cleanedarea_;
        }
        {
            std::lock_guard<std::mutex> lock(target_queue_mutex_);
            if (target_queue_.size() > 0)
            {
                // 路点校验完成，发布状态信息running，然后开始分发路点进行导航
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "running";
                }
                task_index_ = Task_Index::TASK_HANDOUT;
            }
        }
    }
    break;
    case Task_Index::TASK_PATH_WAITING:
    {
        if (current_processing_path_type_ != "cover_path" && 
            current_processing_path_type_ != "teach_path") {
            LOG(ERROR) << "TASK_PATH_WAITING状态但当前类型不是路径: " << current_processing_path_type_;
            // 强制退出错误状态
            path_processing_mode_ = false;
            current_processing_path_type_.clear();
            task_index_ = Task_Index::TASK_HANDOUT;
            break;
        }
        if (current_processing_path_type_ == "teach_path") 
        {
            // 检查示教路径执行状态
            NavStatus teach_status = p_shard_data_->teachingpath_nav_status_.goal_status;
           //ROS_INFO("DEBUG;示教路径状态: %d", teach_status);
            
            if (teach_status == NavStatus::NAV_SUCCESS ||
                p_shard_data_->cover_success_||
                p_shard_data_->teach_success_) 
            {
                LOG(INFO) << "示教路径执行成功: " << now_send_point_info_.point_name;
                p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                p_shard_data_->cover_success_=false;
                p_shard_data_->teach_success_=false;
                p_shard_data_->teach_fault_=false;
                p_shard_data_->cover_fault_=false;
                //waiting_for_path_completion_ = false;
                // 获取当前路径的面积并累加
                double current_path_area = 0.0;
                if (p_shard_data_->current_path_info_.is_calculated && 
                    p_shard_data_->current_path_info_.point_name == now_send_point_info_.point_name) 
                {
                    current_path_area = p_shard_data_->current_path_info_.path_area;
                } else {
                    // 后备计算
                    double path_length = CalculateSinglePathLength(now_send_point_info_.point_array);
                    current_path_area = path_length * effective_robot_radius_ * 2.0;
                }
                
                // 累加面积
                double old_cleanedarea = cleanedarea_;
                cleanedarea_ += current_path_area;
                exed_point_number_++;
                
                LOG(INFO) << "示教路径 " << now_send_point_info_.point_name << " 面积累加: " << old_cleanedarea << " + " << current_path_area << " = " << cleanedarea_;

                p_shard_data_->at_end_=true; 
                p_shard_data_->at_start_=false;
                LOG(INFO) << "at_start_:" << p_shard_data_->at_start_ << "at_end_:" << p_shard_data_->at_end_;
                
                
                        // 路径执行成功，从队列中移除当前点
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    if (!target_queue_.empty()) {
                        // 验证当前点确实是正在等待的点
                        if (target_queue_.front().point_name == now_send_point_info_.point_name &&
                            target_queue_.front().point_type == now_send_point_info_.point_type) {
                            target_queue_.pop();
                            LOG(INFO) << "从队列移除已完成的示教路径点: " << now_send_point_info_.point_name;
                            if (!p_shard_data_->cover_teach_area_queue_.empty()) {
                                p_shard_data_->cover_teach_area_queue_.pop();
                                LOG(INFO) << "从cover_teach_area_queue_移除已完成的路径";
                            }
                        } else {
                            LOG(WARNING) << "队列头部点不匹配，可能已发生变化";
                        }
                    }
                }
                
                // 重置路径处理标志
                path_processing_mode_ = false;
                current_processing_path_type_.clear();
                
                // 检查是否还有下一个点
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    if (!target_queue_.empty()) {
                        LOG(INFO) << "还有 " << target_queue_.size() << " 个点待处理，继续执行下一个";
                        task_index_ = Task_Index::TASK_HANDOUT; 
                    } else {
                        task_index_ = Task_Index::TASK_WAIT;
                        p_shard_data_->is_path_over_=true;
                        //task_index_ = Task_Index::TASK_IDLE;
                        LOG(INFO) << "队列已空，进入 TASK_WAIT";
                    }
                }
                
                // 发布成功状态
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_success";
                }
                LOG(INFO) << "示教路径执行成功: " << now_send_point_info_.point_name;
            }
            else if (teach_status == NavStatus::NAV_FAILED || 
                    teach_status == NavStatus::NAV_ABORTED ||
                    p_shard_data_->cover_fault_||
                    p_shard_data_->teach_fault_) 
            {
                LOG(INFO) << "示教路径状态: " << teach_status << ",示教move状态: " << p_shard_data_->move_status_.load();
                LOG(WARNING) << "示教路径执行失败，失败点: " << now_send_point_info_.point_name;
                p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                p_shard_data_->cover_success_=false;
                p_shard_data_->teach_success_=false;
                p_shard_data_->teach_fault_=false;
                p_shard_data_->cover_fault_=false;
                p_shard_data_->at_end_=true;
                p_shard_data_->at_start_=false;
                LOG(INFO) << "at_start_:" << p_shard_data_->at_start_ << ",at_end_:" << p_shard_data_->at_end_;
                    // 获取当前路径的面积
                double current_path_area = 0.0;
                if (p_shard_data_->current_path_info_.is_calculated && 
                    p_shard_data_->current_path_info_.point_name == now_send_point_info_.point_name) 
                {
                    current_path_area = p_shard_data_->current_path_info_.path_area;
                } else {
                    // 后备计算
                    double path_length = CalculateSinglePathLength(now_send_point_info_.point_array);
                    current_path_area = path_length * effective_robot_radius_ * 2.0;
                }
                
                // 计算实际完成的面积（根据最后的进度）
                double actual_completed_ratio = 0.0;
                if (p_shard_data_->current_path_info_.path_length > 0) {
                    // 获取最后的剩余距离
                    double last_dis_to_end = p_shard_data_->nav_progress_.dis_to_end;
                    if (last_dis_to_end < 0 || last_dis_to_end > p_shard_data_->current_path_info_.path_length) {
                        last_dis_to_end = p_shard_data_->current_path_info_.path_length;
                    }
                    
                    double completed_length = p_shard_data_->current_path_info_.path_length - last_dis_to_end;
                    completed_length = std::clamp(completed_length, 0.0, p_shard_data_->current_path_info_.path_length);
                    actual_completed_ratio = completed_length / p_shard_data_->current_path_info_.path_length;
                }
                
                // 累加实际完成的面积（而不是整个路径面积）
                double actual_completed_area = current_path_area * actual_completed_ratio;
                double old_cleanedarea = cleanedarea_;
                cleanedarea_ += actual_completed_area;
                
                LOG(INFO) << "示教路径失败，部分完成: 进度=" << actual_completed_ratio * 100.0 << "%%, 面积=" << actual_completed_area << "/" << current_path_area << ", 累计面积=" << old_cleanedarea << " + " << actual_completed_area << " = " << cleanedarea_;
                // 路径执行失败，从队列中移除当前点
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    if (!target_queue_.empty()) {
                        if (target_queue_.front().point_name == now_send_point_info_.point_name &&
                            target_queue_.front().point_type == now_send_point_info_.point_type) {
                            target_queue_.pop();
                            LOG(INFO) << "从队列移除失败的示教路径点: " << now_send_point_info_.point_name;
                            if (!p_shard_data_->cover_teach_area_queue_.empty()) {
                                p_shard_data_->cover_teach_area_queue_.pop();
                                LOG(INFO) << "从cover_teach_area_queue_移除已完成的路径";
                            }
                        }
                    }
                }
                
                // 重置路径处理标志
                path_processing_mode_ = false;
                current_processing_path_type_.clear();
                
                // p_shard_data_->fault_code_.B0602 = true; // 注释掉这行

                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                }
                
                LOG(WARNING) << "示教路径执行失败，失败点: " << now_send_point_info_.point_name;
                
                // 检查是否还有下一个点
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    if (!target_queue_.empty()) {
                        task_index_ = Task_Index::TASK_HANDOUT;
                        LOG(INFO) << "还有更多点需要处理，返回 TASK_HANDOUT";
                    } else {
                        task_index_ = Task_Index::TASK_WAIT;
                        p_shard_data_->is_path_over_=true;
                        //task_index_ = Task_Index::TASK_IDLE;
                        LOG(INFO) << "队列已空，进入 TASK_WAIT";
                    }
                }
            }
            else if (teach_status == NavStatus::NAV_IDLE || teach_status == NavStatus::NAV_RUN)
            {
                // 路径仍在执行中，继续等待
               // ROS_INFO_NAMED("path_wait", "等待示教路径执行完成... 状态: %d", teach_status);
            }
            else if (teach_status == NavStatus::NAV_STOP)
            {
                // 路径被暂停，等待继续
                //ROS_WARN("DEBUG;示教路径被暂停: %s", now_send_point_info_.point_name.c_str());
                // 保持当前状态，等待恢复
            }
        }
        else if (current_processing_path_type_ == "cover_path") 
        {
            // 检查覆盖路径执行状态
            NavStatus cover_status = p_shard_data_->coverpath_nav_status_.goal_status;
            
            // 检查是否执行完成
            bool is_completed = (cover_status == NavStatus::NAV_SUCCESS || 
                                p_shard_data_->cover_success_ ||
                                p_shard_data_->teach_success_);
            
            bool is_failed = (cover_status == NavStatus::NAV_FAILED || 
                            cover_status == NavStatus::NAV_ABORTED || 
                            p_shard_data_->cover_fault_ ||
                            p_shard_data_->teach_fault_);
            
            if (is_completed || is_failed)
            {
                std::string completed_path_name = now_send_point_info_.point_name;
                bool is_rescan = (completed_path_name.find("_rescan") != std::string::npos);
                
                LOG(INFO) << "覆盖路径" << completed_path_name << " " << (is_completed ? "执行完成" : "执行失败") << ", is_rescan=" << is_rescan;
                
                //处理补扫相关逻辑
                if (is_completed)
                {
                    if (is_rescan)
                    {
                        // 补扫任务完成
                        p_shard_data_->is_executing_rescan_ = false;
                        
                        // 从待补扫队列中移除
                        {
                            std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
                            if (!p_shard_data_->pending_rescan_queue_.empty()) {
                                std::string front_path = p_shard_data_->pending_rescan_queue_.front();
                                p_shard_data_->pending_rescan_queue_.pop();
                                LOG(INFO) << "补扫任务完成，从待补扫队列移除: " << front_path;
                            }
                            
                            // 标记补扫已完成
                            size_t pos = completed_path_name.find("_rescan");
                            if (pos != std::string::npos) {
                                std::string original_name = completed_path_name.substr(0, pos);
                                auto it = p_shard_data_->cover_path_rescan_map_.find(original_name);
                                if (it != p_shard_data_->cover_path_rescan_map_.end()) {
                                    it->second.rescan_completed = true;
                                    it->second.rescan_inserted = false;
                                    it->second.Clear();
                                    LOG(INFO) << "标记原始路径" << original_name << " 的补扫已完成";
                                }
                            }
                        } 
                        LOG(INFO) << "补扫任务执行成功: " << completed_path_name;
                    }
                    else
                    {
                        if (p_shard_data_->skip_all_rescan_after_resume_) {
                            LOG(INFO) << "续扫模式: 跳过覆盖路径 " << completed_path_name << " 的补扫任务";
                            
                            // 清除该路径的补扫信息
                            std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
                            auto it = p_shard_data_->cover_path_rescan_map_.find(completed_path_name);
                            if (it != p_shard_data_->cover_path_rescan_map_.end()) {
                                it->second.need_rescan = false;
                                it->second.Clear();
                            }
                        } else {
                            // 正常模式：准备补扫任务
                            LOG(INFO) << "正常模式: 准备覆盖路径 " << completed_path_name << " 的补扫任务";
                            PrepareRescanForPath(completed_path_name, 
                                                now_send_point_info_.point_map,
                                                now_send_point_info_.point_array);
                        }
                    }
                }
                else if (is_failed)
                {
                    LOG(INFO) << "覆盖路径执行失败: " << completed_path_name << ", 状态=" << cover_status;
                    
                    if (is_rescan)
                    {
                        // 补扫任务失败
                        p_shard_data_->is_executing_rescan_ = false;
                        
                        {
                            std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
                            if (!p_shard_data_->pending_rescan_queue_.empty()) {
                                p_shard_data_->pending_rescan_queue_.pop();
                            }
                        }
                        LOG(ERROR) << "补扫任务执行失败: " << completed_path_name;
                    }
                    else
                    {
                        if (p_shard_data_->skip_all_rescan_after_resume_) {
                            LOG(INFO) << "续扫模式: 覆盖路径 " << completed_path_name << " 失败，跳过补扫";
                            std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
                            auto it = p_shard_data_->cover_path_rescan_map_.find(completed_path_name);
                            if (it != p_shard_data_->cover_path_rescan_map_.end()) {
                                it->second.need_rescan = false;
                                it->second.Clear();
                            }
                        } else {
                            PrepareRescanForPath(completed_path_name,
                                                now_send_point_info_.point_map,
                                                now_send_point_info_.point_array);
                        }
                    }
                }
                // 重置状态
                p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                p_shard_data_->cover_success_ = false;
                p_shard_data_->teach_success_ = false;
                p_shard_data_->teach_fault_ = false;
                p_shard_data_->cover_fault_ = false;
                p_shard_data_->at_end_ = true;
                p_shard_data_->at_start_ = false;
                
                // 面积累加
                double current_path_area = 0.0;
                if (p_shard_data_->current_path_info_.is_calculated && 
                    p_shard_data_->current_path_info_.point_name == now_send_point_info_.point_name) 
                {
                    current_path_area = p_shard_data_->current_path_info_.path_area;
                } else {
                    double path_length = CalculateSinglePathLength(now_send_point_info_.point_array);
                    current_path_area = path_length * effective_robot_radius_ * 2.0;
                }
                
                double actual_completed_ratio = 1.0;
                if (is_failed) {
                    if (p_shard_data_->current_path_info_.path_length > 0) {
                        double last_dis_to_end = p_shard_data_->nav_progress_.dis_to_end;
                        if (last_dis_to_end < 0 || last_dis_to_end > p_shard_data_->current_path_info_.path_length) {
                            last_dis_to_end = p_shard_data_->current_path_info_.path_length;
                        }
                        double completed_length = p_shard_data_->current_path_info_.path_length - last_dis_to_end;
                        completed_length = std::clamp(completed_length, 0.0, p_shard_data_->current_path_info_.path_length);
                        actual_completed_ratio = completed_length / p_shard_data_->current_path_info_.path_length;
                    }
                }
                
                double actual_completed_area = current_path_area * actual_completed_ratio;
                double old_cleanedarea = cleanedarea_;
                cleanedarea_ += actual_completed_area;
                
                if (is_completed && !is_rescan) {
                    exed_point_number_++;
                }
                LOG(INFO) << "覆盖路径 " << completed_path_name << " 面积累加: " << old_cleanedarea << " + " << actual_completed_area << " = " << cleanedarea_ << " (进度=" << actual_completed_ratio * 100.0 << "%)";
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    if (!target_queue_.empty()) {
                        if (target_queue_.front().point_name == now_send_point_info_.point_name &&
                            target_queue_.front().point_type == now_send_point_info_.point_type) {
                            target_queue_.pop();
                            LOG(INFO) << "从队列移除覆盖路径点: " << now_send_point_info_.point_name;
                        }
                    }
                    if (!p_shard_data_->cover_teach_area_queue_.empty()) {
                        p_shard_data_->cover_teach_area_queue_.pop();
                        LOG(INFO) << "从cover_teach_area_queue_移除路径";
                    }
                }
                bool rescan_inserted = false;
                
                if (!is_rescan)
                {
                    // 续扫模式下不插入补扫
                    if (p_shard_data_->skip_all_rescan_after_resume_) {
                        LOG(INFO) << "续扫模式: 不插入补扫任务";
                    } else {
                        std::lock_guard<std::mutex> lock(p_shard_data_->rescan_mutex_);
                        auto it = p_shard_data_->cover_path_rescan_map_.find(completed_path_name);
                        if (it != p_shard_data_->cover_path_rescan_map_.end() && 
                            it->second.need_rescan && 
                            !it->second.all_rescan_points.empty() &&
                            !it->second.rescan_completed &&
                            !it->second.rescan_inserted) {
                            
                            LOG(INFO) << "正常模式: 插入补扫任务 " << completed_path_name;
                            InsertRescanTaskToQueue(completed_path_name);
                            rescan_inserted = true;
                        }
                    }
                }
                // 重置路径处理标志
                path_processing_mode_ = false;
                current_processing_path_type_.clear();
                
                // 发布状态
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    if (is_completed) {
                        robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_success";
                    } else {
                        robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                    }
                }
                
                // 检查是否还有下一个点
                {
                    std::lock_guard<std::mutex> lock(target_queue_mutex_);
                    if (!target_queue_.empty()) {
                        // 有任务（可能是刚插入的补扫任务），继续执行
                        task_index_ = Task_Index::TASK_HANDOUT;
                        LOG(INFO) << "队列还有 " << target_queue_.size() << " 个点，返回 TASK_HANDOUT";
                    } else {
                        // 队列为空，任务结束
                        task_index_ = Task_Index::TASK_WAIT;
                        p_shard_data_->is_path_over_ = true;
                        LOG(INFO) << "队列已空，进入 TASK_WAIT";
                    }
                }
                
                // 如果是补扫任务完成且队列不为空，立即触发一次TaskControl
                if (is_rescan && !target_queue_.empty()) {
                    LOG(INFO) << "补扫完成，队列还有任务，立即触发状态机";
                    // 状态机会在下一个循环自动处理
                }
            }
        }
        else 
        {
            // 未知路径类型，恢复处理
            LOG(WARNING) << "未知的路径类型: " << current_processing_path_type_;
            
            // 从队列中移除当前点
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                if (!target_queue_.empty()) {
                    target_queue_.pop();
                    LOG(INFO) << "移除未知类型的点: " << now_send_point_info_.point_name;
                }
            }
            
            // 重置路径处理标志
            path_processing_mode_ = false;
            current_processing_path_type_.clear();
            
            // 检查是否还有下一个点
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                if (!target_queue_.empty()) {
                    task_index_ = Task_Index::TASK_HANDOUT;
                    LOG(INFO) << "返回 TASK_HANDOUT 处理下一个点";
                } else {
                    //task_index_ = Task_Index::TASK_WAIT;
                    task_index_ = Task_Index::TASK_IDLE;
                    LOG(INFO) << "队列已空，进入 TASK_IDLE";
                }
            }
        }
    }
    break;
    case Task_Index::TASK_HANDOUT:
        // 依此取出target_queue_队列中的数据，判断其类型，交由对应的模块处理,同时发布正在执行任务名称(marker名称)的信息。
        {
            //if (waiting_for_path_completion_) {
            //    ROS_INFO("DEBUG;正在等待路径完成，暂不分发新任务");
            //    break;
            //}
            {
                // 分发路点前，停止所有路点
                p_access_lift_shared_->thread_pause_flag_ = true;
                p_access_action_->thread_pause_flag_ = true;
                p_accurate_control_shared_->thread_pause_flag_ = true;
                p_back_home_->thread_pause_flag_ = true;
                p_cover_action_->thread_pause_flag_ = true;
                p_normal_action_->thread_pause_flag_ = true;
                //判断路径执行成功失败标志
                p_shard_data_->cover_fault_ = false;
                p_shard_data_->teach_fault_ = false;
                p_shard_data_->cover_success_ = false;
                p_shard_data_->teach_success_ = false;
            }

            running_flg_ = true;
            {
                std::lock_guard<std::mutex> lock(target_queue_mutex_);
                if (target_queue_.size() <= 0)
                {
                    LOG(ERROR) << "target_queue_队列为空,进入到了错误状态";
                    // 状态置为错误状态
                    p_shard_data_->fault_code_.B0604 = true;
                    {
                        std::lock_guard<std::mutex> lock(robot_status_mutex_);
                        robot_status_msg_.data = "GOTO_NULL_POINT";
                    }
                    task_index_ = Task_Index::TASK_FAULT;
                    break;
                }

                p_shard_data_->fault_code_.B0604 = false;
                // 取出第一个路点为当前要导航的点
                now_send_point_info_ = target_queue_.front();
                
                static std::string last_processed_point_name = "";
                static std::string last_processed_point_type = "";
                
                if (now_send_point_info_.point_name != last_processed_point_name ||
                    now_send_point_info_.point_type != last_processed_point_type) {
                    
                    // 新路径，重置经过点ID记录
                    last_passed_point_id_ = 0;
                    has_current_passed_id_ = false;
                    LOG(INFO) << "新路径开始 [" << 
                            now_send_point_info_.point_type << ":" << 
                            now_send_point_info_.point_name << "]，重置经过点ID记录";
                    
                    last_processed_point_name = now_send_point_info_.point_name;
                    last_processed_point_type = now_send_point_info_.point_type;
                }
            }
            if (now_send_point_info_.point_type != "teach_path" && now_send_point_info_.point_type != "cover_path")
            {
                if (path_processing_mode_) {
                    LOG(WARNING) << "检测到残留的路径处理模式，强制重置";
                    
                    // 强制重置路径状态
                    p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    
                    path_processing_mode_ = false;
                    current_processing_path_type_.clear();
                            
                    last_passed_point_id_ = 0;
                    has_current_passed_id_ = false;
                    
                    // 取消所有运动目标
                    p_move_action_->movebase_client_.cancelAllGoals();
                    
                    LOG(WARNING) << "强制重置路径处理模式，当前点类型: " << 
                            now_send_point_info_.point_type;
                }
            }
            {
                std::lock_guard<std::mutex> lock(robot_status_mutex_);
		        if (now_send_point_info_.point_type=="back"){
                    robot_status_msg_.data = "GOTO_back";
                }else{
                    robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name;
                }
            }
            LOG(INFO) << "开始处理点 [" << now_send_point_info_.point_name << "], 类型 [" << now_send_point_info_.point_type << "], 当前累计已清洁面积=" << cleanedarea_ << "m²";
            p_shard_data_->curr_lift_point_name_=now_send_point_info_.point_name;
            p_shard_data_->curr_lift_point_type_=now_send_point_info_.point_type;
            LOG(INFO) << "开始分发路点，此时move_action的状态为" << p_shard_data_->move_status_;
            LOG(INFO) << "开始处理新路径 [" << now_send_point_info_.point_name << "]，当前已清洁面积: " << cleanedarea_ << "m²";
            
            // 在执行前先计算当前路径的面积
            if (now_send_point_info_.point_type == "teach_path" || now_send_point_info_.point_type == "cover_path")
            {
                // 保存原始路径点
                p_shard_data_->current_original_path_points_ = now_send_point_info_.point_array;
                LOG(INFO) << "保存原始路径点，共 " << p_shard_data_->current_original_path_points_.size() << " 个点";
       
                // 计算当前路径的长度和面积
                double path_length = CalculateSinglePathLength(now_send_point_info_.point_array);
                double path_area = path_length * effective_robot_radius_ * 2.0;
                LOG(INFO) << "开始执行路径 [" << now_send_point_info_.point_name << "]: 长度=" << path_length << ", 面积=" << path_area << ", 当前累计已清洁面积=" << cleanedarea_ << "m²";
                
                // 保存到共享数据，供进度计算使用
                p_shard_data_->current_path_info_.point_name = now_send_point_info_.point_name;
                p_shard_data_->current_path_info_.point_type = now_send_point_info_.point_type;
                p_shard_data_->current_path_info_.path_length = path_length;
                p_shard_data_->current_path_info_.path_area = path_area;
                p_shard_data_->current_path_info_.is_calculated = true;
                LOG(INFO) << "理论总面积=" << p_shard_data_->nav_progress_.total_areas << ", 当前累计已清洁面积=" << cleanedarea_ << ", 剩余面积=" << p_shard_data_->nav_progress_.total_areas - cleanedarea_ << "m²";

            }
            if (now_send_point_info_.point_type == "teach_path") {
                LOG(INFO) << " [" << now_send_point_info_.point_name << "], 设置current_executing_path_type=teach_path";
                // {
                //    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                //    robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name;
                // }
                
                PoseData pd;
                pd.path_map=now_send_point_info_.point_map;
                pd.path_name=now_send_point_info_.point_name;
                //pd.path_task=now_send_point_info_.point_task;

                p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;

                if (p_teach_action_) {
                    p_teach_action_->SetCmd("teach_path", pd);
                    LOG(INFO) << "已将示教路径添加到 TeachAction";
                    
                    // 设置为路径处理模式，等待路径执行完成
                    path_processing_mode_ = true;
                    current_processing_path_type_ = "teach_path";
                    //waiting_for_path_completion_ = true;
                    task_index_ = Task_Index::TASK_PATH_WAITING;
                } else {
                    LOG(ERROR) << "TeachAction 未初始化";
                    task_index_ = Task_Index::TASK_FAULT;
                }
            }
            else if (now_send_point_info_.point_type == "cover_path") {
                LOG(INFO) << " [" << now_send_point_info_.point_name << "], 设置current_executing_path_type=cover_path";

                //{
                //    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                //    robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name;
                //}
                bool is_rescan = (now_send_point_info_.point_name.find("_rescan") != std::string::npos);
                if (is_rescan){
                    p_shard_data_->is_executing_rescan_ = true;
                    LOG(INFO) << "开始执行补扫任务: " << now_send_point_info_.point_name;
                }else{
                    p_shard_data_->is_executing_rescan_ = false;
                    ResetCoverPathMonitor(now_send_point_info_.point_name);
                }
                PoseData pd;
                pd.path_map=now_send_point_info_.point_map;
                pd.path_name=now_send_point_info_.point_name;
                //pd.path_task=now_send_point_info_.point_task;
                p_shard_data_->coverpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                // 初始化覆盖路径的进度信息
                p_shard_data_->nav_progress_.num_areas = 1;  // 覆盖路径算作一个区域
                p_shard_data_->nav_progress_.current_index = exed_point_number_ + 1;
                p_shard_data_->nav_progress_.current_area_name = now_send_point_info_.point_name;

                if (p_cover_path_action_) {
                    p_cover_path_action_->SetCmd("cover_path", pd);
                    LOG(INFO) << "已将覆盖路径添加到 CoverPathAction";
                    
                    // 设置为路径处理模式，等待路径执行完成
                    path_processing_mode_ = true;
                    current_processing_path_type_ = "cover_path";
                    //waiting_for_path_completion_ = true;
                    task_index_ = Task_Index::TASK_PATH_WAITING;
                } else {
                    LOG(ERROR) << "CoverPathAction 未初始化";
                    task_index_ = Task_Index::TASK_FAULT;
                }
            }
            else if (now_send_point_info_.point_type == "cover")
            {

                LOG(INFO) << "路点类型为cover,路点名称为: " << now_send_point_info_.point_name;
                std::vector<PoseData> pdata;
                PoseData pd;
                // 检查是否是小区域清扫点
                bool is_area_clean = false;
                double area_size = 1.0;
                double rectangle_area = 0.0;  // 用于面积统计
                double rectangle_perimeter = 0.0; 
                
                if (now_send_point_info_.point_name == "area_clean_1") {
                    is_area_clean = true;
                    area_size = 1.0;
                    rectangle_perimeter = 5.0;
                    rectangle_area = effective_robot_radius_*2*rectangle_perimeter;  // 1x1 = 1平方米
                    LOG(INFO) << "检测到小区域清扫命令: area_clean_1 (1x1米，面积1平方米)";
                } else if (now_send_point_info_.point_name == "area_clean_2") {
                    is_area_clean = true;
                    area_size = 3.0;
                    rectangle_perimeter = 35.38;
                    rectangle_area = effective_robot_radius_*2*rectangle_perimeter;  // 3x3 = 9平方米
                    LOG(INFO) << "检测到小区域清扫命令: area_clean_2 (3x3米，面积9平方米)";
                } else if (now_send_point_info_.point_name == "area_clean_3") {
                    is_area_clean = true;
                    area_size = 5.0;
                    rectangle_perimeter = 58.34; 
                    rectangle_area = effective_robot_radius_*2*rectangle_perimeter;  // 5x5 = 25平方米
                    LOG(INFO) << "检测到小区域清扫命令: area_clean_3 (5x5米，面积25平方米)";
                }
                
                if (is_area_clean) {
                    // 小区域清扫：根据机器人当前位置生成矩形四个顶点
                    // 获取机器人当前位置
                    geometry_msgs::Pose2D current_pose;
                    if (!ListenTF("map", "base_link", current_pose))
                    {
                        LOG(ERROR) << "小区域清扫：无法获取机器人当前位置";
                        task_index_ = Task_Index::TASK_FAULT;
                        break;
                    }
                    
                    // 修正：矩形完全在车前方，近边在车前75cm处
                    // 矩形中心点位置 = 车前距离 + 矩形边长的一半
                    double forward_distance = 0.75;  // 车前75cm（矩形近边距离）
                    double half_size = area_size / 2.0;
                    double center_distance = forward_distance + half_size;  // 中心点距离
                    
                    // 计算矩形中心点
                    double center_x = current_pose.x + center_distance * cos(current_pose.theta);
                    double center_y = current_pose.y + center_distance * sin(current_pose.theta);
                    
                    // 四个顶点相对于中心的偏移（未旋转前）
                    // 注意：所有点的x坐标（车头方向）都应该是正值
                    std::vector<std::pair<double, double>> local_points = {
                        {-half_size, half_size},   // 左前
                        {half_size, half_size},    // 右前
                        {half_size, -half_size},   // 右后
                        {-half_size, -half_size}   // 左后
                    };
                    
                    double cos_theta = cos(current_pose.theta);
                    double sin_theta = sin(current_pose.theta);

                    for (const auto& local_pt : local_points) {
                        
                        // 旋转变换
                        pd.x = center_x + local_pt.first * cos_theta - local_pt.second * sin_theta;
                        pd.y = center_y + local_pt.first * sin_theta + local_pt.second * cos_theta;
                        pd.yaw = current_pose.theta;
                        pdata.push_back(pd);
                        
                        LOG(INFO) << "小区域清扫矩形顶点: (" << pd.x << ", " << pd.y << ")";

                        // 设置路径信息，用于面积计算 
                        p_shard_data_->nav_progress_.total_length = rectangle_perimeter;
                        p_shard_data_->nav_progress_.total_areas = rectangle_area;
                        p_shard_data_->nav_progress_.last_areas = rectangle_area;
                        
                        // 设置 allarea_ 用于面积计算
                        allarea_ = rectangle_area;
                        LOG(INFO) << "小区域清扫：周长=" << rectangle_perimeter << "m, 面积=" << rectangle_area << "m²";
                    }
                }
                else {
                    for (auto point : now_send_point_info_.point_array)
                    {
                        pd.x = point.x;
                        pd.y = point.y;
                        pd.yaw = point.yaw;
                        pdata.push_back(pd);
                    }
                }
                p_shard_data_->coverpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_cover_action_->SetCmd("new_goal", pdata);
                task_index_ = Task_Index::TASK_NORMAL;
            }
            else if (now_send_point_info_.point_type == "access")
            {
                LOG(INFO) << "路点类型为access,不执行动作: " << now_send_point_info_.point_name;
                task_index_ = Task_Index::TASK_WAIT;
            }
            else if (now_send_point_info_.point_type == "lift")
            {
                LOG(INFO) << "路点类型为lift,不执行动作: " << now_send_point_info_.point_name;
                task_index_ = Task_Index::TASK_WAIT;
            }
            else if (now_send_point_info_.point_type == "point" || now_send_point_info_.point_type == "edge")
            {
                LOG(INFO) << "路点类型为" << now_send_point_info_.point_type << ",路点名称为: " << now_send_point_info_.point_name << " ,地图名称为: " << now_send_point_info_.point_map;
                PoseData pd;
                pd.x = now_send_point_info_.point_array[0].x;
                pd.y = now_send_point_info_.point_array[0].y;
                pd.yaw = now_send_point_info_.point_array[0].yaw;
                pd.map = now_send_point_info_.point_map;
                pd.type = now_send_point_info_.point_type == "point" ? GlobalPlannerType::NORMAL : GlobalPlannerType::EDGE_CLEAN;
                pd.point_name = now_send_point_info_.point_name;
                p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_normal_action_->SetCmd("new_goal", pd);
                task_index_ = Task_Index::TASK_NORMAL;
                // 20250529 c_add 三合一乘梯添加start/end点进行开关外设
                if (now_send_point_info_.point_name == "endpoint" && autolift_)
                {
                    // 调用taskmanage中的开关外设服务
                    robot_msgs::Cmd srv;
                    srv.request.cmd = "close_only";
                    if(!clear_io_service_.waitForExistence(ros::Duration(10)))
                    {
                        LOG(ERROR) << "clear_io_service_ died";
                    }                     
                    if (clear_io_service_.call(srv))
                    {
                        if (srv.response.status == "success")
                        {
                            LOG(INFO) << "成功在endpoint点关闭三合一清洁车单一io";
                        }
                        else
                        {
                            LOG(ERROR) << "未成功在endpoint点关闭三合一清洁车单一io";
                        }
                    }
                    else
                    {
                        LOG(ERROR) << "未成功调用服务在endpoint点关闭三合一清洁车单一io";
                    }
                }
            }
            else if (now_send_point_info_.point_type == "back")
            {
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "GOTO_back";
                }
                LOG(INFO) << "路点类型为back";
                PoseData pd;
                p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_back_home_->SetCmd("new_goal", pd);
                task_index_ = Task_Index::TASK_NORMAL;
            }
            else if (now_send_point_info_.point_type == "location")
            {
                LOG(INFO) << "路点类型为location";
                string current_map = p_shard_data_->GetCurrentMap();
                PoseData pd;
                pd.x = p_shard_data_->location_point_.x;
                pd.y = p_shard_data_->location_point_.y;
                pd.yaw = p_shard_data_->location_point_.yaw;
                pd.map = current_map;
                p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_normal_action_->SetCmd("new_goal", pd);
                task_index_ = Task_Index::TASK_NORMAL;
            }
            // 赋值现在的导航状态
            {
                std::lock_guard<std::mutex> lock(robot_status_mutex_);
                p_shard_data_->now_nav_status_ = robot_status_msg_.data;
            }
        }
        break;
    // 门禁闸机任务
    case Task_Index::TASK_ACCESS:
    {
    }
    break;
    // 乘梯任务
    case Task_Index::TASK_LIFT:
    {
    }
    break;
    // 等待结果
    case Task_Index::TASK_NORMAL:
    {
        running_flg_ = true;
        //ROS_INFO("DEBUG;TASK_NORMAL状态，检查路径导航状态");
                    // 添加路径导航状态检查
        // if (now_send_path_info_flag_)
        // {
        //     ROS_INFO("DEBUG;检查teachingpath_nav_status_: %d", p_shard_data_->teachingpath_nav_status_.goal_status);
        //     if (p_shard_data_->teachingpath_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
        //     {
        //         ROS_INFO("DEBUG;路径导航成功");
        //         LOG(INFO) << "teachingpath导航成功，路径名称为:" << now_send_path_info_;
        //         p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
        //         p_shard_data_->move_status_ = MoveStatus::IDLE;
        //         now_send_path_info_flag_ = false;
        //         task_index_ = Task_Index::TASK_WAIT;
        //     }
        //     else if (p_shard_data_->teachingpath_nav_status_.goal_status == NavStatus::NAV_ABORTED)
        //     {
        //         ROS_ERROR("DEBUG;路径导航中止");
        //         LOG(ERROR) << "teachingpath路径规划中止NAV_ABORTED，路径名称为:" << now_send_path_info_;
        //         p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
        //         p_shard_data_->move_status_ = MoveStatus::IDLE;
        //         p_shard_data_->fault_code_.B0602 = true;
        //         {
        //             std::lock_guard<std::mutex> lock(robot_status_mutex_);
        //             robot_status_msg_.data = "GOTO_" + now_send_path_info_ + "_failed";
        //         }
        //         now_send_path_info_flag_ = false;
        //         task_index_ = Task_Index::TASK_FAULT;
        //     }
        //     else if (p_shard_data_->teachingpath_nav_status_.goal_status == NavStatus::NAV_FAILED)
        //     {
        //         ROS_ERROR("DEBUG;路径导航失败");
        //         LOG(ERROR) << "teachingpath路径规划失败NAV_FAILED，路径名称为:" << now_send_path_info_;
        //         p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
        //         p_shard_data_->move_status_ = MoveStatus::IDLE;
        //         p_shard_data_->fault_code_.B0602 = true;
        //         {
        //             std::lock_guard<std::mutex> lock(robot_status_mutex_);
        //             robot_status_msg_.data = "GOTO_" + now_send_path_info_ + "_failed";
        //         }
        //         now_send_path_info_flag_ = false;
        //         task_index_ = Task_Index::TASK_FAULT;
        //     }
        // }
        if (now_send_point_info_.point_type == "point" || now_send_point_info_.point_type == "edge" || now_send_point_info_.point_type == "location")
        {
            //ROS_INFO("DEBUG;检查teachingpath_nav_status_: %d", p_shard_data_->teachingpath_nav_status_.goal_status);
            if (p_shard_data_->normalpoint_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
            {
                LOG(INFO) << "normalpoint导航成功，路点名称为:" << now_send_point_info_.point_name;
                p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE; 
                task_index_ = Task_Index::TASK_WAIT;
                path_processing_mode_ = false;
                // 20250529 c_add 三合一乘梯添加start/end点进行开关外设
                if (now_send_point_info_.point_name == "startpoint" && autolift_)
                {
                    // 调用taskmanage中的开关外设服务
                    robot_msgs::Cmd srv;
                    srv.request.cmd = "open";
                    if(!clear_io_service_.waitForExistence(ros::Duration(10)))
                    {
                        LOG(ERROR) << "clear_io_service_ died";
                    }         
                    if (clear_io_service_.call(srv))
                    {
                        if (srv.response.status == "success")
                        {
                            LOG(INFO) << "成功在startpoint点打开三合一清洁车io";
                        }
                        else
                        {
                            LOG(ERROR) << "未成功在startpoint点打开三合一清洁车io";
                        }
                    }
                    else
                    {
                        LOG(ERROR) << "未成功调用服务在startpoint点打开三合一清洁车io";
                    }
                }
                if (now_send_point_info_.point_name == "endpoint" && autolift_)
                {
                    // 调用taskmanage中的开关外设服务
                    robot_msgs::Cmd srv;
                    srv.request.cmd = "close";
                    if(!clear_io_service_.waitForExistence(ros::Duration(10)))
                    {
                        LOG(ERROR) << "clear_io_service_ died";
                    }        
                    if (clear_io_service_.call(srv))
                    {
                        if (srv.response.status == "success")
                        {
                            LOG(INFO) << "成功在endpoint点关闭三合一清洁车io";
                        }
                        else
                        {
                            LOG(ERROR) << "未成功在endpoint点关闭三合一清洁车io";
                        }
                    }
                    else
                    {
                        LOG(ERROR) << "未成功调用服务在endpoint点关闭三合一清洁车io";
                    }
                }
            }
            else if (p_shard_data_->normalpoint_nav_status_.goal_status == NavStatus::NAV_ABORTED)
            {
                // 根据车型决定是否判断 move_status_==ABORTED
                if (car_type_ == "CD-01")
                {
                    // CD-01车型：不判断 move_status_==ABORTED
                    //ROS_ERROR("DEBUG;路径导航中止");
                    LOG(ERROR) << "navcontrol TASK_NORMAL:normalpoint路径规划中止NAV_ABORTED，路点名称为:" << now_send_point_info_.point_name;
                    // p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    // p_shard_data_->move_status_ = MoveStatus::IDLE;
                    // p_shard_data_->fault_code_.B0602 = true;
                    // {
                    //     std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    //     robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                    // }
                    // task_index_ = Task_Index::TASK_FAULT;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    LOG(WARNING) << "普通点导航失败:" << now_send_point_info_.point_name << " (类型: " << p_shard_data_->normalpoint_nav_status_.goal_status << ")，继续执行下一个点", 
                    
                    // 即使失败也重置状态，继续执行
                    p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    
                    // 这里设置错误码，让任务继续
                    p_shard_data_->fault_code_.B0602 = false; // 保持false
                    
                    {
                        std::lock_guard<std::mutex> lock(robot_status_mutex_);
                        robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                    }
                    
                    // 20260109 yhn 直接进入错误状态
                        task_index_ = Task_Index::TASK_FAULT;
                }
                else if (car_type_ != "CD-01" && p_shard_data_->move_status_ == MoveStatus::ABORTED)
                {
                    // 非CD-01车型：需要同时判断 move_status_==ABORTED
                    //ROS_ERROR("DEBUG;路径导航中止");
                    LOG(ERROR) << "navcontrol TASK_NORMAL:normalpoint路径规划中止NAV_ABORTED，路点名称为:" << now_send_point_info_.point_name;
                    // p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    // p_shard_data_->move_status_ = MoveStatus::IDLE;
                    // p_shard_data_->fault_code_.B0602 = true;
                    // {
                    //     std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    //     robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                    // }
                    // task_index_ = Task_Index::TASK_FAULT;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    LOG(WARNING) << "普通点导航失败: " << now_send_point_info_.point_name << " (类型: " << p_shard_data_->normalpoint_nav_status_.goal_status << ")，继续执行下一个点" ;

                    // 即使失败也重置状态，继续执行
                    p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    
                    // 这里设置错误码，让任务继续
                    p_shard_data_->fault_code_.B0602 = false; // 保持false
                    
                    {
                        std::lock_guard<std::mutex> lock(robot_status_mutex_);
                        robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                    }
                    
                    // 20260109 yhn 直接进入等待状态，移除当前点并处理下一个点
                        task_index_ = Task_Index::TASK_WAIT;
                }
            }
            else if (p_shard_data_->normalpoint_nav_status_.goal_status == NavStatus::NAV_FAILED)
            {
                // 根据车型决定是否判断 move_status_==ABORTED
                if (car_type_ == "CD-01")
                {
                    // CD-01车型
                    LOG(ERROR) << "TASK_NORMAL:normalpoint路径规划失败NAV_FAILED，路点名称为:" << now_send_point_info_.point_name;
                    p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    p_shard_data_->fault_code_.B0602 = true;
                    {
                        std::lock_guard<std::mutex> lock(robot_status_mutex_);
                        robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                    }
                    //task_index_ = Task_Index::TASK_FAULT;
                    // 20260109 yhn 直接进入等待状态，移除当前点并处理下一个点
                    task_index_ = Task_Index::TASK_FAULT;
                    //task_index_ = Task_Index::TASK_WAIT;
                }
                else if (car_type_ != "CD-01" && p_shard_data_->move_status_ == MoveStatus::ABORTED)
                {
                    // 非CD-01车型：需要同时判断 move_status_==ABORTED
                    LOG(ERROR) << "TASK_NORMAL:normalpoint路径规划中止NAV_ABORTED，路点名称为:" << now_send_point_info_.point_name;
                    p_shard_data_->normalpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                    p_shard_data_->move_status_ = MoveStatus::IDLE;
                    p_shard_data_->fault_code_.B0602 = true;
                    {
                        std::lock_guard<std::mutex> lock(robot_status_mutex_);
                        robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                    }
                    //task_index_ = Task_Index::TASK_FAULT;
                    // 20260109 yhn 直接进入等待状态，移除当前点并处理下一个点
                    task_index_ = Task_Index::TASK_WAIT;
                }
            }
        }
        else if (now_send_point_info_.point_type == "teach_path"||now_send_point_info_.point_type == "cover_path"){
            if (p_shard_data_->teachingpath_nav_status_.goal_status == NavStatus::NAV_SUCCESS) {
                LOG(INFO) << "TASK_NORMAL:teachingpath执行成功，路点名称为:" << now_send_point_info_.point_name;
                //p_shard_data_->teachingpath_nav_status_.goal_status = NavStatus::NAV_IDLE;
                //task_index_ = Task_Index::TASK_WAIT;
            }
        }
        else if (now_send_point_info_.point_type == "cover")
        {
            if (p_shard_data_->coverpoint_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
            {
                // 增加面积统计
                {
                    // 清空请求面积的队列
                    std::queue<PointInfo> empty0;
                    std::swap(empty0, p_shard_data_->allarea_queue_);
                    p_shard_data_->allarea_queue_.push(now_send_point_info_); // 加入当前的路点
                    emit signal_RequireArea();                                // 请求清扫的面积
                    //cleanedarea_ += p_shard_data_->clean_area_;               // 累计清理的面积
                    double dis_to_end=p_shard_data_->nav_progress_.dis_to_end;
                    double total_length=p_shard_data_->nav_progress_.total_length;
                    cleanedarea_ +=dis_to_end>0? (total_length-dis_to_end)*effective_robot_radius_:p_shard_data_->clean_area_;
                    exed_point_number_++;
                    if (exed_point_number_ > all_point_number_)
                    { // 防止点的个数超出阈值
                        exed_point_number_ = all_point_number_;
                    }
                    if (cleanedarea_ > allarea_)
                    { // 防止面积超出阈值
                        cleanedarea_ = allarea_;
                    }
                }
                LOG(INFO) << "TASK_NORMAL:coverpoint导航成功，路点名称为:" << now_send_point_info_.point_name;
                p_shard_data_->coverpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                task_index_ = Task_Index::TASK_WAIT;
            }
            else if (p_shard_data_->coverpoint_nav_status_.goal_status == NavStatus::NAV_ABORTED)
            {
                {
                    // 清空请求面积的队列
                    std::queue<PointInfo> empty0;
                    std::swap(empty0, p_shard_data_->allarea_queue_);
                    p_shard_data_->allarea_queue_.push(now_send_point_info_); // 加入当前的路点
                    emit signal_RequireArea();                                // 请求清扫的面积
                    //cleanedarea_ += p_shard_data_->clean_area_;               // 累计清理的面积
                    double dis_to_end=p_shard_data_->nav_progress_.dis_to_end;
                    double total_length=p_shard_data_->nav_progress_.total_length;
                    cleanedarea_ +=dis_to_end>0? (total_length-dis_to_end)*effective_robot_radius_:p_shard_data_->clean_area_;
                    exed_point_number_++;
                    if (exed_point_number_ > all_point_number_)
                    { // 防止点的个数超出阈值
                        exed_point_number_ = all_point_number_;
                    }
                    if (cleanedarea_ > allarea_)
                    { // 防止面积超出阈值
                        cleanedarea_ = allarea_;
                    }
                }
                
                LOG(ERROR) << "TASK_NORMAL:coverpoint路径规划中止NAV_ABORTED，路点名称为:" << now_send_point_info_.point_name;
                p_shard_data_->coverpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                p_shard_data_->fault_code_.B0602 = true;
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                }
                task_index_ = Task_Index::TASK_FAULT;
            }
            else if (p_shard_data_->coverpoint_nav_status_.goal_status == NavStatus::NAV_FAILED)
            {
                {
                    // 清空请求面积的队列
                    std::queue<PointInfo> empty0;
                    std::swap(empty0, p_shard_data_->allarea_queue_);
                    p_shard_data_->allarea_queue_.push(now_send_point_info_); // 加入当前的路点
                    emit signal_RequireArea();                                // 请求清扫的面积
                    //cleanedarea_ += p_shard_data_->clean_area_;               // 累计清理的面积
                    double dis_to_end=p_shard_data_->nav_progress_.dis_to_end;
                    double total_length=p_shard_data_->nav_progress_.total_length;
                    cleanedarea_ +=dis_to_end>0? (total_length-dis_to_end)*effective_robot_radius_:p_shard_data_->clean_area_;
                    exed_point_number_++;
                    if (exed_point_number_ > all_point_number_)
                    { // 防止点的个数超出阈值
                        exed_point_number_ = all_point_number_;
                    }
                    if (cleanedarea_ > allarea_)
                    { // 防止面积超出阈值
                        cleanedarea_ = allarea_;
                    }
                }
                
                LOG(ERROR) << "TASK_NORMAL:coverpoint路径规划失败NAV_FAILED，路点名称为:" << now_send_point_info_.point_name;
                p_shard_data_->coverpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                p_shard_data_->fault_code_.B0602 = true;
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "GOTO_" + now_send_point_info_.point_name + "_failed";
                }
                task_index_ = Task_Index::TASK_FAULT;
            }
        }
        else if (now_send_point_info_.point_type == "back")
        {
            if (p_shard_data_->backpoint_nav_status_.goal_status == NavStatus::NAV_SUCCESS)
            {
                LOG(INFO) << "TASK_NORMAL:backpoint导航成功";
                p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                if (p_shard_data_->resume_status_ == ResumeStatus::RESUME_BACK_HOME) {
                    LOG(INFO) << "返航完成，等待续扫命令";
                    p_shard_data_->resume_status_ = ResumeStatus::RESUME_WAITING;
                    
                    {
                        std::lock_guard<std::mutex> lock(robot_status_mutex_);
                        robot_status_msg_.data = "success";
                    }
                    
                    LOG(INFO) << "返航完成，等待续扫命令";
                    //task_index_ = Task_Index::TASK_PATH_WAITING;
                    
                    // 从队列中移除返航点
                    {
                        std::lock_guard<std::mutex> lock(target_queue_mutex_);
                        if (!target_queue_.empty() && 
                            target_queue_.front().point_type == "back") {
                            target_queue_.pop();
                        }
                    }
                    task_index_ = Task_Index::TASK_IDLE;
                    break;
                    //task_index_ = Task_Index::TASK_IDLE;
                }else {
                    path_processing_mode_ = false;
                    current_processing_path_type_.clear();
                    
                    // 从队列中移除当前点
                    {
                        std::lock_guard<std::mutex> lock(target_queue_mutex_);
                        if (!target_queue_.empty() && 
                            target_queue_.front().point_name == now_send_point_info_.point_name) {
                            target_queue_.pop();
                            LOG(INFO) << "移除已完成的返航点";
                        }
                    }
                    
                    task_index_ = Task_Index::TASK_WAIT;
                    
                    // 立即调用一次任务控制，确保状态转换
                    TaskControl();
                }
            }
            else if (p_shard_data_->backpoint_nav_status_.goal_status == NavStatus::NAV_ABORTED)
            {
                LOG(ERROR) << "TASK_NORMAL:backpoint路径规划中止NAV_ABORTED";
                p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                p_shard_data_->fault_code_.B0602 = true;
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "GOTO_back_failed";
                }
                task_index_ = Task_Index::TASK_FAULT;
            }
            else if (p_shard_data_->backpoint_nav_status_.goal_status == NavStatus::NAV_FAILED)
            {
                LOG(ERROR) << "TASK_NORMAL:backpoint路径规划失败NAV_FAILED";
                p_shard_data_->backpoint_nav_status_.goal_status = NavStatus::NAV_IDLE;
                p_shard_data_->move_status_ = MoveStatus::IDLE;
                p_shard_data_->fault_code_.B0602 = true;
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "GOTO_back_failed";
                }
                task_index_ = Task_Index::TASK_FAULT;
            }
        }
    }
    break;
    case Task_Index::TASK_WAIT:
    {
        LOG(INFO) << "处理当前点完成后的清理工作";
        
        // 检查是否在路径处理模式
        if (path_processing_mode_) {
            // 路径处理模式中，不在这里处理队列，由TASK_PATH_WAITING处理
            LOG(INFO) << "当前处于路径处理模式，跳过队列清理";
            break; // 直接跳出，等待路径执行完成
        }
        
        // 非路径处理模式，正常处理队列
        {
            std::lock_guard<std::mutex> lock(target_queue_mutex_);
            // 移除已完成的点（普通点、覆盖点、返航点等）
            if (!target_queue_.empty()) {
                std::string completed_point_name = target_queue_.front().point_name;
                std::string completed_point_type = target_queue_.front().point_type;
                LOG(INFO) << "移除已完成的点 [" + completed_point_name + "] (" + completed_point_type + ")";
                target_queue_.pop();
                
                // 同时从cover_teach_area_queue_中移除已完成的路径
                if (!p_shard_data_->cover_teach_area_queue_.empty()) {
                    CoverTeachArea completed_area = p_shard_data_->cover_teach_area_queue_.front();
                    if (completed_area.point_name == completed_point_name) {
                        p_shard_data_->cover_teach_area_queue_.pop();
                        LOG(INFO) << "从cover_teach_area_queue_移除已完成的路径 [" + completed_point_name + "]";
                    }
                }
            }
            
            // 检查是否还有下一个点
            if (!target_queue_.empty()) {
                task_index_ = Task_Index::TASK_HANDOUT;
                LOG(INFO) << "队列还有 " << target_queue_.size() << " 个点，返回 TASK_HANDOUT, cleanedarea_=" << cleanedarea_ << "m²";
                
                break;
            } else {
                running_flg_ = false;
                should_reset_cleanedarea_ = true;
                // 任务运行结束
                //ROS_INFO("DEBUG;TASK_WAIT: 所有任务完成，累计清洁面积=%.2fm²/%.2fm²", 
                //        cleanedarea_, p_shard_data_->nav_progress_.total_areas); 
                //LOG(INFO) << "TASK_WAIT导航任务运行全部结束，累计清洁面积=" << cleanedarea_ << "m²";   
                //task_index_ = Task_Index::TASK_IDLE;
                //{
                //    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                //    robot_status_msg_.data = "success";
                //}
                // 检查是否在乘梯过程中收到了新任务
                if (p_shard_data_->task_cancel_during_lift_) {
                    LOG(INFO) << "检测到乘梯后待执行命令，重新读取任务队列";
                    p_shard_data_->task_cancel_during_lift_ = false;                    
                    if (p_shard_data_->api_recved_target_vector_.size() > 0) {
                        LOG(INFO) << "有等待中的新任务，开始执行";
                        {
                            std::lock_guard<std::mutex> lock(robot_status_mutex_);
                            robot_status_msg_.data = "FREE";
                        }
                        task_index_ = Task_Index::TASK_READY;
                        break;
                    }
                }
                
                // 任务运行结束
                LOG(INFO) << "TASK_WAIT: 所有任务完成，累计清洁面积=" << cleanedarea_ << "/" << p_shard_data_->nav_progress_.total_areas; 
                task_index_ = Task_Index::TASK_IDLE;
                {
                    std::lock_guard<std::mutex> lock(robot_status_mutex_);
                    robot_status_msg_.data = "success";
                }
            }
        }
    }
    break;
    case Task_Index::TASK_FAULT:
    {
        p_access_lift_shared_->thread_pause_flag_ = true;
        p_access_action_->thread_pause_flag_ = true;
        p_accurate_control_shared_->thread_pause_flag_ = true;
        p_back_home_->thread_pause_flag_ = true;
        p_cover_action_->thread_pause_flag_ = true;
        p_normal_action_->thread_pause_flag_ = true;
        {
            std::lock_guard<std::mutex> lock(target_queue_mutex_);
            std::queue<PointInfo> empty;
            std::swap(empty, target_queue_);
            //LOG(INFO) << "TASK_FAULT: 已清空任务队列";
        }
    
        // 清理路径处理标志
        path_processing_mode_ = false;
        current_processing_path_type_.clear();
        
        // 清理API接收的目标向量
        p_shard_data_->api_recved_target_vector_.clear();
        
        running_flg_ = false;
        //LOG(INFO) << "TASK_FAULT: 所有清理完成";
        }
    break;
    default:
        break;
    }
}

// QT线程类，自动运行
void NavControl::run()
{
    ros::Rate r(50);
    while (ros::ok())
    {
        TaskControl();
        ros::spinOnce();
        r.sleep();
    }
}
