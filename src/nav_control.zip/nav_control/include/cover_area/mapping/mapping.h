#ifndef MAPPING_H
#define MAPPING_H
#include <memory>
#include <opencv2/core.hpp>
#include "cover_area/common.h"
#include "eigen_types.h"
namespace mapping {

class Submap;
class LoopClosing;
// using Scan2d = sensor_msgs::LaserScan;
// struct Scan
// {
//     Scan2d::ConstPtr scan;
//     tf::Vector3 pose;
// };
/// 栅格模板，预先计算
    struct Model2DPoint {
        int dx_ = 0;
        int dy_ = 0;
        double angle_ = 0;  // in rad
        float range_ = 0;   // in meters
    };
/**
 * 2D 激光建图的主要类
 */
class Mapping2D {
   public:
       struct MappingParams{// 图像大小
        double x_min=0.;
        double x_max=0.;
        double y_min=0.;
        double y_max=0.; 
        Vec2d size;
        std::vector<Model2DPoint> model;  // 用于填充占据栅格的模板，都是世界系下的点
        double closest_th = 0.2;         // 近距离阈值
        double endpoint_close_th = 0.1;  // 末端点障碍物近距离阈值
        double resolution = 20.0;        // 1m 多少像素
        float inv_resolution = 0.05;     // 1个像素多少米（栅格分辨率）       
        int model_size = 400;            // 模板像素大小
        Vec2d center_image;    
        };
        bool Init(SE2& pose);
        bool ProcessScan(Scan* scan);
        void SetMappingCover(std::vector<Vec2d> &cover)
        {
            // map_size_.clear();
            // for(auto &point:si) map_size_.push_back(point);
            vec_cover_=cover;
        };
        cv::Mat occu_image_;
        std::vector<cv::Point> image_cover_;
        MappingParams mapping_params_;
        //std::shared_ptr<cv::Mat> p_occu_image_=std::make_shared<cv::Mat>(occu_image_);
        Vec2d Image2World(const Vec2d& pt) {
            Vec2d pt_map;
            //= (pt- center)/ mapping_params_.resolution+ init_pose_.translation();
            pt_map[0]=(pt[0]-mapping_params_.center_image[0])/ mapping_params_.resolution+ init_pose_.translation()[0];
            pt_map[1]=(mapping_params_.center_image[1]-pt[1])/ mapping_params_.resolution+ init_pose_.translation()[1];
            return pt_map;
        }
   private:

    /// 判定当前帧是否为关键帧
    bool IsKeyFrame();
    /// 增加一个关键帧
    void AddKeyFrame();
    /// 扩展新的submap
    void ExpandSubmap();
    size_t NumFrames() const { return current_frame_->keyframe_id_; }
    size_t GetId() const { return keyframe_id_; }
    /// 往这个占据栅格地图中增加一个frame
    void AddLidarFrame(std::shared_ptr<Frame> frame);
/// 在某个点填入占据或者非占据信息
    void SetPoint(const Vec2i& pt, bool occupy);
    /// 获取黑白灰形式的占据栅格，作可视化使用
    cv::Mat GetOccupancyGridBlackWhite() const;
    Vec2d CalculateMapSize();
    void Visualize2DScan(Scan2d::ConstPtr scan, const SE2& pose, cv::Mat& image, const Vec3b& color, 
                        Vec2d& image_size,float resolution, const SE2& pose_submap);
    // 数据成员
    size_t frame_id_ = 0;
    size_t keyframe_id_ = 0;
    size_t submap_id_ = 0;
    std::vector<Vec2d> map_size_,vec_cover_;//单位m

    bool first_scan_ = true;
    std::shared_ptr<Frame> current_frame_ = nullptr;
    std::shared_ptr<Frame> last_frame_ = nullptr;
    SE2 motion_guess_;
    std::shared_ptr<Frame> last_keyframe_ = nullptr;
    std::shared_ptr<Submap> current_submap_ = nullptr;
    SE2 init_pose_,submap_in_image_;
    std::vector<std::shared_ptr<Frame>> keyframe_;//关键帧统计
    cv::Mat occupancy_grid_;  // 8bit 占据栅格图像
    bool has_outside_pts_ = false;  // 标注栅格化过程中是否有落在外部的点
    // 参数
    inline static constexpr double keyframe_pos_th_ = 5.0;              // 关键帧位移量
    inline static constexpr double keyframe_ang_th_ = 30 * M_PI / 180;  // 关键帧角度量
    Mat2d matrix_map_pose_;

    void SetMappingParams(SE2 pose);
    bool HasOutsidePoints() const { return has_outside_pts_;};
    /// 从世界坐标系转到图像坐标系
    template <class T>
    inline Vec2i World2Image(const Eigen::Matrix<T, 2, 1>& pt) {
        Vec2d pt_map = (init_pose_.inverse() * pt) * mapping_params_.resolution + mapping_params_.center_image;
        int x = int(pt_map[0]);
        int y = int(pt_map[1]);
        return Vec2i(x, y);
    }

    bool IsInside(const Vec2d& pw, const std::vector<Vec2d>& rect) {
        if (pw[0] < rect[0][0] || pw[0] > rect[1][0]) {
            return false;
        }
        if (pw[1] < rect[0][1] || pw[1] > rect[1][1]) {
            return false;
        }
        return true;
    };
    /// 查找某个角度下的range值
    double FindRangeInAngle(double angle, Scan2d::ConstPtr scan);

    /**
     * Bresenham直线填充，给定起始点和终止点，将中间的区域填充为白色
     * @param p1
     * @param p2
     */
    void BresenhamFilling(const Vec2i& p1, const Vec2i& p2);
};

}  // namespace mapping

#endif  // MAPPING_H
