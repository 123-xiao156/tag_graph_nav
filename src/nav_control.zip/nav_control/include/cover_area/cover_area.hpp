#ifndef COVERAREACLASS_HPP_
#define COVERAREACLASS_HPP_
#include <vector>
#include <iostream>
#include <cmath>
#include "common.h"
class CoverAreaClass
{
public:
    bool GetCoverPath(std::vector<PoseData> &inputPolyPoints, std::vector<Point> &outputCoveragePoints,double& radius)
    {
        stepLength = radius; 
        if(inputPolyPoints.size()<4)
        {
            for(auto& point : inputPolyPoints){
                outputCoveragePoints.push_back(Point{point.x, point.y});
            }
            return false;
        }
        std::vector<Point> longerLinePoints;
        std::vector<Point> shorterLinePoints;
        if ((pow(inputPolyPoints[0].x - inputPolyPoints[1].x, 2) + pow(inputPolyPoints[0].y - inputPolyPoints[1].y, 2)) >= (pow(inputPolyPoints[0].x - inputPolyPoints[3].x, 2) + pow(inputPolyPoints[0].y - inputPolyPoints[3].y, 2)))
        {
            if ((pow(inputPolyPoints[0].x - inputPolyPoints[3].x, 2) + pow(inputPolyPoints[0].y - inputPolyPoints[3].y, 2)) >= (pow(inputPolyPoints[1].x - inputPolyPoints[2].x, 2) + pow(inputPolyPoints[1].y - inputPolyPoints[2].y, 2)))
            {
                getInterPoints(inputPolyPoints[0].x, inputPolyPoints[0].y, inputPolyPoints[3].x, inputPolyPoints[3].y, longerLinePoints);
                getInterNumPoints(inputPolyPoints[1].x, inputPolyPoints[1].y, inputPolyPoints[2].x, inputPolyPoints[2].y, shorterLinePoints, longerLinePoints.size());
            }
            else
            {

                getInterPoints(inputPolyPoints[1].x, inputPolyPoints[1].y, inputPolyPoints[2].x, inputPolyPoints[2].y, longerLinePoints);
                getInterNumPoints(inputPolyPoints[0].x, inputPolyPoints[0].y, inputPolyPoints[3].x, inputPolyPoints[3].y, shorterLinePoints, longerLinePoints.size());
            }
        }
        else
        {
            if ((pow(inputPolyPoints[0].x - inputPolyPoints[1].x, 2) + pow(inputPolyPoints[0].y - inputPolyPoints[1].y, 2)) >= (pow(inputPolyPoints[3].x - inputPolyPoints[2].x, 2) + pow(inputPolyPoints[3].y - inputPolyPoints[2].y, 2)))
            {
                getInterPoints(inputPolyPoints[0].x, inputPolyPoints[0].y, inputPolyPoints[1].x, inputPolyPoints[1].y, longerLinePoints);
                getInterNumPoints(inputPolyPoints[3].x, inputPolyPoints[3].y, inputPolyPoints[2].x, inputPolyPoints[2].y, shorterLinePoints, longerLinePoints.size());
            }
            else
            {

                getInterPoints(inputPolyPoints[3].x, inputPolyPoints[3].y, inputPolyPoints[2].x, inputPolyPoints[2].y, longerLinePoints);
                getInterNumPoints(inputPolyPoints[0].x, inputPolyPoints[0].y, inputPolyPoints[1].x, inputPolyPoints[1].y, shorterLinePoints, longerLinePoints.size());
            }
        }

        bool flag = true;
        for (size_t i = 0; i < longerLinePoints.size() && i <  shorterLinePoints.size(); i++)
        {
            //20250703jch修复区域内转弯处残留水渍问题
            Point ex_point;
            if (flag)
            {
                ex_point=extendPoint(longerLinePoints[i],shorterLinePoints[i],radius);
                //qDebug()<<"1push_back "<< longerLinePoints[i].x<<" "<< longerLinePoints[i].y
                 //       <<" "<<ex_point.x<<" "<<ex_point.y;
                outputCoveragePoints.push_back(longerLinePoints[i]);
                outputCoveragePoints.push_back(ex_point);
                flag = false;
            }
            else
            {
                ex_point=extendPoint(shorterLinePoints[i],longerLinePoints[i],radius);
                //qDebug()<<"2push_back "<<" "<<shorterLinePoints[i].x<<" "<<shorterLinePoints[i].y
                //        << ex_point.x<<" "<< ex_point.y;
                outputCoveragePoints.push_back(shorterLinePoints[i]);
                outputCoveragePoints.push_back(ex_point);
                flag = true;
            }
        }
        return true;
    }
    /*
     *function:calculateTwoPointArea
     *author:lishuai ptc000004
     *date:2022-06-16
     *description:计算三角形面积
     */
    float calculateTwoPointArea(float a_x, float a_y, float b_x, float b_y, float c_x, float c_y)
    {
        float area = 0.0;
        float d_ab = 0.0;
        float d_ac = 0.0;
        float d_bc = 0.0;
        float p = 0.0;

        d_ab = sqrt(pow(b_x - a_x, 2) + pow(b_y - a_y, 2));
        d_ac = sqrt(pow(c_x - a_x, 2) + pow(c_y - a_y, 2));
        d_bc = sqrt(pow(b_x - c_x, 2) + pow(b_y - c_y, 2));

        p = (d_ab + d_ac + d_bc) / 2;

        area = sqrt(p * (p - d_ab) * (p - d_ac) * (p - d_bc));
        return area;
    }
    /*
     *function:calculateAnyPointArea
     *author:lishuai ptc000004
     *date:2022-06-16
     *description:计算多边形面积
     */
    float calculateAnyPointArea(std::vector<std::vector<double>> &ptVector)
    {
        int i_count = ptVector.size();
        float area_ = 0.f;
        for (int i = 0; i < i_count; i++)
        {
            area_ = area_ + (ptVector[i][0] * ptVector[(i + 1) % i_count][1] - ptVector[(i + 1) % i_count][0] * ptVector[i][1]);
        }
        return abs(0.5 * area_);
    }

private:
    float stepLength = 0.4; //zkk 20221215 0.4
    /*
     *function:getTheta
     *author:zhaolongliang ptc000004
     *date:2022-06-16
     *description:
     */
    double getTheta(float start_x, float start_y, float end_x, float end_y)
    {

        double thetaCosValue = (end_x - start_x) / sqrt(pow(end_y - start_y, 2) + pow(end_x - start_x, 2));
        double thetaValue = acos(thetaCosValue);

        if ((end_y - start_y) < 0.0)
        {
            thetaValue = -thetaValue;
        }
        return thetaValue;
    }

    /*
     *function:getInterPoints
     *author:zhaolongliang ptc000004
     *date:2022-06-16
     *description:
     */
    bool getInterPoints(float star_x, float star_y, float end_x, float end_y, std::vector<Point> &points)
    {

        if (fabs(stepLength) < 0.01)
        {
            return false;
        }
        double distance = sqrt(pow(end_y - star_y, 2) + pow(end_x - star_x, 2));
        int steps = distance / stepLength;
        double thetaValue = getTheta(star_x, star_y, end_x, end_y);
        Point point;
        for (int i = 0; i <= steps; i++)
        {
            point.x=star_x + stepLength * i * cos(thetaValue);
            point.y=star_y + stepLength * i * sin(thetaValue);
            points.push_back(point);
            //std::cout << "getInterPoints,x:" << point[0] << ",y:" << point[1] << std::endl;
        }
        if (distance - stepLength * steps > 0.1)
        {
            point.x=end_x;
            point.y=end_y;
            points.push_back(point);
            //std::cout << "getInterPoints,x:" << point[0] << ",y:" << point[1] << std::endl;
        }
        return true;
    }

    /*
     *function:getInterNumPoints
     *author:zhaolongliang ptc000004
     *date:2022-06-16
     *description:
     */
    bool getInterNumPoints(float star_x, float star_y, float end_x, float end_y, std::vector<Point> &points, int steps)
    {

        double distance = sqrt(pow(end_y - star_y, 2) + pow(end_x - star_x, 2));
        if (steps < 2)
        {
            return false;
        }
        double stepLenth = distance / (steps - 1);
        double thetaValue = getTheta(star_x, star_y, end_x, end_y);
        Point point;
        for (int i = 0; i < steps - 1; i++)
        {
            point.x=star_x + stepLenth * i * cos(thetaValue);
            point.y=star_y + stepLenth * i * sin(thetaValue);
            points.push_back(point);
            //std::cout << "getInterNumPoints,x:" << point.x << ",y:" << point.y << std::endl;
        }
        point.x=end_x;
        point.y=end_y;
        points.push_back(point);
        //std::cout << "getInterNumPoints,x:" << point.x << ",y:" << point.y << std::endl;
        return true;
    }
    Point extendPoint(const Point& p1, const Point& p2, double l) {
        // 计算 p1 到 p2 的方向向量
        double dx = p2.x - p1.x;
        double dy = p2.y - p1.y;
        // 计算 p1 到 p2 的距离
        double distance = std::hypot(dx, dy);
        // 计算单位方向向量
        double dir_x = fabs(distance <0.01)?p2.x:dx / distance;
        double dir_y = fabs(distance <0.01)?p2.y:dy / distance;
        // 计算延长线上的点
        Point extended_point;
        extended_point.x = p2.x + l * dir_x;
        extended_point.y = p2.y + l * dir_y;
        return extended_point;
    }
};
#endif
