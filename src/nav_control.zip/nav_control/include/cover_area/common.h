//
// Created by hela on 2023/12/23.
//
#ifndef COMMOM_H
#define COMMOM_H
#include <Eigen/Core>
#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <sensor_msgs/LaserScan.h>
#include "sophus/se2.hpp"//模板类sophus库
#include "sophus/se3.hpp"
#include <tf/tf.h>
#include <angles/angles.h>
#include "shard_data.h"
using Scan2d = sensor_msgs::LaserScan;

using Vec2i = Eigen::Vector2i;
using Vec3i = Eigen::Vector3i;
using Vec3b = Eigen::Matrix<char, 3, 1>;
using Vec2d = Eigen::Vector2d;
using Mat2d = Eigen::Matrix2d;
using SE2 = Sophus::SE2d;
enum COVERCMD{COVER,COVERESTOP,GOON,CANCLE,RESET};
//enum NAVSTATUS{ROAD_SEND,FINISH,COVERRUN,ROAD,INSPECTION_SEND,INSPECTION_RUN,SEND,COVERFAULT,COVERWAIT};//导航状态
//enum PointType
//{
//   NORMAL = 0,
//   NARROW = 1,
//   EDGE_CLEAN = 2,
//   TWO_POINTS_CLEAN = 3,
//   NO_YAW = 4,
//   NARROW_NO_YAW = 5,
//   EDGE_CLEAN_NO_YAW = 6,
//};
struct Point
{
   double x;
   double y;
   double yaw;
    GlobalPlannerType type;
};
   struct Pose
   {
      double x;
      double y;
      double yaw;
   };
struct Params
   {
      bool giveup_failed_point;//自动跳过失败的路点
      int time_out=5;//超时时间
      bool dont_move_check=false;//机器人导航时不移动的检查
   };
   struct Scan
   {
      Scan2d::ConstPtr scan;
      SE2 pose;
   };
   /**
 * 一次2D lidar扫描
 */
struct Frame {
    Frame() {}
    Frame(Scan* pscan) : scan_(pscan->scan),pose_(pscan->pose) {}
    size_t id_ = 0;               // scan id
    size_t keyframe_id_ = 0;      // 关键帧 id
    double timestamp_ = 0;        // 时间戳，一般不用
    Scan2d::ConstPtr scan_ = nullptr;  // 激光扫描数据
    SE2 pose_;                    // 位姿，world to scan, T_w_c
    SE2 pose_submap_;             // 位姿，submap to scan, T_s_c
};
#endif //COMMOM_H
