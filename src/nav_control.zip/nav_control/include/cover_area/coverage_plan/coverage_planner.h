#ifndef COVERAGEPLANNER_H_
#define COVERAGEPLANNER_H_
#include <vector>
#include <iostream>
#include <math.h>

#include "opencv2/core/core.hpp"
#include "opencv2/highgui/highgui.hpp"
#include "opencv2/imgproc/imgproc.hpp"

#include <CGAL/Boolean_set_operations_2.h>
#include <CGAL/Surface_sweep_2_algorithms.h>
#include <CGAL/squared_distance_2.h>

#include "cgal_comm.h"
#include "decomposition.h"
#include "sweep.h"
#include "cover_area/common.h"
class MouseParams{
public:
    MouseParams(const cv::Mat& img_){
        img = img_.clone();
        point = Point_2(-1, -1);
    }
    Point_2 point;
    cv::Mat img;
};

class CellNode
{
public:
    CellNode()
    {
        isVisited = false;
        isCleaned = false;
        parentIndex = INT_MAX;
        cellIndex = INT_MAX;
    }
    bool isVisited;
    bool isCleaned;

    int parentIndex;
    std::deque<int> neighbor_indices;

    int cellIndex;
};

class CoveragePlanner
{
private:
    double raduis_;//机器人半径

public:
    std::vector<Vec2d> vec_path_;
    double totoal_areas_=0.0;
    CoveragePlanner(){};
    void plan(cv::Mat &img,int &raduis);
    void inflatePolygon(std::vector<cv::Point>& polygon, double l);
    static void onMouseHandle(int event, int x, int y, int flags, void* params);
    Point_2 getStartingPoint(cv::Mat& img);
    std::vector<CellNode> calculateDecompositionAdjacency(const std::vector<Polygon_2>& decompositions);
    // DFS
    void walkThroughGraph(std::vector<CellNode>& cell_graph, int cell_index, int& unvisited_counter, std::deque<CellNode>& path);

    std::deque<int> getTravellingPath(const std::vector<CellNode>& cell_graph, int first_cell_index);

    std::vector<std::map<int, std::list<Point_2 >>> calculateCellIntersections(std::vector<Polygon_2>& decompositions, std::vector<CellNode>& cell_graph);

    Point_2 findNextGoal(const Point_2& start, const Point_2& goal, const std::list<Point_2>& candidates);

    bool doReverseNextSweep(const Point_2& curr_point, const std::vector<Point_2>& next_sweep){
        return CGAL::to_double(CGAL::squared_distance(curr_point, next_sweep.front())) > CGAL::to_double(CGAL::squared_distance(curr_point, next_sweep.back()));
    };
    std::vector<Point_2> getShortestPath(const Polygon_2& polygon, const Point_2& start, const Point_2& goal){
        polygon_coverage_planning::visibility_graph::VisibilityGraph vis_graph(polygon);
        std::vector<Point_2> shortest_path;
        polygon_coverage_planning::calculateShortestPath(vis_graph, start, goal, &shortest_path);
        return shortest_path;
    };
    int getCellIndexOfPoint(const std::vector<Polygon_2>& decompositions, const Point_2& point){
        int index = -1;
        for(size_t i = 0; i < decompositions.size(); i++){
            if(polygon_coverage_planning::pointInPolygon(decompositions[i], point)){
                index = i;
                break;
            }
        }
        return index;
    };

};
#endif
