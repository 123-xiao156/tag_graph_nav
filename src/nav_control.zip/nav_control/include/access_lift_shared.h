//
// Created by iimt on 24-4-7.
//

#ifndef NAV_CONTROL_ACCESS_LIFT_SHARED_H
#define NAV_CONTROL_ACCESS_LIFT_SHARED_H
#include <QObject>
#include <glog/logging.h>
#include "shard_data.h"
#include "accesspoint_action.h"

class AccessLiftShared:public QObject {
    enum ProcessIndex{
        STEP0 = 0,
        STEP1,
        STEP2,
        STEP3,
        STEP4,
        STEP5,
        STEP6,
        STEP7,
        STEP8,
        STEP9,
        STEP10,
        STEP11,
        STEP12,
        STEP13,
        STEP14,
        STEP15,
        STEP16,
        STEP17,
        STEP18
    };
Q_OBJECT
public:
    PoseData lift_pose_;//精确控制的乘梯点
    AccessLiftShared(ros::NodeHandle nh);
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "access_lift_shared SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    void SetCmd(std::string cmd_type);
    bool thread_pause_flag_{true};//线程暂停执行，假暂停
//    void SetCmd(std::string cmd_type,PoseData pdata);
private:
    void PublishVoice(std::string name);
    double YawNormalize(double yaw);
    ros::Publisher pub_voice_;
    ros::NodeHandle nh_;
    ros::ServiceClient clear_costmap_client_, srv_database_;//清除障碍层
    std::shared_ptr<ShardData> p_shard_data_;
    int16_t interval_ms_;
    ProcessIndex process_index_{ProcessIndex::STEP0};
    PoseData currentMap_lift_point_;//当前地图的乘梯点
    PoseData goalMap_lift_point_;//目标地图的乘梯点
    PoseData goal_point_;
    bool need_lift_=false;//是否需要乘梯

    std::string car_type_;  //车子类型
    bool new_method_lift_{false};//是否使用新方式打乘梯点
    double new_method_lift_distance_;
    std::string nav_node_="";//导航节点名称
    void TimerThread(int16_t interval_ms);
    void MainLoop();
    std::mutex mtx_;
    void SendtoAccessAction(double sx,double sy,double gx,double gy);
    void SendtoLiftAction(double ax,double ay,double ayaw,std::string floornumber);

    // 20250716 c_add 添加乘梯成功后，检查是否代价地图切换完成
    ros::Subscriber sub_global_costmap_iimt_updates_, sub_only_static_costmap_iimt_updates_;
    void globalcostmapupdateCB(const geometry_msgs::PoseStamped& msg);
    void onlystaticcostmapupdateCB(const geometry_msgs::PoseStamped& msg);
    struct CostmapUpdateData
    {
        double x = 0.0;
        double y = 0.0;
        ros::Time stamp = ros::Time(0);
    };
    CostmapUpdateData globalcostmapupdatedata_;
    CostmapUpdateData onlystaticcostmapupdatedata_;
    CostmapUpdateData pre_costmapupdatedata_;
    ros::Time pre_stamp_;
    bool first_flag_{false};

    bool IsJson(std::string str,Json::Value& root)
    {
        Json::CharReaderBuilder builder;
        std::string errors;
        std::istringstream jsonStream(str);
        bool parsingSuccessful = Json::parseFromStream(builder, jsonStream, &root, &errors);
        if (parsingSuccessful) return true;
        return false;
    };
signals:
    void signal_MoveCmd(QVariant movecmd);
    void signal_toLiftAction(QString msg);
    void signal_toAccesssAction(QString msg);
    void signal_PubStatus(std::string status);
    void signal_AccurateControl(QVariant movecmd);//请求精确控制
private slots:
    void slot_NewCmd(QVariant movecmd);
    void slot_SetCmd(QVariant movecmd);

};


#endif //NAV_CONTROL_ACCESS_LIFT_SHARED_H
