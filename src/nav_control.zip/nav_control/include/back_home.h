#ifndef BACK_HOME_H
#define BACK_HOME_H

#include <QObject>
#include "shard_data.h"
#include "geometry_msgs/Pose2D.h"
#include <sensor_msgs/LaserScan.h>
#include "nav_msgs/OccupancyGrid.h"
#include <angles/angles.h>
#include <QFile>
#include <glog/logging.h>
#define WEB_FILE "/home/iimt/.cfg/controlmaster/controlmaster/param/yaml/web.yaml"

class BackHome:public QObject
{
    enum BackHomeIndex{
        STEP0 = 0,
        STEP1,
        STEP2,
        STEP3,
        STEP4,
        STEP5,
        STEP6,
        STEP7,
        STEP8,
        STEP9,
        STEP10,
        STEP11,
        STEP12
    };
    Q_OBJECT
public:
    BackHome(ros::NodeHandle nh);
    void MainLoop();
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "back_home SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    void ThreadPause(bool flag);
    bool thread_pause_flag_{true};//线程暂停执行，假暂停
    void SetCmd(std::string cmd_type);
    void SetCmd(std::string cmd_type,PoseData pdata);
private:
    ros::NodeHandle nh_;
    ros::ServiceClient clear_costmap_client_;
    BackHomeIndex process_index_{BackHomeIndex::STEP0};
    PoseData currentMap_lift_point_;
    PoseData back_point_;
    std::shared_ptr<ShardData> p_shard_data_; 
    int16_t interval_ms_;
    bool back_home_start_{false};
    std::mutex mtx_;
    void TimerThread(int16_t interval_ms);
    void SendtoLiftAction(double ax,double ay,double ayaw,std::string floornumber);
    void SendtoAccessAction(double ax,double ay,double ayaw,double sx,double sy,double gx,double gy);

    // 20230326 c_add
    nav_msgs::OccupancyGrid::ConstPtr global_costmap_data_;
    geometry_msgs::Pose2D sub_current_pose_;
    ros::ServiceClient client_originpoint_;
    ros::Publisher pub_cmd_vel_, pub_voice_;
    geometry_msgs::Twist angular_adjust_;
    geometry_msgs::Twist velocity_cmd_;
    std::string nav_node_="";//导航节点名称
    std::string ReadDefaultMap();
    void PublishVoice(std::string name);
    // 20230326 c_add

    std::string car_type_;  //车子类型
    // 20250902 c_add 添加乘梯功能关闭时返航选取当前地图返航点功能
    bool autolift_{false};
   std::string nav_yaml_path_;//导航参数文件路径
signals:
    void signal_MoveCmd(QVariant movecmd);
    void signal_AccessLiftCmd(QVariant movecmd);
    void signal_toLiftAction(QString msg);
    void signal_toAccesssAction(QString msg);
    void signal_AccurateControl(QVariant movecmd);//请求精确控制
    void signal_PubStatus(std::string status);
private slots:
    void slot_NewCmd(const QVariant movecmd);
};

#endif // BACK_HOME_H
