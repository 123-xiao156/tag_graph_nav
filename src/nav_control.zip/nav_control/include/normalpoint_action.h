#ifndef NORMALPOINT_ACTION_H
#define NORMALPOINT_ACTION_H

#include <QObject>
#include <glog/logging.h>
#include "shard_data.h"
class NormalpointAction:public QObject
{
        enum ProcessIndex{
        STEP0 = 0,
        STEP1,
        STEP2,
        STEP3,
        STEP4,
        STEP5,
        STEP6,
        STEP7,
        STEP8,
        STEP9,
        STEP10,
        STEP11
    };
    Q_OBJECT
public:
    NormalpointAction(ros::NodeHandle nh);
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "navtask_node;normalpoint_action SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    void SetCmd(std::string cmd_type);
    void SetCmd(std::string cmd_type,PoseData pdata);
    bool thread_pause_flag_{true};//线程暂停执行，假暂停
private:
    void PublishVoice(std::string name);

    std::string car_type_;  //车子类型

    ros::Publisher pub_voice_;
    ros::NodeHandle nh_;
    ros::ServiceClient clear_costmap_client_;//清除障碍层
    std::shared_ptr<ShardData> p_shard_data_;
    int16_t interval_ms_;
    ProcessIndex process_index_{ProcessIndex::STEP0};
    PoseData currentMap_lift_point_;
    PoseData goal_point_;
    int nav_=1;//导航算法
    void TimerThread(int16_t interval_ms);
    void MainLoop();
    std::mutex mtx_;
    void SendtoAccessAction(double ax,double ay,double ayaw,double sx,double sy,double gx,double gy);
    void SendtoLiftAction(double ax,double ay,double ayaw,std::string floornumber);
signals:
    void signal_MoveCmd(QVariant movecmd);
    void signal_AccessLiftCmd(QVariant movecmd);
    void signal_toLiftAction(QString msg);
    void signal_toAccesssAction(QString msg);
    //void signal_PubStatus(std::string status);
private slots:
    void slot_NewCmd(QVariant movecmd);
};

#endif // NORMALPOINT_ACTION_H
