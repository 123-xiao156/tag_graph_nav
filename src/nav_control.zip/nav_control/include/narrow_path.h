#ifndef NARROW_PATH_H
#define NARROW_PATH_H
/**
 * Copyright (c) 2023Jiangsu Jitri Intelligent Manufacturing Technology All rights reserved.
 * function: 202310 hela 窄区域路径规划
 * 
*/
#include <iostream>
#include <vector>
#include <glog/logging.h>
#include <visualization_msgs/MarkerArray.h>
#include <geometry_msgs/PolygonStamped.h>
#include <geometry_msgs/Polygon.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/Pose2D.h>
#include <nav_msgs/Path.h>
#include <tf/tf.h>
#include <tf/transform_listener.h>
#include <sensor_msgs/LaserScan.h>
#include <tf2/convert.h>
#include <tf2/transform_datatypes.h>
#include <tf2/utils.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf2_ros/buffer.h>
#include <ros/ros.h>
#include <angles/angles.h>
#include <nav_msgs/GetPlan.h>
#include "shard_data.h"

namespace narrow_path{

    struct Footprint
    {
        geometry_msgs::PoseStamped center;
        double radius;
    };
    enum Color {blue, red, green};
    struct CmdVelStr
      {
         double linear=0.0;
         double angular=0.0;
      };
    struct Point
    {
        double x;
        double y;
    };
class NarrowPath
{
private:

    ros::NodeHandle nh_;
    ros::Publisher footprint_pub_,real_footprint_pub_,ref_footprint_pub_,assist_point_pub_,cmd_vel_pub_,test_pub_;
    ros::Subscriber path_sub_,scan_sub_,sub_clicked_point_;
        ros::ServiceClient service_client_;
    double footprint_radius_;
    double robot_r_;
    double robot_radius_;
    double footprint_threshold_,forward_distance_;
    double detect_angle_;//闸机探测角度
    Point point_left_,point_right_;
    geometry_msgs::Pose2D assist_point_,current_pose_;
    char move_step_,vel_index_;
    double max_linear_velocity_,max_angular_velocity_,min_linear_velocity_,min_angular_velocity_;
    tf::TransformListener tf_listener_;
    tf::StampedTransform transform_base_link_to_laser_link_,transform_base_link_to_odom_;
    sensor_msgs::LaserScan test_msg;
    std::vector<geometry_msgs::Pose2D> clicked_points_;

    const nav_msgs::Path::ConstPtr global_path_ptr;
    nav_msgs::Path global_path_;
    std::string nav_node_="";//导航节点名称
    void PublishFootprint(std::vector<Footprint>& footprint,ros::Publisher& footprint_pub);
    void FootprintToMarker(Footprint& footprint, visualization_msgs::Marker& marker,unsigned int& i, Color marker_color);
    void PoseToPose2D(const geometry_msgs::Pose pose, geometry_msgs::Pose2D& pose2D)
    {
        // use tf-pkg to convert angles
        tf2::Transform pose_tf;
        // convert geometry_msgs::PoseStamped to tf2::Transform
        tf2::convert(pose, pose_tf); //msg类型转tf类型
        // now get Euler-Angles from pose_tf
        double useless_pitch, useless_roll, yaw;
        pose_tf.getBasis().getEulerYPR(yaw, useless_pitch, useless_roll);
        // normalize angle
        yaw = angles::normalize_angle(yaw);
        // and set to pose2D
        pose2D.x = pose.position.x;
        pose2D.y = pose.position.y;
        pose2D.theta = yaw;
    };
    void PathCallback(const nav_msgs::Path::ConstPtr& msg);
    void ShowRobotPath(const nav_msgs::Path& msg,double& radius);
    void ScanCallback(const sensor_msgs::LaserScan::ConstPtr& msg);
    //void CoordinateTransformation( source_pose, target_pose);
    double CalculateFootprint(const sensor_msgs::LaserScan::ConstPtr& msg,const geometry_msgs::Pose2D& pose);
    void PublishAssistPoints();
    void GetAssistPoint(const std::vector<Point>& point_cloud);
    bool MoveToGoal(const geometry_msgs::Pose2D& target_point,const geometry_msgs::Pose2D&  current_pose,CmdVelStr& vel,double threshold_dis=0.05,double threshold_angle=0.09);
    bool GoThroughAG(const geometry_msgs::Pose2D& target_point,double& distance,CmdVelStr& cmd_vel);
    void LaserScanToPoseList(const sensor_msgs::LaserScan::ConstPtr &scan_msg,std::vector<Point> &laser_points);
    double AngleDiff(double a, double b) 
    {
        double diff = angles::normalize_angle(b - a);
        diff=fabs(diff) > M_PI ?(diff>0?(diff- 2 * M_PI):(diff+ 2 * M_PI )):diff;
        return diff;
    };
    bool ListenTF(std::string target,std::string source,geometry_msgs::Pose2D& pose);
    void ClickedPointCallback(const geometry_msgs::PointStampedConstPtr& msg);
    void CameraToScanCB(const sensor_msgs::LaserScan::ConstPtr &msg);
    ros::Subscriber sub_camera_to_scan_;
    bool flg_obstacle_;//障碍物检测标志
    double judge_depth_;
    bool is_waiting_obstacle_;    // 是否正在等待障碍物清除
public:
    NarrowPath(ros::NodeHandle nh);
    ~NarrowPath();
    std::vector<Point> point_cloud_;
    void FollowPath(const std::vector<Point>& point_cloud,CmdVelStr& cmd_vel);
    void PublishVelocity(CmdVelStr data)
    {
        geometry_msgs::Twist msg;
        msg.angular.z = data.angular;
        msg.linear.x = data.linear;
        cmd_vel_pub_.publish(msg);
    };
    bool Control(CmdVelStr& cmd_vel, geometry_msgs::Pose2D& accessin, geometry_msgs::Pose2D& accessout);
    bool FollowPath(const geometry_msgs::Pose2D&  current_pose,CmdVelStr& cmd_vel);
    void GetPath(const geometry_msgs::Pose2D&  start,const geometry_msgs::Pose2D&  goal);
    bool HasObstacle() const { return flg_obstacle_; }
    bool IsWaitingObstacle() const { return is_waiting_obstacle_; }
    void SetWaitingObstacle(bool waiting) { is_waiting_obstacle_ = waiting; }
    // 获取障碍物检测距离阈值
    double GetJudgeDepth() const { return judge_depth_; }

};
}
#endif // NARROW_PATH_H
