//
// Created by iimt on 24-5-8.
//

#ifndef NAV_CONTROL_ACCURATE_CONTROL_H
#define NAV_CONTROL_ACCURATE_CONTROL_H
#include "shard_data.h"
#include <robot_msgs/JudgePose.h>
#include <glog/logging.h>
class AccurateControl:public QObject
{
    Q_OBJECT
public:
    AccurateControl(ros::NodeHandle nh);
    // 当返航点有障碍物时，一共有三种动作，是动作的索引（1.计算调整角度，并旋转至计算出来的角度 2.开始判断back点是否被占用，开始语音播报 3.当目标点不被占据时,开始向目标点运动）
    enum ControlStatus{
        INIT = 0,
        ADJUST_ANGLE,//收到乘梯命令//计算调整角度，并旋转至计算出来的角度
        VOICE,//开始判断back点是否被占用，开始语音播报
        MOVE_TO_AIM,//当目标点不被占据时,开始向目标点运动
        STEP4,//乘梯结束
        FAILED
    };
    ControlStatus control_status_;
    int first_adjust_angular_flag_ = 0;// 计算调整角度标志位，只需计算一次，就置为1，就不计算了，从而开始下一步，旋转至计算出来的角度
    PoseData aim_point_;
    void Init();
    void SetCmd(std::string cmd_type);
    void SetCmd(std::string cmd_type,PoseData pdata);
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "accurate_control SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    bool thread_pause_flag_{true};//线程暂停执行，假暂停
    void InitAccurateControl();
private:
    std::mutex mtx_;
    geometry_msgs::Twist velocity_cmd_;
    ros::Publisher pub_voice_;
    ros::Subscriber sub_costmap_;
    nav_msgs::OccupancyGrid::ConstPtr global_costmap_data_;
    int costmap_occu_flag_ = 0;
    bool costmap_refresh_ = 1;
    int wait_voice_flag_ = 0;
    ros::Publisher pub_cmd_vel_;//发布速度
    double modify_raw_ = 0.0;// 第一个动作计算出的调整角度
    geometry_msgs::Twist angular_adjust_;//发布的角度调整
    void MainLoop();
    int16_t interval_ms_;
    std::shared_ptr<ShardData> p_shard_data_;
    ros::NodeHandle nh_;

    std::string car_type_;  //车子类型
    double goto_back_dis_;//返航距离

    // 20250108 添加检查点的代价值
    ros::ServiceClient check_point_cost_client_;
    // 20250418 c_add 添加清空障碍层
    ros::ServiceClient clear_costmap_client_; // 清除障碍层
    std::string nav_node_="";//导航节点名称
    void TimerThread(int16_t interval_ms);
    void PublishVoice(std::string name);
    int Convert(double x, double y);
    bool CalculateVelocity(geometry_msgs::Twist& vel,const PoseData &currentPose, const PoseData& targetPose,double threshold_dis=0.05,double threshold_angle=0.09);
    double AngleDiff(double a, double b) {
        //double diff = fmod(angles::normalize_angle(b) - angles::normalize_angle(a) + M_PI, 2 * M_PI) - M_PI;
        double diff = angles::normalize_angle(b - a);
        diff=fabs(diff) > M_PI ?(diff>0?(diff- 2 * M_PI):(diff+ 2 * M_PI )):diff;
        return diff;
    };
    int vel_index_ = 0; // 速度控制索引
    signals:
    void signal_MoveCmd(QVariant movecmd);
    void signal_PubStatus(std::string status);
private slots:
    void slot_NewCmd(QVariant movecmd);
    void slot_SetCmd(QVariant movecmd);
};

#endif //NAV_CONTROL_ACCURATE_CONTROL_H
