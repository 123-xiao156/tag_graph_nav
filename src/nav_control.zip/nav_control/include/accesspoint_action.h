#ifndef ACCESSPOINT_ACTION_H
#define ACCESSPOINT_ACTION_H

#include <QObject>
#include "shard_data.h"
#include <nav_msgs/GetPlan.h>
#include <geometry_msgs/PoseStamped.h>
#include <boost/foreach.hpp>
#include <glog/logging.h>
#include "narrow_path.h"
#define forEach BOOST_FOREACH

class AccesspointAction : public QObject, public narrow_path::NarrowPath
{
    enum AccessProcessIndex
    {
        WAIT = 0,
        STEP1,
        STEP2,
        STEP3,
        STEP4,
        STEP5,
        STEP6,
        STEP7,
        STEP8,
        STEP9,
        STEP10,
        STEP11,
        STEP12,
        STEP13,
        STEP14,
        STEP15,
        STEP16
    };
    struct PointStruct
    {
        float x;
        float y;
        float yaw;
        int type;
        string map;
        PointStruct()
        {
            x = 0.0;
            y = 0.0;
            yaw = 0.0;
            map = "default";
        }
    };
    Q_OBJECT
public:
    std::string access_status_ = "";
    PoseData access_in_out_;
    ros::NodeHandle nh_;
    AccesspointAction(ros::NodeHandle nh);
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data)
    {
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "accesspoint_action SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };

    void SetCmd(std::string cmd_type, PoseData pdata);
    bool thread_pause_flag_{true}; // 线程暂停执行，假暂停
    void StartKeepDoorTimer();
    void StopKeepDoorTimer();
private:
    AccessProcessIndex access_index_{AccessProcessIndex::WAIT};
    void PublishVoice(std::string name);
    // 20240918 c_add 过门禁启用超声波避停
    ros::Publisher pub_voice_, pub_ultrasonic_avoidance_;
    bool start_ultrasonic_flag_ = false;
    // 20240918 c_add 过门禁启用超声波避停
    std::string GetFloorNo(std::string map_name);
    ros::ServiceClient client_access_;        // 门禁服务客户端
    ros::ServiceClient clear_costmap_client_; // 清除障碍层
    ros::Subscriber sub_running_result_;      // 订阅乘梯门禁话题
    ros::Publisher pub_access_gate_marker_; // 发布乘梯区域marker
    ros::Publisher pub_cmd_sensor_;     // 发布车辆状态
    std::mutex mtx_;
    ros::ServiceClient service_client_;
    float access_area_length_{1.5}; // 闸机区域长度
    float access_rrea_width_{0.8};  // 闸机区域宽度
    std::shared_ptr<ShardData> p_shard_data_;
    int16_t interval_ms_;
    bool in_access_area_flag_;       // 是否在闸机区域
    PointStruct rec_topleft_;        // 区域左上角
    PointStruct rec_topright_;       // 区域右上角
    PointStruct rec_bottomleft_;     // 区域左下角
    PointStruct rec_bottomright_;    // 区域右下角
    PointStruct rec_mid_left_;       // 区域左中
    PointStruct rec_mid_right_;      // 区域中
    PointStruct rec_top_access_;     // 上面的乘梯点(梯点上方的点)
    PointStruct rec_bottom_access_;  // 下面的乘梯点(梯点下方的点)
    PointStruct p_in_first_;         //
    PointStruct access_point_;       // 门禁点
    PointStruct access_in_;          // 门禁区域入口点(开门禁点)
    PointStruct access_out_;         // 门禁区域出口点(释放门禁点)
    PointStruct start_point_;        // 规划起始点
    PointStruct goal_point_;         // 目标点
    float access_length_;            // 门禁区域设置的长度
    float access_width_;             // 门禁区域设置的宽度
    bool in_bottom_area_ = false;    // 是否在区划区域的下半部分
    bool in_top_area_ = false;       // 是否在区划区域的上半部分
    std::string running_state_ = ""; // 乘梯的运行状态

    std::string car_type_; // 车子类型

    float access_open_time_;//门禁闸机开门等待时间
    std::string nav_node_="";//导航节点名称
    geometry_msgs::Point AddPointToMarker(double x, double y);
    void callback_ElevatorResult(const std_msgs::String::ConstPtr &msg);
    void MainLoop();
    bool CheckPathPassesThroughGate(PointStruct p_start, PointStruct p_goal);
    void GetInpointAndOutpoint(const float length, const PointStruct pt, const PointStruct p, PointStruct &in_point, PointStruct &out_point);
    std::vector<PointStruct> GetAccessArea4Point(const double length, const double width, const PointStruct p);
    PointStruct movePointAlongYaw(double x, double y, double yaw, double l);
    bool IsPointInMatrix(PointStruct &p);
    bool IsPointInTopMatrix(PointStruct &p, std::vector<PointStruct> &points);
    bool IsPointInBottomMatrix(PointStruct &p, std::vector<PointStruct> &points);
    void SetVehicleStatus(const std::string& new_status);
    // 计算向量叉积，判断点P相对于向量P1P2的位置关系，正值点位于向量逆时针方向，负值点位于向量顺时针方向，0点位于向量上
    float GetCross(PointStruct &p1, PointStruct &p2, PointStruct &p)
    {
        return (p2.x - p1.x) * (p.y - p1.y) - (p.x - p1.x) * (p2.y - p1.y);
    };
    void TimerThread(int16_t interval_ms);
    int CallPlanningService(ros::ServiceClient &service_client, nav_msgs::GetPlan &srv, std::vector<std::vector<PointStruct>> &all_area_points);
    // 发送目标运动位姿到move action线程的接口函数
    void SendCmd(TaskStatus ts_type, double x, double y, double yaw, GlobalPlannerType gpt);
    double YawNormalize(double yaw);

    // 获取传来的位置点
    PointStruct rec_current_pose_, rec_goal_pose_;

    std::vector<PoseData> check_access_points_;
    std::vector<PoseData> sort_access_points_;
    // 各个门禁闸机区域相关点
    std::vector<std::vector<PointStruct>> all_area_points_;
    std::vector<std::vector<PointStruct>> sort_area_points_;
    //检测障碍物相关参数
    ros::Timer keep_door_timer_;           // 保持门禁开启的定时器
    ros::Time last_keep_door_time_;        // 上次发送开门命令的时间
    void KeepDoorOpenCallback(const ros::TimerEvent&);
    float access_open_time_interval_;//遇到障碍物间隔20s后重新发长开门命令
private slots:
    void slot_NewCmd(const QVariant movecmd); // 接收API新指令的回调函数
    void slot_NewTask(const QString ntask);   // 接收新指令的回调函数
signals:
    void signal_PubStatus(std::string status);
    void signal_MoveCmd(QVariant movecmd);         // 与move action连接的信号函数
    void signal_AccurateControl(QVariant movecmd); // 请求精确控制
};

#endif // ACCESSPOINT_ACTION_H
