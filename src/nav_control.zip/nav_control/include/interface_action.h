#ifndef INTERFACECLASS_H
#define INTERFACECLASS_H

#include <QObject>
#include <glog/logging.h>
#include "shard_data.h"
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QJsonValue>

class InterfaceAction : public QObject
{
    Q_OBJECT
public:
    InterfaceAction(ros::NodeHandle nh);
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data)
    {
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "interface_action SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };

private:
    ros::NodeHandle nh_;
    std::shared_ptr<ShardData> p_shard_data_;
    ros::ServiceServer api_service_;
    ros::Publisher pub_voice_;
    int16_t interval_ms_;
    // 20250902 c_add 添加乘梯功能关闭时检查当前地图与指令地图是否匹配 
    bool autolift_{false};
    ros::ServiceClient path_query_client;//示教路径服务回调

    bool callback_ApiService(robot_msgs::Move::Request &request, robot_msgs::Move::Response &response);
    void TimerThread(int16_t interval_ms);
    void SendCmd(TaskStatus ts_type);
    void PublishVoice(std::string name);
signals:
    void signal_MoveCmd(QVariant movecmd); // 发送API指令信号函数
    void signal_PubStatus(std::string status);
private slots:
    void slot_PubVoice(std::string name);
};

#endif // INTERFACECLASS_H
