/*********************************************************************
*
* Software License Agreement (BSD License)
*
* Copyright（c） 2024 jiangsu Jitri Interlligent Manufacturing Technology 
* All rights reserved.
*
* brief:
* version: 1.0
* author: wangyong
* date:20240104
*********************************************************************/
#include <iostream>
#include <unordered_map>
#define faultcode_filepath = "/iimt/home/.cfg/controlmaster/faultcode.yaml"
class FaultCode{
public:
    FaultCode();
    void ReadFaultCode(){

    };
    std::string FaultCodeIndex(int16_t index){
        return faultcode_[index];
    };
private:
    std::unordered_map<int16_t,std::string> faultcode_;
};