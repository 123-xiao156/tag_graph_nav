#ifndef LIFTPOINT_ACTION_H
#define LIFTPOINT_ACTION_H

#include <QObject>
#include <glog/logging.h>
#include "shard_data.h"
class LiftpointAction:public QObject
{
    Q_OBJECT
public:
    /*乘梯运行状态*/
    enum LiftStatus{
        INIT = 0,
        STEP1,//收到乘梯命令
        STEP2,//前往乘梯点
        STEP3,//开始乘梯
        STEP4,//乘梯结束
        FAILED
    };

    LiftpointAction(ros::NodeHandle nh);
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "navtask_node;liftpoint_action SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    void SetCmd(std::string cmd_type);
    void SetCmd(std::string cmd_type,PoseData pdata);
private:
    // bool lift_cancel_=false;//乘梯中收到导航取消命令
    bool lift_stop_=false;//乘梯中收到导航暂停命令
    ros::ServiceClient client_elevator_;//门禁服务客户端
    ros::Subscriber sub_running_result_;//订阅乘梯门禁话题
    ros::NodeHandle nh_;
    std::shared_ptr<ShardData> p_shard_data_;
    int16_t interval_ms_;
    LiftStatus lift_status_;
    std::string floor_number_;
    PoseData goal_point_;
    void TimerThread(int16_t interval_ms);
    void MainLoop();
    std::mutex mtx_;
    bool thread_pause_flag_{true};//线程暂停执行，假暂停
    double YawNormalize(double yaw);
    std::string GetFloorNo(std::string map_name);
    std::string running_state_="";//乘梯的运行状态
    void callback_ElevatorResult(const std_msgs::String::ConstPtr &msg);
signals:
    void signal_MoveCmd(QVariant movecmd);
    void signal_PubStatus(std::string status);
private slots:
    void slot_NewCmd(const QVariant movecmd);
    void slot_NewTask(const QString ntask);
};

#endif // LIFTPOINT_ACTION_H
