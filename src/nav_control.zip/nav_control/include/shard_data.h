#ifndef SHARD_DATA_H
#define SHARD_DATA_H

#include <QObject>
#include <QVariant>
#include <QMetaType>
#include <QJsonDocument>
#include <QJsonObject>
#include <QDebug>
#include <unordered_map>
#include <queue>
#include <vector>
#include <math.h>
#include <QTime>
#include <QTimer>
#include <jsoncpp/json/json.h>
#include <std_srvs/Empty.h>
#include "actionlib/client/simple_action_client.h"
#include "actionlib/server/simple_action_server.h"
#include "move_base_msgs/MoveBaseAction.h"
#include "move_base_msgs/MoveBaseGoal.h"
#include <tf/transform_listener.h>
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <nav_msgs/Odometry.h>
#include <std_msgs/String.h>
#include "robot_msgs/ElevatorPoint.h"
#include <robot_msgs/MoveToGoalAction.h> 
#include "robot_msgs/testInfo.h"
#include "robot_msgs/elevatorResult.h"
#include "robot_msgs/LiftPoint.h"
#include "robot_msgs/Elevator.h"
#include "robot_msgs/Point.h"
#include "robot_msgs/DataBase.h"
#include "robot_msgs/Database_data.h"
#include "robot_msgs/Move.h"
#include "robot_msgs/Voice.h"
#include "robot_msgs/GetPlanService.h"
#include <mutex>
#include <thread>
#include "nav_msgs/OccupancyGrid.h"
#include <angles/angles.h>
#include <sensor_msgs/LaserScan.h>
#include <tf2_ros/transform_listener.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include "geometry_msgs/Pose2D.h"
#include "robot_msgs/Cmd.h"
#include "yaml-cpp/yaml.h"
#include <atomic>
#include <glog/logging.h>
using std::string;


struct FaultCodePub{
    bool B0410;//请求的路点为空或不存在
    bool B0411;//请求的地图或其对应的表格不存在
    bool B0412;//move_action的action启动失败
    bool B0413;//规划不出路径,回原点失败
    bool B0414;//规划不出路径,发送下一个路点
    bool B0415;//原点坐标是无效数据
    bool B0416;//不能找到楼层号
    bool B0417;//无法获取返航点
    bool B0418;//无法找到乘梯点
    bool B0419;//发布的点类型不匹配
    bool B0601;//请求乘梯失败
    bool B0602;//导航失败，停止导航
    bool B0603;//路点格式错误
    bool B0604;//分发路点时，队列为空
    bool B0605;//目标楼层与乘梯的楼层不一致
    bool B0606;//乘梯状态返回FAULT
    bool B0607;//数据解析失败
    bool B0490;//未查询到当前地图楼层号
    bool B0491;//未查询到目标地图楼层号
    bool B0492;//未查询到device内容
    bool B0493;//查询到device内容不是json格式
    bool B0494;//查询到device内容不是json的数组格式
    bool B0495;//没有找到当前楼层和目标楼层与之对应的乘梯点
    bool B0496;//需要乘梯，无法找到当前地图的乘梯点
    bool B0497;//需要乘梯，无法找到目标地图的乘梯点
    bool B0498;//不需要乘梯，无法导航到其他地图上的点
    FaultCodePub(){
        B0410=false;
        B0411=false;
        B0412=false;
        B0413=false;
        B0414=false;
        B0415=false;
        B0416=false;
        B0417=false;
        B0418=false;
        B0419=false;
        B0601=false;
        B0602=false;
        B0604=false;
        B0605=false;
        B0606=false;
        B0607=false;
        B0490=false;
        B0491=false;
        B0492=false;
        B0493=false;
        B0494=false;
        B0495=false;
        B0496=false;
        B0497=false;
        B0498=false;
    }

};
//故障码枚举类型定义
enum FaultCode{
    U0412,
    U0413,
    U0414,//目标不存在
    B0416,//通过地图名获取楼层号失败
    UKONW_ERROR, //未知错误
    TRUE,
    FALSE
};
enum DB_Type{
    EXECL_NAME = 0,   //返回数据库列表单
    EXECL_SAVE = 1,   //保持数据库表单数据
    EXECL_DELETE = 2, //删除数据库指定表单
    EXECL_CHANGE = 3, //修改数据库表单内容
    EXECL_READ = 4    //获取数据库指定表单数据
};
enum AccessStatus{None,RUN,OK,NEW};
//目标点运动状态枚举类型
enum MoveStatus{IDLE=0,ACTIVATION,RUNNING,ARRIVE,ESTOP,CANCEL,FAULT,ABORTED};
enum MoveCmdStatus{NEWMARKET_TASK=0,NEWLOCATION_TASK,TASK_STOP,TASK_GOON,TASK_CANCEL,BACK,NONE};//api接口收到的指令类型
//目标点运动状态枚举类型
enum TaskStatus{//navgation to movebase//interface to navgation
    T_IDLE = 0,//没有任务
    T_MARKET,  //新任务 路点代号
    T_LOCALE,  //坐标数据
    T_RUNNING, //任务正在运行
    T_END,     //任务完成
    T_ESTOP,   //普通暂停
    T_GOON,    //普通继续
    T_CANCEL,  //任务取消
    T_BACK,    //执行回家
    T_FAULT,    //任务执行过程中出现故障
    T_TASK_ESTOP,//专用于任务的暂停
    T_TASK_GOON,//专用于任务的继续
    T_PATH, //示教路径
    C_PATH //覆盖路径
};
//导航系统状态
enum NavStatus{
    NAV_IDLE = 0,//导航空闲
    NAV_RUN,//正在执行目标点
    NAV_SUCCESS,//目标成功到达
    NAV_ABORTED,//目标点丢弃
    NAV_FAILED,//目标执行失败，致命错误。导航全部中止
    NAV_STOP//目标暂停执行
};
enum GlobalPlannerType
{
    NORMAL = 0,//普通点
    NARROW = 1,//狭窄
    EDGE_CLEAN = 2,//贴边点
    TWO_POINTS_CLEAN = 3,//两点直线
    NO_YAW = 4,//没有方向
    NARROW_NO_YAW = 5,//狭窄没有方向
    EDGE_CLEAN_NO_YAW = 6,//贴边点没有方向
    COVERAGE=7, //覆盖
    FIX_PATH=8, //示教路径
    COVER_PATH=9
};
enum ResumeStatus {
    RESUME_IDLE = 0,      // 空闲状态
    RESUME_PAUSED,        // 已暂停
    RESUME_BACK_HOME,     // 正在返航
    RESUME_WAITING,       // 等待恢复
    RESUME_CONTINUE       // 正在恢复
};
/*位置信息结构体*/
struct PoseData
{
    float x;
    float y;
    float yaw;
    int type;
    string point_name;
    string map;
    std::string path_map;     // 路径所在的地图
    std::string path_name;    // 路径名称
    std::string path_task;    // 路径任务
    PoseData(){
        x = 0.0;
        y = 0.0;
        yaw = 0.0;
        point_name = "specified_point";
        map = "default";
    }
};
Q_DECLARE_METATYPE(PoseData);
/***覆盖任务进展统计 */
struct NavProgress
{
    PoseData current_pose;//当前机器人位置
    float total_areas=0.;//规划总面积
    float total_cleaned_areas;//存储累计清洁面积
    float last_areas=0.;//剩余的面积
    unsigned int num_areas=0;//区域数量
    unsigned int current_index=0;//当前区域索引
    std::string current_area_name;//当前区域名称
    double total_time;//需要的时间，预计完成时间
    std::string actual_time;//已使用时间 
    std::string nav_status;//导航状态
    double total_length;//总长度
    double dis_to_end;//剩余长度
};
/*路点信息结构体*/
struct PointInfo
{
    string point_name;
    string point_map;
    string point_type;//access
    string point_task;

    std::vector<PoseData> point_array;

    string point_action;//open_door,close_door
    string lora_addr;//lora通讯地址,乘梯，门禁，闸机需要绑定

    PointInfo(){
        point_name = "specified_point";
        point_map = "test_map";
        point_type = "test_type";
        point_action = "test_action";
        lora_addr = "ox0010";
    };
};
//
struct CoverTeachArea
{
    string point_name;
    string point_map;
    string point_type;//access
    std::vector<PoseData> path_points;  // 路径点数组
    double path_length = 0.0;//路径长度
};
//添加当前路径信息
struct CurrentPathInfo {
    std::string point_name;
    std::string point_type;
    double path_length;      // 路径总长度
    double path_area;        // 路径总面积
    bool is_calculated;      // 是否已计算
};
//API收到的数据类型定义
struct ApiPointInfo
{
    string point_name;
    string point_map;
    string point_type;//market or location 
    //string point_task;

    double x=0.0;
    double y=0.0;
    double yaw=0.0;
    //ApiPointInfo(string point_name,string point_map,string point_type,string point_task,double x,double y ,double yaw){
    ApiPointInfo(string point_name,string point_map,string point_type,double x,double y ,double yaw){
        this->point_name = point_name;
        this->point_map = point_map;
        this->point_type = point_type;
        //this->point_task = point_task;
        this->x = x;
        this->y = y;
        this->yaw = yaw;
    };
};
//API收到的数据类型定义
struct NomalPoint
{

    double x=0.0;
    double y=0.0;
    double yaw=0.0;
    NomalPoint(){
        x=0.0;
        y=0.0;
        yaw=0.0;
    };
};
//闸机点执行数据交换主体
struct GateDataInfo{
    PoseData access_point_; //闸机点，需要执行穿越闸机时将该点赋值
    PoseData start_point_; //起点，当前位姿
    PoseData goal_point_;  //终点，目的地
    AccessStatus access_runing_status_;//闸机点执行状态
};
//单点数据结构体
struct NavPointStatus{
    NavStatus goal_status=NavStatus::NAV_IDLE;
    PoseData goal;
};
typedef struct _MoveDataCmd{
    //std::string cmd_type;
    TaskStatus taskcmd_type;
    std::vector<PoseData> goal;
}MoveDataCmd;
struct CmdVelStr
{
    double linear=0.0;
    double angular=0.0;
};
//暂停路径信息结构体
struct PausedPathInfo
{
    PointInfo point_info;           // 路径信息
    std::vector<PoseData> original_points;  // 原始路径点
    std::vector<PoseData> remaining_points; // 剩余未清扫的点
    double remaining_length;        // 剩余长度（米）
    double completed_ratio;         // 已完成比例（0-1）
    double completed_area;          // 已完成面积（m²）
    bool is_multi_path;             // 是否是多路径模式
    std::queue<CoverTeachArea> remaining_paths; // 剩余的路径队列
    size_t current_path_index;      // 当前路径索引（多路径时使用）
    
    // 基于数据库路径点ID的暂停信息
    size_t paused_point_id;          // 暂停时的路径点ID（数据库中的索引）
    bool has_paused_point_id;        // 是否有保存的暂停点ID
    double paused_pose_x;            // 暂停时的X坐标
    double paused_pose_y;            // 暂停时的Y坐标
    
    PausedPathInfo() 
        : remaining_length(0.0), 
          completed_ratio(0.0), 
          completed_area(0.0),
          is_multi_path(false),
          current_path_index(0),
          paused_point_id(0),
          has_paused_point_id(false),
          paused_pose_x(0.0),
          paused_pose_y(0.0)
    {}
};
// 漏扫路段信息
struct MissedSegment
{
    int start_id;               // 起始路径点ID
    int end_id;                 // 结束路径点ID
    double start_dis;           // 障碍物出现前的剩余距离
    double end_dis;             // 障碍物消失后的剩余距离
    std::vector<PoseData> segment_points;  // 该路段的路径点
    double segment_length;      // 路段长度
    int occurrence_index;       // 第几次出现漏扫
    
    MissedSegment() 
        : start_id(-1), end_id(-1), start_dis(-1), end_dis(-1), 
          segment_length(0.0), occurrence_index(0) {}
};
// 单条覆盖路径的补扫信息
struct CoverPathRescanInfo
{
    std::string path_name;                      // 原始路径名
    std::string path_map;                       // 地图名
    std::string rescan_path_name;               // 补扫路径名（原始名+_rescan）
    std::vector<MissedSegment> missed_segments; // 所有漏扫路段
    std::vector<PoseData> all_rescan_points;    // 合并后的所有补扫点
    double rescan_length;                       // 补扫总长度
    bool need_rescan;                           // 是否需要补扫
    bool rescan_completed;                      // 补扫是否已完成
    int obstacle_encounter_count;               // 遇到障碍物的次数
    bool rescan_inserted;                      // 补扫任务是否已插入队列
    
    CoverPathRescanInfo() 
        : rescan_length(0.0), need_rescan(false), 
          rescan_completed(false), obstacle_encounter_count(0) {}
    
    void Clear() {
        path_name.clear();
        path_map.clear();
        rescan_path_name.clear();
        missed_segments.clear();
        all_rescan_points.clear();
        rescan_length = 0.0;
        need_rescan = false;
        rescan_completed = false;
        obstacle_encounter_count = 0;
        rescan_inserted = false;
    }
};
// struct Point
// {
//     double x;
//     double y;
// };
Q_DECLARE_METATYPE(MoveDataCmd);// 声明了一个 Qt 类型，使得 MoveDataCmd 类型能够被用于 Qt 元对象系统（Meta-Object System）中，从而支持诸如信号和槽、属性系统等。

typedef std::unordered_map<std::string,std::vector<PointInfo>> umap;
typedef std::vector<std::string> Tokens;


class ShardData:public QObject
{
    Q_OBJECT
public:
    std::mutex share_data_mutex; //共享数据锁
//    bool backhonme_thread_pause_flag_=true;
    ros::Subscriber sub_robot_pose_;
    ros::Subscriber sub_laser_;
    void callback_RobotPosepose(const geometry_msgs::Pose msg);
    int nav_resend_time_=51;
    std::string new_of_old_database_="old";
    void InitAccurateControl();
    double target_distance_ = 0.0;//精确控制时与目标点的距离
    QTimer *timer_;
    ros::NodeHandle nh_;
    geometry_msgs::Twist angular_adjust_;//发布的角度调整
    void callback_RobotLaser(const sensor_msgs::LaserScan::ConstPtr &msg);
    bool task_cancel_during_lift_ = false;    // 乘梯过程中是否有任务被取消
    // 添加路径向量 - 用于存储示教路径名称
    std::vector<std::string> api_recved_path_vector_;
    std::vector<std::string> api_recved_cpath_vector_;
    bool is_teach_path_start_=false;
    bool is_teach_path_end_=false;
    bool is_cover_path_start_=false;
    bool is_cover_path_end_=false;



    ShardData();
    std::string current_map_;//现在的地图
    std::string now_nav_status_;//现在的发布的导航状态
    bool debug_=true;
    FaultCodePub fault_code_;
    //map列表,第一个参数是地图名，第二个是列表名
    std::unordered_map<std::string,std::string> maplist_;
    umap waypoint_list_; //路点列表
    std::vector<ApiPointInfo> api_recved_target_vector_;
    NomalPoint location_point_;//lication存储的单点信息
    bool robot_isHome_flag{false};//机器人是否在原点标记，true,在；false,不在
    /*********backhome相关数据定义****************/
    bool back_home_success_{false};
    std::queue<PointInfo> allarea_queue_;//请求所有面积的队列
    std::queue<CoverTeachArea> cover_teach_area_queue_;//请求所有面积的队列
    CurrentPathInfo current_path_info_;
    float clean_area_;//清洁面积
    float cover_clean_area_;//覆盖路径清洁面积
    float teach_clean_area_;//示教路径清洁面积

    /************move_action相关数据定义************/
    PoseData move_point_;//移动点，需要move_action执行的点。
    //MoveStatus move_status_;//目标点执行状态
    std::atomic<MoveStatus> move_status_{MoveStatus::IDLE};
    /*********normalpoint_action服务器接口数据定义****************/
   
    /******************navcontrol向其他线程下发指令接口定义************************/
    PointInfo access_point_;                //闸机点，需要执行穿越闸机时将该点赋值
    GateDataInfo gate_data_;
    PoseData lift_point_;                   //成梯点，需要执行成梯时将该点赋值
    std::string target_floor_number_;       //成梯的目标楼层
    NavPointStatus normalpoint_nav_status_;      //normalpoint_action服务器接口数据定义 成功到达 或丢弃
    NavPointStatus coverpoint_nav_status_;      //cover_action服务器接口数据定义 成功到达 或丢弃
    NavPointStatus backpoint_nav_status_;      //back_action服务器接口数据定义 成功到达 或丢弃
    NavPointStatus access_nav_status_;         //门禁状态 成功到达 或丢弃
    NavPointStatus access_lift_shared_nav_status_;         //门禁与乘梯最终状态 成功到达 或丢弃
    NavPointStatus accurate_control_nav_status_;         //精确导航控制状态 成功到达 或丢弃
    NavPointStatus lift_nav_status_;         //乘梯最终状态 成功到达 或丢弃
    NavPointStatus teachingpath_nav_status_;//示教路径最终状态
    NavPointStatus coverpath_nav_status_;//覆盖路径最终状态
    bool at_start_{false};
    bool at_end_{false};
    bool teach_fault_{false};
    bool cover_fault_{false};
    bool teach_success_{false};
    bool cover_success_{false};
    bool is_path_over_{false}; 

    // 暂停路径队列 
    std::queue<PausedPathInfo> paused_path_queue_;
    std::mutex paused_queue_mutex_;//暂停队列
    // 暂停路径信息 
    PausedPathInfo paused_path_info_;
    bool has_paused_path_ = false;
    std::mutex paused_path_mutex_; 
    // 当前路径的原始点（用于恢复时重新计算）
    std::vector<PoseData> current_original_path_points_;
    ResumeStatus resume_status_ = RESUME_IDLE;    // 中断续扫状态
    bool waiting_for_resume_ = false;             // 等待恢复标志
    std::string resume_path_type_;                // 需要恢复的路径类型
    std::string resume_path_name_;                // 需要恢复的路径名称

    std::queue<PointInfo> original_task_queue_;   // 原始完整任务队列
    std::mutex original_task_mutex_;              // 原始任务队列互斥锁
    bool has_original_task_queue_ = false;        // 是否有保存的原始任务队列
    std::string curr_lift_point_name_;
    std::string curr_lift_point_type_;
    bool skip_all_rescan_after_resume_{false};  // 续扫后跳过所有后续补扫
    //std::queue<PausedPathInfo> paused_history_queue_;
//    NavPointStatus backpoint_nav_status_;      //back_action服务器接口数据定义 成功到达 或丢弃
    // 补扫相关 - 支持多条覆盖路径
    std::map<std::string, CoverPathRescanInfo> cover_path_rescan_map_;  // 路径名 -> 补扫信息
    std::queue<std::string> pending_rescan_queue_;                      // 待补扫的路径名队列
    std::mutex rescan_mutex_;                                           // 补扫数据锁
    bool is_executing_rescan_ = false;                                  // 是否正在执行补扫
    std::string current_rescan_path_name_;                              // 当前正在补扫的路径名

    // 当前覆盖路径的实时监控数据（临时）
    struct CurrentCoverMonitorData {
        double last_valid_dis_to_end = -1;
        int consecutive_invalid_count = 0;
        bool is_in_obstacle = false;
        int obstacle_encounter_count = 0;
        std::string current_path_name;
        
        void Reset() {
            last_valid_dis_to_end = -1;
            consecutive_invalid_count = 0;
            is_in_obstacle = false;
            obstacle_encounter_count = 0;
            current_path_name.clear();
        }
    } cover_monitor_data_;
    /**************其他数据******************/
    PoseData current_pose_;//机器人当前位置
    float closest_obstacle_distance_=1000.0;//激光雷达检测到的障碍物的最小距离
    MoveCmdStatus move_cmd_;//api接口收到的指令类型
    string default_map_;//默认地图，系统开机加载的地图，机器人充电桩部署所在地图，机器人返回时的地图
    bool battry_low{false};  //电量低
    bool cable_charge{false};//手动充电,线缆连接充电

    bool update_waypointlist_flag{false};//是否需要更新路点列表，true：数据库立即更新，false:数据库不需要更新

    // 20240702 c_add 乘梯状态时接收指令确保地图没问题
    bool current_lift_state_{false};
    bool continue_state_{false};
    PointInfo pending_back_point_;//待执行返航点
    std::string storage_cmd_type;
    PoseData storage_pdata;
    bool current_lift_state_flag_{false};
    bool lift_cancel_=false;//乘梯中收到导航取消命令
    // 20240702 c_add 乘梯状态时接收指令确保地图没问题
    NavProgress nav_progress_;//20251111导航进度

    // 使用 std::pair 来表示点
    typedef std::pair<int, int> Point;
    // 计算多边形的面积
    double PolygonArea(const std::vector<Point>& points) {
        int n = points.size();
        double area = 0.0;

        // 计算所有顶点的交叉乘积的总和
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n; // 循环回到第一个点
            area += points[i].first * points[j].second;
            area -= points[j].first * points[i].second;
        }

        // 取绝对值并除以2
        return std::abs(area) / 2.0;
    }

    //返回当前设备正在使用的地图名称
    string GetCurrentMap(){
        // 加锁
        std::unique_lock<std::mutex> locker(share_data_mutex);

        return current_map_;
    };
    //获取当前地图集的返回点(充电桩点)
    FaultCode GetBackPoint(PoseData& back_point){
        // 加锁
        std::unique_lock<std::mutex> locker(share_data_mutex);

        //通过地图找到对应的路点容器，在通过marke标记查找具体的信息
        if(default_map_=="")
            return FaultCode::FALSE;
        auto it = waypoint_list_.find(default_map_);
        if(it != waypoint_list_.end()){

            locker.unlock();

            auto vt = it->second;
            auto tt = vt.begin();
            while (tt != vt.end())
            {
                if((*tt).point_type == "origin"){
                    back_point.x = (*tt).point_array[0].x;
                    back_point.y = (*tt).point_array[0].y;
                    back_point.yaw = (*tt).point_array[0].yaw;
                    back_point.map= (*tt).point_array[0].map;
                    return FaultCode::TRUE;
                }
                *tt++;
            }
        }
        return FaultCode::FALSE;
    };
    //获取乘梯点
    FaultCode GetLiftPoint(std::string map_name,std::string point_name,PoseData& lift_point){
        // 加锁
        std::unique_lock<std::mutex> locker(share_data_mutex);

        //通过地图找到对应的路点容器，在通过marke标记查找具体的信息
        auto it = waypoint_list_.find(map_name);
        if(it != waypoint_list_.end()){

            locker.unlock();

            auto vt = it->second;
            auto tt = vt.begin();
            while (tt != vt.end())
            {
                if((*tt).point_type == "lift" && (*tt).point_name == point_name){
                    lift_point.x = (*tt).point_array[0].x;
                    lift_point.y = (*tt).point_array[0].y;
                    lift_point.yaw = (*tt).point_array[0].yaw;
                    lift_point.map= map_name;
                    return FaultCode::TRUE;
                }
                *tt++;
            }
        }
        return FaultCode::FALSE;
    };
    //获取门禁点
    FaultCode GetAccessPoint(std::string map_name,std::vector<PoseData>& access_points){
        // 加锁
        std::unique_lock<std::mutex> locker(share_data_mutex);

        //通过地图找到对应的路点容器，在通过marke标记查找具体的信息
        auto it = waypoint_list_.find(map_name);
        if(it != waypoint_list_.end()){

            locker.unlock();

            auto vt = it->second;
            auto tt = vt.begin();
            while (tt != vt.end())
            {
                PoseData access_point;
                if((*tt).point_type == "access"){
                    access_point.x = (*tt).point_array[0].x;
                    access_point.y = (*tt).point_array[0].y;
                    access_point.yaw = (*tt).point_array[0].yaw;
                    access_point.map = (*tt).point_array[0].map;
                    access_point.point_name = (*tt).point_name;
                    access_points.push_back(access_point);
                }
                *tt++;
            }
        }
        if (access_points.size() > 0)
        {
            return FaultCode::TRUE;
        }
        else
        {
            return FaultCode::FALSE;
        }
    };
    /**
     * @brief 获取楼层号
     * @param[in] data 地图名
     * @author wangyong 20231115
     * @return 楼层号
     */
    FaultCode GetFloorNumber(std::string map_name,std::string& floor_num)
    {
        // 加锁
        std::unique_lock<std::mutex> locker(share_data_mutex);

        floor_num = "0F";
        char split_c = '_';
        std::vector<std::string> str_results;
        
        if (map_name == ""){
            //std::cout << "error : str is null" << std::endl;
            return FaultCode::B0416;
        }
        str_results = split(map_name,split_c);

        if(str_results.size() > 2) 
        {
            floor_num = str_results[2].substr(0, str_results[2].length() - 1);
            //std::cout << "floor num : " << floor_num <<std::endl;        
            return FaultCode::TRUE;
        } else {
            return FaultCode::B0416;;
        }
    }
    //计算两个坐标点的距离
    double GetDistance(double x1,double y1,double x2,double y2){
        double dis_err = 0.0;
        double deta_x = std::pow(x2-x1,2);
        double deta_y = std::pow(y2-y1,2);
        dis_err = std::sqrt(deta_x+deta_y);
        return dis_err;
    };
    //设置当前地图名称
    void SetCurrentMap(const std::string map){
        // 加锁
        std::unique_lock<std::mutex> locker(share_data_mutex);

        current_map_ =  map;
    };
    //
    void SetRobotPose(const PoseData pose)
    {
        // 加锁
        std::unique_lock<std::mutex> locker(share_data_mutex);

        current_pose_ = pose;
    }
    /**
     * @brief 字符串分割
     * @param[in] data 被分割字符串，分割符
     * @author wangyong 20231115
     * @return 分割完成的字符容器
     */
    Tokens split(const string & tokenstring, char delimiter)
    {
        Tokens tokens;

        size_t current_pos = 0;
        size_t pos = 0;
        while ((pos = tokenstring.find(delimiter, current_pos)) != string::npos) {
            tokens.push_back(tokenstring.substr(current_pos, pos - current_pos));
            current_pos = pos + 1;
        }
        tokens.push_back(tokenstring.substr(current_pos));
        return tokens;
    }
    /**
     * @brief 检查目标点是否存在
     * @param[in] data 目标名，地图名，
     * @param[out] data 目标的详细信息
     * @author wangyong 20231115
     * @return FaultCode
     */
    FaultCode TargetEffectivenessCheck(const string target_name,const string map_name,PointInfo &point)
    {
        // 加锁
        std::unique_lock<std::mutex> locker(share_data_mutex);

        //通过地图找到对应的路点容器，在通过marke标记查找具体的信息
        auto it = waypoint_list_.find(map_name);
        if(it != waypoint_list_.end()){

            locker.unlock();

            auto vt = it->second; 
            auto tt = vt.begin();
            while (tt != vt.end())
            {
                if((*tt).point_name == target_name){
                    point = (*tt);
                    return FaultCode::TRUE;
                }
                *tt++;
            }
        }
        if(debug_){
            //std::cout<<"share_data_TargetEffectivenessCheck没有找到"<<map_name<<":"<<target_name<<std::endl;
        }
        return FaultCode::U0414;
    }

    /**
    * @brief 控制导航的精度
    * @author wangyong 20231115
    * @return FaultCode
    */
    void AccurateControl(PoseData aim_point,std::string point_type);
private:
    void PublishVoice(std::string name);

    tf2_ros::Buffer tf_buffer_;
    tf2_ros::TransformListener tf_listener_;
    geometry_msgs::TransformStamped T_laser2base_,T_base2map_;

private slots:
    void Run();
};

#endif // SHARD_DATA_H
