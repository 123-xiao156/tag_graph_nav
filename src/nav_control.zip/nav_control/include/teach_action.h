#ifndef TEACH_ACTION_H
#define TEACH_ACTION_H

#include <QObject>
#include "shard_data.h"
#include <geometry_msgs/Pose2D.h>
#include <nav_msgs/Path.h>
#include <glog/logging.h>

class TeachAction:public QObject
{
    enum ProcessIndex{
        STEP0 = 0,
        STEP1,
        STEP2,
        STEP3,
        STEP4,
        STEP5,
        STEP6,
        STEP7,
        STEP8,
        STEP9,
        STEP10,
        STEP11,
        SEND_PATH,
        RUN,
        RESUME_PATH
    };
    Q_OBJECT
public:
    TeachAction(ros::NodeHandle nh);
    void Init();
    //void TimerThread(int16_t interval_ms);
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            // LOG(ERROR) <<"navtask_node;teach_action SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    bool FollowPath(const geometry_msgs::Pose2D &current_pose, CmdVelStr &cmd_vel);
    bool ListenTF(std::string target, std::string source, geometry_msgs::Pose2D &pose);
    void PublishVoice(const std::string& name);
    void MainLoop();
    bool thread_pause_flag_{true};//线程暂停执行，假暂停
    //bool is_pose(const PoseData &target_pose, const PoseData &Cur_pose);
    void SetCmd(std::string cmd_type,PoseData pdata);
    void SendRemainingPath();
private:
    ros::NodeHandle nh_;
    std::shared_ptr<ShardData> p_shard_data_; 
    int16_t interval_ms_;

    ros::ServiceClient clear_costmap_client_;//清除障碍层
    ros::Publisher pub_voice_;
    ros::Publisher io_data_all_pub_;

    double min_linear_velocity_ = 0.15;
    double max_linear_velocity_ = 0.8;
    double min_angular_velocity_ = 0.15;
    double max_angular_velocity_ = 1.0;

    tf::TransformListener tf_listener_;
    tf::StampedTransform transform_base_link_to_odom_;

    nav_msgs::Path global_path_;
    
    ProcessIndex process_index_{ProcessIndex::STEP0};

    std::string send_path_name_;
    bool first_flag_{false};
    void TimerThread(int16_t interval_ms);
    ros::ServiceClient srv_draw_path_;
    nav_msgs::Path send_path_;
    geometry_msgs::Pose2D current_pose_;
    CmdVelStr send_cmd_vel_;

    std::mutex mtx_;

    std::string path_map_name_;    // 地图名
    std::string path_only_name_;   // 路径名
    std::string tpath_task_;         // 新增：任务名
    std::vector<std::string> path_queue_;  // 路径队列
    size_t current_path_index_;            // 当前执行的路径索引
    bool multi_path_mode_;                 // 多路径模式标志
    bool SetNextPath();
    void HandleMultiPathError(const std::string& error_msg);
    void CompleteCurrentPath(bool success);
    
    void HandlePathError(const std::string& error_msg);
    //任务类
    std::string path_task_;
    // PoseData start_pose_;
    // PoseData end_pose_;
    // bool start_reached_ = false;
    // bool end_reached_ = false;
    //续扫
    bool need_resend_path_=false;
    bool is_resume_mode_=false;
    bool is_recovering_;
    bool need_resume_after_request_; 
    std::string cmd_type_;

    bool is_executing_teach_ = false;  // 是否正在执行示教路径

    std::string current_path_sub_type_;
    
signals:
    // TODO
    void signal_CmdVel(CmdVelStr data);
    void signal_MoveCmd(QVariant movecmd);
    void signal_PubStatus(std::string status);
    //void signal_ReqPeripheralCtrl(const std::string& cmd);//打开外设信号槽
private slots:
    void slot_NewCmd(QVariant movecmd);
};

#endif // TEACH_ACTION_H


