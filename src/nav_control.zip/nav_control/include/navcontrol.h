/*********************************************************************
*
* Software License Agreement (BSD License)
*
* Copyright（c） 2024 jiangsu Jitri Interlligent Manufacturing Technology 
* All rights reserved.
*
* brief:
* version: 1.0
* author: wangyong
* date:20240103
*********************************************************************/
#ifndef NAVCONTROL_H
#define NAVCONTROL_H
#include "shard_data.h"
constexpr int fault_true=FaultCode::TRUE;
#include "back_home.h"
#include "database_action.h"
#include "interface_action.h"
#include "normalpoint_action.h"
#include "move_action.h"
#include "cover_action.h"
#include "liftpoint_action.h"
#include "accesspoint_action.h"
#include "access_lift_shared.h"
#include "accurate_control.h"
#include "teach_action.h"
#include "cover_path_action.h"
#include <QThread>
#include <robot_msgs/Web.h>
#include <glog/logging.h>
#include <sys/stat.h>   
#include <sys/types.h>  

class NavControl:public QThread{
    enum Task_Index{
        TASK_IDLE,//任务空闲
        TASK_READY,//准备任务
        TASK_WAIT,//等待任务
        TASK_HANDOUT,//队列出点
        TASK_ACCESS,//闸机任务
        TASK_LIFT,//乘梯任务
        TASK_COVER,//覆盖任务
        TASK_NORMAL,//普通任务
        TASK_STOP,//停止任务
        TASK_BACK,//返回任务
        TASK_FAULT,//返回任务
        TASK_CANCEL,//返回任务
        TASK_PATH,//示教路径任务
        TASK_CPATH,//覆盖路径任务
        TASK_PATH_WAITING//等待路径执行完成
    };
    Q_OBJECT
public:
    NavControl(ros::NodeHandle nh);
    //数据共享
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "navtask_node:navcontrol SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    void Init();
    void PublishNavProgress(const std::string& data)
    {
        std_msgs::String msg;
        msg.data = data;
        pub_nav_progress_.publish(msg);
    };
    void CountNavProgress();
// public slots:
//     void slot_ReqPeripheralCtrl(const std::string& cmd);
private:
    bool running_flg_=false;
    ros::Publisher  pub_nav_progress_;//导航进度
    ros::Publisher  pub_error_;//电机错误码
    std::mutex robot_status_mutex_;
    std::mutex target_queue_mutex_;
    std_msgs::String robot_status_msg_;//执行状态"DEFAULT,running/free/success/failed[B0XXX],CANCEL,GOTO_路点名称"
    ros::Publisher pub_nav_status_;                //发布导航状态
    PointInfo now_send_point_info_;//现在导航的点的信息
    std::string now_send_path_info_;//现在示教路径的名称
    bool now_send_path_info_flag_{false};
    QTimer *init_timer_;//spin 计时器
    ros::NodeHandle nh_;
    //ros::Publisher io_data_all_pub_;
    std::shared_ptr<ShardData> p_shard_data_; //数据共享
    BackHome *p_back_home_;//回家类
    CoverAction *p_cover_action_;//覆盖区域类
    InterfaceAction *p_interface_action_;//接口类
    AccesspointAction *p_access_action_;//action通道
    LiftpointAction *p_lift_action_;//乘梯action
    NormalpointAction *p_normal_action_;//普通路点
    AccessLiftShared *p_access_lift_shared_;//门禁和乘梯共享类
    AccurateControl *p_accurate_control_shared_;//导航精确控制共享类
    DatabaseAction *p_database_action_;//数据库action
    MoveAction *p_move_action_;//移动action
    TeachAction *p_teach_action_;//路径action
    CoverPathAction* p_cover_path_action_;// 添加覆盖路径动作类
    std::queue<PointInfo> target_queue_;//目标队列
    float allarea_;//所有的清扫面积
    float cleanedarea_;//已经清扫面积
    float all_point_number_;//所有点的数量
    float exed_point_number_;//已经执行点的数量
    std::queue<PointInfo> stop_from_target_queue_;//普通停止目标队列
    std::queue<PointInfo> task_stop_from_target_queue_;//from停止目标队列
    Task_Index task_index_;//任务索引
    int16_t interval_ms_;//间隔时间
    ros::ServiceClient clear_costmap_client_;//刷新障碍层
    double robot_radius_=0.;
    double max_linear_velocity_=0.;
    std::chrono::high_resolution_clock::time_point task_starttime_;//任务开始计时
    void TaskControl();
    void ReqPeripheralCtrl(const std::string& cmd);//打开外设功能类
    // 20250529 c_add 三合一乘梯添加start/end点进行开关外设
    ros::ServiceClient clear_io_service_;
    bool autolift_{false};
    // 20250606 c_add 取消导航后，单独起线程延迟1秒失能电机
    ros::Publisher pub_motor_;
    NavProgress nav_progress_;//20251111导航进度
    bool cover_first_point_reached_ = false; // 标记是否已到达覆盖路径的第一个点
    std::string current_cover_path_name_;    // 当前覆盖路径名称
    std::string first_cover_point_name_;      // 覆盖路径第一个点的名称
    bool cover_first_point_processed_ = false; // 标记第一个点是否已处理
    std::string wash_status;        // 洗地状态
    std::string brush_status;       // 刷子状态  
    std::string mop_status;         // 拖布状态
    std::string saction_status;     // 吸尘状态
    std::string car_type_;
    bool path_processing_mode_;              // 是否正在处理路径
    std::string current_processing_path_type_; // 当前处理的路径类型
    tf::TransformListener tf_listener_;
    tf::StampedTransform transform_base_link_to_laser_link_,transform_base_link_to_map_;
    //路径面积计算类
    ros::ServiceClient srv_draw_cpath_;  // 用于获取覆盖路径和示教路径所有路点并计算面积的
    void SaveInterruptedPathInfo(const PointInfo& current_point);
    bool RestoreInterruptedPath();
    bool ListenTF(std::string target,std::string source,geometry_msgs::Pose2D& pose);
    bool RequestPathData(const std::string& map_name, const std::string& path_name, const std::string& path_type,PointInfo& point_info);
    double CalculateSinglePathLength(const std::vector<PoseData>& points);
    bool should_reset_cleanedarea_ = true;//用于跟踪是否需要重置总面积
    ros::Subscriber sub_io_status_;//io状态订阅
    // 当前有效的清扫半径（动态调整）
    double effective_robot_radius_;
    double wash_radius_;      // 洗地模式半径
    double brush_radius_;     // 扫地模式半径
    double mop_radius_;       // 尘推模式半径
    double saction_radius_;   // 吸尘模式半径
    double all_status_radius_;   // 四和一半径
    void ioStatusCallback(const std_msgs::String::ConstPtr& msg);//外设状态回调 
    struct PeripheralStatus {
        bool wash_open = false;
        bool brush_open = false;
        bool mop_open = false;
        bool saction_open = false;
    };
    
    PeripheralStatus peripheral_status_;
    
    void motorJstopCallback(const std_msgs::UInt16 &msg);
    
    // 急停状态标志
    int last_motor_jstop_state_ = 0; 
    ros::Subscriber sub_motorjstop_; 
    bool motorJstop =true;
    bool cancel_received_;
    bool if_use_estop_{false};//按下急停是否使用紧急停止
    private:
    // 获取当前经过的路径点ID（基于dis_to_end和车的位置）
    size_t GetCurrentPassedPointId(const PointInfo& point_info, double dis_to_end);
    // 获取当前经过的路径点ID（基于实时位置计算）
    size_t GetCurrentPassedPointIdByPose(const PointInfo& point_info);
    // 更新当前路径的经过点ID
    void UpdateCurrentPassedPointId();
    // 保存当前路径的暂停点ID
    void SavePausedPointId(const PointInfo& current_point, size_t passed_id);
    // 根据暂停的ID恢复剩余路径点
    std::vector<PoseData> GetRemainingPointsFromId(const PointInfo& point_info, size_t start_id);
    // 当前正在执行的路径的经过点ID记录
    size_t current_passed_point_id_;
    size_t last_passed_point_id_;  // 上一个记录的经过点ID
    bool has_current_passed_id_;

    // 补扫监控数据（每条覆盖路径独立）
    double last_valid_dis_to_end_ = -1;
    int consecutive_invalid_count_ = 0;
    bool is_in_obstacle_ = false;
    int obstacle_encounter_count_ = 0;
    
    // 补扫相关函数
    void MonitorCoverPathProgress();                                    // 监控覆盖路径进度
    void ResetCoverPathMonitor(const std::string& path_name);           // 重置监控状态
    void RecordMissedSegment(double start_dis, double end_dis);         // 记录漏扫路段
    int FindPathIdByRemainingDistance(double dis_to_end, 
                                       const std::vector<PoseData>& points);
    bool RequestPathDataWithIds(const std::string& map_name,
                                 const std::string& path_name,
                                 std::map<int, PoseData>& id_to_pose);
    void PrepareRescanForPath(const std::string& path_name, 
                              const std::string& path_map,
                              const std::vector<PoseData>& original_points);
    void InsertRescanTaskToQueue(const std::string& path_name);
    void ExecuteNextRescanIfNeeded();
    bool HasPendingRescan();
    void ClearRescanForPath(const std::string& path_name);

protected:
    void run();
signals:
    void signal_toAccessAction();
    void signal_toLiftAction();
    void signal_toCoverAction();
    void signal_toNormalAction();
    void signal_RequireArea();

    void signal_BackHome(QString msg);
    void signal_MoveCmd(QVariant movecmd); //发送API指令信号函数
private slots:
    void slot_NewCmd(const QVariant movecmd);
    void slot_RosRun();
    void slot_PubNavStatus(std::string status);
};
//模板工厂类
/*
 * 这是一个C++模板类的定义，名为ActionFactory，作为一个工厂类，用于创建和删除特定类型的动作（Action）对象。
 * 这个类的目的是提供一种通用的方法来创建和管理动作对象，而无需知道对象的具体类型。
 */
template<typename T>//声明了一个模板类，T是一个模板参数，表示ActionFactory类可以用于任何类型。
class ActionFactory{//开始定义ActionFactory类。
    private:
    //声明了一个私有构造函数。这是为了防止外部代码创建ActionFactory的实例，因为这个类旨在只通过它的静态成员函数来使用。
    ActionFactory();//action工厂
    //声明了一个私有析构函数。这同样是为了控制对象的生命周期，防止外部代码直接删除ActionFactory的实例。
    ~ActionFactory();
    public:
    //声明一个公开部分，这里的成员函数可以被任何有权限访问这个类的代码调用。
    //声明并实现了一个公开的静态成员函数CreateAction，它接收一个ros::NodeHandle参数（这在ROS（Robot Operating System）应用程序中用于节点通信管理）
    // 并返回一个指向T类型对象的指针。
    // 这个函数通过调用T类型的构造函数，动态分配一个新的T类型对象，并返回其指针。由于这个函数是模板化的，T可以是任何拥有接受ros::NodeHandle的构造函数的类型。
    static T* CreateAction(ros::NodeHandle nh){
        return new T(nh);
    };
    //另一个CreateAction重载版本，不接受任何参数，并返回一个新的T类型对象的指针。这适用于T类型的对象可以无参数构造的情况。
    static T* CreateAction(){
        return new T();
    };
    //声明并实现了一个静态成员函数DeletePtr，它接受一个指向T类型对象的指针并删除它。这个函数提供了一种管理通过ActionFactory创建的对象生命周期的方法，确保动态分配的内存被正确释放。
    static void DeletePtr(T* ptr){delete ptr;};
};
#endif