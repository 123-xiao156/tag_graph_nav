// cover_path_action.h
#ifndef COVER_PATH_ACTION_H
#define COVER_PATH_ACTION_H

#include <ros/ros.h>
#include <tf/transform_listener.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/Pose2D.h>
#include <robot_msgs/Web.h>
#include <glog/logging.h>
#include "shard_data.h"
#include "move_action.h"
#include <cstdio>

class CoverPathAction : public QObject
{
    Q_OBJECT
public:
    CoverPathAction(ros::NodeHandle nh);
    void Init();
    void SetCmd(std::string cmd_type, PoseData pdata);
    //bool is_pose(const PoseData &target_pose, const PoseData &Cur_pose);
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            //ROS_ERROR("ERROR;navtask_node;teach_action SetShardData receive nullptr");
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    
public slots:
    void slot_NewCmd(QVariant movecmd);
    
signals:
    void signal_MoveCmd(QVariant movecmd);
    void signal_CmdVel(CmdVelStr cmd_vel);
    void signal_PubStatus(std::string status);
    //void signal_ReqPeripheralCtrl(const std::string& cmd);//打开外设信号槽
    
private:
    void TimerThread(int16_t interval_ms);
    void MainLoop();
    void PublishVoice(const std::string &name);
    bool ListenTF(std::string target, std::string source, geometry_msgs::Pose2D &pose);
    bool FollowPath(const geometry_msgs::Pose2D &current_pose, CmdVelStr &cmd_vel);
    void SendRemainingPath();
    ros::NodeHandle nh_;
    tf::TransformListener tf_listener_;
    tf::StampedTransform transform_base_link_to_odom_;
    
    ros::ServiceClient srv_draw_cpath_;  // 覆盖路径服务
    ros::Publisher pub_voice_;
    ros::Publisher io_data_all_pub_;
    
    std::shared_ptr<ShardData> p_shard_data_;
    
    // 覆盖路径相关
    nav_msgs::Path send_path_;
    std::string send_cpath_name_;
    std::string cpath_map_name_;
    std::string cpath_only_name_;
    std::string cpath_task_;
    
    // 多路径支持
    std::vector<std::string> cpath_queue_;
    size_t current_cpath_index_ = 0;
    bool multi_cpath_mode_ = false;
    
    enum class ProcessIndex
    {
        STEP0,
        STEP1,       // 请求覆盖路径
        SEND_PATH,   // 发送路径
        RUN,          // 运行
        RESUME_PATH  //恢复路径运行
    };
    
    ProcessIndex process_index_ = ProcessIndex::STEP0;
    bool first_flag_ = false;
    bool thread_pause_flag_ = false;
    int16_t interval_ms_ = 100;
    
    // 控制参数
    double max_linear_velocity_ = 0.6;
    double min_linear_velocity_ = 0.1;
    double max_angular_velocity_ = 0.5;
    double min_angular_velocity_ = 0.05;
    
    std::mutex mtx_;
    
    //续扫
    bool need_resend_path_=false;
    bool is_resume_mode_=false;
    //路径起点终点相关参数
    // PoseData start_pose_;
    // PoseData end_pose_;
    // bool start_reached_ = false;
    // bool end_reached_ = false;
    bool is_recovering_;
    bool need_resume_after_request_; 
    
    std::string cmd_type_;

    bool is_executing_cover_ = false;  // 是否正在执行覆盖路径
};

#endif // COVER_PATH_ACTION_H