#ifndef MOVE_ACTION_H
#define MOVE_ACTION_H

#include <QObject>
#include "shard_data.h"
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <glog/logging.h>
// 20240511______________________________________y add
#include <QFile>
#include <QDir>
#include <QFileInfo>
#include <condition_variable>
#include <std_msgs/Bool.h>
#include <nlohmann/json.hpp>
#include <nav_msgs/GetPlan.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <std_msgs/UInt16.h>
#include "robot_msgs/TaskAction.h"
#include "robot_msgs/TaskService.h"
using json = nlohmann::json;
class BaseMoveAction:public QObject
{
    Q_OBJECT
public:
    //virtual ~BaseMoveAction() = 0;
};

class MoveAction:public BaseMoveAction
{
    enum MoveIndex{WAIT = 0,MOVE,STATUS,ESTOP,CANCEL,GOON};
    Q_OBJECT
public:
    MoveAction(ros::NodeHandle nh);
    ~MoveAction();
    void MainLoop();
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            LOG(ERROR) << "navtask_node;move_action SetShardData receive nullptr";
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> movebase_client_; //move_base客户端
private:
    ros::NodeHandle nh_;
    int16_t interval_ms_;
    ros::Subscriber sub_odom_;
    ros::Subscriber sub_currentmap_,sub_pose_;                //接收当前地图话题，获取当前地图信息
    ros::Publisher pub_fault_,pub_cmd_vel_,pub_nav_progress_,pub_cmd_sensor_;
    actionlib::SimpleActionClient<robot_msgs::TaskAction>* ac_client_;
    ros::ServiceClient task_client_;
    ros::Subscriber sub_nav_info_;
    ros::Publisher pub_nav_exception_;
    void TimerThread(int16_t interval_ms);
    MoveIndex move_index_=MoveIndex::WAIT;
    std::shared_ptr<ShardData> p_shard_data_;
    MoveDataCmd current_nav_cmd_;
    std::vector<PoseData> goal_;
    // 20240511______________________________________y add
    bool nav_exception_flag_;//导航异常
    int status;//导航异常种类
    QStringList baglist_;//存放bag数组
    std::condition_variable nav_exception_;
    std::mutex excep_nav_;
    int nav_=1;//导航算法
    std::string nav_node_="";//导航节点名称
    FaultCode MoveGoal(const std::vector<PoseData>& cmd_goal);
    bool isQuaternionValid(const geometry_msgs::Quaternion& q);

    void callback_RobotVel(const nav_msgs::Odometry::ConstPtr &msg);
    void callback_CurrentMap(const std_msgs::String::ConstPtr &msg);
    void PublishFaultCode(const std::string& data);
	void NavInfoCB(const std_msgs::UInt16ConstPtr &msg);
    void DoneCb(const actionlib::SimpleClientGoalState &state, const robot_msgs::TaskResultConstPtr &result);
    void ActiveCb();
    void FeedbackCb(const robot_msgs::TaskFeedbackConstPtr &feedback);
    void SendSingleGoal(const geometry_msgs::PoseStamped::ConstPtr &goal);
    void SendFixGoal(const geometry_msgs::PoseStamped::ConstPtr &goal);
    void SendCoverage(const nav_msgs::PathConstPtr &coverage_path);
    void SendFollowLine(const nav_msgs::PathConstPtr &line);
    void SendFixGoal(const nav_msgs::PathConstPtr &path);
    void SendFixGoalCover(const nav_msgs::PathConstPtr &path);
    void SetVehicleStatus(const std::string& new_status);
    // 20240506______________________________________y add
    ros::Subscriber sub_movebase_status_;
    void callback_movebase_status(const actionlib_msgs::GoalStatusArray::ConstPtr& msg);
    void WakeUpNavException()
    {
        nav_exception_.notify_one(); //唤醒导航异常录包线程
    }
    void PublishVelocity(CmdVelStr& data);


private slots:
    void slot_NewCmd(const QString cmd);//
    void slot_MoveCmd(QVariant movecmd);
    void slot_CmdVel(CmdVelStr data);
	void slot_StatusMsg(const QString msg,const int msg_type);
};

#endif // MOVE_ACTION_H
