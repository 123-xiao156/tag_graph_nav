#ifndef DATABASE_ACTION_H
#define DATABASE_ACTION_H
#include "shard_data.h"
#include "ros/ros.h"
#include <QObject>
#include <QThread>

class DatabaseAction:public QObject
{
    Q_OBJECT
public:
    DatabaseAction(ros::NodeHandle nh);
    FaultCode ReadMaplist(std::unordered_map<std::string,std::string> &maplist);
    FaultCode ReadAllWaypointList(const std::unordered_map<std::string,std::string> maplist,umap &waypointlist);
    //检查数据库是否存在该目标点，单张列表的路点名称需要唯一，整个数据库的地图名需要唯一
    FaultCode TargetEffectivenessCheck(const string target_name,const string map_name,umap &list,PointInfo &point);
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            //ROS_ERROR("ERROR;navtask_node;database_action SetShardData receive nullptr");
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
protected:
   //void run();
   private:
    ros::NodeHandle nh_;
    ros::ServiceClient db_client_;
    int16_t interval_ms_;
    std::shared_ptr<ShardData> p_shard_data_; 
    FaultCode ReadDataBase(ros::ServiceClient cs,DB_Type r_type,std::string r_data,std::string &data_content);
    FaultCode TableDataAnalysis(const std::string &data_content,std::unordered_map<std::string,std::string> &maplist);
    FaultCode WaypointDataAnalysis(const std::string &data_content,
        const std::string execl_name,const std::string map_name,std::unordered_map<std::string,std::vector<PointInfo>> &list);
    void TimerThread(int16_t interval_ms);
signals:
    // TODO
};

#endif // DATABASE_ACTION_H
