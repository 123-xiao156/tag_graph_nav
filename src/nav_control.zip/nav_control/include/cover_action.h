#ifndef COVER_ACTION_H
#define COVER_ACTION_H

#include <QObject>
#include <dynamic_reconfigure/server.h>
#include "nav_control/NavControlConfig.h"
#include "shard_data.h"
#include "cover_area/cover_area.hpp"
#include <condition_variable>
#include "cover_area/common.h"
#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <tf/transform_datatypes.h>
#include <geometry_msgs/Quaternion.h>
#include "message_filters/subscriber.h"
#include "tf2_ros/buffer.h"
#include "tf2_ros/message_filter.h"
#include "tf2/LinearMath/Transform.h"
#include "tf2/convert.h"
#include "tf2/utils.h"
#include "nav_msgs/Path.h"
#include <tf/transform_listener.h>
#include <ros/ros.h>
#include <std_msgs/String.h>
#include "mapping.h"
#include "coverage_planner.h"
#include <geometry_msgs/Pose2D.h>
#include <visualization_msgs/MarkerArray.h>
class CoverAction:public QObject
{
    Q_OBJECT
public:
    struct ParamsMap
    {
        unsigned int resolution;
        unsigned int x_size;
        unsigned int y_size;
    };
    struct Line
    {
        Point start;
        Point end;
    };
    // struct Vec2 {
    //     double x;
    //     double y;
    //     Vec2(double _x = 0, double _y = 0) : x(_x), y(_y) {}
    //     Vec2 operator+(const Vec2& other) const {
    //         return Vec2(x + other.x, y + other.y);
    //     }
    //     Vec2 operator-(const Vec2& other) const {
    //         return Vec2(x - other.x, y - other.y);
    //     }
    //     Vec2 operator/(double scalar) const {
    //         return Vec2(x / scalar, y / scalar);
    //     }
    //     double dot(const Vec2& other) const {
    //         return x * other.x + y * other.y;
    //     }
    //     double cross(const Vec2& other) const {
    //         return x * other.y - y * other.x;
    //     }
    //     double lengthSquared() const {
    //         return x * x + y * y;
    //     }
    //     double length() const {
    //         return sqrt(lengthSquared());
    //     }
    //     Vec2 normalize() const {
    //         double len = length();
    //         if (len > 0) {
    //             return Vec2(x / len, y / len);
    //         }
    //         return Vec2();  // 如果向量长度为0，返回零向量
    //     }
    // };
    // struct OBB {
    //     Vec2 center;
    //     Vec2 halfSize;
    //     Vec2 axisX;
    //     Vec2 axisY;
    // };
    struct Node {
        geometry_msgs::Pose2D pose;
        Node* prev;// 指向路径上前一个节点的指针，用于回溯构建路径
        //double cost;// 从起点到该节点的累积代价std::numeric_limits<double>::max()
        double g;  // 从起始节点到当前节点的实际代价
        double h;  // 启发式估计代价
        double f;  // 综合代价，f = g + h；//g(std::numeric_limits<double>::max())，f(std::numeric_limits<double>::max())，
        Node(const geometry_msgs::Pose2D& p) : pose(p), prev(nullptr), g(std::numeric_limits<double>::max()), h(0), f(std::numeric_limits<double>::max()) {}
    };
    // // 比较两个节点的代价，用于优先队列的排序
    struct CompareNodeCost {
        bool operator()(const Node* lhs, const Node* rhs) const {
            return lhs->f > rhs->f;
        }
    };
    enum EXECUTE_STATUS{SEND,RUN,FAILED,FINISHED,WAIT};
    CoverAction(ros::NodeHandle nh);
    ~CoverAction();
    void Init();
    void SetShardData(std::shared_ptr<ShardData> shard_data){
        // 20250821 c_add 判断指针非空
        if (nullptr == shard_data)
        {
            PublishLog("ERROR;navtask_node;cover_action SetShardData receive nullptr");
            return;
        }
        // 20250821 c_add 判断指针非空
        p_shard_data_ = shard_data;
    };
    void SetCmd(std::string cmd_type);
    void SetCmd(std::string cmd_type,std::vector<PoseData> &pdata);
    bool thread_pause_flag_{true};//线程暂停执行，假暂停
private:
    ros::NodeHandle nh_;
    ros::Publisher  pub_log_,pub_plan_,pub_nav_status_,pub_nav_progress_,pub_line_,cover_pub_,assist_point_pub_,
                    pub_costmap_,pub_aabb_path_;
    ros::Subscriber sub_pose_,sub_clicked_point_,sub_cmd_,scan_sub_,local_costmap_sub_,global_costmap_sub_;
    std::shared_ptr<ShardData> p_shard_data_;
    std::shared_ptr<CoverAreaClass> p_cov_area_=std::make_shared<CoverAreaClass>();
    int16_t interval_ms_;
    void TimerThread(int16_t interval_ms); 
    std::mutex mtx_;
    std::vector<PoseData> vec_cov_points_,path_;
    std::vector<Vec2d> vec_cover_;//给mapping的区域边界
    EXECUTE_STATUS execute_index_=WAIT;
    unsigned int path_index_=0;
    PoseData current_point_;
    bool use_dynamic_cover_;//使用动态覆盖
    Scan s;
    Scan* p_scan_=&s;//激光及当前位置指针
    bool flg_received_scan_;//激光帧接收到的标志
    std::condition_variable cv_mapping_;
    dynamic_reconfigure::Server<nav_control::NavControlConfig> config_server_;
    dynamic_reconfigure::Server<nav_control::NavControlConfig>::CallbackType cb_reconfigure_;
    std::shared_ptr<tf2_ros::Buffer> tf_;
    std::shared_ptr<tf2_ros::TransformListener> tfl_;
    message_filters::Subscriber<sensor_msgs::LaserScan>* sub_scan_;
    tf2_ros::MessageFilter<sensor_msgs::LaserScan>* scan_filter_;
    Pose robot_pose_;
    unsigned int interval_s_=100;//地图刷新间隔ms,
    bool start_map_=false;//开始建图的标志

    std::shared_ptr<mapping::Mapping2D> p_mapping_=std::make_shared<mapping::Mapping2D>();
    std::shared_ptr<CoveragePlanner> p_plan_=std::make_shared<CoveragePlanner>();
    std::chrono::steady_clock::time_point start_time_ = std::chrono::steady_clock::now(); // 记录开始时间
    unsigned int num_cover_=0;//所有区域数量
    Params params_;
    unsigned int mapping_index_=0;//建图点索引
    double totoal_areas_=0.;
    //覆盖路径20241127
    double max_linear_velocity_,max_angular_velocity_,min_linear_velocity_,min_angular_velocity_,max_acc_angular_,max_acc_linear_;
    geometry_msgs::Pose2D current_pose_,local_goal_;
    double footprint_radius_,robot_radius_,footprint_threshold_,forward_distance_;
    int obstacle_avoidave_method_;
    tf::TransformListener tf_listener_;
    tf::StampedTransform transform_base_link_to_laser_link_,transform_base_link_to_map_;
    std::vector<Point> point_cloud_;
    std::vector<Line> ref_line_;
    mutable std::mutex line_mutex_,path_mutex_;
    std::atomic<bool> taskCompleted_{true};
    nav_msgs::Path local_path_,cover_path_;
    nav_msgs::OccupancyGrid local_costmap_,global_costmap_;
    bool flg_collision_=false;
    bool use_camera_;
    bool result_makeplan_=false;
    bool play_finished_=true;
    std::string nav_node_="";//导航节点名称
    void Execute();
    void CalculateCoveragePath(std::vector<PoseData> &pdata);
    void PublishLog(const std::string& data)
    {
        std_msgs::String msg;
        msg.data = data;
        pub_log_.publish(msg);
    };
    void PublishPlan(const std::vector<PoseData> &path)
    {
        // create a message for the plan
        nav_msgs::Path gui_path;
        gui_path.poses.resize(path.size());
        gui_path.header.frame_id = "/map";
        gui_path.header.stamp = ros::Time::now();
        // Extract the plan in world co-ordinates, we assume the path is all in the same frame
        for (unsigned int i = 0; i < path.size(); i++)
        {
            gui_path.poses[i].pose.position.x = path[i].x;
            gui_path.poses[i].pose.position.y = path[i].y;
        }
        cover_pub_.publish(gui_path);
    }
    void ReconfigureCB(nav_control::NavControlConfig& config, uint32_t level);
    //void CountNavProgress();
    void CalculateMap();
    void MapThread(int duration);
    void AmclPoseCB(const geometry_msgs::PoseWithCovarianceStamped &msg);
    void ScanCB(const sensor_msgs::LaserScan::ConstPtr &msg);
    bool CheckIfMoved(Pose pos);
    void WakeUpMapping()
    {
        start_map_=true;
        cv_mapping_.notify_one(); // 唤醒建图线程
    };
    double CalculateArea(std::vector<PoseData> &pdata)
	{//只是四边形面积
	if(pdata.size()!=4) return 0;
		return fabs((pdata[1].x-pdata[0].x)*(pdata[2].y-pdata[0].y)-(pdata[2].x-pdata[0].x)*(pdata[1].y-pdata[0].y))/2
			+fabs((pdata[2].x-pdata[1].x)*(pdata[3].y-pdata[1].y)-(pdata[3].x-pdata[1].x)*(pdata[2].y-pdata[1].y))/2;
	};
    bool FollowCoverPath(CmdVelStr &cmd_vel);
    void checkFuture();
    nav_msgs::Path CoveragePath(std::vector<PoseData> &polygon);
    void ScanCallback(const sensor_msgs::LaserScan::ConstPtr &msg);
    void LaserScanToPoseList(const sensor_msgs::LaserScan::ConstPtr &scan_msg,std::vector<Point> &laser_points);
    void PublishLineMarker(std::vector<Line> &line);
    nav_msgs::Path GetLocalPath(const geometry_msgs::Pose2D &start, const geometry_msgs::Pose2D &goal,const double &dis);
    bool ListenTF(std::string target,std::string source,geometry_msgs::Pose2D& pose);
    void GlobalCostmapCallback(const nav_msgs::OccupancyGrid::ConstPtr &msg);
    void LocalCostmapCallback(const nav_msgs::OccupancyGrid::ConstPtr &msg);

    nav_msgs::OccupancyGrid OverlayRobotOnMap(const nav_msgs::OccupancyGrid& map, const geometry_msgs::Pose2D& pose, double radius);
    //std::vector<std::vector<Vec2>> ExtractObstacleVertices(const nav_msgs::OccupancyGrid& map);
    bool CheckObstacleIntersection(const geometry_msgs::Pose2D& robotPose, double robotRadius, const nav_msgs::OccupancyGrid& costmap);
    double distanceBetweenPoints(double x1, double y1, double x2, double y2) {
        return std::sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
    };
    bool MakePlan(const geometry_msgs::Pose2D& start, const geometry_msgs::Pose2D& goal, const nav_msgs::OccupancyGrid& costmap,nav_msgs::Path& path);
    bool IsPointInObstacle(const geometry_msgs::Pose2D& point, const nav_msgs::OccupancyGrid& costmap);
    bool CheckObstacleIntersection(const nav_msgs::Path& path, const nav_msgs::OccupancyGrid& costmap,std::vector<geometry_msgs::Pose2D>& intersection_point);
    bool IsCollision(const geometry_msgs::Pose2D& pose, const nav_msgs::OccupancyGrid& costmap);
    nav_msgs::Path SmoothPath(const nav_msgs::Path& path, int windowSize);
    geometry_msgs::Pose2D CalculateVector(const geometry_msgs::Point& p1, const geometry_msgs::Point& p2) {
        geometry_msgs::Pose2D v;
        v.x = p2.x - p1.x;
        v.y = p2.y - p1.y;
        return v;
    };
    double VectorLength(const geometry_msgs::Pose2D& v) {
    return std::sqrt(v.x * v.x + v.y * v.y);
    };
    double EstimateCurvature(const nav_msgs::Path& path_points);
    bool CheckCollision(const nav_msgs::OccupancyGrid& local_costmap,const nav_msgs::OccupancyGrid& global_costmap,nav_msgs::Path& path);
    void GetPlan();
    bool MakePlan();
    void PlayVoice();
    double Heuristic(const geometry_msgs::Pose2D& a, const geometry_msgs::Pose2D& b,const nav_msgs::OccupancyGrid& costmap) {
         double dx = std::abs(a.x - b.x);
         double dy = std::abs(a.y - b.y);
         //return dx + dy;  // 曼哈顿距离作为启发式估计
        //return sqrt(dx*dx+dy*dy);//欧几里得距离
        return sqrt(2)*std::min(dx,dy)+dx+dy;
        //double obstacleFactor = IsLineBlocked(a,b,costmap)?1.5:1; 
        //return (dx + dy)*obstacleFactor;
    };
    bool IsLineBlocked(geometry_msgs::Pose2D start, geometry_msgs::Pose2D end, const nav_msgs::OccupancyGrid& costmap) {
        double dx = end.x - start.x;
        double dy = end.y - start.y;
        double distance = std::sqrt((start.x - end.x) * (start.x - end.x) + (start.y - end.y) * (start.y - end.y));
        double stepX = dx / distance;
        double stepY = dy / distance;
        for (double t = 0; t < distance; t += costmap.info.resolution) {
            size_t x = std::round((start.x + t * stepX - costmap.info.origin.position.x) / costmap.info.resolution);
            size_t y = std::round((start.y + t * stepY - costmap.info.origin.position.y) / costmap.info.resolution);
            if (x >= 0 && x < costmap.info.width && y >= 0 && y < costmap.info.height && costmap.data[x*y] >0) {
                return true;
            }
        }
        return false;
    };
    bool IsGoalInCostmap(const geometry_msgs::Pose2D& goal, const nav_msgs::OccupancyGrid& costmap) {
        // 获取地图的宽度、高度以及分辨率等信息
        int width = costmap.info.width;
        int height = costmap.info.height;
        double resolution = costmap.info.resolution;
        double origin_x = costmap.info.origin.position.x;
        double origin_y = costmap.info.origin.position.y;

        // 计算目标点在地图坐标下对应的离散坐标（整数坐标）
        int goal_x_index = static_cast<int>((goal.x - origin_x) / resolution);
        int goal_y_index = static_cast<int>((goal.y - origin_y) / resolution);

        // 判断目标点的坐标是否在地图有效范围内（x和y坐标都在边界内）
        if (goal_x_index >= 0 && goal_x_index < width && goal_y_index >= 0 && goal_y_index < height) {
            return true;
        }
        return false;
    };
signals:
    void signal_StatusMsg(QString msg,int msg_type);
    void signal_MoveCmd(QVariant movecmd);
    void signal_CmdVel(CmdVelStr data);
    void signal_PubVoice(std::string data);
private slots:
    void slot_NewCmd(QVariant movecmd);
    void RequireArea();
};

#endif // COVER_ACTION_H
