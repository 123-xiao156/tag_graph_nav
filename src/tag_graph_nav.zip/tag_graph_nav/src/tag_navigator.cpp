#include "tag_graph_nav/tag_navigator.h"

namespace tag_graph_nav
{
TagNavigator::TagNavigator()
    : nh_(),
      private_nh_("~"),
      tf_listener_(ros::Duration(10.0))
{
  // 路网文件是启动导航器的必要条件，加载失败时保持未初始化状态。
  std::string route_file;
  private_nh_.param<std::string>("route_map_file", route_file, "");
  if (route_file.empty())
  {
    ROS_ERROR("Set ~route_map_file to a surveyed Tag route JSON file");
    return;
  }
  graph_.reset(new TagRouteGraph(route_file));
  if (!graph_->IsValid())
  {
    ROS_ERROR("Failed to load route map: %s", route_file.c_str());
    return;
  }

  // 读取定位、路径匹配和运动控制参数。
  private_nh_.param<std::string>("base_frame", base_frame_, "base_link");
  private_nh_.param("arrival_tolerance", arrival_tolerance_, 0.10);
  private_nh_.param("angle_tolerance", angle_tolerance_, 0.10);
  private_nh_.param("max_linear", max_linear_, 0.35);
  private_nh_.param("max_angular", max_angular_, 0.30);
  private_nh_.param("min_linear", min_linear_, 0.05);
  private_nh_.param("control_rate", control_rate_, 30.0);
  private_nh_.param("heading_kp", heading_kp_, 2.0);
  private_nh_.param("lateral_kp", lateral_kp_, 1.0);
  private_nh_.param("linear_kp", linear_kp_, 0.7);
  private_nh_.param("heading_hold", heading_hold_, 0.35);
  private_nh_.param("turn_angle_threshold", turn_angle_threshold_, 0.261799);
  private_nh_.param("node_snap_distance", node_snap_distance_, 0.10);
  private_nh_.param("edge_snap_distance", edge_snap_distance_, 0.40);
  private_nh_.param("max_tag_age", max_tag_age_, 0.5);
  private_nh_.param("max_lost_count", max_lost_count_, 15);
  private_nh_.param("navigation_timeout", navigation_timeout_, 60.0);

  if (!ValidateParameters())
  {
    return;
  }

  // 参数和路网全部有效后再建立ROS通信接口。
  cmd_vel_pub_ = nh_.advertise<geometry_msgs::Twist>("cmd_vel", 5);
  path_pub_ = private_nh_.advertise<nav_msgs::Path>("planned_path", 1, true);
  pose_pub_ = private_nh_.advertise<geometry_msgs::PoseStamped>("estimated_pose", 1);
  target_sub_ = nh_.subscribe("/target_tag_id", 1, &TagNavigator::TargetCallback, this);
  initialized_ = true;
  ROS_INFO("Loaded %zu Tags and %zu directed edges in %s", graph_->Nodes().size(), graph_->Edges().size(), graph_->FrameId().c_str());
}
void TagNavigator::Run()
{
  if (!initialized_)
  {
    ROS_ERROR("TagNavigator is not initialized");
    return;
  }
  ROS_INFO("Waiting for a target on /target_tag_id");
  ros::Rate rate(10.0);
  while (ros::ok())
  {
    int target = -1;
    {
      // 回调线程只写入目标，导航任务始终由当前线程串行执行。
      std::lock_guard<std::mutex> lock(state_mutex_);
      if (target_received_)
      {
        target = target_tag_;
        target_received_ = false;
      }
    }
    if (target >= 0)
    {
      StartNavigation(target);
    }
    rate.sleep();
  }
}
bool TagNavigator::ValidateParameters() const
{
  if (arrival_tolerance_ < 0.0 || angle_tolerance_ < 0.0 ||
      max_linear_ <= 0.0 || max_angular_ <= 0.0 || min_linear_ < 0.0 ||
      min_linear_ > max_linear_ || control_rate_ <= 0.0 ||
      !std::isfinite(turn_angle_threshold_) || turn_angle_threshold_ < 0.0 || turn_angle_threshold_ > M_PI ||
      node_snap_distance_ < 0.0 || edge_snap_distance_ < 0.0 ||
      max_tag_age_ <= 0.0 || max_lost_count_ < 0 || navigation_timeout_ <= 0.0)
  {
    ROS_ERROR("Invalid navigation parameter value");
    return false;
  }
  return true;
}
void TagNavigator::TargetCallback(const std_msgs::Int32::ConstPtr &message)
{
  const auto node = graph_->Nodes().find(message->data);
  if (node == graph_->Nodes().end())
  {
    ROS_WARN("Target tag_%d is not in the route map", message->data);
    return;
  }
  if (!node->second.targetable)
  {
    ROS_WARN("Target tag_%d is localization-only", message->data);
    return;
  }
  {
    std::lock_guard<std::mutex> lock(state_mutex_);
    target_tag_ = message->data;
    target_received_ = true;
  }
  ROS_INFO("Target tag_%d received", message->data);
}
bool TagNavigator::TagTransformIsFresh(const std::string &tag_frame) const
{
  try
  {
    ros::Time stamp;
    std::string error;
    // 采用两坐标系最新的共同时间，避免使用过期的Tag观测。
    tf_listener_.getLatestCommonTime(base_frame_, tag_frame, stamp, &error);
    const double age = (ros::Time::now() - stamp).toSec();
    return stamp.toSec() > 0.0 && age >= 0.0 && age <= max_tag_age_;
  }
  catch (const tf::TransformException &error)
  {
    ROS_DEBUG_THROTTLE(2.0, "Cannot query fresh TF %s <-> %s: %s", base_frame_.c_str(), tag_frame.c_str(), error.what());
    return false;
  }
}
bool TagNavigator::GetRobotPose(Pose2D &robot_pose) const
{
  struct Observation
  {
    double distance;
    int tag_id;
    Pose2D pose;
  };
  std::vector<Observation> observations;

  // 分别利用每个当前可见的Tag估计机器人在路网坐标系中的位姿。
  for (const auto &item : graph_->Nodes())
  {
    const int tag_id = item.first;
    const std::string tag_frame = "tag_" + std::to_string(tag_id);
    if (!TagTransformIsFresh(tag_frame))
    {
      continue;
    }
    try
    {
      tf::StampedTransform tag_in_base;
      tf::StampedTransform base_in_tag;
      // tag_in_base用于比较观测距离，base_in_tag用于计算机器人全局位姿。
      tf_listener_.lookupTransform(base_frame_, tag_frame, ros::Time(0), tag_in_base);
      tf_listener_.lookupTransform(tag_frame, base_frame_, ros::Time(0), base_in_tag);

      // 将Tag坐标系中的机器人位姿变换到路网坐标系。
      const Pose2D &tag_pose = item.second.tag_pose;
      const double relative_x = base_in_tag.getOrigin().x();
      const double relative_y = base_in_tag.getOrigin().y();
      const double relative_yaw = tf::getYaw(base_in_tag.getRotation());
      const Pose2D pose{
          tag_pose.x + std::cos(tag_pose.yaw) * relative_x - std::sin(tag_pose.yaw) * relative_y,
          tag_pose.y + std::sin(tag_pose.yaw) * relative_x + std::cos(tag_pose.yaw) * relative_y,
          TagRouteGraph::AngleError(tag_pose.yaw + relative_yaw, 0.0)};
      observations.push_back(Observation{std::hypot(tag_in_base.getOrigin().x(), tag_in_base.getOrigin().y()), tag_id, pose});
    }
    catch (const tf::TransformException &error)
    {
      ROS_DEBUG_THROTTLE(2.0, "Cannot transform with %s: %s", tag_frame.c_str(), error.what());
      continue;
    }
  }

  if (observations.empty())
  {
    return false;
  }
  // 多个Tag同时可见时选择距离最近的观测，减少远距离测量误差。
  const Observation &best = *std::min_element(
      observations.begin(), observations.end(),
      [](const Observation &a, const Observation &b)
      {
        return std::tie(a.distance, a.tag_id) < std::tie(b.distance, b.tag_id);
      });
  robot_pose = best.pose;
  pose_pub_.publish(ToPoseStamped(best.pose));
  ROS_INFO_THROTTLE(2.0, "Robot localized from tag_%d: x=%.2f y=%.2f yaw=%.2f", best.tag_id, best.pose.x, best.pose.y, best.pose.yaw);
  return true;
}
geometry_msgs::PoseStamped TagNavigator::ToPoseStamped(const Pose2D &pose) const
{
  geometry_msgs::PoseStamped message;
  message.header.frame_id = graph_->FrameId();
  message.header.stamp = ros::Time::now();
  message.pose.position.x = pose.x;
  message.pose.position.y = pose.y;
  message.pose.orientation = tf::createQuaternionMsgFromYaw(pose.yaw);
  return message;
}
void TagNavigator::PublishPath(const Pose2D &robot_pose, const Pose2D &target_pose, double path_yaw) const
{
  nav_msgs::Path path;
  path.header.frame_id = graph_->FrameId();
  path.header.stamp = ros::Time::now();
  const double tangent_x = std::cos(path_yaw);
  const double tangent_y = std::sin(path_yaw);
  const double along = (robot_pose.x - target_pose.x) * tangent_x + (robot_pose.y - target_pose.y) * tangent_y;
  // 规划路径从机器人在线上的投影点开始，并直接连接最终目标点。
  path.poses.push_back(ToPoseStamped(Pose2D{target_pose.x + along * tangent_x, target_pose.y + along * tangent_y, path_yaw}));
  path.poses.push_back(ToPoseStamped(Pose2D{target_pose.x, target_pose.y, path_yaw}));
  path_pub_.publish(path);
}
void TagNavigator::StopRobot() const
{
  cmd_vel_pub_.publish(geometry_msgs::Twist());
}
bool TagNavigator::FollowLine(const Pose2D &target_pose, double path_yaw, const RouteEdge &route_settings, const ros::Time &started_at) const
{
  ros::Rate rate(control_rate_);
  int lost_count = 0;
  const double direction = route_settings.motion == "forward" ? 1.0 : -1.0;
  const double speed_limit = std::min(max_linear_, route_settings.speed_limit);
  // 倒车时机器人朝向与路径方向相差pi，但速度沿路径反方向输出。
  const double body_yaw = direction > 0.0 ? path_yaw : path_yaw + M_PI;

  while (ros::ok() && navigating_)
  {
    if ((ros::Time::now() - started_at).toSec() > navigation_timeout_)
    {
      ROS_ERROR("Tag route navigation timed out");
      StopRobot();
      return false;
    }

    Pose2D pose;
    if (!GetRobotPose(pose))
    {
      // 短时丢失定位立即停车，连续丢失超过阈值后终止本次导航。
      ++lost_count;
      StopRobot();
      if (lost_count > max_lost_count_)
      {
        ROS_ERROR("Lost all fresh Tag observations");
        return false;
      }
      rate.sleep();
      continue;
    }
    lost_count = 0;

    const double dx = target_pose.x - pose.x;
    const double dy = target_pose.y - pose.y;
    const double distance = std::hypot(dx, dy);
    double linear_command = 0.0;
    double angular_command = 0.0;
    if (distance <= arrival_tolerance_)
    {
      // 到达目标位置后只校正最终朝向。
      const double yaw_error = TagRouteGraph::AngleError(body_yaw, pose.yaw);
      if (std::abs(yaw_error) <= angle_tolerance_)
      {
        StopRobot();
        return true;
      }
      angular_command = heading_kp_ * yaw_error;
    }
    else
    {
      // 航向误差和横向误差共同生成角速度；朝向偏差过大时不输出线速度。
      const double heading_error = TagRouteGraph::AngleError(body_yaw, pose.yaw);
      const double lateral_error = -std::sin(path_yaw) * (pose.x - target_pose.x) + std::cos(path_yaw) * (pose.y - target_pose.y);
      angular_command = heading_kp_ * heading_error - lateral_kp_ * lateral_error;
      if (std::abs(heading_error) <= heading_hold_)
      {
        linear_command = direction * std::min(speed_limit, std::max(min_linear_, linear_kp_ * distance));
      }
    }

    geometry_msgs::Twist command;
    command.linear.x = linear_command;
    command.angular.z = std::max(-max_angular_, std::min(max_angular_, angular_command));
    cmd_vel_pub_.publish(command);
    ROS_INFO_THROTTLE(1.0, "Line tracking: distance=%.3f v=%.3f w=%.3f", distance, command.linear.x, command.angular.z);
    rate.sleep();
  }
  StopRobot();
  return false;
}
void TagNavigator::StartNavigation(int target_id)
{
  // 原子置位可防止同一时刻启动多个导航任务。
  if (navigating_.exchange(true))
  {
    ROS_WARN("Already navigating");
    return;
  }
  const ros::Time started_at = ros::Time::now();
  bool success = false;
  Pose2D robot_pose;
  if (!GetRobotPose(robot_pose))
  {
    ROS_ERROR("No fresh visible Tag for initial localization");
  }
  else
  {
    // 将机器人当前位置匹配到有向路网，并规划到目标Tag的边序列。
    std::vector<EdgeKey> route;
    if (!graph_->PlanFromPose(robot_pose, target_id, node_snap_distance_, edge_snap_distance_, route))
    {
      ROS_ERROR("No directed path to tag_%d from current position", target_id);
    }
    else
    {
      std::ostringstream route_text;
      for (std::size_t index = 0; index < route.size(); ++index)
      {
        if (index != 0U)
        {
          route_text << " -> ";
        }
        route_text << route[index].first << ":" << route[index].second;
      }
      ROS_INFO("Directed route: %s", route.empty() ? "at target node" : route_text.str().c_str());

      std::vector<std::vector<EdgeKey>> sections;
      if (!graph_->SplitRouteAtTurns(route, turn_angle_threshold_, sections))
      {
        ROS_ERROR("Cannot split directed route to tag_%d", target_id);
      }
      else if (sections.empty())
      {
        const Pose2D target_pose = graph_->TagTargetPose(target_id);
        RouteEdge route_settings;
        route_settings.motion = "forward";
        route_settings.speed_limit = max_linear_;
        PublishPath(robot_pose, target_pose, target_pose.yaw);
        success = FollowLine(target_pose, target_pose.yaw, route_settings, started_at);
      }
      else
      {
        success = true;
        for (std::size_t section_index = 0; section_index < sections.size(); ++section_index)
        {
          const std::vector<EdgeKey> &section = sections[section_index];
          const int section_goal_id = section.back().second;
          const Pose2D section_goal = graph_->TagTargetPose(section_goal_id);
          const double path_yaw = graph_->RouteLineYaw(section);
          RouteEdge route_settings = graph_->Edges().at(section.front());
          for (const EdgeKey &key : section)
          {
            route_settings.speed_limit = std::min(route_settings.speed_limit, graph_->Edges().at(key).speed_limit);
          }

          ROS_INFO("Straight section %zu/%zu ends at tag_%d", section_index + 1U, sections.size(), section_goal_id);
          PublishPath(robot_pose, section_goal, path_yaw);
          if (!FollowLine(section_goal, path_yaw, route_settings, started_at))
          {
            success = false;
            break;
          }
          robot_pose = section_goal;
          if (section_index + 1U < sections.size())
          {
            ROS_INFO("Turning at tag_%d", section_goal_id);
          }
        }
      }
    }
  }

  navigating_ = false;
  StopRobot();
  ROS_INFO("Navigation %s: tag_%d", success ? "finished" : "failed", target_id);
}
} // namespace tag_graph_nav
